# ** I am no longer supporting this addon **



![Gi logo](https://i.imgur.com/g0iJMJk.jpg# )

This is a multi-purpose addon that tracks your currently equipped gear and buffs to display valuable information.

![Imgur](https://i.imgur.com/L27g5JD.png)  
The addon can be used in conjunction with Gearswap to facilitate gear swapping.

Please check out the [the wiki](https://github.com/sebyg666/GearInfo/wiki) for all the information you'll need to get you started.
