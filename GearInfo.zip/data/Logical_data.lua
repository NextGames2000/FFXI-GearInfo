return {
    [1]={
        ["discription"]="Dispense: Angelwing", 
        ["en"]="Redeyes", 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=16120, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [2]={
        ["discription"]="DEF:4 +2 +2 Fishing skill +1 Reduces chances of fishing up items ", 
        ["DEF"]=4, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Fisherman's Smock", 
        ["id"]=11337, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [3]={
        ["discription"]="Enchantment: Increases skill at tiring fish", 
        ["en"]="Penguin Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15556, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [4]={
        ["discription"]="DEF:16 Monster correlation effects +10 \"Efflux\" TP bonus +250", 
        ["category"]="Armor", 
        ["en"]="Rosmerta's Cape", 
        ["Magic Atk. Bonus"]=10, 
        ["augments"]={
            [1]="INT+10", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="Magic Damage +10", 
            [4]="\"Mag.Atk.Bns.\"+10", 
            [5]="none"
        }, 
        ["INT"]=10, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [16]="BLU"
        }, 
        ["id"]=26261, 
        ["DEF"]=16, 
        ["Magic Accuracy"]=20
    }, 
    [5]={
        ["discription"]="Fishing support: Reduces fish stamina recovery", 
        ["en"]="Heron Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15846, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [6]={
        ["discription"]="DEF:1  Fishing skill +1", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Fsh. Gloves", 
        ["id"]=14070, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [7]={
        ["discription"]="DEF:1 +2 +2", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Fisherman's Cuffs", 
        ["id"]=15051, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [8]={
        ["discription"]="A legendary fishing rod believed to  have caught a sea dragon. ", 
        ["skill"]="Fishing", 
        ["slots"]={
            [2]="Range"
        }, 
        ["id"]=17386, 
        ["en"]="Lu Shang's F. Rod", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [9]={
        ["discription"]="DEF:1 Fishing skill +1", 
        ["DEF"]=1, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Fisherman's Hose", 
        ["id"]=14292, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [10]={
        ["discription"]="DEF:2 +1 Fishing skill +2", 
        ["DEF"]=2, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Waders", 
        ["id"]=14195, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [11]={
        ["discription"]="Enchantment: Increases stamina while fishing", 
        ["en"]="Albatross Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15555, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [12]={
        ["discription"]="Fishing skill +2", 
        ["en"]="Fisher's Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=10925, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [13]={
        ["discription"]="A small cephalopod with a characteristic pointed shell. Bait.", 
        ["skill"]="Fishing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=17006, 
        ["en"]="Drill Calamary", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [14]={
        ["jobs"]={
            [16]="BLU"
        }, 
        ["DEX"]=5, 
        ["MND"]=5, 
        ["INT"]=5, 
        ["category"]="Armor", 
        ["Magic Atk. Bonus"]=15, 
        ["en"]="Cornflower Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["Blue Magic skill"]=10, 
        ["DEF"]=16, 
        ["discription"]="DEF:16 STR+5 INT+5 MND+5 Magic Accuracy+15 \"Magic Atk. Bonus\"+15 Blue magic skill +5", 
        ["STR"]=5, 
        ["id"]=28632, 
        ["augments"]={
            [1]="MP+20", 
            [2]="DEX+5", 
            [3]="Blue Magic skill +10", 
            [4]="none", 
            [5]="none"
        }, 
        ["MP"]=20, 
        ["Magic Accuracy"]=15
    }, 
    [15]={
        ["discription"]="An extremely rare species of tiny pugil. Bait.", 
        ["skill"]="Fishing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=17007, 
        ["en"]="Dwarf Pugil", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [16]={
        ["discription"]="Angler's Discernment +1", 
        ["en"]="Fisher's Rope", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=11768, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [17]={
        ["discription"]="A legendary fishing rod that appears in Far Eastern mythology.", 
        ["skill"]="Fishing", 
        ["slots"]={
            [2]="Range"
        }, 
        ["id"]=17011, 
        ["en"]="Ebisu Fishing Rod", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [18]={
        ["discription"]="Fishing skill (journeyman and above): Increases chances of fishing up large prey. ", 
        ["en"]="Puffin Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=11654, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [19]={
        ["discription"]="Fishing skill (artisan and above): Reduces chances of fishing up monsters.", 
        ["en"]="Noddy Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=11655, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [20]={
        ["discription"]="Fishing support: Increases fish stamina reduction", 
        ["en"]="Seagull Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15845, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [21]={
        ["discription"]="STR+2～5 DEX+2～5 \"Store TP\"+5 \"Subtle Blow\"+5", 
        ["en"]="Rajas Ring", 
        ["Store TP"]=5, 
        ["DEX"]=2, 
        ["category"]="Armor", 
        ["STR"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15543, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }
    }, 
    [22]={
        ["discription"]="DEF:28 Fellow: HP+10 MP+10 INT+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["INT"]=2, 
        ["category"]="Armor", 
        ["en"]="Hydra Cap", 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15263, 
        ["DEF"]=28, 
        ["MP"]=10, 
        ["HP"]=10
    }, 
    [23]={
        ["discription"]="DEF:1", 
        ["CHR"]=1, 
        ["category"]="Armor", 
        ["en"]="Mecisto. Mantle", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=6, 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="Cap. Point+50%", 
            [2]="CHR+1", 
            [3]="DEF+5", 
            [4]="none", 
            [5]="none"
        }, 
        ["id"]=27596
    }, 
    [24]={
        ["discription"]="Capacity point bonus: +200% Maximum duration: 720 minutes Maximum bonus: 30000", 
        ["en"]="Endorsement Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28469, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [25]={
        ["discription"]="DEF:35 Fellow: HP+10 MP+10 STR+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hydra Hose", 
        ["HP"]=10, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15598, 
        ["DEF"]=35, 
        ["MP"]=10, 
        ["STR"]=2
    }, 
    [26]={
        ["discription"]="DEF:20 Fellow: HP+10 MP+10 DEX+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hydra Bracers", 
        ["HP"]=10, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=14927, 
        ["DEF"]=20, 
        ["MP"]=10, 
        ["DEX"]=2
    }, 
    [27]={
        ["discription"]="Reives: Damage taken -8% Auto-Reraise", 
        ["en"]="Adoulin's Refuge +1", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=28367, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["DT"]=-8
    }, 
    [28]={
        ["discription"]="Enchantment: Fishy Intuition", 
        ["en"]="Duck Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28570, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [29]={
        ["discription"]="Accuracy+4 Attack+4 Assault: STR+4 DEX+4 Adds \"Regen\" effect", 
        ["category"]="Armor", 
        ["en"]="Ulthalam's Ring", 
        ["STR"]=4, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15808, 
        ["DEX"]=4, 
        ["Accuracy"]=4, 
        ["Attack"]=4
    }, 
    [30]={
        ["discription"]="DEF:42 Fellow: HP+20 MP+20 VIT+2 ", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hydra Jupon", 
        ["HP"]=20, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=14518, 
        ["DEF"]=42, 
        ["MP"]=20, 
        ["VIT"]=2
    }, 
    [31]={
        ["discription"]="Experience point bonus: +100% Maximum duration: 720 min. Maximum bonus: 12000", 
        ["en"]="Duodec. Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28562, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [32]={
        ["discription"]="Slightly enhances chocobo digging skill", 
        ["en"]="Chocobo Rope", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=11767, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [33]={
        ["discription"]="Accuracy+20 Magic Accuracy+20 \"Triple Attack\" damage +4", 
        ["category"]="Armor", 
        ["en"]="Asn. Gorget +1", 
        ["id"]=25448, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=20, 
        ["Magic Accuracy"]=20
    }, 
    [34]={
        ["Evasion"]=41, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=39, 
        ["DEF"]=97, 
        ["MND"]=26, 
        ["id"]=27140, 
        ["Ranged Accuracy"]=12, 
        ["en"]="Herculean Gloves", 
        ["AGI"]=8, 
        ["HP"]=20, 
        ["augments"]={
            [1]="Accuracy+10", 
            [2]="Weapon skill damage +5%", 
            [3]="Attack+10", 
            [4]="none", 
            [5]="none"
        }, 
        ["VIT"]=30, 
        ["INT"]=14, 
        ["STR"]=16, 
        ["Haste"]=5, 
        ["Accuracy"]=22, 
        ["CHR"]=19, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["discription"]="DEF:97 HP+20 STR+16 DEX+39 VIT+30 AGI+8 INT+14 MND+26 CHR+19 Accuracy+12 Ranged Accuracy+12 Evasion+41 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+2% \"Subtle Blow\"+5 Physical damage taken -2%", 
        ["Attack"]=10
    }, 
    [35]={
        ["discription"]="DMG:345 Delay:492 Magic Damage+155 Polearm skill +269 Parrying skill +269 Magic Accuracy skill +228 \"Store TP\"+10 \"TP Bonus\"+500 \"Stardiver\" Aftermath: Increases skillchain potency Increases magic burst potency Ultimate Skillchain", 
        ["item_level"]=119, 
        ["id"]=20935, 
        ["category"]="Weapon", 
        ["Store TP"]=10, 
        ["en"]="Trishula", 
        ["delay"]=492, 
        ["skill"]="Polearm", 
        ["slots"]={
            [0]="Main"
        }, 
        ["Polearm skill"]=269, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["Parrying skill"]=269, 
        ["damage"]=345
    }, 
    [36]={
        ["discription"]="Enchantment: Warp", 
        ["en"]="Warp Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28540, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [37]={
        ["discription"]="DEF:15 Avatar: Lv.+1 \"Blood Pact\" damage +5", 
        ["category"]="Armor", 
        ["Attack"]=20, 
        ["en"]="Campestres's Cape", 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="Accuracy+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEF"]=15, 
        ["DEX"]=20, 
        ["Accuracy"]=30, 
        ["id"]=26260, 
        ["DT"]=-5
    }, 
    [38]={
        ["discription"]="DMG:144 Delay:216 MP+40 INT+15 MND+15 Accuracy+40 Magic Accuracy+40 \"Magic Atk. Bonus\"+35 Magic Damage+248 Club skill +242 Parrying skill +242 Magic Accuracy skill +255 Magic burst damage +10 \"Cure\" potency +30%", 
        ["MND"]=15, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=22041, 
        ["item_level"]=119, 
        ["en"]="Bunzi's Rod", 
        ["Club skill"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=216, 
        ["Accuracy"]=40, 
        ["damage"]=144, 
        ["skill"]="Club", 
        ["MP"]=40, 
        ["Parrying skill"]=242, 
        ["INT"]=15, 
        ["Magic Atk. Bonus"]=35, 
        ["category"]="Weapon", 
        ["Magic Accuracy"]=40
    }, 
    [39]={
        ["Evasion"]=39, 
        ["MND"]=28, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Perfect Dodge\" effect", 
            [4]="none"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEX"]=33, 
        ["DEF"]=90, 
        ["AGI"]=3, 
        ["STR"]=9, 
        ["item_level"]=119, 
        ["HP"]=25, 
        ["en"]="Plun. Armlets +1", 
        ["Accuracy"]=15, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=5, 
        ["id"]=26987, 
        ["INT"]=10, 
        ["category"]="Armor", 
        ["CHR"]=24, 
        ["VIT"]=30, 
        ["discription"]="DEF:90 HP+25 STR+9 DEX+33 VIT+30 AGI+3 INT+10 MND+28 CHR+24 Accuracy+15 Evasion+39 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+5% Enmity+6 \"Treasure Hunter\"+3"
    }, 
    [40]={
        ["discription"]="Enchantment: Teleport (Crag of Dem) Destination is close to the dimensional portal in Konschtat Highlands.", 
        ["en"]="Dim. Ring (Dem)", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26177, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [41]={
        ["Ranged Attack"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["AGI"]=51, 
        ["DEX"]=24, 
        ["Haste"]=4, 
        ["augments"]={
            [1]="Attack+9", 
            [2]="Weapon skill damage +5%", 
            [3]="AGI+8", 
            [4]="Accuracy+13", 
            [5]="none"
        }, 
        ["MND"]=11, 
        ["discription"]="DEF:79 HP+9 STR+16 DEX+24 VIT+10 AGI+43 MND+11 CHR+26 Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+5 Evasion+80 Magic Evasion+75 Haste+4% \"Triple Attack\"+2 \"Subtle Blow\"+6 Physical damage taken -2%", 
        ["Ranged Accuracy"]=10, 
        ["en"]="Herculean Boots", 
        ["item_level"]=119, 
        ["HP"]=9, 
        ["Accuracy"]=23, 
        ["id"]=27496, 
        ["CHR"]=26, 
        ["category"]="Armor", 
        ["STR"]=16, 
        ["DEF"]=79, 
        ["Evasion"]=80, 
        ["Magic Accuracy"]=10, 
        ["VIT"]=10, 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["PDT"]=-2, 
        ["Attack"]=19
    }, 
    [42]={
        ["discription"]="DEF:73 HP+15 STR+12 DEX+24 VIT+12 AGI+44 MND+12 CHR+30 Evasion+107 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+4% \"Treasure Hunter\"+3 \"Despoil\" effect +6 Set: Augments \"Triple Attack\"", 
        ["MND"]=12, 
        ["Set Bonus"]={
            ["set id"]=65, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["Haste"]=4, 
        ["AGI"]=44, 
        ["STR"]=12, 
        ["item_level"]=119, 
        ["HP"]=15, 
        ["DEX"]=24, 
        ["id"]=27422, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=73, 
        ["en"]="Skulk. Poulaines +1", 
        ["CHR"]=30, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["Evasion"]=107
    }, 
    [43]={
        ["HP"]=40, 
        ["Ranged Accuracy"]=21, 
        ["Throwing skill"]=242, 
        ["slots"]={
            [2]="Range"
        }, 
        ["category"]="Weapon", 
        ["discription"]="DMG:71 Delay:252 HP+40 MP+40 +16 +16 Ranged Accuracy+21 Ranged Attack+21 Throwing skill +242 Unity Ranking: \"Double Attack\"+1～3%", 
        ["en"]="Antitail +1", 
        ["delay"]=252, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [11]="RNG"
        }, 
        ["item_level"]=119, 
        ["Ranged Attack"]=21, 
        ["skill"]="Throwing", 
        ["id"]=22267, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["MP"]=40, 
        ["damage"]=71
    }, 
    [44]={
        ["Evasion"]=49, 
        ["DEF"]=132, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEX"]=36, 
        ["Critical hit rate"]=4, 
        ["MND"]=23, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Ambush\" effect", 
            [4]="none"
        }, 
        ["slots"]={
            [5]="Body"
        }, 
        ["item_level"]=119, 
        ["AGI"]=35, 
        ["HP"]=59, 
        ["id"]=26811, 
        ["Critical hit damage"]=3, 
        ["STR"]=31, 
        ["Haste"]=4, 
        ["MP"]=44, 
        ["en"]="Plunderer's Vest +1", 
        ["INT"]=23, 
        ["category"]="Armor", 
        ["CHR"]=23, 
        ["VIT"]=24, 
        ["discription"]="DEF:132 HP+59 MP+44 STR+31 DEX+36 VIT+24 AGI+35 INT+23 MND+23 CHR+23 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+4% Enmity+7 Critical hit rate +4% Critical hit damage +3%"
    }, 
    [45]={
        ["Evasion"]=60, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEX"]=34, 
        ["DEF"]=133, 
        ["augments"]={
            [1]="Weapon skill damage +5%", 
            [2]="STR+9", 
            [3]="Attack+13", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=20, 
        ["id"]=25718, 
        ["Ranged Accuracy"]=15, 
        ["Store TP"]=3, 
        ["item_level"]=119, 
        ["HP"]=61, 
        ["Accuracy"]=15, 
        ["en"]="Herculean Vest", 
        ["INT"]=21, 
        ["STR"]=37, 
        ["Haste"]=4, 
        ["AGI"]=30, 
        ["CHR"]=21, 
        ["discription"]="DEF:133 HP+61 STR+28 DEX+34 VIT+24 AGI+30 INT+21 MND+20 CHR+21 Accuracy+15 Ranged Accuracy+15 Evasion+60 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% Enmity-4 \"Store TP\"+3 Critical hit rate +3%", 
        ["category"]="Armor", 
        ["Critical hit rate"]=3, 
        ["VIT"]=24, 
        ["Attack"]=13
    }, 
    [46]={
        ["discription"]="DMG:140 Delay:200 Magic Damage+155 Dagger skill +269 Parrying skill +269 Magic Accuracy skill +228 \"Store TP\"+10 \"TP Bonus\"+500 \"Exenterator\" Aftermath: Increases skillchain potency Increases magic burst potency Ultimate Skillchain", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Aeneas", 
        ["Store TP"]=10, 
        ["delay"]=200, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF", 
            [10]="BRD", 
            [19]="DNC"
        }, 
        ["id"]=20594, 
        ["Parrying skill"]=269, 
        ["Dagger skill"]=269, 
        ["skill"]="Dagger", 
        ["damage"]=140
    }, 
    [47]={
        ["Ranged Attack"]=30, 
        ["DEX"]=25, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=26, 
        ["id"]=23761, 
        ["Accuracy"]=40, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=40, 
        ["Evasion"]=91, 
        ["MND"]=26, 
        ["en"]="Nyame Helm", 
        ["AGI"]=23, 
        ["HP"]=91, 
        ["DEF"]=156, 
        ["Attack"]=30, 
        ["slots"]={
            [4]="Head"
        }, 
        ["INT"]=28, 
        ["Haste"]=6, 
        ["MP"]=59, 
        ["discription"]="DEF:156 HP+91 MP+59 STR+26 DEX+25 VIT+24 AGI+23 INT+28 MND+26 CHR+24 Accuracy+40 Attack+30 Ranged Accuracy+40 Ranged Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Evasion+91 Magic Evasion+123 \"Magic Def. Bonus\"+5 Haste+6% Magic burst damage +5 \"Skillchain Bonus\"+5 Damage taken -7% Pet: Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50", 
        ["CHR"]=24, 
        ["Magic Atk. Bonus"]=30, 
        ["category"]="Armor", 
        ["VIT"]=24, 
        ["DT"]=-7, 
        ["Magic Accuracy"]=40
    }, 
    [48]={
        ["Ranged Attack"]=30, 
        ["DEX"]=24, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=35, 
        ["id"]=23768, 
        ["Accuracy"]=40, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=40, 
        ["Evasion"]=102, 
        ["MND"]=37, 
        ["en"]="Nyame Mail", 
        ["AGI"]=33, 
        ["HP"]=136, 
        ["DEF"]=189, 
        ["Attack"]=30, 
        ["slots"]={
            [5]="Body"
        }, 
        ["INT"]=42, 
        ["Haste"]=3, 
        ["MP"]=88, 
        ["discription"]="DEF:189 HP+136 MP+88 STR+35 DEX+24 VIT+35 AGI+33 INT+42 MND+37 CHR+35 Accuracy+40 Attack+30 Ranged Accuracy+40 Ranged Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Evasion+102 Magic Evasion+139 \"Magic Def. Bonus\"+8 Haste+3% Magic burst damage +7 \"Skillchain Bonus\"+7 Damage taken -9% Pet: Acc.+50 Ranged Acc.+50 Magic Acc.+50", 
        ["CHR"]=35, 
        ["Magic Atk. Bonus"]=30, 
        ["category"]="Armor", 
        ["VIT"]=35, 
        ["DT"]=-9, 
        ["Magic Accuracy"]=40
    }, 
    [49]={
        ["discription"]="STR+10 DEX+10 VIT+10 \"Quad Attack\"+3% \"Subtle Blow II\"+5", 
        ["en"]="Niqmaddu Ring", 
        ["DEX"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["STR"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [18]="PUP", 
            [22]="RUN"
        }, 
        ["id"]=26185, 
        ["VIT"]=10
    }, 
    [50]={
        ["Evasion"]=38, 
        ["MND"]=17, 
        ["DEF"]=113, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEX"]=5, 
        ["STR"]=29, 
        ["AGI"]=20, 
        ["en"]="Pill. Culottes +1", 
        ["discription"]="DEF:113 HP+47 STR+29 DEX+5 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Accuracy+10 Attack+10 Evasion+38 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% \"Steal\"+2 Critical hit damage +4%", 
        ["HP"]=47, 
        ["item_level"]=119, 
        ["Accuracy"]=10, 
        ["INT"]=30, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=6, 
        ["id"]=28116, 
        ["CHR"]=11, 
        ["VIT"]=16, 
        ["category"]="Armor", 
        ["Critical hit damage"]=4, 
        ["Attack"]=10
    }, 
    [51]={
        ["discription"]="DEF:18 All Jumps: \"Double Attack\"+20% Wyvern: \"Breath\" attacks +15", 
        ["category"]="Armor", 
        ["en"]="Brigantia's Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="STR+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="STR+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="none"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=18, 
        ["STR"]=30, 
        ["Accuracy"]=20, 
        ["id"]=26259, 
        ["Attack"]=20
    }, 
    [52]={
        ["Evasion"]=22, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["discription"]="DMG:82 Delay:142 +20 Evasion+22 Magic Accuracy+21 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Triple Attack\"+3% Additional effect: Wind damage Unity Ranking: AGI+10～15", 
        ["item_level"]=119, 
        ["en"]="Jugo Kukri +1", 
        ["AGI"]=15, 
        ["delay"]=142, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["id"]=20609, 
        ["Unity Ranking Bonus Applied"]="AGI + 15", 
        ["skill"]="Dagger", 
        ["Dagger skill"]=242, 
        ["category"]="Weapon", 
        ["Parrying skill"]=242, 
        ["damage"]=82, 
        ["Magic Accuracy"]=21
    }, 
    [53]={
        ["Evasion"]=76, 
        ["MND"]=5, 
        ["Haste"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=19, 
        ["STR"]=16, 
        ["AGI"]=32, 
        ["item_level"]=119, 
        ["Store TP"]=8, 
        ["HP"]=15, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["en"]="Tatena. Sune. +1", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=86, 
        ["id"]=25924, 
        ["Unity Ranking Bonus Applied"]="Store TP + 8", 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["VIT"]=16, 
        ["discription"]="DEF:86 HP+15 STR+16 DEX+19 VIT+16 AGI+32 MND+5 CHR+19 Evasion+76 Magic Evasion+80 \"Magic Def. Bonus\"+2 Haste+3% \"Zanshin\"+6 Unity Ranking: \"Store TP\"+4～8"
    }, 
    [54]={
        ["discription"]="DMG:348 Delay:492 STR+25 VIT+25 Accuracy+42 Attack+48 Polearm skill +242 Parrying skill +242 Magic Accuracy skill +228 Haste+7% Critical hit rate +7% All Jumps: Increases damage based on current HP", 
        ["damage"]=348, 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["STR"]=25, 
        ["en"]="Geirrothr", 
        ["Critical hit rate"]=7, 
        ["item_level"]=119, 
        ["delay"]=492, 
        ["id"]=21856, 
        ["Parrying skill"]=242, 
        ["Haste"]=7, 
        ["Polearm skill"]=242, 
        ["Accuracy"]=42, 
        ["skill"]="Polearm", 
        ["VIT"]=25, 
        ["category"]="Weapon", 
        ["Attack"]=48
    }, 
    [55]={
        ["Ranged Attack"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=17, 
        ["DEX"]=42, 
        ["DEF"]=142, 
        ["id"]=23775, 
        ["MND"]=40, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=40, 
        ["en"]="Nyame Gauntlets", 
        ["AGI"]=12, 
        ["HP"]=91, 
        ["Accuracy"]=40, 
        ["Attack"]=30, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["INT"]=28, 
        ["Haste"]=3, 
        ["MP"]=73, 
        ["discription"]="DEF:142 HP+91 MP+73 STR+17 DEX+42 VIT+39 AGI+12 INT+28 MND+40 CHR+24 Accuracy+40 Attack+30 Ranged Accuracy+40 Ranged Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Eva.+80 Magic Eva.+112 \"Magic Def. Bonus\"+4 Haste+3% Magic burst damage+5 \"Skillchain Bonus\"+5 Damage taken -7% Pet: Acc.+50 Ranged Acc.+50 Magic Acc.+50", 
        ["CHR"]=24, 
        ["Magic Atk. Bonus"]=30, 
        ["category"]="Armor", 
        ["DT"]=-7, 
        ["VIT"]=39, 
        ["Magic Accuracy"]=40
    }, 
    [56]={
        ["Evasion"]=38, 
        ["Magic Accuracy"]=43, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEX"]=21, 
        ["slots"]={
            [4]="Head"
        }, 
        ["MND"]=29, 
        ["item_level"]=119, 
        ["discription"]="DEF:125 HP+114 STR+32 DEX+21 VIT+44 AGI+16 INT+26 MND+29 CHR+38 Accuracy+41 Attack+45 Magic Accuracy+43 Evasion+38 Magic Evasion+53 \"Magic Def. Bonus\"+8 \"Double Attack\"+6% \"Store TP\"+7 Damage taken -10%", 
        ["Store TP"]=7, 
        ["AGI"]=16, 
        ["HP"]=114, 
        ["id"]=25592, 
        ["en"]="Hjarrandi Helm", 
        ["INT"]=26, 
        ["STR"]=32, 
        ["DEF"]=125, 
        ["Accuracy"]=41, 
        ["CHR"]=38, 
        ["VIT"]=44, 
        ["category"]="Armor", 
        ["DT"]=-10, 
        ["Attack"]=45
    }, 
    [57]={
        ["discription"]="DEF:15 Enfeebling magic effect +10 Enhancing magic duration +20%", 
        ["category"]="Armor", 
        ["en"]="Sucellos's Cape", 
        ["id"]=26250, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["DEF"]=15, 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="AGI+2", 
            [2]="Eva.+2 /Mag. Eva.+2", 
            [3]="none", 
            [4]="\"Dbl.Atk.\"+1", 
            [5]="none"
        }, 
        ["AGI"]=2
    }, 
    [58]={
        ["Evasion"]=65, 
        ["MND"]=19, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG"
        }, 
        ["DEX"]=11, 
        ["DEF"]=63, 
        ["AGI"]=37, 
        ["STR"]=10, 
        ["item_level"]=119, 
        ["HP"]=13, 
        ["en"]="Jute Boots +1", 
        ["VIT"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=3, 
        ["MP"]=14, 
        ["id"]=28276, 
        ["Unity Ranking Bonus Applied"]="Evasion + 10", 
        ["CHR"]=34, 
        ["INT"]=17, 
        ["category"]="Armor", 
        ["discription"]="DEF:63 HP+13 MP+14 STR+10 DEX+11 VIT+10 AGI+37 INT+17 MND+19 CHR+34 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+3% \"Resist Gravity\"+20 Movement speed +18% Unity Ranking: Evasion+1～10"
    }, 
    [59]={
        ["discription"]="DEF:18 All Jumps: \"Double Attack\"+20% Wyvern: \"Breath\" attacks +15", 
        ["category"]="Armor", 
        ["Attack"]=20, 
        ["en"]="Brigantia's Mantle", 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=18, 
        ["DEX"]=30, 
        ["Accuracy"]=20, 
        ["id"]=26259, 
        ["DT"]=-5
    }, 
    [60]={
        ["discription"]="VIT+4 \"Subtle Blow\"-4 \"Quadruple Attack\"+2%", 
        ["en"]="Ganesha's Mala", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=10928, 
        ["jobs"]={
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["category"]="Armor", 
        ["VIT"]=4
    }, 
    [61]={
        ["discription"]="Accuracy+20 Attack+20 Critical hit rate +3% Wyvern: Lv.+1", 
        ["category"]="Armor", 
        ["en"]="Dgn. Collar +1", 
        ["Critical hit rate"]=3, 
        ["id"]=25496, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=20, 
        ["Attack"]=20
    }, 
    [62]={
        ["Evasion"]=22, 
        ["augments"]={
            [1]="Accuracy+50", 
            [2]="Crit. hit rate+5%", 
            [3]="\"Triple Atk.\"+3"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["AGI"]=10, 
        ["id"]=20618, 
        ["en"]="Sandung", 
        ["item_level"]=119, 
        ["delay"]=200, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["Critical hit rate"]=5, 
        ["category"]="Weapon", 
        ["skill"]="Dagger", 
        ["Dagger skill"]=242, 
        ["damage"]=102, 
        ["Accuracy"]=50, 
        ["Parrying skill"]=242, 
        ["discription"]="DMG:102 Delay:200 AGI+10 Evasion+22 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Enmity-10 \"Treasure Hunter\"+1 Weapon skill damage +5"
    }, 
    [63]={
        ["Evasion"]=74, 
        ["STR"]=31, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["DEF"]=93, 
        ["MND"]=6, 
        ["en"]="Flam. Gambieras +2", 
        ["item_level"]=119, 
        ["Store TP"]=6, 
        ["AGI"]=26, 
        ["HP"]=40, 
        ["id"]=25953, 
        ["Set Bonus"]={
            ["set id"]=218, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["STR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["STR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["STR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["STR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=2, 
        ["MP"]=10, 
        ["Accuracy"]=42, 
        ["CHR"]=20, 
        ["VIT"]=20, 
        ["category"]="Armor", 
        ["discription"]="DEF:93 HP+40 MP+10 STR+31 DEX+34 VIT+20 AGI+26 MND+6 CHR+20 Accuracy+42 Magic Accuracy+42 Evasion+74 Magic Evasion+86 \"Magic Def. Bonus\"+5 Haste+2% \"Double Attack\"+6% \"Store TP\"+6 Set: Increases Strength, Dexterity, and Vitality", 
        ["Magic Accuracy"]=42
    }, 
    [64]={
        ["Evasion"]=44, 
        ["STR"]=29, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEX"]=19, 
        ["DEF"]=93, 
        ["MND"]=18, 
        ["discription"]="DEF:93 HP+20 MP+20 STR+29 DEX+19 VIT+29 AGI+26 MND+18 CHR+32 Accuracy+42 Attack+46 Evasion+44 Magic Evasion+75 \"Magic Def. Bonus\"+1 Haste+1% Weapon skill damage +7% Damage taken -4% Set: Enhances \"Subtle Blow\" effect", 
        ["en"]="Sulev. Leggings +2", 
        ["item_level"]=119, 
        ["AGI"]=26, 
        ["HP"]=20, 
        ["id"]=25946, 
        ["Set Bonus"]={
            ["set id"]=161, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }
        }, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=1, 
        ["MP"]=20, 
        ["Accuracy"]=42, 
        ["CHR"]=32, 
        ["VIT"]=29, 
        ["category"]="Armor", 
        ["DT"]=-4, 
        ["Attack"]=46
    }, 
    [65]={
        ["Evasion"]=52, 
        ["MND"]=10, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Empathy\" effect", 
            [4]="none"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEX"]=17, 
        ["DEF"]=78, 
        ["en"]="Ptero. Greaves +1", 
        ["STR"]=18, 
        ["AGI"]=32, 
        ["HP"]=35, 
        ["item_level"]=119, 
        ["Accuracy"]=12, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=3, 
        ["MP"]=20, 
        ["id"]=27355, 
        ["CHR"]=26, 
        ["VIT"]=15, 
        ["category"]="Armor", 
        ["discription"]="DEF:78 HP+35 MP+20 STR+18 DEX+17 VIT+15 AGI+32 MND+10 CHR+26 Accuracy+12 Attack+12 Evasion+52 Magic Evasion+75 \"Magic Def. Bonus\"+2 Haste+3% Wyvern: HP+230", 
        ["Attack"]=12
    }, 
    [66]={
        ["Evasion"]=22, 
        ["MND"]=16, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=120, 
        ["AGI"]=15, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Strafe\" effect", 
            [4]="none"
        }, 
        ["item_level"]=119, 
        ["HP"]=65, 
        ["DEX"]=12, 
        ["id"]=27179, 
        ["STR"]=33, 
        ["Haste"]=5, 
        ["en"]="Ptero. Brais +1", 
        ["INT"]=26, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["VIT"]=31, 
        ["discription"]="DEF:120 HP+65 STR+33 DEX+12 VIT+31 AGI+15 INT+26 MND+16 CHR+12 Evasion+22 Magic Evasion+75 \"Magic Def. Bonus\"+3 Haste+5% \"High Jump\": Enmity reduction +27% Wyvern: Physical damage taken -9%"
    }, 
    [67]={
        ["Evasion"]=83, 
        ["en"]="Gleti's Mask", 
        ["jobs"]={
            [6]="THF", 
            [9]="BST", 
            [14]="DRG", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["DEX"]=28, 
        ["slots"]={
            [4]="Head"
        }, 
        ["MND"]=19, 
        ["discription"]="DEF:152 HP+68 STR+33 DEX+28 VIT+30 AGI+23 INT+19 MND+19 CHR+19 Accuracy+40 Attack+40 Magic Accuracy+40 Evasion+83 Magic Evasion+86 \"Magic Def. Bonus\"+13 Haste+6% Enmity-8 Physical damage limit +6% \"Regain\"+2 Critical hit rate +5% Physical damage taken -6% Pet: Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50", 
        ["Critical hit rate"]=5, 
        ["item_level"]=119, 
        ["AGI"]=23, 
        ["HP"]=68, 
        ["id"]=23756, 
        ["Haste"]=6, 
        ["INT"]=19, 
        ["STR"]=33, 
        ["DEF"]=152, 
        ["Accuracy"]=40, 
        ["CHR"]=19, 
        ["PDT"]=-6, 
        ["category"]="Armor", 
        ["VIT"]=30, 
        ["Magic Accuracy"]=40, 
        ["Attack"]=40
    }, 
    [68]={
        ["Evasion"]=16, 
        ["Set Bonus"]={
            ["set id"]=161, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["STR"]=47, 
        ["DEF"]=135, 
        ["MND"]=20, 
        ["item_level"]=119, 
        ["en"]="Sulev. Cuisses +2", 
        ["discription"]="DEF:135 HP+50 MP+50 STR+47 VIT+33 AGI+14 INT+24 MND+20 CHR+18 Accuracy+45 Attack+49 Evasion+16 Magic Evasion+75 \"Magic Def. Bonus\"+2 Haste+2% \"Triple Attack\"+4% Damage taken -7% Set: Enhances \"Subtle Blow\" effect", 
        ["AGI"]=14, 
        ["HP"]=50, 
        ["id"]=25879, 
        ["DT"]=-7, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=2, 
        ["MP"]=50, 
        ["Accuracy"]=45, 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["CHR"]=18, 
        ["VIT"]=33, 
        ["Attack"]=49
    }, 
    [69]={
        ["Evasion"]=42, 
        ["MND"]=26, 
        ["Haste"]=5, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEX"]=20, 
        ["STR"]=43, 
        ["AGI"]=25, 
        ["Set Bonus"]={
            ["set id"]=129, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Magic Accuracy"]=15
                }, 
                [3]={
                    ["Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Magic Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Magic Accuracy"]=45
                }, 
                [5]={
                    ["Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Magic Accuracy"]=60
                }
            }
        }, 
        ["discription"]="DEF:141 HP+85 STR+43 DEX+20 VIT+29 AGI+25 INT+36 MND+26 CHR+22 Accuracy+49 Evasion+42 Magic Evasion+95 \"Magic Def. Bonus\"+4 Haste+5% \"Ancient Circle\"+1 \"High Jump\": Enmity reduction +29% Weapon skill damage +10% Wyvern: HP+27% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["HP"]=85, 
        ["en"]="Vishap Brais +3", 
        ["Accuracy"]=49, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=141, 
        ["id"]=23589, 
        ["INT"]=36, 
        ["category"]="Armor", 
        ["CHR"]=22, 
        ["VIT"]=29, 
        ["item_level"]=119
    }, 
    [70]={
        ["discription"]="DEF:16 \"Sneak Attack\"+10 \"Triple Attack\" damage +20", 
        ["category"]="Armor", 
        ["Attack"]=20, 
        ["en"]="Toutatis's Cape", 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=16, 
        ["DEX"]=30, 
        ["Accuracy"]=20, 
        ["id"]=26251, 
        ["DT"]=-5
    }, 
    [71]={
        ["discription"]="DEF:16 \"Sneak Attack\"+10 \"Triple Attack\" damage +20", 
        ["category"]="Armor", 
        ["en"]="Toutatis's Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=16, 
        ["DEX"]=30, 
        ["Accuracy"]=20, 
        ["id"]=26251, 
        ["Attack"]=20
    }, 
    [72]={
        ["Evasion"]=16, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["DEF"]=111, 
        ["MND"]=32, 
        ["discription"]="DEF:111 HP+30 MP+30 STR+23 DEX+34 VIT+45 INT+6 MND+32 CHR+27 Accuracy+43 Attack+47 Evasion+16 Magic Evasion+37 Haste+3% \"Double Attack\"+6% Damage taken -5% Set: Enhances \"Subtle Blow\" effect", 
        ["Set Bonus"]={
            ["set id"]=161, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }
        }, 
        ["item_level"]=119, 
        ["en"]="Sulev. Gauntlets +2", 
        ["HP"]=30, 
        ["id"]=25828, 
        ["DT"]=-5, 
        ["STR"]=23, 
        ["Haste"]=3, 
        ["MP"]=30, 
        ["Accuracy"]=43, 
        ["INT"]=6, 
        ["category"]="Armor", 
        ["CHR"]=27, 
        ["VIT"]=45, 
        ["Attack"]=47
    }, 
    [73]={
        ["Evasion"]=42, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEX"]=43, 
        ["DEF"]=116, 
        ["MND"]=36, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Angon\" effect", 
            [4]="none"
        }, 
        ["discription"]="DEF:116 HP+77 MP+50 STR+16 DEX+43 VIT+40 AGI+20 INT+20 MND+36 CHR+30 Accuracy+46 Attack+63 Magic Accuracy+38 Evasion+42 Magic Evasion+46 \"Magic Def. Bonus\"+3 Haste+4% Weapon skill damage +10% Wyvern: Magic damage taken -11%", 
        ["en"]="Ptero. Fin. G. +3", 
        ["AGI"]=20, 
        ["HP"]=77, 
        ["id"]=23545, 
        ["item_level"]=119, 
        ["STR"]=16, 
        ["Haste"]=4, 
        ["MP"]=50, 
        ["Accuracy"]=46, 
        ["INT"]=20, 
        ["category"]="Armor", 
        ["CHR"]=30, 
        ["Magic Accuracy"]=38, 
        ["VIT"]=40, 
        ["Attack"]=63
    }, 
    [74]={
        ["Evasion"]=44, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=25, 
        ["DEF"]=146, 
        ["MND"]=20, 
        ["en"]="Valorous Mail", 
        ["id"]=25717, 
        ["Store TP"]=3, 
        ["AGI"]=20, 
        ["HP"]=61, 
        ["augments"]={
            [1]="\"Dbl.Atk.\"+5", 
            [2]="Accuracy+15", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["VIT"]=29, 
        ["INT"]=20, 
        ["STR"]=29, 
        ["Haste"]=3, 
        ["Accuracy"]=35, 
        ["CHR"]=20, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["discription"]="DEF:146 HP+61 STR+29 DEX+25 VIT+29 AGI+20 INT+20 MND+20 CHR+20 Accuracy+20 Evasion+44 Magic Evasion+59 \"Magic Def. Bonus\"+4 Haste+3% \"Store TP\"+3 \"Double Attack\"+2% Physical damage taken -2%"
    }, 
    [75]={
        ["Evasion"]=76, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEX"]=39, 
        ["DEF"]=161, 
        ["MND"]=31, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Spirit Surge\" effect", 
            [4]="none"
        }, 
        ["discription"]="DEF:161 HP+102 MP+64 STR+44 DEX+39 VIT+36 AGI+31 INT+31 MND+31 CHR+31 Accuracy+40 Attack+80 Magic Accuracy+40 Evasion+76 Magic Evasion+73 \"Magic Def. Bonus\"+6 Haste+3% All Jumps: Adds 100% of wyvern's max HP as additional damage Wyvern: Adds support job abilities to wyvern", 
        ["en"]="Ptero. Mail +3", 
        ["AGI"]=31, 
        ["HP"]=102, 
        ["id"]=23478, 
        ["item_level"]=119, 
        ["STR"]=44, 
        ["Haste"]=3, 
        ["MP"]=64, 
        ["Accuracy"]=40, 
        ["INT"]=31, 
        ["category"]="Armor", 
        ["CHR"]=31, 
        ["Magic Accuracy"]=40, 
        ["VIT"]=36, 
        ["Attack"]=80
    }, 
    [76]={
        ["Evasion"]=33, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEX"]=15, 
        ["DEF"]=111, 
        ["MND"]=14, 
        ["discription"]="DEF:111 HP+60 MP+23 STR+27 DEX+15 VIT+25 AGI+15 INT+14 MND+14 CHR+14 Accuracy+15 Attack+15 Evasion+33 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+7% Wyvern: \"Breath\" attacks +22", 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Deep Breathing\" effect", 
            [4]="none"
        }, 
        ["en"]="Ptero. Armet +1", 
        ["AGI"]=15, 
        ["HP"]=60, 
        ["id"]=26651, 
        ["item_level"]=119, 
        ["STR"]=27, 
        ["Haste"]=7, 
        ["MP"]=23, 
        ["Accuracy"]=15, 
        ["INT"]=14, 
        ["category"]="Armor", 
        ["CHR"]=14, 
        ["VIT"]=25, 
        ["Attack"]=15
    }, 
    [77]={
        ["Evasion"]=49, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=32, 
        ["DEF"]=123, 
        ["MND"]=12, 
        ["en"]="Flam. Zucchetto +2", 
        ["discription"]="DEF:123 HP+80 MP+20 STR+36 DEX+32 VIT+24 AGI+16 INT+12 MND+12 CHR+12 Accuracy+44 Magic Accuracy+44 Evasion+49 Magic Evasion+53 \"Magic Def. Bonus\"+3 Haste+4% \"Triple Attack\"+5% \"Store TP\"+6 Set: Increases Strength, Dexterity, and Vitality", 
        ["Store TP"]=6, 
        ["AGI"]=16, 
        ["HP"]=80, 
        ["id"]=25569, 
        ["Set Bonus"]={
            ["set id"]=218, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["STR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["STR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["STR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["STR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["STR"]=36, 
        ["Haste"]=4, 
        ["MP"]=20, 
        ["Accuracy"]=44, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["item_level"]=119, 
        ["VIT"]=24, 
        ["Magic Accuracy"]=44
    }, 
    [78]={
        ["Ranged Attack"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["item_level"]=119, 
        ["STR"]=43, 
        ["DEF"]=169, 
        ["id"]=23782, 
        ["MND"]=32, 
        ["discription"]="DEF:169 HP+114 MP+59 STR+43 VIT+30 AGI+34 INT+44 MND+32 CHR+24 Accuracy+40 Attack +30 Ranged Accuracy+40 Ranged Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Evasion+85 Magic Evasion+150 \"Magic Def. Bonus\"+7 Haste+5% Magic burst damage +6 \"Skillchain Bonus\"+6 Damage taken -8% Pet: Acc.+50 Ranged Acc.+50 Magic Acc.+50", 
        ["Ranged Accuracy"]=40, 
        ["en"]="Nyame Flanchard", 
        ["AGI"]=34, 
        ["HP"]=114, 
        ["Accuracy"]=40, 
        ["Attack"]=30, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["INT"]=44, 
        ["Haste"]=5, 
        ["MP"]=59, 
        ["Evasion"]=85, 
        ["CHR"]=24, 
        ["Magic Atk. Bonus"]=30, 
        ["category"]="Armor", 
        ["DT"]=-8, 
        ["VIT"]=30, 
        ["Magic Accuracy"]=40
    }, 
    [79]={
        ["Evasion"]=94, 
        ["en"]="Gleti's Cuirass", 
        ["jobs"]={
            [6]="THF", 
            [9]="BST", 
            [14]="DRG", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["DEX"]=34, 
        ["slots"]={
            [5]="Body"
        }, 
        ["MND"]=26, 
        ["discription"]="DEF:184 HP+91 STR+39 DEX+34 VIT+39 AGI+26 INT+26 MND+26 CHR+26 Accuracy+40 Attack+40 Magic Accuracy+40 Evasion+94 Magic Evasion+102 \"Magic Def. Bonus\"+15 Haste+3% Physical damage limit +9% \"Waltz\" potency +10% \"Regain\"+3 Critical hit rate +8% Physical damage taken -9% Pet: Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50", 
        ["Critical hit rate"]=8, 
        ["item_level"]=119, 
        ["AGI"]=26, 
        ["HP"]=91, 
        ["id"]=23763, 
        ["Haste"]=3, 
        ["INT"]=26, 
        ["STR"]=39, 
        ["DEF"]=184, 
        ["Accuracy"]=40, 
        ["CHR"]=26, 
        ["PDT"]=-9, 
        ["category"]="Armor", 
        ["VIT"]=39, 
        ["Magic Accuracy"]=40, 
        ["Attack"]=40
    }, 
    [80]={
        ["Evasion"]=72, 
        ["en"]="Gleti's Gauntlets", 
        ["jobs"]={
            [6]="THF", 
            [9]="BST", 
            [14]="DRG", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["DEX"]=42, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["MND"]=30, 
        ["discription"]="DEF:138 HP+68 STR+20 DEX+42 VIT+43 AGI+15 INT+14 MND+30 CHR+24 Accuracy+40 Attack+40 Magic Accuracy+40 Evasion+72 Magic Evasion+75 \"Magic Def. Bonus\"+12 Haste+3% \"Regain\"+2 Physical damage limit +7% Critical hit rate +6% Physical damage taken -7% Pet: Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Damage taken -8%", 
        ["Critical hit rate"]=6, 
        ["item_level"]=119, 
        ["AGI"]=15, 
        ["HP"]=68, 
        ["id"]=23770, 
        ["Haste"]=3, 
        ["INT"]=14, 
        ["STR"]=20, 
        ["DEF"]=138, 
        ["Accuracy"]=40, 
        ["CHR"]=24, 
        ["PDT"]=-7, 
        ["category"]="Armor", 
        ["VIT"]=43, 
        ["Magic Accuracy"]=40, 
        ["Attack"]=40
    }, 
    [81]={
        ["Ranged Attack"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=23, 
        ["DEX"]=26, 
        ["DEF"]=122, 
        ["id"]=23789, 
        ["MND"]=26, 
        ["discription"]="DEF:122 HP+68 MP+44 STR+23 DEX+26 VIT+24 AGI+46 INT+25 MND+26 CHR+38 Accuracy+40 Attack+30 Ranged Accuracy+40 Ranged Attack+30 Magic Accracy+40 \"Magic Atk. Bonus\"+30 Eva.+119 Magic Eva.+150 \"Magic Def. Bonus\"+5 Haste+3% Magic burst damage +5 \"Skillchain Bonus\"+5 Damage taken -7% Pet: Acc.+50 Ranged Acc.+50 Magic Acc.+50", 
        ["Ranged Accuracy"]=40, 
        ["en"]="Nyame Sollerets", 
        ["AGI"]=46, 
        ["HP"]=68, 
        ["Accuracy"]=40, 
        ["DT"]=-7, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=3, 
        ["MP"]=44, 
        ["item_level"]=119, 
        ["INT"]=25, 
        ["category"]="Armor", 
        ["CHR"]=38, 
        ["VIT"]=24, 
        ["Magic Atk. Bonus"]=30, 
        ["Attack"]=30
    }, 
    [82]={
        ["Evasion"]=77, 
        ["id"]=23777, 
        ["jobs"]={
            [6]="THF", 
            [9]="BST", 
            [14]="DRG", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=165, 
        ["MND"]=20, 
        ["item_level"]=119, 
        ["en"]="Gleti's Breeches", 
        ["discription"]="DEF:165 HP+79 STR+49 VIT+37 AGI+23 INT+30 MND+20 CHR+17 Accuracy+40 Attack+40 Magic Accuracy+40 Evasion+77 Magic Evasion+112 \"Magic Def. Bonus\"+14 Haste+5% Physical damage limit +8% \"Sic\" and \"Ready\" ability delay -5 \"Regain\"+3 Critical hit rate +7% Physical damage taken -8% Pet: Acc.+50 Ranged Acc.+50 Magic Acc.+50", 
        ["AGI"]=23, 
        ["HP"]=79, 
        ["Critical hit rate"]=7, 
        ["VIT"]=37, 
        ["INT"]=30, 
        ["STR"]=49, 
        ["Haste"]=5, 
        ["Accuracy"]=40, 
        ["CHR"]=17, 
        ["PDT"]=-8, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=40, 
        ["Attack"]=40
    }, 
    [83]={
        ["discription"]="HP+70 Accuracy+30 Attack+30 Weapon skill DEX +10%", 
        ["category"]="Weapon", 
        ["en"]="Utu Grip", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["HP"]=70, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [22]="RUN"
        }, 
        ["id"]=22212, 
        ["skill"]="(N/A)", 
        ["Accuracy"]=30, 
        ["Attack"]=30
    }, 
    [84]={
        ["Critical hit rate"]=2, 
        ["item_level"]=119, 
        ["Throwing skill"]=242, 
        ["slots"]={
            [2]="Range"
        }, 
        ["category"]="Weapon", 
        ["en"]="Wingcutter +1", 
        ["AGI"]=6, 
        ["delay"]=286, 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN"
        }, 
        ["Unity Ranking Bonus Applied"]="DEX + 5", 
        ["discription"]="DMG:65 Delay:286 AGI+6 +20 Throwing skill +242 Critical hit rate +2% Unity Ranking: DEX+1～5", 
        ["skill"]="Throwing", 
        ["DEX"]=5, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["id"]=21350, 
        ["damage"]=65
    }, 
    [85]={
        ["Evasion"]=110, 
        ["en"]="Gleti's Boots", 
        ["jobs"]={
            [6]="THF", 
            [9]="BST", 
            [14]="DRG", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["DEX"]=29, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["MND"]=12, 
        ["discription"]="DEF:119 HP+57 STR+28 DEX+29 VIT+26 AGI+33 MND+12 CHR+26 Accuracy+40 Attack+40 Magic Accuracy+40 Evasion+110 Magic Evasion+112 \"Magic Def. Bonus\"+13 Haste+3% \"Regain\"+2 Physical damage limit +5% Critical hit rate +4% Physical damage taken -5% Pet: Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Summoned Pet: Lv.+1", 
        ["Critical hit rate"]=4, 
        ["item_level"]=119, 
        ["AGI"]=33, 
        ["HP"]=57, 
        ["id"]=23784, 
        ["PDT"]=-5, 
        ["CHR"]=26, 
        ["STR"]=28, 
        ["Haste"]=3, 
        ["Accuracy"]=40, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=40, 
        ["VIT"]=26, 
        ["DEF"]=119, 
        ["Attack"]=40
    }, 
    [86]={
        ["Evasion"]=70, 
        ["MND"]=23, 
        ["DEF"]=150, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=39, 
        ["Ranged Accuracy"]=47, 
        ["item_level"]=119, 
        ["slots"]={
            [5]="Body"
        }, 
        ["AGI"]=37, 
        ["HP"]=122, 
        ["id"]=26528, 
        ["Accuracy"]=52, 
        ["INT"]=24, 
        ["STR"]=33, 
        ["Haste"]=4, 
        ["Critical hit rate"]=9, 
        ["CHR"]=21, 
        ["VIT"]=21, 
        ["category"]="Armor", 
        ["en"]="Ken. Samue +1", 
        ["discription"]="DEF:150 HP+122 STR+33 DEX+39 VIT+21 AGI+37 INT+24 MND+23 CHR+21 Accuracy+52 Ranged Accuracy+47 Evasion+70 Magic Evasion+117 \"Magic Def. Bonus\"+9 Haste+4% \"Triple Attack\"+6% \"Subtle Blow\"+12 Critical hit rate +9%"
    }, 
    [87]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Migawari\"+5", 
        ["category"]="Armor", 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="Accuracy+10", 
            [4]="\"Store TP\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["en"]="Andartia's Mantle", 
        ["Store TP"]=10, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Attack"]=20, 
        ["DEX"]=20, 
        ["Accuracy"]=30, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=26258, 
        ["DEF"]=16, 
        ["DT"]=-5
    }, 
    [88]={
        ["Evasion"]=59, 
        ["MND"]=16, 
        ["DEF"]=132, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=5, 
        ["Ranged Accuracy"]=46, 
        ["item_level"]=119, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["AGI"]=33, 
        ["HP"]=115, 
        ["id"]=25892, 
        ["Accuracy"]=51, 
        ["INT"]=32, 
        ["STR"]=37, 
        ["Haste"]=9, 
        ["Critical hit rate"]=7, 
        ["CHR"]=12, 
        ["VIT"]=25, 
        ["category"]="Armor", 
        ["en"]="Ken. Hakama +1", 
        ["discription"]="DEF:132 HP+115 STR+37 DEX+5 VIT+25 AGI+33 INT+32 MND+16 CHR+12 Accuracy+51 Ranged Accuracy+46 Evasion+59 Magic Evasion+139 \"Magic Def. Bonus\"+8 Haste+9% \"Triple Attack\"+5% \"Subtle Blow\"+10 Critical hit rate +7%"
    }, 
    [89]={
        ["Evasion"]=62, 
        ["MND"]=17, 
        ["DEF"]=120, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=47, 
        ["Ranged Accuracy"]=45, 
        ["item_level"]=119, 
        ["slots"]={
            [4]="Head"
        }, 
        ["AGI"]=34, 
        ["HP"]=88, 
        ["id"]=25552, 
        ["Accuracy"]=50, 
        ["INT"]=19, 
        ["STR"]=23, 
        ["Haste"]=6, 
        ["Critical hit rate"]=5, 
        ["CHR"]=19, 
        ["VIT"]=32, 
        ["category"]="Armor", 
        ["en"]="Ken. Jinpachi +1", 
        ["discription"]="DEF:120 HP+88 STR+23 DEX+47 VIT+32 AGI+34 INT+19 MND+17 CHR+19 Accuracy+50 Ranged Accuracy+45 Evasion+62 Magic Evasion+101 \"Magic Def. Bonus\"+6 Haste+6% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit rate +5%"
    }, 
    [90]={
        ["Evasion"]=51, 
        ["MND"]=28, 
        ["DEF"]=108, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=62, 
        ["Ranged Accuracy"]=44, 
        ["item_level"]=119, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["AGI"]=5, 
        ["HP"]=61, 
        ["id"]=25979, 
        ["Accuracy"]=49, 
        ["INT"]=14, 
        ["STR"]=14, 
        ["Haste"]=4, 
        ["Critical hit rate"]=5, 
        ["CHR"]=21, 
        ["VIT"]=37, 
        ["category"]="Armor", 
        ["en"]="Ken. Tekko +1", 
        ["discription"]="DEF:108 HP+61 STR+14 DEX+62 VIT+37 AGI+5 INT+14 MND+28 CHR+21 Accuracy+49 Ranged Accuracy+44 Evasion+51 Magic Evasion+90 \"Magic Def. Bonus\"+5 Haste+4% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit rate +5%"
    }, 
    [91]={
        ["Evasion"]=20, 
        ["Critical hit rate"]=5, 
        ["skill"]="Dagger", 
        ["jobs"]={
            [5]="RDM", 
            [6]="THF", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=15, 
        ["en"]="Gleti's Knife", 
        ["item_level"]=119, 
        ["discription"]="DMG:133 Delay:200 DEX+15 AGI+15 Accuracy+40 Attack+30 Magic Accuracy+40 Evasion+20 Dagger skill +255 Parrying skill +255 Magic Accuracy skill +242 Haste+2% \"Triple Attack\"+6% \"Waltz\" potency +10% Critical hit rate +5%", 
        ["AGI"]=15, 
        ["delay"]=200, 
        ["Dagger skill"]=255, 
        ["Accuracy"]=40, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Haste"]=2, 
        ["id"]=21567, 
        ["category"]="Weapon", 
        ["Parrying skill"]=255, 
        ["damage"]=133, 
        ["Magic Accuracy"]=40, 
        ["Attack"]=30
    }, 
    [92]={
        ["Evasion"]=80, 
        ["MND"]=14, 
        ["Critical hit rate"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=44, 
        ["Ranged Accuracy"]=43, 
        ["item_level"]=119, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["AGI"]=44, 
        ["HP"]=70, 
        ["DEF"]=81, 
        ["Accuracy"]=48, 
        ["STR"]=20, 
        ["Haste"]=3, 
        ["id"]=25959, 
        ["CHR"]=26, 
        ["VIT"]=21, 
        ["category"]="Armor", 
        ["en"]="Ken. Sune-Ate +1", 
        ["discription"]="DEF:81 HP+70 STR+20 DEX+44 VIT+21 AGI+44 MND+14 CHR+26 Accuracy+48 Ranged Accuracy+43 Evasion+80 Magic Evasion+139 \"Magic Def. Bonus\"+6 Haste+3% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit rate +5%"
    }, 
    [93]={
        ["discription"]="DMG:159 Delay:227 Magic Damage+186 Katana skill +269 Parrying skill +269 Magic Accuracy skill +242 \"Store TP\"+10 \"TP Bonus\"+500 \"Blade: Shun\" Aftermath: Increases skillchain potency Increases magic burst potency Ultimate Skillchain", 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["Katana skill"]=269, 
        ["Store TP"]=10, 
        ["en"]="Heishi Shorinken", 
        ["delay"]=227, 
        ["id"]=20977, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=269, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["item_level"]=119, 
        ["damage"]=159
    }, 
    [94]={
        ["discription"]="Accuracy+25 Ranged Accuracy+25 \"Store TP\"+7", 
        ["Ranged Accuracy"]=25, 
        ["category"]="Armor", 
        ["en"]="Ninja Nodowa +2", 
        ["Store TP"]=7, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=25, 
        ["id"]=25491
    }, 
    [95]={
        ["discription"]="DMG:101 Delay:192 HP+25 Attack+13 Throwing skill +242 \"Store TP\"+2", 
        ["HP"]=25, 
        ["Throwing skill"]=242, 
        ["category"]="Weapon", 
        ["Store TP"]=2, 
        ["item_level"]=119, 
        ["delay"]=192, 
        ["skill"]="Throwing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["damage"]=101, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=21391, 
        ["en"]="Seki Shuriken", 
        ["Attack"]=13
    }, 
    [96]={
        ["discription"]="Accuracy-10 Attack-10 Ranged Accuracy-10 Ranged Attack-10 \"Store TP\"+8", 
        ["category"]="Armor", 
        ["en"]="Dedition Earring", 
        ["Store TP"]=8, 
        ["Ranged Attack"]=-10, 
        ["Ranged Accuracy"]=-10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=-10, 
        ["id"]=27544, 
        ["Attack"]=-10
    }, 
    [97]={
        ["discription"]="Double Attack+3% \"Triple Attack\"+3%", 
        ["en"]="Epona's Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=11651, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["Attack"]=3
    }, 
    [98]={
        ["discription"]="Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 \"Double Attack\"+1% \"Store TP\"+5", 
        ["category"]="Armor", 
        ["en"]="Telos Earring", 
        ["Store TP"]=5, 
        ["Ranged Attack"]=10, 
        ["Ranged Accuracy"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=10, 
        ["id"]=27545, 
        ["Attack"]=10
    }, 
    [99]={
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [13]="NIN", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["en"]="Gere Ring", 
        ["id"]=28471, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="STR+10 Attack+16 \"Triple Attack\"+5%", 
        ["STR"]=10, 
        ["Attack"]=16
    }, 
    [100]={
        ["discription"]="Haste+9% \"Triple Attack\"+2% Unity Ranking: Attack+10～15", 
        ["category"]="Armor", 
        ["en"]="Sailfi Belt +1", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["Unity Ranking Bonus Applied"]="Attack + 15", 
        ["Haste"]=9, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28428, 
        ["Attack"]=15
    }, 
    [101]={
        ["Evasion"]=99, 
        ["MND"]=22, 
        ["AGI"]=44, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=25, 
        ["discription"]="DEF:92 HP+29 STR+24 DEX+25 VIT+21 AGI+44 INT+20 MND+22 CHR+39 Magic Accuracy+52 Evasion+99 Magic Evasion+84 \"Magic Atk. Bonus\"+23 \"Magic Def. Bonus\"+4 Haste+4% Magic burst damage +10 Dusk to dawn: Movement speed +25% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["en"]="Hachiya Kyahan +3", 
        ["item_level"]=119, 
        ["Haste"]=4, 
        ["HP"]=29, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=84
        }, 
        ["INT"]=20, 
        ["STR"]=24, 
        ["DEF"]=92, 
        ["id"]=23655, 
        ["CHR"]=39, 
        ["Magic Atk. Bonus"]=23, 
        ["category"]="Armor", 
        ["VIT"]=21, 
        ["Magic Accuracy"]=52
    }, 
    [102]={
        ["discription"]="DMG:125 Delay:180 DEX+15 INT+15 MND+15 Accuracy+40 Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+16 Magic Damage+217 Dagger skill +250 Parrying skill +250 Magic Accuracy skill +250 Main hand: \"Evisceration\" \"Evisceration\" damage +50% Increases critical hit rate based on lower TP.", 
        ["MND"]=15, 
        ["jobs"]={
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["DEX"]=15, 
        ["skill"]="Dagger", 
        ["en"]="Tauret", 
        ["Attack"]=30, 
        ["item_level"]=119, 
        ["delay"]=180, 
        ["Dagger skill"]=250, 
        ["Accuracy"]=40, 
        ["INT"]=15, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=21565, 
        ["category"]="Weapon", 
        ["damage"]=125, 
        ["Magic Atk. Bonus"]=16, 
        ["Parrying skill"]=250, 
        ["Magic Accuracy"]=40
    }, 
    [103]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Migawari\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["Magic Atk. Bonus"]=10, 
        ["id"]=26258, 
        ["INT"]=30, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="INT+20", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="INT+10", 
            [4]="\"Mag.Atk.Bns.\"+10", 
            [5]="none"
        }, 
        ["DEF"]=16, 
        ["Magic Accuracy"]=20
    }, 
    [104]={
        ["Evasion"]=89, 
        ["STR"]=28, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=29, 
        ["AGI"]=48, 
        ["MND"]=22, 
        ["item_level"]=119, 
        ["discription"]="DEF:93 HP+33 STR+28 DEX+29 VIT+25 AGI+48 MND+22 CHR+39 Accuracy+43 Attack+76 Magic Accuracy+36 Evasion+89 Magic Evasion+84 \"Magic Def. Bonus\"+5 Ninjutsu skill +23 Haste+4% Enmity+8", 
        ["id"]=23678, 
        ["en"]="Mochi. Kyahan +3", 
        ["HP"]=33, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enh. Ninj. Mag. Acc/Cast Time Red.", 
            [4]="none"
        }, 
        ["Attack"]=76, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=4, 
        ["Ninjutsu skill"]=23, 
        ["Accuracy"]=43, 
        ["CHR"]=39, 
        ["VIT"]=25, 
        ["category"]="Armor", 
        ["DEF"]=93, 
        ["Magic Accuracy"]=36
    }, 
    [105]={
        ["Evasion"]=73, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["item_level"]=119, 
        ["DEX"]=31, 
        ["Attack"]=62, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Yonin\" and \"Innin\" effect", 
            [4]="none"
        }, 
        ["MND"]=32, 
        ["STR"]=31, 
        ["discription"]="DEF:120 HP+56 STR+31 DEX+31 VIT+33 AGI+33 INT+32 MND+32 CHR+32 Accuracy+44 Attack+62 Magic Accuracy+37 Evasion+73 Magic Evasion+63 \"Magic Atk. Bonus\"+61 \"Magic Def. Bonus\"+6 Parrying skill +20 Haste+8% Ninjutsu damage +21", 
        ["id"]=23410, 
        ["en"]="Mochi. Hatsuburi +3", 
        ["HP"]=56, 
        ["Accuracy"]=44, 
        ["Parrying skill"]=20, 
        ["INT"]=32, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=120, 
        ["AGI"]=33, 
        ["CHR"]=32, 
        ["Magic Atk. Bonus"]=61, 
        ["category"]="Armor", 
        ["Haste"]=8, 
        ["VIT"]=33, 
        ["Magic Accuracy"]=37
    }, 
    [106]={
        ["discription"]="+20 +20 +20 +20 +20 +20 Occasionally absorbs magic damage taken Unity Ranking: Enmity+1～8", 
        ["id"]=27505, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Warder's Charm +1", 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [107]={
        ["discription"]="MP+35 Magic Damage+11 Unity Ranking: INT+2～6", 
        ["category"]="Weapon", 
        ["en"]="Ghastly Tathlum +1", 
        ["skill"]="(N/A)", 
        ["Unity Ranking Bonus Applied"]="INT + 6", 
        ["INT"]=6, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["MP"]=35, 
        ["id"]=21344, 
        ["augments"]={
            [1]="Path: A"
        }
    }, 
    [108]={
        ["Evasion"]=55, 
        ["en"]="Samnuha Coat", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=33, 
        ["AGI"]=29, 
        ["MND"]=20, 
        ["Dual Wield"]=3, 
        ["STR"]=26, 
        ["id"]=26973, 
        ["item_level"]=119, 
        ["HP"]=63, 
        ["augments"]={
            [1]="Mag. Acc.+12", 
            [2]="\"Mag.Atk.Bns.\"+12", 
            [3]="\"Dual Wield\"+3", 
            [4]="none", 
            [5]="none"
        }, 
        ["Haste"]=4, 
        ["INT"]=20, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=138, 
        ["Accuracy"]=23, 
        ["CHR"]=20, 
        ["Magic Atk. Bonus"]=32, 
        ["category"]="Armor", 
        ["discription"]="DEF:138 HP+63 STR+26 DEX+33 VIT+23 AGI+29 INT+20 MND+20 CHR+20 Accuracy+23 Magic Accuracy+23 Evasion+55 Magic Evasion+69 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+6 Haste+4% Magic burst damage II +8 \"Death\" resistance +15", 
        ["VIT"]=23, 
        ["Magic Accuracy"]=35
    }, 
    [109]={
        ["discription"]="MND+2 \"Magic Def. Bonus\"+2  Bonus damage added to magic burst", 
        ["id"]=15962, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Static Earring", 
        ["MND"]=2, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [110]={
        ["discription"]="Magic Atk. Bonus+10 Enmity+2", 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Friomisi Earring", 
        ["id"]=28514, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [111]={
        ["discription"]="Magic critical hit rate +5% Bonus damage added to magic burst", 
        ["id"]=28582, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Locus Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [112]={
        ["Ranged Attack"]=15, 
        ["Haste"]=6, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Evasion"]=62, 
        ["AGI"]=32, 
        ["MND"]=15, 
        ["STR"]=33, 
        ["discription"]="DEF:114 HP+38 STR+33 VIT+16 AGI+32 INT+29 MND+15 CHR+10 Attack+15 Ranged Attack+15 Evasion+62 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% Enmity-4 \"Store TP\"+4 Physical damage taken -2%", 
        ["Store TP"]=4, 
        ["en"]="Herculean Trousers", 
        ["HP"]=38, 
        ["augments"]={
            [1]="\"Waltz\" potency +11%", 
            [2]="INT+4", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["id"]=25842, 
        ["INT"]=33, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=114, 
        ["item_level"]=119, 
        ["CHR"]=10, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["VIT"]=16, 
        ["Attack"]=15
    }, 
    [113]={
        ["discription"]="Skillchain Bonus+5 Magic burst damage II +5", 
        ["id"]=11672, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Mujin Band", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [114]={
        ["discription"]="Increases all elemental attacks by 1-15 based on distance to target", 
        ["id"]=26359, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Orpheus's Sash", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [115]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Migawari\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["id"]=26258, 
        ["Fast Cast"]=10, 
        ["INT"]=20, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="INT+20", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="Mag. Acc.+10", 
            [4]="\"Fast Cast\"+10", 
            [5]="none"
        }, 
        ["DEF"]=16, 
        ["Magic Accuracy"]=30
    }, 
    [116]={
        ["Evasion"]=68, 
        ["MND"]=31, 
        ["AGI"]=32, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=33, 
        ["discription"]="DEF:122 HP+64 STR+33 DEX+33 VIT+32 AGI+32 INT+31 MND+31 CHR+31 Magic Accuracy+54 Evasion+68 Magic Evasion+63 \"Magic Def. Bonus\"+5 Ninjutsu skill +17 Haste+8% \"Subtle Blow\"+9 Weapon skill damage +10% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["en"]="Hachiya Hatsu. +3", 
        ["item_level"]=119, 
        ["DEF"]=122, 
        ["HP"]=64, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=84
        }, 
        ["STR"]=33, 
        ["Haste"]=8, 
        ["Ninjutsu skill"]=17, 
        ["id"]=23387, 
        ["INT"]=31, 
        ["category"]="Armor", 
        ["CHR"]=31, 
        ["VIT"]=32, 
        ["Magic Accuracy"]=54
    }, 
    [117]={
        ["discription"]="Magic skills +10 MP not depleted when magic used +1%", 
        ["id"]=26016, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Incanter's Torque", 
        ["Magic skills"]=10, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [118]={
        ["Evasion"]=15, 
        ["category"]="Weapon", 
        ["en"]="Yamarang", 
        ["Store TP"]=3, 
        ["discription"]="Accuracy+15 Magic Accuracy+15 Evasion+15 Magic Evasion+15 \"Store TP\"+3 \"Waltz\" potency +5%", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Accuracy"]=15, 
        ["id"]=22280, 
        ["Magic Accuracy"]=15
    }, 
    [119]={
        ["Evasion"]=102, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["Haste"]=4, 
        ["DEX"]=49, 
        ["AGI"]=42, 
        ["id"]=23733, 
        ["MND"]=24, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=11, 
        ["en"]="Malignance Tabard", 
        ["HP"]=68, 
        ["Accuracy"]=50, 
        ["slots"]={
            [5]="Body"
        }, 
        ["STR"]=19, 
        ["DEF"]=143, 
        ["MP"]=44, 
        ["discription"]="DEF:143 HP+68 MP+44 STR+19 DEX+49 VIT+25 AGI+42 INT+19 MND+24 CHR+24 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+102 Magic Evasion+139 \"Magic Def. Bonus\"+8 Haste+4% \"Store TP\"+11 Physical damage limit +6% Damage taken -9%", 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["CHR"]=24, 
        ["Magic Accuracy"]=50, 
        ["VIT"]=25, 
        ["DT"]=-9
    }, 
    [120]={
        ["discription"]="Accuracy+10 Magic Accuracy+10 \"Subtle Blow\"+5 \"Store TP\"+3", 
        ["category"]="Armor", 
        ["en"]="Digni. Earring", 
        ["Store TP"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27547, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Accuracy"]=10, 
        ["Magic Accuracy"]=10
    }, 
    [121]={
        ["id"]=26100, 
        ["en"]="Hnoss Earring", 
        ["DEF"]=20, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:20 Ninjutsu skill +10", 
        ["Ninjutsu skill"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [122]={
        ["discription"]="INT+6 MND+6 CHR+6 Converts 60 HP to MP Unity Ranking: Magic Accuracy+1～5", 
        ["MND"]=6, 
        ["category"]="Armor", 
        ["en"]="Metamor. Ring +1", 
        ["CHR"]=6, 
        ["INT"]=6, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27563, 
        ["augments"]={
            [1]="Path: A"
        }
    }, 
    [123]={
        ["Evasion"]=80, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["Haste"]=4, 
        ["DEX"]=56, 
        ["AGI"]=24, 
        ["id"]=23734, 
        ["MND"]=42, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=12, 
        ["en"]="Malignance Gloves", 
        ["HP"]=57, 
        ["Accuracy"]=50, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["STR"]=25, 
        ["DEF"]=108, 
        ["MP"]=36, 
        ["discription"]="DEF:108 HP+57 MP+36 STR+25 DEX+56 VIT+32 AGI+24 INT+11 MND+42 CHR+21 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+80 Magic Evasion+112 \"Magic Def. Bonus\"+4 Haste+4% \"Store TP\"+12 Physical damage limit +4% Damage taken -5%", 
        ["INT"]=11, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["Magic Accuracy"]=50, 
        ["VIT"]=32, 
        ["DT"]=-5
    }, 
    [124]={
        ["Evasion"]=85, 
        ["STR"]=28, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["discription"]="DEF:125 HP+45 MP+29 STR+28 VIT+17 AGI+42 INT+26 MND+19 CHR+12 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+85 Magic Evasion+150 \"Magic Def. Bonus\"+7 Haste+9% \"Store TP\"+10 Physical damage limit +5% Damage taken -7%", 
        ["AGI"]=42, 
        ["MND"]=19, 
        ["Magic Accuracy"]=50, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=10, 
        ["item_level"]=119, 
        ["HP"]=45, 
        ["id"]=23735, 
        ["Haste"]=9, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=125, 
        ["MP"]=29, 
        ["Accuracy"]=50, 
        ["INT"]=26, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["en"]="Malignance Tights", 
        ["VIT"]=17, 
        ["DT"]=-7
    }, 
    [125]={
        ["discription"]="MND+8 Magic Accuracy+11 All magic skills +8 \"Refresh\"+1", 
        ["category"]="Armor", 
        ["en"]="Stikini Ring +1", 
        ["All magic skills"]=8, 
        ["MND"]=8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26184, 
        ["Magic Accuracy"]=11
    }, 
    [126]={
        ["Ranged Attack"]=15, 
        ["Ranged Accuracy"]=15, 
        ["discription"]="DEF:9 HP+20 MP+20 Accuracy+15 Ranged Accuracy+15 Attack+15 Ranged Attack+15 Magic Accuracy+7 \"Magic Atk. Bonus\"+7", 
        ["category"]="Armor", 
        ["Magic Atk. Bonus"]=7, 
        ["en"]="Eschan Stone", 
        ["HP"]=20, 
        ["MP"]=20, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["Attack"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=15, 
        ["DEF"]=9, 
        ["id"]=28415, 
        ["Magic Accuracy"]=7
    }, 
    [127]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Migawari\"+5", 
        ["category"]="Armor", 
        ["DT"]=-5, 
        ["en"]="Andartia's Mantle", 
        ["DEX"]=30, 
        ["id"]=26258, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["Attack"]=20
    }, 
    [128]={
        ["Accuracy"]=6, 
        ["en"]="Cessance Earring", 
        ["Store TP"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Accuracy+6 \"Double Attack\"+3% \"Store TP\"+3", 
        ["id"]=27541, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [129]={
        ["discription"]="Enhances \"Double Attack\" effect \"Store TP\"+1", 
        ["Store TP"]=1, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Brutal Earring", 
        ["id"]=14813, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [130]={
        ["discription"]="DMG:157 Delay:227 DEX+15 AGI+15 INT+15 Accuracy+40 Attack+30 Ranged Accuracy+40 Magic Accuracy+40 \"Magic Atk. Bonus\"+16 Magic Damage+217 Katana skill +250 Parrying skill +250 Magic Accuracy skill +250 Main hand: \"Blade: Ku\" \"Blade: Ku\" damage +60% Enhances \"Regain\" based on \"Dual Wield\" effect", 
        ["item_level"]=119, 
        ["Attack"]=30, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=15, 
        ["Ranged Accuracy"]=40, 
        ["en"]="Gokotai", 
        ["Katana skill"]=250, 
        ["AGI"]=15, 
        ["delay"]=227, 
        ["skill"]="Katana", 
        ["Accuracy"]=40, 
        ["INT"]=15, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=21922, 
        ["category"]="Weapon", 
        ["damage"]=157, 
        ["Magic Atk. Bonus"]=16, 
        ["Parrying skill"]=250, 
        ["Magic Accuracy"]=40
    }, 
    [131]={
        ["discription"]="Damage taken -10%", 
        ["id"]=13566, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Defending Ring", 
        ["DT"]=-10, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [132]={
        ["discription"]="DEF:73 HP+15 STR+14 DEX+26 VIT+12 AGI+39 MND+12 CHR+30 Evasion+80 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+5% \"Tactical Parry\"+20 \"Utsusemi\"+1 Set: Augments \"Dual Wield\"", 
        ["MND"]=12, 
        ["Evasion"]=80, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["AGI"]=39, 
        ["item_level"]=119, 
        ["DEF"]=73, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["HP"]=15, 
        ["DEX"]=26, 
        ["id"]=27436, 
        ["STR"]=14, 
        ["Haste"]=5, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=222
        }, 
        ["CHR"]=30, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["en"]="Hattori Kyahan +1"
    }, 
    [133]={
        ["Ranged Attack"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=108, 
        ["DEX"]=28, 
        ["discription"]="DEF:108 HP+38 STR+22 DEX+28 VIT+18 AGI+25 INT+20 MND+16 CHR+17 Attack+15 Ranged Attack+15 \"Magic Atk. Bonus\"+10 Evasion+55 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+8% \"Fast Cast\"+7%", 
        ["augments"]={
            [1]="Accuracy+13", 
            [2]="\"Fast Cast\"+6", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=16, 
        ["id"]=25642, 
        ["STR"]=22, 
        ["Fast Cast"]=13, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["Accuracy"]=13, 
        ["Evasion"]=55, 
        ["INT"]=20, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Haste"]=8, 
        ["AGI"]=25, 
        ["CHR"]=17, 
        ["Magic Atk. Bonus"]=10, 
        ["category"]="Armor", 
        ["en"]="Herculean Helm", 
        ["VIT"]=18, 
        ["Attack"]=15
    }, 
    [134]={
        ["MP"]=30, 
        ["en"]="Orunmila's Torque", 
        ["id"]=10394, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="MP+30 Magic Accuracy+1 \"Fast Cast\" effect+5 Enmity-3", 
        ["Magic Accuracy"]=1, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [135]={
        ["skill"]="(N/A)", 
        ["en"]="Sapience Orb", 
        ["id"]=22252, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["discription"]="Enmity+2 \"Fast Cast\"+2%", 
        ["Fast Cast"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [136]={
        ["Ranged Attack"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["STR"]=22, 
        ["DEX"]=29, 
        ["en"]="Taeon Tabard", 
        ["augments"]={
            [1]="Accuracy+20 Attack+20", 
            [2]="Crit.hit rate+3", 
            [3]="Crit. hit damage +3%", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=21, 
        ["id"]=26893, 
        ["Haste"]=4, 
        ["Fast Cast"]=4, 
        ["item_level"]=119, 
        ["HP"]=59, 
        ["Accuracy"]=20, 
        ["Critical hit damage"]=3, 
        ["slots"]={
            [5]="Body"
        }, 
        ["INT"]=21, 
        ["DEF"]=128, 
        ["MP"]=44, 
        ["discription"]="DEF:128 HP+59 MP+44 STR+22 DEX+29 VIT+22 AGI+28 INT+21 MND+21 CHR+21 Attack+10 Ranged Attack+10 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+4% \"Fast Cast\"+4%", 
        ["CHR"]=21, 
        ["AGI"]=28, 
        ["category"]="Armor", 
        ["Evasion"]=49, 
        ["VIT"]=22, 
        ["Attack"]=30
    }, 
    [137]={
        ["discription"]="MP+30 Enhances \"Fast Cast\" effect", 
        ["id"]=14812, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Loquac. Earring", 
        ["MP"]=30, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [138]={
        ["discription"]="CHR+5 Magic Accuracy+6 \"Fast Cast\"+2%", 
        ["category"]="Armor", 
        ["en"]="Enchntr. Earring +1", 
        ["Fast Cast"]=2, 
        ["CHR"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=28494, 
        ["Magic Accuracy"]=6
    }, 
    [139]={
        ["discription"]="MP+30 Magic Accuracy+5 \"Fast Cast\"+2%", 
        ["category"]="Armor", 
        ["en"]="Rahab Ring", 
        ["Fast Cast"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26162, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=30, 
        ["Magic Accuracy"]=5
    }, 
    [140]={
        ["Evasion"]=24, 
        ["STR"]=11, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=35, 
        ["en"]="Leyline Gloves", 
        ["MND"]=30, 
        ["id"]=27135, 
        ["discription"]="DEF:91 HP+25 STR+11 DEX+35 VIT+32 AGI+5 INT+12 MND+30 CHR+17 Accuracy+18 Magic Accuracy+18 Evasion+24 Magic Evasion+62 \"Magic Atk. Bonus\"+15 \"Magic Def. Bonus\"+2 Haste+5% \"Fast Cast\"+5%", 
        ["Haste"]=5, 
        ["item_level"]=119, 
        ["HP"]=25, 
        ["augments"]={
            [1]="Accuracy+15", 
            [2]="Mag. Acc.+15", 
            [3]="\"Mag.Atk.Bns.\"+15", 
            [4]="\"Fast Cast\"+3", 
            [5]="none"
        }, 
        ["AGI"]=5, 
        ["INT"]=12, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=91, 
        ["Accuracy"]=33, 
        ["CHR"]=17, 
        ["Magic Atk. Bonus"]=30, 
        ["category"]="Armor", 
        ["Fast Cast"]=8, 
        ["VIT"]=32, 
        ["Magic Accuracy"]=33
    }, 
    [141]={
        ["Magic Accuracy"]=5, 
        ["en"]="Kishar Ring", 
        ["id"]=26188, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Magic Accuracy+5 \"Fast Cast\"+4% Enfeebling magic duration +10% \"Absorb\" effect duration +10%", 
        ["Fast Cast"]=4, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [13]="NIN", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [142]={
        ["discription"]="DEF:8 HP+55 STR+3", 
        ["category"]="Armor", 
        ["en"]="Oneiros Belt", 
        ["HP"]=55, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=11773, 
        ["STR"]=3
    }, 
    [143]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Migawari\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["id"]=26258, 
        ["AGI"]=30, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="AGI+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="AGI+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["Attack"]=20
    }, 
    [144]={
        ["Ranged Attack"]=34, 
        ["discription"]="DEF:75 HP+11 STR+15 DEX+23 VIT+8 AGI+42 MND+11 CHR+25 Attack+34 Ranged Attack+34 Evasion+74 Magic Evasion+75 \"Magic Atk. Bonus\"+35 \"Magic Def. Bonus\"+5 Haste+4% \"True Shot\"+2 Critical hit rate +4% Set: Increases rate of critical hits", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=35, 
        ["Critical hit rate"]=4, 
        ["MND"]=11, 
        ["id"]=27474, 
        ["Haste"]=4, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["item_level"]=119, 
        ["HP"]=11, 
        ["augments"]={
            [1]="STR+12", 
            [2]="DEX+12", 
            [3]="Attack+20"
        }, 
        ["AGI"]=42, 
        ["CHR"]=25, 
        ["STR"]=27, 
        ["DEF"]=75, 
        ["en"]="Adhe. Gamashes +1", 
        ["category"]="Armor", 
        ["VIT"]=8, 
        ["Magic Atk. Bonus"]=35, 
        ["Evasion"]=74, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }, 
            ["set id"]=11
        }, 
        ["Attack"]=54
    }, 
    [145]={
        ["Ranged Attack"]=36, 
        ["Evasion"]=49, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=33, 
        ["AGI"]=19, 
        ["MND"]=14, 
        ["STR"]=31, 
        ["discription"]="DEF:102 HP+41 STR+19 DEX+21 VIT+15 AGI+19 INT+14 MND+14 CHR+14 Attack+36 Ranged Attack+36 Evasion+49 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+8% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit damage +6% Set: Increases rate of critical hits", 
        ["Haste"]=8, 
        ["item_level"]=119, 
        ["HP"]=41, 
        ["augments"]={
            [1]="STR+12", 
            [2]="DEX+12", 
            [3]="Attack+20"
        }, 
        ["id"]=25614, 
        ["INT"]=14, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=102, 
        ["en"]="Adhemar Bonnet +1", 
        ["CHR"]=14, 
        ["VIT"]=15, 
        ["category"]="Armor", 
        ["Critical hit damage"]=6, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }, 
            ["set id"]=11
        }, 
        ["Attack"]=56
    }, 
    [146]={
        ["discription"]="Critical hit rate +2% Critical hit damage +6%", 
        ["en"]="Yetshila +1", 
        ["skill"]="(N/A)", 
        ["Critical hit damage"]=6, 
        ["category"]="Weapon", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [13]="NIN", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["id"]=21379, 
        ["Critical hit rate"]=2
    }, 
    [147]={
        ["discription"]="DEX+10 Accuracy+10 Critical hit rate +5%", 
        ["category"]="Armor", 
        ["en"]="Odr Earring", 
        ["DEX"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26108, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Accuracy"]=10, 
        ["Critical hit rate"]=5
    }, 
    [148]={
        ["discription"]="Dusk to dawn: STR+8 DEX+8 VIT+8 INT+8 Unity Ranking: \"Double Attack\"+1～3%", 
        ["category"]="Armor", 
        ["en"]="Lugra Earring +1", 
        ["DEX"]=8, 
        ["STR"]=8, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["INT"]=8, 
        ["id"]=28482, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["VIT"]=8
    }, 
    [149]={
        ["Evasion"]=24, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["STR"]=12, 
        ["DEX"]=50, 
        ["AGI"]=13, 
        ["augments"]={
            [1]="DEX+12", 
            [2]="Accuracy+25", 
            [3]="\"Dbl.Atk.\"+4"
        }, 
        ["MND"]=30, 
        ["Haste"]=4, 
        ["Ranged Accuracy"]=33, 
        ["id"]=27116, 
        ["item_level"]=119, 
        ["HP"]=29, 
        ["Accuracy"]=58, 
        ["Critical hit damage"]=5, 
        ["INT"]=12, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=106, 
        ["discription"]="DEF:106 HP+29 STR+12 DEX+38 VIT+30 AGI+13 INT+12 MND+30 CHR+17 Accuracy+33 Ranged Accuracy+33 Evasion+24 Magic Evasion+32 \"Magic Def. Bonus\"+1 Haste+4% Critical hit rate +5% Critical hit damage +5% Set: Increases Attack", 
        ["CHR"]=17, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Attack"]=20
                }, 
                [3]={
                    ["Attack"]=30
                }, 
                [4]={
                    ["Attack"]=40
                }, 
                [5]={
                    ["Attack"]=50
                }
            }, 
            ["set id"]=239
        }, 
        ["category"]="Armor", 
        ["Critical hit rate"]=5, 
        ["VIT"]=30, 
        ["en"]="Ryuo Tekko +1"
    }, 
    [150]={
        ["Evasion"]=63, 
        ["Magic Accuracy"]=39, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Haste"]=6, 
        ["AGI"]=36, 
        ["MND"]=27, 
        ["Dual Wield"]=10, 
        ["discription"]="DEF:134 HP+82 STR+42 VIT+24 AGI+36 INT+42 MND+27 CHR+20 Accuracy+39 Attack+64 Magic Accuracy+39 Evasion+63 Magic Evasion+84 \"Magic Def. Bonus\"+5 Haste+6% \"Dual Wield\"+10 Weapon skill damage +10%", 
        ["id"]=23611, 
        ["en"]="Mochi. Hakama +3", 
        ["HP"]=82, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Mijin Gakure\" effect", 
            [4]="none"
        }, 
        ["STR"]=42, 
        ["INT"]=42, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=134, 
        ["Accuracy"]=39, 
        ["CHR"]=20, 
        ["VIT"]=24, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["Attack"]=64
    }, 
    [151]={
        ["Ranged Attack"]=20, 
        ["AGI"]=10, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]={
                [1]=91, 
                [2]=9, 
                [3]=47, 
                [4]=87, 
                [5]=6, 
                [6]=46, 
                [7]=133, 
                [8]=45, 
                [9]=84, 
                [10]=129, 
                [11]=92, 
                [12]=10, 
                [13]=50, 
                [14]=88
            }
        }, 
        ["category"]="Armor", 
        ["discription"]="HP+50 STR+10 DEX+10 VIT+10 AGI+10 Attack+20 Ranged Attack+20 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["en"]="Regal Ring", 
        ["HP"]=50, 
        ["STR"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["DEX"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26191, 
        ["VIT"]=10, 
        ["Attack"]=20
    }, 
    [152]={
        ["discription"]="TP not depleted when weapon skill used +1% Latent effect: Weapon Skill Accuracy+10 Weapon skill damage +10%", 
        ["id"]=27510, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Fotia Gorget", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [153]={
        ["discription"]="Accuracy+13 Attack+13 \"Magic Atk. Bonus\"+7 Unity ranking: STR+1～5", 
        ["category"]="Weapon", 
        ["STR"]=1, 
        ["en"]="Seeth. Bomblet +1", 
        ["Magic Atk. Bonus"]=7, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [13]="NIN", 
            [22]="RUN"
        }, 
        ["Accuracy"]=13, 
        ["id"]=22255, 
        ["Attack"]=13
    }, 
    [154]={
        ["Evasion"]=55, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["item_level"]=119, 
        ["DEX"]=45, 
        ["STR"]=38, 
        ["augments"]={
            [1]="STR+12", 
            [2]="DEX+12", 
            [3]="Attack+20"
        }, 
        ["MND"]=20, 
        ["Dual Wield"]=6, 
        ["Ranged Accuracy"]=35, 
        ["Haste"]=4, 
        ["en"]="Adhemar Jacket +1", 
        ["HP"]=63, 
        ["Accuracy"]=35, 
        ["AGI"]=29, 
        ["INT"]=20, 
        ["CHR"]=20, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=133, 
        ["id"]=25687, 
        ["category"]="Armor", 
        ["Ranged Attack"]=35, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }, 
            ["set id"]=11
        }, 
        ["discription"]="DEF:133 HP+63 STR+26 DEX+33 VIT+23 AGI+29 INT+20 MND+20 CHR+20 Accuracy+35 Attack+35 Ranged Accuracy+35 Ranged Attack+35 Evasion+55 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% \"Triple Attack\"+4% Enmity-8 \"Dual Wield\"+6 Set: Increases rate of critical hits", 
        ["VIT"]=23, 
        ["Attack"]=55
    }, 
    [155]={
        ["Accuracy"]=4, 
        ["en"]="Moonshade Earring", 
        ["id"]=11697, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="none", 
        ["augments"]={
            [1]="Accuracy+4", 
            [2]="TP Bonus +250", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [156]={
        ["discription"]="DEF:10 HP+60 DEX+10 AGI+10 Attack+25 \"Store TP\"+5 ", 
        ["category"]="Armor", 
        ["DEX"]=10, 
        ["en"]="Ilabrat Ring", 
        ["Store TP"]=5, 
        ["HP"]=60, 
        ["AGI"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26186, 
        ["DEF"]=10, 
        ["Attack"]=25
    }, 
    [157]={
        ["Evasion"]=36, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["STR"]=27, 
        ["DEX"]=56, 
        ["AGI"]=7, 
        ["augments"]={
            [1]="STR+12", 
            [2]="DEX+12", 
            [3]="Attack+20"
        }, 
        ["MND"]=30, 
        ["discription"]="DEF:93 HP+22 STR+15 DEX+44 VIT+29 AGI+7 INT+12 MND+30 CHR+17 Accuracy+32 Ranged Accuracy+32 Evasion+36 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+4% \"Store TP\"+7 Set: Increases rate of critical hits", 
        ["Ranged Accuracy"]=32, 
        ["Store TP"]=7, 
        ["item_level"]=119, 
        ["HP"]=22, 
        ["Accuracy"]=32, 
        ["id"]=27118, 
        ["INT"]=12, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=93, 
        ["Haste"]=5, 
        ["CHR"]=17, 
        ["en"]="Adhemar Wrist. +1", 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }, 
            ["set id"]=11
        }, 
        ["VIT"]=29, 
        ["Attack"]=20
    }, 
    [158]={
        ["Evasion"]=77, 
        ["MND"]=31, 
        ["AGI"]=21, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=12, 
        ["discription"]="DEF:115 STR+46 VIT+15 AGI+21 INT+30 MND+31 CHR+8 Attack+43 Evasion+77 Magic Evasion+64 \"Magic Def. Bonus\"+3 Haste+6% \"Store TP\"+8 \"Regen\"+3 Set: Augments \"Martial Arts\"", 
        ["item_level"]=119, 
        ["Haste"]=6, 
        ["Store TP"]=8, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Rao Haidate +1", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Martial Arts"]=8
                }, 
                [3]={
                    ["Martial Arts"]=12
                }, 
                [4]={
                    ["Martial Arts"]=16
                }, 
                [5]={
                    ["Martial Arts"]=20
                }
            }, 
            ["set id"]=144
        }, 
        ["INT"]=30, 
        ["STR"]=58, 
        ["DEF"]=115, 
        ["augments"]={
            [1]="STR+12", 
            [2]="DEX+12", 
            [3]="Attack+20"
        }, 
        ["CHR"]=8, 
        ["VIT"]=15, 
        ["category"]="Armor", 
        ["id"]=27203, 
        ["Attack"]=63
    }, 
    [159]={
        ["discription"]="DEF:7 \"Conserve TP\"+7 TP not depleted when weapon skill used +1% Latent effect: Weapon Skill Accuracy+10 Weapon skill damage +10%", 
        ["DEF"]=7, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Fotia Belt", 
        ["id"]=28420, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [160]={
        ["skill"]="Throwing", 
        ["Ranged Accuracy"]=5, 
        ["Throwing skill"]=242, 
        ["Evasion"]=5, 
        ["category"]="Weapon", 
        ["AGI"]=5, 
        ["en"]="Date Shuriken", 
        ["delay"]=192, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=5, 
        ["discription"]="DMG:125 Delay:192 DEX+5 AGI+5 Accuracy+5 Ranged Accuracy+5 Evasion+5 Throwing skill +242 Enmity +3", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["item_level"]=119, 
        ["id"]=22292, 
        ["Accuracy"]=5, 
        ["damage"]=125
    }, 
    [161]={
        ["Ranged Attack"]=10, 
        ["DEX"]=24, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Evasion"]=80, 
        ["augments"]={
            [1]="Mag. Acc.+4", 
            [2]="\"Fast Cast\"+6", 
            [3]="INT+7", 
            [4]="none", 
            [5]="none"
        }, 
        ["Accuracy"]=10, 
        ["PDT"]=-2, 
        ["Ranged Accuracy"]=10, 
        ["item_level"]=119, 
        ["MND"]=11, 
        ["en"]="Herculean Boots", 
        ["discription"]="DEF:79 HP+9 STR+16 DEX+24 VIT+10 AGI+43 MND+11 CHR+26 Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+5 Evasion+80 Magic Evasion+75 Haste+4% \"Triple Attack\"+2 \"Subtle Blow\"+6 Physical damage taken -2%", 
        ["HP"]=9, 
        ["Haste"]=4, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["INT"]=7, 
        ["CHR"]=26, 
        ["STR"]=16, 
        ["DEF"]=79, 
        ["AGI"]=43, 
        ["Fast Cast"]=6, 
        ["Attack"]=10, 
        ["VIT"]=10, 
        ["category"]="Armor", 
        ["id"]=27496, 
        ["Magic Atk. Bonus"]=10, 
        ["Magic Accuracy"]=14
    }, 
    [162]={
        ["MDT"]=-4, 
        ["DEX"]=33, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["STR"]=26, 
        ["augments"]={
            [1]="HP+105", 
            [2]="\"Fast Cast\"+10", 
            [3]="Magic dmg. taken -4"
        }, 
        ["Accuracy"]=35, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=35, 
        ["Haste"]=4, 
        ["MND"]=20, 
        ["en"]="Adhemar Jacket +1", 
        ["Dual Wield"]=6, 
        ["HP"]=168, 
        ["id"]=25687, 
        ["discription"]="DEF:133 HP+63 STR+26 DEX+33 VIT+23 AGI+29 INT+20 MND+20 CHR+20 Accuracy+35 Attack+35 Ranged Accuracy+35 Ranged Attack+35 Evasion+55 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% \"Triple Attack\"+4% Enmity-8 \"Dual Wield\"+6 Set: Increases rate of critical hits", 
        ["slots"]={
            [5]="Body"
        }, 
        ["INT"]=20, 
        ["DEF"]=133, 
        ["Evasion"]=55, 
        ["AGI"]=29, 
        ["CHR"]=20, 
        ["Fast Cast"]=10, 
        ["VIT"]=23, 
        ["category"]="Armor", 
        ["Ranged Attack"]=35, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }, 
            ["set id"]=11
        }, 
        ["Attack"]=35
    }, 
    [163]={
        ["Ranged Attack"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=6, 
        ["Evasion"]=62, 
        ["AGI"]=32, 
        ["augments"]={
            [1]="Mag. Acc.+14 \"Mag.Atk.Bns.\"+14", 
            [2]="\"Fast Cast\"+6", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=15, 
        ["STR"]=33, 
        ["discription"]="DEF:114 HP+38 STR+33 VIT+16 AGI+32 INT+29 MND+15 CHR+10 Attack+15 Ranged Attack+15 Evasion+62 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% Enmity-4 \"Store TP\"+4 Physical damage taken -2%", 
        ["Store TP"]=4, 
        ["en"]="Herculean Trousers", 
        ["HP"]=38, 
        ["item_level"]=119, 
        ["VIT"]=16, 
        ["INT"]=29, 
        ["CHR"]=10, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=114, 
        ["id"]=25842, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=14, 
        ["Magic Atk. Bonus"]=14, 
        ["Fast Cast"]=6, 
        ["PDT"]=-2, 
        ["Attack"]=15
    }, 
    [164]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Migawari\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["HP"]=60, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="HP+60", 
            [2]="Eva.+20 /Mag. Eva.+20", 
            [3]="none", 
            [4]="Enmity+10", 
            [5]="System: 1 ID: 640 Val: 4"
        }, 
        ["id"]=26258
    }, 
    [165]={
        ["id"]=26037, 
        ["en"]="Moonlight Necklace", 
        ["DEF"]=16, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:16 Magic Accuracy+15 Magic Evasion+15 Enmity+15 Spell interruption rate down 15%", 
        ["Magic Accuracy"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [7]="PLD", 
            [13]="NIN", 
            [22]="RUN"
        }
    }, 
    [166]={
        ["Evasion"]=70, 
        ["AGI"]=23, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=24, 
        ["id"]=26871, 
        ["MND"]=23, 
        ["Haste"]=4, 
        ["discription"]="DEF:131 HP+61 STR+25 DEX+24 VIT+25 AGI+23 INT+23 MND+23 CHR+23 Evasion+70 Magic Evasion+64 \"Magic Def. Bonus\"+5 Haste+4% Enmity+10 Physical damage taken -6% Unity Ranking: Accuracy+10～20", 
        ["item_level"]=119, 
        ["en"]="Emet Harness +1", 
        ["HP"]=61, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["VIT"]=25, 
        ["Unity Ranking Bonus Applied"]="Accuracy + 20", 
        ["STR"]=25, 
        ["DEF"]=131, 
        ["Accuracy"]=20, 
        ["INT"]=23, 
        ["category"]="Armor", 
        ["CHR"]=23, 
        ["PDT"]=-6, 
        ["slots"]={
            [5]="Body"
        }
    }, 
    [167]={
        ["discription"]="Katana skill +5 Enmity+5 \"Double Attack\"+3%", 
        ["id"]=28515, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Trux Earring", 
        ["Katana skill"]=5, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [168]={
        ["discription"]="HP+40 Enmity+4 \"Counter\"+3", 
        ["id"]=28483, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Cryptic Earring", 
        ["HP"]=40, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [169]={
        ["discription"]="HP+30 MP+30 VIT+5 Accuracy+7 Enmity+5", 
        ["category"]="Armor", 
        ["en"]="Supershear Ring", 
        ["MP"]=30, 
        ["HP"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=28535, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=7, 
        ["VIT"]=5
    }, 
    [170]={
        ["Evasion"]=44, 
        ["MND"]=30, 
        ["AGI"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=35, 
        ["discription"]="DEF:92 HP+25 STR+11 DEX+35 VIT+32 AGI+5 INT+12 MND+30 CHR+17 Accuracy+20 Evasion+44 Magic Evasion+57 \"Magic Def. Bonus\"+2 Haste+5% Enmity+9 Damage taken -2%", 
        ["en"]="Kurys Gloves", 
        ["Haste"]=5, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["HP"]=25, 
        ["item_level"]=119, 
        ["Accuracy"]=20, 
        ["STR"]=11, 
        ["DEF"]=92, 
        ["id"]=27134, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["VIT"]=32, 
        ["DT"]=-2
    }, 
    [171]={
        ["Evasion"]=38, 
        ["MND"]=17, 
        ["AGI"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["discription"]="DEF:111 HP+47 STR+29 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Evasion+38 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% Enmity+6 \"Triple Attack\"+3% \"Store TP\"-5 Unity Ranking: \"Double Attack\"+1～5%", 
        ["item_level"]=119, 
        ["Haste"]=6, 
        ["Store TP"]=-5, 
        ["HP"]=47, 
        ["id"]=27231, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["STR"]=29, 
        ["DEF"]=111, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["VIT"]=16, 
        ["en"]="Zoar Subligar +1"
    }, 
    [172]={
        ["discription"]="HP+70 Enmity+5  Enhances resistance against \"Death\"", 
        ["id"]=10798, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Eihwaz Ring", 
        ["HP"]=70, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [173]={
        ["id"]=15895, 
        ["en"]="Trance Belt", 
        ["DEF"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:5 HP+14 Enmity+4", 
        ["HP"]=14, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [174]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Migawari\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["id"]=26258, 
        ["AGI"]=30, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="AGI+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="AGI+10", 
            [4]="Crit.hit rate+10", 
            [5]="none"
        }, 
        ["Attack"]=20
    }, 
    [175]={
        ["discription"]="DEF:11 VIT+9 CHR+9 \"Resist Charm\"+9 Enmity+10 Unity Ranking: Accuracy+1～5", 
        ["category"]="Armor", 
        ["CHR"]=9, 
        ["en"]="Unmoving Collar +1", 
        ["Unity Ranking Bonus Applied"]="Accuracy + 5", 
        ["id"]=27509, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=11, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=5, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["VIT"]=9
    }
}