return {
    [1]={
        ["discription"]="A legendary fishing rod that appears in Far Eastern mythology.", 
        ["skill"]="Fishing", 
        ["slots"]={
            [2]="Range"
        }, 
        ["id"]=17011, 
        ["en"]="Ebisu Fishing Rod", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [2]={
        ["discription"]="Dispense: Angelwing", 
        ["en"]="Redeyes", 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=16120, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [3]={
        ["discription"]="A fishing apparatus comprised of  several hooks. The hooks are designed to latch on  to the fish's scales.", 
        ["skill"]="Fishing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=17398, 
        ["en"]="Rogue Rig", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [4]={
        ["discription"]="DEF:4 +2 +2 Fishing skill +1 Reduces chances of fishing up items ", 
        ["DEF"]=4, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Fisherman's Smock", 
        ["id"]=11337, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [5]={
        ["discription"]="Enchantment: Increases skill at tiring fish", 
        ["en"]="Penguin Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15556, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [6]={
        ["discription"]="A fishing apparatus comprised of  several baited hooks. Designed for catching small fish.", 
        ["skill"]="Fishing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=17399, 
        ["en"]="Sabiki Rig", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [7]={
        ["discription"]="Fishing support: Reduces fish stamina recovery", 
        ["en"]="Heron Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15846, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [8]={
        ["discription"]="DEF:1  Fishing skill +1", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Fsh. Gloves", 
        ["id"]=14070, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [9]={
        ["discription"]="DEF:1 +2 +2", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Fisherman's Cuffs", 
        ["id"]=15051, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [10]={
        ["discription"]="Enchantment: Increases skill at tiring fish", 
        ["en"]="Penguin Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15556, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [11]={
        ["discription"]="DEF:1 Fishing skill +1", 
        ["DEF"]=1, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Fisherman's Hose", 
        ["id"]=14292, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [12]={
        ["discription"]="DEF:2 +1 Fishing skill +2", 
        ["DEF"]=2, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Waders", 
        ["id"]=14195, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [13]={
        ["discription"]="Enchantment: Increases stamina while fishing", 
        ["en"]="Albatross Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15555, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [14]={
        ["discription"]="A small cephalopod with a characteristic pointed shell. Bait.", 
        ["skill"]="Fishing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=17006, 
        ["en"]="Drill Calamary", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [15]={
        ["discription"]="Fishing skill +2", 
        ["en"]="Fisher's Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=10925, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [16]={
        ["discription"]="An extremely rare species of tiny pugil. Bait.", 
        ["skill"]="Fishing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=17007, 
        ["en"]="Dwarf Pugil", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [17]={
        ["discription"]="A fishing lure made in the shape of  a small fish. Designed for catching bottom fish.", 
        ["skill"]="Fishing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=17400, 
        ["en"]="Sinking Minnow", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [18]={
        ["discription"]="A fishing lure made in the shape of  a frog. ", 
        ["skill"]="Fishing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=17403, 
        ["en"]="Frog Lure", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [19]={
        ["discription"]="A fishing lure made in the shape of  a shrimp. ", 
        ["skill"]="Fishing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=17402, 
        ["en"]="Shrimp Lure", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [20]={
        ["discription"]="Angler's Discernment +1", 
        ["en"]="Fisher's Rope", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=11768, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [21]={
        ["discription"]="A fishing lure made in the shape of  a worm. ", 
        ["skill"]="Fishing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=17404, 
        ["en"]="Worm Lure", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [22]={
        ["discription"]="A fishing lure made in the shape of  a caterpillar. ", 
        ["skill"]="Fishing", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=17405, 
        ["en"]="Fly Lure", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [23]={
        ["discription"]="Fishing skill (journeyman and above): Increases chances of fishing up large prey. ", 
        ["en"]="Puffin Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=11654, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [24]={
        ["discription"]="Fishing skill (artisan and above): Reduces chances of fishing up monsters.", 
        ["en"]="Noddy Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=11655, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [25]={
        ["discription"]="Enchantment: Increases stamina while fishing", 
        ["en"]="Albatross Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15555, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [26]={
        ["discription"]="Fishing support: Increases fish stamina reduction", 
        ["en"]="Seagull Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15845, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [27]={
        ["discription"]="Enchantment: Fishy Intuition", 
        ["en"]="Duck Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28570, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [28]={
        ["discription"]="A legendary fishing rod believed to  have caught a sea dragon. ", 
        ["skill"]="Fishing", 
        ["slots"]={
            [2]="Range"
        }, 
        ["id"]=17386, 
        ["en"]="Lu Shang's F. Rod", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [29]={
        ["discription"]="Campaign: STR+2 DEX+2", 
        ["en"]="Fullmetal Bullet", 
        ["STR"]=2, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=19214, 
        ["DEX"]=2
    }, 
    [30]={
        ["discription"]="DMG:19 Delay:183 AGI+3 Attack+7 Additional effect: Silence", 
        ["category"]="Weapon", 
        ["en"]="Garuda's Dagger", 
        ["AGI"]=3, 
        ["delay"]=183, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["damage"]=19, 
        ["id"]=17627, 
        ["skill"]="Dagger", 
        ["Attack"]=7
    }, 
    [31]={
        ["discription"]="Daytime: HP+30 Nighttime: Evasion+10", 
        ["en"]="Fenrir's Stone", 
        ["Evasion"]=10, 
        ["HP"]=30, 
        ["category"]="Weapon", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18165, 
        ["slots"]={
            [3]="Ammo"
        }
    }, 
    [32]={
        ["discription"]="DEF:2 Enhances chocobo digging endurance", 
        ["DEF"]=2, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Blue Race Silks", 
        ["id"]=11325, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [33]={
        ["en"]="Carbuncle Mitts", 
        ["id"]=14062, 
        ["DEF"]=5, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:5 MP+14", 
        ["MP"]=14, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [34]={
        ["discription"]="DMG:65 Delay:420 Latent effect: DMG:78 Critical hit rate +6%", 
        ["en"]="Michishiba", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=420, 
        ["category"]="Weapon", 
        ["skill"]="Great Katana", 
        ["jobs"]={
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["id"]=17827, 
        ["damage"]=65
    }, 
    [35]={
        ["discription"]="DEF:2 Enhances chocobo caring ability", 
        ["DEF"]=2, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Green Race Silks", 
        ["id"]=11328, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [36]={
        ["discription"]="DMG:57 Delay:402 Dark weather: Enhances effect of \"Drain\" and \"Aspir\" Additional effect: \"Slow\"", 
        ["en"]="Diabolos's Pole", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=402, 
        ["category"]="Weapon", 
        ["skill"]="Staff", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=17599, 
        ["damage"]=57
    }, 
    [37]={
        ["discription"]="DMG:16 Delay:150 DEX+1 AGI+1", 
        ["category"]="Weapon", 
        ["en"]="Hornetneedle", 
        ["skill"]="Dagger", 
        ["delay"]=150, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [5]="RDM", 
            [6]="THF", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN"
        }, 
        ["AGI"]=1, 
        ["id"]=17980, 
        ["DEX"]=1, 
        ["damage"]=16
    }, 
    [38]={
        ["discription"]="DEF:1 +3", 
        ["DEF"]=1, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Straw Hat", 
        ["id"]=27733, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [39]={
        ["discription"]="DMG:22 Delay:278 VIT+3  Additional effect: Earth damage", 
        ["category"]="Weapon", 
        ["en"]="Titan's Cudgel", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=278, 
        ["damage"]=22, 
        ["skill"]="Club", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=17438, 
        ["VIT"]=3
    }, 
    [40]={
        ["id"]=15515, 
        ["en"]="Peacock Amulet", 
        ["category"]="Armor", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=10, 
        ["discription"]="-10 Accuracy+10 Ranged Accuracy+10", 
        ["Ranged Accuracy"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [41]={
        ["MDT"]=-5, 
        ["en"]="Resentment Cape", 
        ["DEF"]=8, 
        ["slots"]={
            [15]="Back"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:8 Enmity+2 In areas outside own nation's control: Magic damage taken -5%", 
        ["id"]=15468, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [42]={
        ["discription"]="DEF:11", 
        ["DEF"]=11, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Dune Boots", 
        ["id"]=14168, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [9]="BST", 
            [10]="BRD", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [43]={
        ["discription"]="DMG:11 Delay:600 AGI+1", 
        ["category"]="Weapon", 
        ["en"]="Firefly", 
        ["slots"]={
            [2]="Range"
        }, 
        ["delay"]=600, 
        ["AGI"]=1, 
        ["skill"]="Marksmanship", 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR"
        }, 
        ["id"]=19221, 
        ["damage"]=11
    }, 
    [44]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=11546, 
        ["DEF"]=6, 
        ["slots"]={
            [15]="Back"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:6 Attack+8 \"Double Attack\"+1% On Darksdays: \"Double Attack\"+2%", 
        ["en"]="Aesir Mantle", 
        ["Attack"]=8
    }, 
    [45]={
        ["discription"]="DMG:+11 Delay:+60 INT+3 Accuracy+8  Additional effect: Paralysis", 
        ["category"]="Weapon", 
        ["en"]="Shiva's Claws", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=60, 
        ["INT"]=3, 
        ["skill"]="Hand-to-Hand", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [13]="NIN", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["Accuracy"]=8, 
        ["id"]=17492, 
        ["damage"]=11
    }, 
    [46]={
        ["discription"]="Woodworking skill +2", 
        ["en"]="Carver's Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=10948, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [47]={
        ["discription"]="Improves mining, logging, and harvesting success rate", 
        ["en"]="Field Rope", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=11769, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [48]={
        ["discription"]="+20 Elemental magic skill +7 Dark magic skill +7 On Darksdays: Elemental magic skill +10 Dark magic skill +10", 
        ["en"]="Aesir Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=11589, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [49]={
        ["discription"]="Enchantment: Teleport (Party Leader)", 
        ["en"]="Nexus Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=11538, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [50]={
        ["discription"]="+20 Healing magic skill +7 Enhancing magic skill +7 On Lightsdays: Healing magic skill +10 Enhancing magic skill +10", 
        ["en"]="Colossus's Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=11590, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [51]={
        ["discription"]="DMG:36 Delay:236 STR+3 Attack+10 Additional effect: Fire damage", 
        ["category"]="Weapon", 
        ["en"]="Ifrit's Blade", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=236, 
        ["STR"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [16]="BLU"
        }, 
        ["damage"]=36, 
        ["id"]=17665, 
        ["skill"]="Sword", 
        ["Attack"]=10
    }, 
    [52]={
        ["id"]=21460, 
        ["en"]="Matre Bell", 
        ["slots"]={
            [2]="Range"
        }, 
        ["skill"]="Handbell", 
        ["category"]="Weapon", 
        ["discription"]="MP+5", 
        ["MP"]=5, 
        ["jobs"]={
            [21]="GEO"
        }
    }, 
    [53]={
        ["discription"]="Attack+7 \"Conserve TP\"+3 Dark weather: \"Conserve TP\"+6", 
        ["en"]="Aesir Ear Pendant", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=16057, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["Attack"]=7
    }, 
    [54]={
        ["discription"]="HP+10 MP+10 Physical damage taken -1% Light weather: Physical damage taken -2%", 
        ["category"]="Armor", 
        ["en"]="Colossus's Earring", 
        ["HP"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=16058, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["MP"]=10, 
        ["PDT"]=-2
    }, 
    [55]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Volunteer's Dart", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="Besieged: Attack+10 ", 
        ["id"]=18689, 
        ["Attack"]=10
    }, 
    [56]={
        ["MDT"]=-2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Lieutenant's Sash", 
        ["BDT"]=-2, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=15912, 
        ["DEF"]=5, 
        ["discription"]="DEF:5 HP+15 MP+15 Magic damage taken -2% Breath damage taken -2% Enchantment: Removes food effect", 
        ["MP"]=15, 
        ["HP"]=15
    }, 
    [57]={
        ["discription"]="Enchantment: Costume", 
        ["en"]="Goblin Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=15929, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [58]={
        ["discription"]="DMG:9 Delay:286 AGI+1", 
        ["category"]="Weapon", 
        ["en"]="Rogetsurin", 
        ["slots"]={
            [2]="Range"
        }, 
        ["delay"]=286, 
        ["AGI"]=1, 
        ["skill"]="Throwing", 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["id"]=18246, 
        ["damage"]=9
    }, 
    [59]={
        ["discription"]="DEF:26 Adds \"Regen\" effect Light Spirit perpetuation cost -1", 
        ["DEF"]=26, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Nimbus Doublet", 
        ["id"]=14410, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [15]="SMN"
        }
    }, 
    [60]={
        ["discription"]="DEF:32 Ranged Accuracy+2 Haste+4%", 
        ["Ranged Accuracy"]=2, 
        ["category"]="Armor", 
        ["en"]="Rapparee Harness", 
        ["jobs"]={
            [6]="THF", 
            [19]="DNC"
        }, 
        ["DEF"]=32, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=14403, 
        ["Haste"]=4
    }, 
    [61]={
        ["discription"]="DMG:1 Delay:999 +3", 
        ["en"]="Hoe", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=999, 
        ["category"]="Weapon", 
        ["skill"]="Scythe", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=20909, 
        ["damage"]=1
    }, 
    [62]={
        ["discription"]="DEF:3 DEX+3 AGI+3", 
        ["category"]="Armor", 
        ["en"]="Bounding Boots", 
        ["AGI"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=3, 
        ["DEX"]=3, 
        ["id"]=15351, 
        ["slots"]={
            [8]="Feet"
        }
    }, 
    [63]={
        ["Parrying skill"]=5, 
        ["category"]="Armor", 
        ["en"]="Prf. Gloves", 
        ["Evasion skill"]=5, 
        ["discription"]="DEF:11  In areas outside own nation's control:  VIT+2 Evasion skill +5  Parrying skill +5", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=11, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=14015, 
        ["VIT"]=2
    }, 
    [64]={
        ["discription"]="DEF:15  In areas outside own nation's control:  AGI+2 Evasion skill +10", 
        ["category"]="Armor", 
        ["en"]="Mst.Cst. Mitts", 
        ["AGI"]=2, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [9]="BST", 
            [10]="BRD", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=15, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=14016, 
        ["Evasion skill"]=10
    }, 
    [65]={
        ["discription"]="DEF:28 MP+20 Accuracy+6 Besieged: MP+100", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["category"]="Armor", 
        ["en"]="Volunteer's Brais", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15623, 
        ["DEF"]=28, 
        ["Accuracy"]=6, 
        ["MP"]=100
    }, 
    [66]={
        ["discription"]="In areas outside own nation's control:  MP+50", 
        ["category"]="Armor", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=13141, 
        ["en"]="Rep.Gold Medal", 
        ["MP"]=50, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [67]={
        ["discription"]="DEF:36 Wyvern: HP+65 HP recovered while healing +1", 
        ["DEF"]=36, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Wyvern Mail", 
        ["id"]=14405, 
        ["category"]="Armor", 
        ["jobs"]={
            [14]="DRG"
        }
    }, 
    [68]={
        ["discription"]="DEF:9 STR+2 MND+2", 
        ["MND"]=2, 
        ["category"]="Armor", 
        ["en"]="Ryl. Army Mantle", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=9, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=13580, 
        ["STR"]=2
    }, 
    [69]={
        ["discription"]="DEF:6 HP+6 DEX+2 VIT+2", 
        ["category"]="Armor", 
        ["en"]="Rep. Army Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["HP"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=6, 
        ["DEX"]=2, 
        ["id"]=13582, 
        ["VIT"]=2
    }, 
    [70]={
        ["discription"]="DEF:18  In areas outside own nation's control:  Adds \"Regen\" effect", 
        ["DEF"]=18, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="President. Hairpin", 
        ["id"]=13880, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [13]="NIN", 
            [14]="DRG", 
            [19]="DNC"
        }
    }, 
    [71]={
        ["discription"]="DMG:1 Delay:288  Enchantment: Give gift to party member (Cannot target self)", 
        ["en"]="Nmd. Moogle Rod", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=288, 
        ["category"]="Weapon", 
        ["skill"]="Club", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18842, 
        ["damage"]=1
    }, 
    [72]={
        ["discription"]="DMG:1 Delay:366 Enchantment: \"Retrace\" (San d'Oria)", 
        ["en"]="Ram Staff", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["skill"]="Staff", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18612, 
        ["damage"]=1
    }, 
    [73]={
        ["discription"]="DMG:55 Delay:402 CHR+4 TP Bonus Latent effect: Light damage Enchantment: Recover HP", 
        ["category"]="Weapon", 
        ["en"]="Carbuncle's Pole", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=402, 
        ["CHR"]=4, 
        ["skill"]="Staff", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18581, 
        ["damage"]=55
    }, 
    [74]={
        ["discription"]="DMG:1 Delay:366 Enchantment: \"Retrace\" (Windurst)", 
        ["en"]="Cobra Staff", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["skill"]="Staff", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18614, 
        ["damage"]=1
    }, 
    [75]={
        ["discription"]="DEF:3～", 
        ["DEF"]=3, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Variable Mantle", 
        ["id"]=13680, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [76]={
        ["discription"]="DEF:28 Accuracy+3 Attack+3", 
        ["jobs"]={
            [5]="RDM", 
            [10]="BRD", 
            [16]="BLU", 
            [18]="PUP", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Cerise Doublet", 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=14407, 
        ["DEF"]=28, 
        ["Accuracy"]=3, 
        ["Attack"]=3
    }, 
    [77]={
        ["discription"]="Enchantment: DEX+1～8", 
        ["DEX"]=1, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15770, 
        ["en"]="Random Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [78]={
        ["discription"]="Enchantment: Fishing support", 
        ["en"]="Fisherman's Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=15452, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [79]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Yoran Unity Shirt", 
        ["id"]=25743, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [80]={
        ["discription"]="DEF:6 MP+6 AGI+2 INT+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["INT"]=2, 
        ["category"]="Armor", 
        ["en"]="Fed. Army Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=13581, 
        ["DEF"]=6, 
        ["MP"]=6, 
        ["AGI"]=2
    }, 
    [81]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Fenrir's Earring", 
        ["id"]=13399, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Daytime: Attack+10 Nighttime: Ranged Attack+10", 
        ["Ranged Attack"]=10, 
        ["Attack"]=10
    }, 
    [82]={
        ["en"]="Key Ring Belt", 
        ["id"]=15880, 
        ["DEF"]=2, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:2 DEX+1 \"Steal\"+1 Dispense: Skeleton Key", 
        ["DEX"]=1, 
        ["jobs"]={
            [6]="THF"
        }
    }, 
    [83]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Councilor's Cuffs", 
        ["id"]=28063, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [84]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Diabolos's Earring", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Accuracy"]=-3, 
        ["discription"]="Accuracy+3 Dark weather: Accuracy-3 Magic Accuracy+2", 
        ["id"]=14814, 
        ["Magic Accuracy"]=2
    }, 
    [85]={
        ["discription"]="DEF:1 While in Adoulin: Movement speed +25%", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Councilor's Garb", 
        ["id"]=27923, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [86]={
        ["discription"]="DMG:1 Delay:366 Enchantment: \"Retrace\" (Bastok)", 
        ["en"]="Fourth Staff", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["skill"]="Staff", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18613, 
        ["damage"]=1
    }, 
    [87]={
        ["discription"]="A dark orichalcum crown set with glittering painites. The message \"Gifted to the champion of Aht Urhgan by Her Magnificence, Nashmeira II\" is inscribed on the inside of the crown.", 
        ["en"]="Glory Crown", 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=16070, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [88]={
        ["discription"]="DEF:33 Enhances \"Souleater\" effect", 
        ["DEF"]=33, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Gloom Breastplate", 
        ["id"]=14409, 
        ["category"]="Armor", 
        ["jobs"]={
            [8]="DRK"
        }
    }, 
    [89]={
        ["discription"]="HP+10 Increases combat skill gain rate", 
        ["HP"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=11040, 
        ["en"]="Terminus Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [90]={
        ["discription"]="MP+10 Increases magic skill gain rate", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=11041, 
        ["en"]="Liminus Earring", 
        ["MP"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [91]={
        ["id"]=11677, 
        ["en"]="Prouesse Ring", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=10, 
        ["discription"]="HP+10 MP+10 Increases combat skill gain rate", 
        ["HP"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [92]={
        ["discription"]="Enchantment: \"Teleport\" (Wajaom Woodlands)", 
        ["en"]="Olduum Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15769, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [93]={
        ["discription"]="Cannot Equip Leggear DEF:2 +3", 
        ["DEF"]=2, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Overalls", 
        ["id"]=27879, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [94]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Alliance Shirt", 
        ["id"]=27899, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [95]={
        ["discription"]="DEF:6 DEX+1 AGI+1 In areas outside own nation's control: Converts 40 MP to HP", 
        ["category"]="Armor", 
        ["en"]="Intruder Earring", 
        ["AGI"]=1, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=6, 
        ["DEX"]=1, 
        ["id"]=14806, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }
    }, 
    [96]={
        ["discription"]="DEF:1 +3", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Work Gloves", 
        ["id"]=28023, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [97]={
        ["discription"]="DEF:1 Enchantment: \"Teleport\" (Castle Zvahl Keep)", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Shadow Lord Shirt", 
        ["id"]=26517, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [98]={
        ["discription"]="DEF:10 +10 +10 +10 +10 +10 +10 -50 +10 Enchantment: Calls Choplix", 
        ["DEF"]=10, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Choplix's Coif", 
        ["id"]=15217, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [99]={
        ["discription"]="DEF:6 MP+12 INT+1 MND+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["INT"]=1, 
        ["MND"]=2, 
        ["category"]="Armor", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=12973, 
        ["DEF"]=6, 
        ["MP"]=12, 
        ["en"]="Mannequin Pumps"
    }, 
    [100]={
        ["discription"]="DEF:1 +3", 
        ["DEF"]=1, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Thatch Boots", 
        ["id"]=28302, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [101]={
        ["discription"]="STR+1 INT+1", 
        ["category"]="Weapon", 
        ["en"]="Balm Sachet", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["INT"]=1, 
        ["STR"]=1, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18247, 
        ["skill"]="(N/A)"
    }, 
    [102]={
        ["discription"]="STR+1 DEX+1 VIT+1  AGI+1 INT+1 MND+1 CHR-7", 
        ["category"]="Armor", 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Opo-opo Crown", 
        ["AGI"]=1, 
        ["CHR"]=-7, 
        ["MND"]=1, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=13870, 
        ["INT"]=1, 
        ["STR"]=1, 
        ["DEX"]=1, 
        ["VIT"]=1
    }, 
    [103]={
        ["discription"]="DEF:26 \"Conserve MP\"+4 Dark Spirit perpetuation cost -1", 
        ["DEF"]=26, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Duende Cotehardie", 
        ["id"]=14401, 
        ["category"]="Armor", 
        ["jobs"]={
            [4]="BLM", 
            [15]="SMN", 
            [21]="GEO"
        }
    }, 
    [104]={
        ["en"]="Nokizaru Gi", 
        ["id"]=14402, 
        ["DEF"]=31, 
        ["slots"]={
            [5]="Body"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:31 AGI+4 Enmity+1", 
        ["AGI"]=4, 
        ["jobs"]={
            [13]="NIN"
        }
    }, 
    [105]={
        ["discription"]="DEF:50 INT+13 MND+13 CHR+13 Summoning magic skill +10 Light Elemental Magic Accuracy+10 Enmity-5", 
        ["MND"]=13, 
        ["category"]="Armor", 
        ["en"]="Augur's Jaseran", 
        ["CHR"]=13, 
        ["INT"]=13, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=14365, 
        ["DEF"]=50, 
        ["Magic Accuracy"]=10
    }, 
    [106]={
        ["en"]="Zelus Tiara", 
        ["id"]=11799, 
        ["Haste"]=8, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="Evasion-5 Haste+8%", 
        ["Evasion"]=-5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [107]={
        ["discription"]="DMG:55 Delay:224 HP+50 MP+50 STR+10 VIT+10 Resistance against terror", 
        ["category"]="Weapon", 
        ["delay"]=224, 
        ["en"]="Talekeeper", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["HP"]=50, 
        ["STR"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [14]="DRG", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["MP"]=50, 
        ["damage"]=55, 
        ["id"]=18903, 
        ["skill"]="Sword", 
        ["VIT"]=10
    }, 
    [108]={
        ["Store TP"]=5, 
        ["en"]="Goading Belt", 
        ["Haste"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="Haste+5% \"Store TP\"+5 Enmity+3", 
        ["id"]=11729, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [109]={
        ["discription"]="Haste+6%", 
        ["Haste"]=6, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Velocious Belt", 
        ["id"]=15899, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [110]={
        ["en"]="Auspex Gages", 
        ["id"]=10537, 
        ["DEF"]=28, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:28 MP+50 Spell interruption rate down 17% Enhances avatar attack Increases \"Blood Pact\" damage", 
        ["MP"]=50, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [111]={
        ["discription"]="HP+30 MP+30 Haste+5%", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Walahra Turban", 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15270, 
        ["Haste"]=5, 
        ["MP"]=30, 
        ["HP"]=30
    }, 
    [112]={
        ["discription"]="DMG:45 Delay:222 DEX+10 Enhances \"Fast Cast\" effect", 
        ["category"]="Weapon", 
        ["en"]="Hochomasamune", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=222, 
        ["skill"]="Katana", 
        ["DEX"]=10, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=19282, 
        ["damage"]=45
    }, 
    [113]={
        ["discription"]="DEF:39 STR+3 DEX+3 AGI-3 Accuracy+7 Attack+7", 
        ["category"]="Armor", 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Thrk. Breastplate", 
        ["STR"]=3, 
        ["AGI"]=-3, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=39, 
        ["DEX"]=3, 
        ["Accuracy"]=7, 
        ["id"]=11343, 
        ["Attack"]=7
    }, 
    [114]={
        ["discription"]="DMG:46 Delay:210 AGI+3 Attack+5", 
        ["category"]="Weapon", 
        ["en"]="Angr Harpe", 
        ["AGI"]=3, 
        ["delay"]=210, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF", 
            [19]="DNC"
        }, 
        ["damage"]=46, 
        ["id"]=19137, 
        ["skill"]="Dagger", 
        ["Attack"]=5
    }, 
    [115]={
        ["discription"]="DEF:59 Accuracy+25 +15 \"Store TP\"+5", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Taranis's Harness", 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=11360, 
        ["DEF"]=59, 
        ["Accuracy"]=25, 
        ["Store TP"]=5
    }, 
    [116]={
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["en"]="Eisen Grip", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="Physical damage taken -2%", 
        ["id"]=19050, 
        ["PDT"]=-2
    }, 
    [117]={
        ["discription"]="STR+4 Great Axe skill +4 Scythe skill +4", 
        ["category"]="Weapon", 
        ["en"]="Uther's Grip", 
        ["Great Axe skill"]=4, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Scythe skill"]=4, 
        ["skill"]="(N/A)", 
        ["id"]=18804, 
        ["STR"]=4
    }, 
    [118]={
        ["Ranged Attack"]=7, 
        ["category"]="Armor", 
        ["en"]="Loki's Kaftan", 
        ["Store TP"]=7, 
        ["slots"]={
            [5]="Body"
        }, 
        ["discription"]="DEF:58 DEX+11 AGI+11 Ranged Attack+7 \"Store TP\"+7 Increases critical hit damage", 
        ["DEX"]=11, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=14337, 
        ["DEF"]=58, 
        ["AGI"]=11
    }, 
    [119]={
        ["discription"]="DEF:28 STR+3 AGI+3 Critical hit rate +3%", 
        ["category"]="Armor", 
        ["en"]="Leonine Mask", 
        ["AGI"]=3, 
        ["id"]=16151, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [13]="NIN", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=28, 
        ["STR"]=3, 
        ["Critical hit rate"]=3, 
        ["slots"]={
            [4]="Head"
        }
    }, 
    [120]={
        ["discription"]="DEF:80 HP+100 Damage taken -11%  Enmity+9 \"Slow\"+2%", 
        ["category"]="Armor", 
        ["en"]="Laeradr Breastplate", 
        ["Slow"]=2, 
        ["HP"]=100, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK"
        }, 
        ["DEF"]=80, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=10280, 
        ["DT"]=-11
    }, 
    [121]={
        ["discription"]="DEF:49 STR+10 DEX+10 VIT+10 Accuracy+12 \"Triple Attack\"+1% Occasionally absorbs magic damage taken", 
        ["category"]="Armor", 
        ["en"]="Nocturnus Mail", 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEX"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEF"]=49, 
        ["STR"]=10, 
        ["Accuracy"]=12, 
        ["id"]=11354, 
        ["VIT"]=10
    }, 
    [122]={
        ["en"]="Trotter Boots", 
        ["id"]=15736, 
        ["DEF"]=4, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:4 AGI+2 Movement speed +12%", 
        ["AGI"]=2, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG"
        }
    }, 
    [123]={
        ["en"]="Yinyang Robe", 
        ["id"]=14468, 
        ["DEF"]=43, 
        ["slots"]={
            [5]="Body"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:43 MP+25 Adds \"Refresh\" effect \"Blood Pact\" ability delay -5 Avatar: Enmity+5", 
        ["MP"]=25, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [124]={
        ["discription"]="DEF:42 HP-1% Accuracy+3 Attack+18", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Assault Jerkin", 
        ["HP"]=-1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=13805, 
        ["DEF"]=42, 
        ["Accuracy"]=3, 
        ["Attack"]=18
    }, 
    [125]={
        ["Evasion"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Ocelot Trousers", 
        ["discription"]="DEF:23 Accuracy+6 Evasion+10 Haste+4% Enmity+6", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15428, 
        ["Haste"]=4, 
        ["Accuracy"]=6, 
        ["DEF"]=23
    }, 
    [126]={
        ["discription"]="DEF:20 Garuda: Perpetuation cost -2 Attack Bonus Defense Bonus", 
        ["DEF"]=20, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Karura Hachigane", 
        ["id"]=16154, 
        ["category"]="Armor", 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [127]={
        ["discription"]="Accuracy+3 Attack-5 Haste+4%", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Swift Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=15457, 
        ["Haste"]=4, 
        ["Accuracy"]=3, 
        ["Attack"]=-5
    }, 
    [128]={
        ["discription"]="DMG:23 Delay:231 Latent effect: DMG:36 Critical hit rate +6%", 
        ["en"]="Dissector", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=231, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["id"]=17699, 
        ["damage"]=23
    }, 
    [129]={
        ["Evasion"]=-7, 
        ["category"]="Armor", 
        ["en"]="Ace's Helm", 
        ["discription"]="DEF:28 STR+4 Accuracy+7 Evasion-7 Haste+4%", 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["Haste"]=4, 
        ["STR"]=4, 
        ["Accuracy"]=7, 
        ["id"]=15223, 
        ["DEF"]=28
    }, 
    [130]={
        ["MDT"]=-5, 
        ["category"]="Weapon", 
        ["en"]="Narigitsune", 
        ["Evasion"]=5, 
        ["delay"]=227, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["discription"]="DMG:38 Delay:227 Evasion+5 Magic damage taken -5%", 
        ["id"]=19280, 
        ["damage"]=38
    }, 
    [131]={
        ["discription"]="DMG:38 Delay:176 \"Triple Attack\"+3% Increases \"Triple Attack\" damage", 
        ["en"]="Triplus Dagger", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=176, 
        ["category"]="Weapon", 
        ["skill"]="Dagger", 
        ["jobs"]={
            [6]="THF"
        }, 
        ["id"]=19133, 
        ["damage"]=38
    }, 
    [132]={
        ["discription"]="DMG:35 Delay:224 +14 Occasionally attacks twice", 
        ["en"]="Joyeuse", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=224, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [14]="DRG", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["id"]=17652, 
        ["damage"]=35
    }, 
    [133]={
        ["discription"]="DMG:85 Delay:489 Attack+3 \"Triple Attack\"+3% Additional effect: Fire damage", 
        ["category"]="Weapon", 
        ["en"]="Algol", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=489, 
        ["damage"]=85, 
        ["skill"]="Great Sword", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["id"]=18385, 
        ["Attack"]=3
    }, 
    [134]={
        ["discription"]="HP-15 DEX+3 AGI+3 Evasion+10", 
        ["category"]="Armor", 
        ["en"]="Empress Hairpin", 
        ["slots"]={
            [4]="Head"
        }, 
        ["HP"]=-15, 
        ["AGI"]=3, 
        ["DEX"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15224, 
        ["Evasion"]=10
    }, 
    [135]={
        ["Evasion"]=3, 
        ["category"]="Weapon", 
        ["en"]="Shiranui", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=227, 
        ["discription"]="DMG:37 Delay:227 Evasion+3  Additional effect: Light damage", 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=17774, 
        ["damage"]=37
    }, 
    [136]={
        ["en"]="Fenrir's Crown", 
        ["id"]=11496, 
        ["DEF"]=10, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:10 MP+12 Fenrir: Enhances accuracy", 
        ["MP"]=12, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [137]={
        ["discription"]="DMG:85 Delay:444 \"Regain\"+10 Additional effect: Terror", 
        ["en"]="Nightfall", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=444, 
        ["category"]="Weapon", 
        ["skill"]="Great Sword", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["id"]=19163, 
        ["damage"]=85
    }, 
    [138]={
        ["Evasion"]=8, 
        ["category"]="Weapon", 
        ["slots"]={
            [2]="Range"
        }, 
        ["en"]="Ungur Boomerang", 
        ["delay"]=220, 
        ["HP"]=8, 
        ["discription"]="DMG:30 Delay:220 HP+8 MP+8 +8 Evasion+8", 
        ["skill"]="Throwing", 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN"
        }, 
        ["MP"]=8, 
        ["id"]=18141, 
        ["damage"]=30
    }, 
    [139]={
        ["discription"]="DMG:33 Delay:312 Latent effect: DMG:46 Critical hit rate +6%", 
        ["en"]="Retributor", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=312, 
        ["category"]="Weapon", 
        ["skill"]="Axe", 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [22]="RUN"
        }, 
        ["id"]=17944, 
        ["damage"]=33
    }, 
    [140]={
        ["discription"]="DMG:25 Delay:227 Latent effect: DMG:38 Critical hit rate +6%", 
        ["en"]="Senjuinrikio", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=227, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=17793, 
        ["damage"]=25
    }, 
    [141]={
        ["discription"]="DMG:24 Delay:185 Accuracy+3 Latent effect: Parrying skill +5", 
        ["category"]="Weapon", 
        ["en"]="Hototogisu", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=185, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=16899, 
        ["skill"]="Katana", 
        ["Accuracy"]=3, 
        ["damage"]=24
    }, 
    [142]={
        ["Evasion"]=-2, 
        ["en"]="Anger Bomblet", 
        ["discription"]="Attack+2 Evasion-2 \"Double Attack\"+1%", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [8]="DRK", 
            [13]="NIN"
        }, 
        ["id"]=19760, 
        ["Attack"]=2
    }, 
    [143]={
        ["discription"]="DEF:36 STR+4 VIT+4 Haste+3%", 
        ["category"]="Armor", 
        ["en"]="Barb. Zerehs", 
        ["Haste"]=3, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["DEF"]=36, 
        ["STR"]=4, 
        ["id"]=15617, 
        ["VIT"]=4
    }, 
    [144]={
        ["discription"]="DMG:11 Delay:264", 
        ["en"]="Octave Club", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=264, 
        ["category"]="Weapon", 
        ["skill"]="Club", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN"
        }, 
        ["id"]=18852, 
        ["damage"]=11
    }, 
    [145]={
        ["discription"]="DEF:8 Enhances pet accuracy", 
        ["DEF"]=8, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Herder's Subligar", 
        ["id"]=16368, 
        ["category"]="Armor", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }
    }, 
    [146]={
        ["discription"]="DMG:55 Delay:366 MP+30 Summoning magic skill +5 Avatar perpetuation cost -3", 
        ["category"]="Weapon", 
        ["en"]="Bahamut's Staff", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=366, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["id"]=17598, 
        ["skill"]="Staff", 
        ["MP"]=30, 
        ["damage"]=55
    }, 
    [147]={
        ["discription"]="DMG:4 Delay:366 MP+30 Occasionally attacks 2 to 5 times", 
        ["category"]="Weapon", 
        ["en"]="Mercurial Pole", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=366, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [7]="PLD", 
            [10]="BRD", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=17586, 
        ["skill"]="Staff", 
        ["MP"]=30, 
        ["damage"]=4
    }, 
    [148]={
        ["discription"]="DMG:30 Delay:150 AGI+6 Increases critical hit damage", 
        ["category"]="Weapon", 
        ["en"]="Oneiros Knife", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=150, 
        ["AGI"]=6, 
        ["skill"]="Dagger", 
        ["jobs"]={
            [5]="RDM", 
            [6]="THF", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN"
        }, 
        ["id"]=19141, 
        ["damage"]=30
    }, 
    [149]={
        ["discription"]="DMG:32 Delay:150 Accuracy+12 Haste+1%", 
        ["category"]="Weapon", 
        ["en"]="Rapidus Sax", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=150, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["Haste"]=1, 
        ["skill"]="Dagger", 
        ["Accuracy"]=12, 
        ["id"]=19129, 
        ["damage"]=32
    }, 
    [150]={
        ["discription"]="DMG:39 Delay:201 \"Subtle Blow\"+10 Enhances \"Dual Wield\" effect", 
        ["category"]="Weapon", 
        ["en"]="Auric Dagger", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=201, 
        ["Dual Wield"]=5, 
        ["skill"]="Dagger", 
        ["jobs"]={
            [6]="THF", 
            [19]="DNC"
        }, 
        ["id"]=17626, 
        ["damage"]=39
    }, 
    [151]={
        ["discription"]="DEF:24 STR+6 DEX+4 Attack+8 Slow +5%", 
        ["category"]="Armor", 
        ["en"]="Gnadbhod's Helm", 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEX"]=4, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=24, 
        ["STR"]=6, 
        ["id"]=16158, 
        ["Attack"]=8
    }, 
    [152]={
        ["discription"]="DMG:37 Delay:210 Enhances \"Resist Petrify\" effect", 
        ["en"]="Perseus's Harpe", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=210, 
        ["category"]="Weapon", 
        ["skill"]="Dagger", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF"
        }, 
        ["id"]=18002, 
        ["damage"]=37
    }, 
    [153]={
        ["discription"]="DMG:15 Delay:205 Latent effect: DMG:30 Critical hit rate +6%", 
        ["en"]="Heart Snatcher", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=205, 
        ["category"]="Weapon", 
        ["skill"]="Dagger", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["id"]=18005, 
        ["damage"]=15
    }, 
    [154]={
        ["discription"]="DMG:60 Delay:366 Summoning magic skill +7 \"Blood Boon\"+5 Avatar: Attack+10 \"Magic Atk. Bonus\"+5", 
        ["en"]="Soulscourge", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["skill"]="Staff", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["id"]=17105, 
        ["damage"]=60
    }, 
    [155]={
        ["discription"]="DMG:40 Delay:236 Occasionally attacks 2 to 3 times", 
        ["en"]="Ridill", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=236, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM"
        }, 
        ["id"]=16555, 
        ["damage"]=40
    }, 
    [156]={
        ["discription"]="DMG:104 Delay:504 STR+8 Additional effect: Amnesia", 
        ["category"]="Weapon", 
        ["en"]="Vermeil Bhuj", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=504, 
        ["skill"]="Great Axe", 
        ["STR"]=8, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["id"]=18510, 
        ["damage"]=104
    }, 
    [157]={
        ["discription"]="DMG:34 Delay:201 Increases critical hit damage", 
        ["en"]="X's Knife", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=201, 
        ["category"]="Weapon", 
        ["skill"]="Dagger", 
        ["jobs"]={
            [6]="THF", 
            [9]="BST"
        }, 
        ["id"]=18019, 
        ["damage"]=34
    }, 
    [158]={
        ["discription"]="DMG:+22 Delay:+96 Critical hit rate +3% Additional effect: \"Kick Attacks\"+7", 
        ["category"]="Weapon", 
        ["en"]="Afflictors", 
        ["id"]=16428, 
        ["delay"]=96, 
        ["slots"]={
            [0]="Main"
        }, 
        ["skill"]="Hand-to-Hand", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [9]="BST", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["Critical hit rate"]=3, 
        ["damage"]=22
    }, 
    [159]={
        ["en"]="Bullwhip Belt", 
        ["id"]=11728, 
        ["Haste"]=7, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="HP-75 -50 -50 -50 -50 -50 -50 Haste+7%", 
        ["HP"]=-75, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }
    }, 
    [160]={
        ["discription"]="Accuracy+10 Ranged Accuracy+10  Evasion+10", 
        ["Ranged Accuracy"]=10, 
        ["category"]="Armor", 
        ["en"]="Optical Hat", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=13915, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Accuracy"]=10, 
        ["Evasion"]=10
    }, 
    [161]={
        ["discription"]="Magic Accuracy+6 Enfeebling magic skill +15 Elemental magic skill +15 Dark magic skill +15", 
        ["en"]="Avesta Bangles", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=11919, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=6
    }, 
    [162]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Bibiki Seashell", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="VIT+4 +3  Enhances \"Aquan Killer\" effect", 
        ["id"]=18257, 
        ["VIT"]=4
    }, 
    [163]={
        ["discription"]="DMG:27 Delay:200 AGI+2 +8  \"Steal\"+2 Additional effect: Water damage", 
        ["category"]="Weapon", 
        ["en"]="Btm. Knife", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=200, 
        ["AGI"]=2, 
        ["skill"]="Dagger", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["id"]=17623, 
        ["damage"]=27
    }, 
    [164]={
        ["discription"]="DMG:26 Delay:150 -7 +7 Additional effect: Wind damage", 
        ["en"]="Sirocco Kukri", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=150, 
        ["category"]="Weapon", 
        ["skill"]="Dagger", 
        ["jobs"]={
            [6]="THF"
        }, 
        ["id"]=18018, 
        ["damage"]=26
    }, 
    [165]={
        ["discription"]="DEF:22 DEX+4 AGI+8 Haste+3% Enmity+3", 
        ["category"]="Armor", 
        ["en"]="Ocelot Gloves", 
        ["AGI"]=8, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=3, 
        ["DEX"]=4, 
        ["id"]=14887, 
        ["DEF"]=22
    }, 
    [166]={
        ["discription"]="DMG:49 Delay:236 MP+25 Additional effect: Damage varies with MP", 
        ["category"]="Weapon", 
        ["en"]="Tyrfing", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=236, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [16]="BLU"
        }, 
        ["id"]=16540, 
        ["skill"]="Sword", 
        ["MP"]=25, 
        ["damage"]=49
    }, 
    [167]={
        ["discription"]="DMG:44 Delay:190 DEX+5 \"Ninja tool expertise\" Additional effect: Lowers enemy critical hit evasion", 
        ["category"]="Weapon", 
        ["en"]="Oirandori", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=190, 
        ["skill"]="Katana", 
        ["DEX"]=5, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=19291, 
        ["damage"]=44
    }, 
    [168]={
        ["discription"]="DMG:46 Delay:210 Latent effect: \"Blade: Metsu\"", 
        ["en"]="Sekirei", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=210, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=19288, 
        ["damage"]=46
    }, 
    [169]={
        ["Evasion"]=-10, 
        ["category"]="Armor", 
        ["en"]="Bandomusha Kote", 
        ["discription"]="DEF:21 HP+3% -5 +5 -5 +5 -5 +5 -5 +5 Attack+22 Evasion-10", 
        ["HP"]=3, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=21, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=14873, 
        ["Attack"]=22
    }, 
    [170]={
        ["discription"]="HP+30 CHR+1 -30", 
        ["category"]="Weapon", 
        ["en"]="Verthandi's Gem", 
        ["HP"]=30, 
        ["CHR"]=1, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=19244, 
        ["skill"]="(N/A)"
    }, 
    [171]={
        ["INT"]=-7, 
        ["en"]="Andvaranauts", 
        ["DEF"]=12, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:12 INT-7  \"Gilfinder\"+1", 
        ["id"]=14075, 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH"
        }
    }, 
    [172]={
        ["discription"]="DEF:18 DEX+2 INT+2 Accuracy+4 Enmity-4 Set: Increases pet defense and enmity", 
        ["INT"]=2, 
        ["Set Bonus"]={
            ["set id"]=554, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Breeder Mufflers", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["DEF"]=18, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Accuracy"]=4, 
        ["id"]=15001, 
        ["DEX"]=2
    }, 
    [173]={
        ["discription"]="DMG:39 Delay:180 Accuracy+8 Attack+8 Increases critical hit damage", 
        ["category"]="Weapon", 
        ["en"]="Kamome", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=180, 
        ["damage"]=39, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=8, 
        ["id"]=19287, 
        ["Attack"]=8
    }, 
    [174]={
        ["discription"]="DMG:35 Delay:210 Accuracy+7 Magnus stone equipped: Occ. deals double damage", 
        ["category"]="Weapon", 
        ["en"]="Toki", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=210, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=19289, 
        ["skill"]="Katana", 
        ["Accuracy"]=7, 
        ["damage"]=35
    }, 
    [175]={
        ["en"]="Nabu's Tiara", 
        ["id"]=27656, 
        ["DEF"]=30, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:30 MP+50 Enhancing magic skill +10 Avatar: Increases magic accuracy and  \"Magic Atk. Bonus\"", 
        ["MP"]=50, 
        ["jobs"]={
            [3]="WHM", 
            [10]="BRD", 
            [15]="SMN"
        }
    }, 
    [176]={
        ["id"]=15184, 
        ["en"]="Voyager Sallet", 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEX"]=4, 
        ["category"]="Armor", 
        ["discription"]="STR+3 DEX+4", 
        ["STR"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [177]={
        ["discription"]="DMG:106 Delay:528 Additional effect: Darkness damage", 
        ["en"]="Plaga Scythe", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=528, 
        ["category"]="Weapon", 
        ["skill"]="Scythe", 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["id"]=18961, 
        ["damage"]=106
    }, 
    [178]={
        ["discription"]="STR+1 Accuracy+3", 
        ["category"]="Weapon", 
        ["en"]="Astrolabe", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [14]="DRG", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=19239, 
        ["STR"]=1, 
        ["Accuracy"]=3, 
        ["skill"]="(N/A)"
    }, 
    [179]={
        ["discription"]="DEF:15 MND+7 CHR+7 Spell interruption rate down 10%", 
        ["CHR"]=7, 
        ["category"]="Armor", 
        ["en"]="Muse Tariqah", 
        ["jobs"]={
            [1]="WAR", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [9]="BST", 
            [12]="SAM"
        }, 
        ["DEF"]=15, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["id"]=16175, 
        ["MND"]=7
    }, 
    [180]={
        ["Evasion"]=-14, 
        ["category"]="Armor", 
        ["en"]="Oneiros Barbut", 
        ["PDT"]=-5, 
        ["discription"]="DEF:30 VIT+9 Evasion-14 Physical damage taken -5% Reduces movement speed", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD"
        }, 
        ["DEF"]=30, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=11817, 
        ["VIT"]=9
    }, 
    [181]={
        ["discription"]="DMG:35 Delay:286 AGI+6 +12 Evasion+6", 
        ["category"]="Weapon", 
        ["en"]="Aliyat Chakram", 
        ["AGI"]=6, 
        ["delay"]=286, 
        ["slots"]={
            [2]="Range"
        }, 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["Evasion"]=6, 
        ["id"]=19770, 
        ["skill"]="Throwing", 
        ["damage"]=35
    }, 
    [182]={
        ["en"]="Oneiros Helm", 
        ["id"]=11816, 
        ["DEF"]=28, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:28 DEX+13 \"Double Attack\"-3% \"Triple Attack\"-3% Increases critical hit damage", 
        ["DEX"]=13, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [14]="DRG", 
            [22]="RUN"
        }
    }, 
    [183]={
        ["discription"]="DEF:7 STR+7 Haste+12% \"Subtle Blow\"+5 Physical damage taken -5%", 
        ["category"]="Armor", 
        ["en"]="Black Belt", 
        ["Haste"]=12, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["jobs"]={
            [2]="MNK"
        }, 
        ["DEF"]=7, 
        ["STR"]=7, 
        ["id"]=13186, 
        ["PDT"]=-5
    }, 
    [184]={
        ["discription"]="DEF:33 AGI+10 MND+5 \"Subtle Blow\"+10", 
        ["MND"]=5, 
        ["category"]="Armor", 
        ["en"]="Ambusher's Hose", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=33, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=11935, 
        ["AGI"]=10
    }, 
    [185]={
        ["discription"]="DMG:109 Delay:196 Accuracy+15 Evasion+22 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Additional effect: Haste", 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["en"]="Blurred Knife", 
        ["item_level"]=119, 
        ["delay"]=196, 
        ["Evasion"]=22, 
        ["skill"]="Dagger", 
        ["Accuracy"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["id"]=20601, 
        ["Dagger skill"]=242, 
        ["damage"]=109
    }, 
    [186]={
        ["damage"]=217, 
        ["Staff skill"]=242, 
        ["MND"]=12, 
        ["INT"]=12, 
        ["category"]="Weapon", 
        ["Magic Atk. Bonus"]=28, 
        ["item_level"]=119, 
        ["delay"]=412, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [7]="PLD", 
            [10]="BRD", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["slots"]={
            [0]="Main"
        }, 
        ["discription"]="DMG:217 Delay:412 INT+12 MND+12 Magic Accuracy+20 \"Magic Atk. Bonus\"+28 Magic Damage+217 Staff skill +242 Parrying skill +242 Magic Accuracy skill +228 Additional effect: Haste", 
        ["skill"]="Staff", 
        ["Parrying skill"]=242, 
        ["id"]=21157, 
        ["en"]="Blurred Staff", 
        ["Magic Accuracy"]=20
    }, 
    [187]={
        ["discription"]="DMG:92 Delay:192 HP+30 Throwing skill +215", 
        ["category"]="Weapon", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["item_level"]=117, 
        ["delay"]=192, 
        ["HP"]=30, 
        ["Throwing skill"]=215, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["en"]="Suppa Shuriken", 
        ["id"]=21356, 
        ["skill"]="Throwing", 
        ["damage"]=92
    }, 
    [188]={
        ["discription"]="Accuracy+6 \"Tonberry's Grudge\"", 
        ["category"]="Armor", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=10931, 
        ["en"]="Rancor Collar", 
        ["Accuracy"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [189]={
        ["discription"]="DMG:66 Delay:280 MND+15 Enhances \"Starlight\" effect Additional effect: Regen", 
        ["category"]="Weapon", 
        ["en"]="Dukkha", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=280, 
        ["MND"]=15, 
        ["skill"]="Club", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=18887, 
        ["damage"]=66
    }, 
    [190]={
        ["discription"]="DMG:28 Delay:192 Magic Accuracy+8", 
        ["category"]="Weapon", 
        ["en"]="Aureole", 
        ["slots"]={
            [2]="Range"
        }, 
        ["delay"]=192, 
        ["damage"]=28, 
        ["skill"]="Throwing", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18245, 
        ["Magic Accuracy"]=8
    }, 
    [191]={
        ["discription"]="DEF:52 MP+30 STR+10 DEX+10 VIT+10  AGI+10 INT+10 MND+10 CHR+10  +50", 
        ["STR"]=10, 
        ["MND"]=10, 
        ["category"]="Armor", 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Kirin's Osode", 
        ["AGI"]=10, 
        ["INT"]=10, 
        ["DEX"]=10, 
        ["CHR"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["MP"]=30, 
        ["DEF"]=52, 
        ["id"]=12562, 
        ["VIT"]=10
    }, 
    [192]={
        ["discription"]="DMG:48 Delay:264 HP-55 STR+3 Attack+10 Critical hit rate +3%", 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["en"]="Organics", 
        ["id"]=17753, 
        ["HP"]=-55, 
        ["delay"]=264, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["Critical hit rate"]=3, 
        ["STR"]=3, 
        ["damage"]=48, 
        ["skill"]="Sword", 
        ["Attack"]=10
    }, 
    [193]={
        ["discription"]="DMG:40 Delay:320  Enchantment: \"Reraise III\"", 
        ["en"]="Raphael's Rod", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=320, 
        ["category"]="Weapon", 
        ["skill"]="Club", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18398, 
        ["damage"]=40
    }, 
    [194]={
        ["discription"]="DMG:60 Delay:402 HP+20 MP+20 INT+10 MND+10 +15 +15 +15 +15 +15 +15 +15 +15", 
        ["category"]="Weapon", 
        ["delay"]=402, 
        ["en"]="Kirin's Pole", 
        ["slots"]={
            [0]="Main"
        }, 
        ["HP"]=20, 
        ["MND"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [7]="PLD", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["MP"]=20, 
        ["INT"]=10, 
        ["id"]=17567, 
        ["skill"]="Staff", 
        ["damage"]=60
    }, 
    [195]={
        ["discription"]="DMG:42 Delay:402 MP+20 \"Magic Atk. Bonus\"+25 MP recovered while healing +10", 
        ["category"]="Weapon", 
        ["en"]="Dorje", 
        ["Magic Atk. Bonus"]=25, 
        ["delay"]=402, 
        ["slots"]={
            [0]="Main"
        }, 
        ["skill"]="Staff", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["MP"]=20, 
        ["id"]=18594, 
        ["damage"]=42
    }, 
    [196]={
        ["MDT"]=-8, 
        ["en"]="Minerva's Ring", 
        ["id"]=15550, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Physical damage taken +8% Magic damage taken -8%", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["PDT"]=8
    }, 
    [197]={
        ["discription"]="Capacity point bonus: +50% Maximum duration: 720 minutes Maximum bonus: 30000", 
        ["en"]="Capacity Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28546, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [198]={
        ["discription"]="Enchantment: Teleport (Crag of Dem) Destination is close to the dimensional portal in Konschtat Highlands.", 
        ["en"]="Dim. Ring (Dem)", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26177, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [199]={
        ["discription"]="DEF:1 Increases synthesis skill gain rate", 
        ["DEF"]=1, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Shaper's Shawl", 
        ["id"]=11009, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [200]={
        ["discription"]="Capacity point bonus: +200% Maximum duration: 720 minutes Maximum bonus: 30000", 
        ["en"]="Endorsement Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28469, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [201]={
        ["discription"]="DEF:6 Attack+6 Haste+6% \"Subtle Blow\"+6 Spell interruption rate down 6%", 
        ["category"]="Armor", 
        ["en"]="Ninurta's Sash", 
        ["DEF"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Haste"]=6, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=15458, 
        ["Attack"]=6
    }, 
    [202]={
        ["discription"]="Evasion+7 Enmity-7", 
        ["Evasion"]=7, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=14809, 
        ["en"]="Novia Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [203]={
        ["discription"]="DEF:52 Accuracy+20 Attack+20 Critical hit rate +5% Enhances \"Zanshin\" effect Set: Enhances \"Store TP\" effect", 
        ["Set Bonus"]={
            ["set id"]=86, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Store TP"]=5
                }, 
                [3]={
                    ["Store TP"]=10
                }, 
                [4]={
                    ["Store TP"]=15
                }, 
                [5]={}
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Hachiryu Haramaki", 
        ["Critical hit rate"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=52, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Accuracy"]=20, 
        ["id"]=11281, 
        ["Attack"]=20
    }, 
    [204]={
        ["discription"]="Enchantment: Teleport (Crag of Mea) Destination is close to the dimensional portal Tahrongi Canyon.", 
        ["en"]="Dim. Ring (Mea)", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26178, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [205]={
        ["discription"]="DEF:42 STR+10 Attack+5 Enhances \"Zanshin\" effect Set: Enhances \"Store TP\" effect", 
        ["Set Bonus"]={
            ["set id"]=86, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Store TP"]=5
                }, 
                [3]={
                    ["Store TP"]=10
                }, 
                [4]={
                    ["Store TP"]=15
                }, 
                [5]={}
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Hachiryu Haidate", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=42, 
        ["STR"]=10, 
        ["id"]=16337, 
        ["Attack"]=5
    }, 
    [206]={
        ["discription"]="STR+7 DEX+7 VIT+7 AGI+7 INT+7 MND+7 CHR+7 Enchantment: \"Teleport\" (Ru'Lude Gardens)", 
        ["category"]="Armor", 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Maat's Cap", 
        ["AGI"]=7, 
        ["CHR"]=7, 
        ["MND"]=7, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15194, 
        ["INT"]=7, 
        ["STR"]=7, 
        ["DEX"]=7, 
        ["VIT"]=7
    }, 
    [207]={
        ["discription"]="Accuracy+20 Ranged Accuracy+20 \"Store TP\"+5", 
        ["Ranged Accuracy"]=20, 
        ["category"]="Armor", 
        ["en"]="Ninja Nodowa +1", 
        ["Store TP"]=5, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=20, 
        ["id"]=25490
    }, 
    [208]={
        ["discription"]="HP+30 Damage taken -3% Avatar: Accuracy+15 Ranged Accuracy+15 Magic Accuracy+15", 
        ["en"]="Summoner's Collar", 
        ["id"]=25501, 
        ["HP"]=30, 
        ["category"]="Armor", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["DT"]=-3
    }, 
    [209]={
        ["discription"]="DMG:262 Delay:507 Accuracy+20 Polearm skill +242 Parrying skill +242 Magic Accuracy skill +188 Additional effect: Haste", 
        ["category"]="Weapon", 
        ["en"]="Blurred Lance", 
        ["item_level"]=119, 
        ["Accuracy"]=20, 
        ["delay"]=507, 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["Polearm skill"]=242, 
        ["Parrying skill"]=242, 
        ["id"]=20940, 
        ["skill"]="Polearm", 
        ["damage"]=262
    }, 
    [210]={
        ["discription"]="HP+70 Enmity+5  Enhances resistance against \"Death\"", 
        ["HP"]=70, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=10798, 
        ["en"]="Eihwaz Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [211]={
        ["damage"]=104, 
        ["Ranged Accuracy"]=10, 
        ["Throwing skill"]=242, 
        ["en"]="Togakushi Shuriken", 
        ["category"]="Weapon", 
        ["AGI"]=3, 
        ["item_level"]=119, 
        ["delay"]=192, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["discription"]="DMG:104 Delay:192 VIT+3 AGI+3 Accuracy+5 Attack+5 Ranged Accuracy+10 Throwing skill +242", 
        ["skill"]="Throwing", 
        ["VIT"]=3, 
        ["id"]=21357, 
        ["Accuracy"]=5, 
        ["Attack"]=5
    }, 
    [212]={
        ["discription"]="DMG:1 Delay:366 Enchantment: \"Signet\"", 
        ["en"]="Rep. Signet Staff", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["skill"]="Staff", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=17584, 
        ["damage"]=1
    }, 
    [213]={
        ["discription"]="Capacity point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["en"]="Trizek Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=27557, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [214]={
        ["discription"]="HP+55 \"Magic Def. Bonus\"+4 Enmity+4", 
        ["HP"]=55, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28584, 
        ["en"]="Vexer Ring +1", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [215]={
        ["Evasion"]=-8, 
        ["Ranged Accuracy"]=8, 
        ["category"]="Armor", 
        ["en"]="Bellona's Ring", 
        ["discription"]="Ranged Accuracy+8 Ranged Attack+8 Evasion-8 DEF-8", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=-8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15549, 
        ["Ranged Attack"]=8
    }, 
    [216]={
        ["discription"]="Capacity point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["en"]="Facility Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26165, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [217]={
        ["Evasion"]=13, 
        ["category"]="Armor", 
        ["en"]="Kasiri Belt", 
        ["discription"]="DEF:13 HP+30 Evasion+13 Enmity+3 Haste+4%", 
        ["HP"]=30, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=4, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28456, 
        ["DEF"]=13
    }, 
    [218]={
        ["discription"]="Enchantment: \"Teleport\" (Tavnazian Safehold)", 
        ["en"]="Tavnazian Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=14672, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [219]={
        ["discription"]="DEF:11 AGI+10 Attack-5 Evasion+10 \"Resist Gravity\"+15", 
        ["category"]="Armor", 
        ["en"]="Svelt. Gouriz +1", 
        ["AGI"]=10, 
        ["Evasion"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=11, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28436, 
        ["Attack"]=-5
    }, 
    [220]={
        ["Evasion"]=-8, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Mars's Ring", 
        ["discription"]="Accuracy+8 Attack+8 Evasion-8 DEF-8", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15548, 
        ["DEF"]=-8, 
        ["Accuracy"]=8, 
        ["Attack"]=8
    }, 
    [221]={
        ["discription"]="Accuracy+15 Magic Accuracy+15 \"Triple Attack\" damage +3", 
        ["category"]="Armor", 
        ["en"]="Assassin's Gorget", 
        ["id"]=25447, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=15, 
        ["Magic Accuracy"]=15
    }, 
    [222]={
        ["discription"]="DEF:1 Increases chances of obtaining crystals In Bastok: Movement speed +12%", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Republic Aketon", 
        ["id"]=14429, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [223]={
        ["discription"]="Accuracy+15 Attack+15 Critical hit rate +2% Wyvern: Lv.+1", 
        ["category"]="Armor", 
        ["en"]="Dragoon's Collar", 
        ["id"]=25495, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["Critical hit rate"]=2, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=15, 
        ["Attack"]=15
    }, 
    [224]={
        ["discription"]="DMG:140 Delay:240 Accuracy+20 Magic Accuracy+20 Sword skill +223 Parrying skill +223 Magic Accuracy skill +223", 
        ["Parrying skill"]=223, 
        ["skill"]="Sword", 
        ["category"]="Weapon", 
        ["Sword skill"]=223, 
        ["en"]="Ajja Sword", 
        ["delay"]=240, 
        ["item_level"]=119, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["id"]=21618, 
        ["damage"]=140, 
        ["Magic Accuracy"]=20
    }, 
    [225]={
        ["discription"]="Experience point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["en"]="Echad Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=27556, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [226]={
        ["discription"]="DMG:274 Delay:420 STR+15 Accuracy+47 Katana skill +228 Parrying skill +228 Magic Accuracy skill +188 Weapon Skill Accuracy+25 Adds \"Tachi: Gekko\" effect", 
        ["skill"]="Great Katana", 
        ["STR"]=15, 
        ["Katana skill"]=228, 
        ["item_level"]=119, 
        ["en"]="Beryllium Tachi", 
        ["delay"]=420, 
        ["Parrying skill"]=228, 
        ["slots"]={
            [0]="Main"
        }, 
        ["Accuracy"]=25, 
        ["jobs"]={
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["id"]=21963, 
        ["category"]="Weapon", 
        ["damage"]=274
    }, 
    [227]={
        ["discription"]="Accuracy+15 Ranged Accuracy+15 \"Store TP\"+3", 
        ["Ranged Accuracy"]=15, 
        ["category"]="Armor", 
        ["en"]="Ninja Nodowa", 
        ["Store TP"]=3, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=15, 
        ["id"]=25489
    }, 
    [228]={
        ["discription"]="Physical damage taken +5% Pet: \"Regen\"+1 Physical damage taken -5%", 
        ["en"]="Hypaspist Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=26079, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["PDT"]=5
    }, 
    [229]={
        ["discription"]="DEF:8 Attack+8 Enhances \"Dual Wield\" effect \"Store TP\"+5", 
        ["category"]="Armor", 
        ["en"]="Patentia Sash", 
        ["Store TP"]=5, 
        ["Dual Wield"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=10838, 
        ["Attack"]=8
    }, 
    [230]={
        ["INT"]=3, 
        ["en"]="Strophadic Earring", 
        ["Magic Atk. Bonus"]=4, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="INT+3 \"Magic Atk. Bonus\"+4 Elemental magic skill +4", 
        ["id"]=11035, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [231]={
        ["MDT"]=-8, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Reiki Cloak", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=27615, 
        ["DEF"]=19, 
        ["discription"]="DEF:19 HP+130 Enmity+6 Enemy critical hit rate -3% Magic damage taken -8%", 
        ["HP"]=130
    }, 
    [232]={
        ["id"]=21381, 
        ["en"]="Seraphicaller", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="\"Blood Pact\" recast time II -5 Avatar: Lv. 119", 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [233]={
        ["discription"]="HP+75 -75", 
        ["HP"]=75, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=13567, 
        ["en"]="Bomb Queen Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [234]={
        ["discription"]="DEF:12 MP+25 Magic Accuracy+5 \"Magic Atk. Bonus\"+10 \"Conserve MP\"+2 ", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Izdubar Mantle", 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=27616, 
        ["DEF"]=12, 
        ["MP"]=25, 
        ["Magic Accuracy"]=5
    }, 
    [235]={
        ["discription"]="DEF:18 \"Last Resort\" effect duration +15 \"Absorb\" effect duration +10%", 
        ["DEF"]=18, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Ankou's Mantle", 
        ["id"]=26253, 
        ["category"]="Armor", 
        ["jobs"]={
            [8]="DRK"
        }
    }, 
    [236]={
        ["discription"]="DEF:9 Magic Damage+5 Converts 110 HP to MP Unity Ranking: Enmity-3～7", 
        ["DEF"]=9, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Mephitas's Ring +1", 
        ["id"]=27559, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [237]={
        ["discription"]="DEF:5 Summoning magic skill +7 \"Blood Boon\"+5 Avatar perpetuation cost -2", 
        ["DEF"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Lucidity Sash", 
        ["id"]=28416, 
        ["category"]="Armor", 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [238]={
        ["discription"]="DEF:20 HP+100 MP+100 Accuracy+5 Damage taken -3%", 
        ["category"]="Armor", 
        ["en"]="Xucau Mantle", 
        ["MP"]=100, 
        ["HP"]=100, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=20, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=5, 
        ["id"]=27614, 
        ["DT"]=-3
    }, 
    [239]={
        ["discription"]="DEF:10 Attack+20 \"Store TP\"+7 \"Resist Stun\"+10", 
        ["category"]="Armor", 
        ["en"]="Anu Torque", 
        ["Store TP"]=7, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [14]="DRG", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=10, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=26029, 
        ["Attack"]=20
    }, 
    [240]={
        ["discription"]="Magic Accuracy+2 Enhances \"Resist Poison\" effect Enhances \"Resist Silence\" effect Enhances \"Resist Virus\" effect", 
        ["en"]="Insect Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15827, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=2
    }, 
    [241]={
        ["discription"]="INT+4 MND+4 \"Magic Atk. Bonus\"+8 Magic burst damage +10 \"Resist Charm\"+5", 
        ["MND"]=4, 
        ["category"]="Armor", 
        ["en"]="Mizu. Kubikazari", 
        ["INT"]=4, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=28379, 
        ["Magic Atk. Bonus"]=8
    }, 
    [242]={
        ["en"]="M. No.17's Locket", 
        ["id"]=15518, 
        ["DEF"]=2, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:2 MP+10 +30 Enhances \"Resist Charm\" effect", 
        ["MP"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [243]={
        ["MDT"]=-3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Etiolation Earring", 
        ["HP"]=50, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["MP"]=50, 
        ["id"]=28478, 
        ["discription"]="HP+50 MP+50 \"Fast Cast\"+1% Magic damage taken -3% \"Resist Silence\"+15 ", 
        ["Fast Cast"]=1
    }, 
    [244]={
        ["discription"]="Evasion+9 \"Subtle Blow\"+9", 
        ["Evasion"]=9, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=11626, 
        ["en"]="Torero Torque", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [245]={
        ["discription"]="DEF:3 \"Blood Boon\"+3 Diabolos perpetuation cost -1", 
        ["DEF"]=3, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Diabolos's Rope", 
        ["id"]=11752, 
        ["category"]="Armor", 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [246]={
        ["discription"]="Blood Boon+3 Avatar: Accuracy+5 Magic Accuracy+5 Enmity+5", 
        ["en"]="Consumm. Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=26000, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [247]={
        ["discription"]="STR+6 DEX+6 AGI+6 \"Store TP\"+3 \"Subtle Blow\"+5", 
        ["category"]="Armor", 
        ["en"]="Apate Ring", 
        ["Store TP"]=3, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["AGI"]=6, 
        ["DEX"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26173, 
        ["STR"]=6
    }, 
    [248]={
        ["discription"]="DEF:16 AGI+6 Accuracy+10 Evasion+15 \"Triple Attack\"+2%", 
        ["category"]="Armor", 
        ["augments"]={
            [1]="DEX+2", 
            [2]="AGI+3", 
            [3]="\"Dual Wield\"+5", 
            [4]="none", 
            [5]="none"
        }, 
        ["en"]="Canny Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["AGI"]=9, 
        ["Evasion"]=15, 
        ["DEX"]=2, 
        ["Accuracy"]=10, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["id"]=28622, 
        ["DEF"]=16, 
        ["Dual Wield"]=5
    }, 
    [249]={
        ["discription"]="INT+5 Scythe skill +5 Staff skill +5", 
        ["INT"]=5, 
        ["category"]="Armor", 
        ["en"]="Aife's Annulet", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Scythe skill"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=10759, 
        ["Staff skill"]=5
    }, 
    [250]={
        ["discription"]="VIT+5 Hand-to-Hand skill +5 Polearm skill +5", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Portus Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Polearm skill"]=5, 
        ["id"]=10760, 
        ["Hand-to-Hand skill"]=5, 
        ["VIT"]=5
    }, 
    [251]={
        ["discription"]="INT+6 MND+6 CHR+6 Converts 60 HP to MP Unity Ranking: Magic Accuracy+1～5", 
        ["MND"]=6, 
        ["category"]="Armor", 
        ["en"]="Metamor. Ring +1", 
        ["INT"]=6, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27563, 
        ["CHR"]=6
    }, 
    [252]={
        ["discription"]="DEF:6 Accuracy+15 Attack+15 \"Double Attack\"+1%", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Anguinus Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=11731, 
        ["DEF"]=6, 
        ["Accuracy"]=15, 
        ["Attack"]=15
    }, 
    [253]={
        ["discription"]="Damage taken -3%", 
        ["en"]="Nierenschutz", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=11730, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [14]="DRG"
        }, 
        ["category"]="Armor", 
        ["DT"]=-3
    }, 
    [254]={
        ["discription"]="DEF:17 Occasionally annuls severe physical damage taken Dark weather: Accuracy+13 Attack+13", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Archon Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=10975, 
        ["DEF"]=17, 
        ["Accuracy"]=13, 
        ["Attack"]=13
    }, 
    [255]={
        ["discription"]="DEF:16 STR+5 Attack+35", 
        ["category"]="Armor", 
        ["en"]="Niht Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="Attack+10", 
            [2]="Dark magic skill +6", 
            [3]="\"Drain\" and \"Aspir\" potency +22", 
            [4]="none", 
            [5]="none"
        }, 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["DEF"]=16, 
        ["STR"]=5, 
        ["id"]=28624, 
        ["Attack"]=45
    }, 
    [256]={
        ["discription"]="Evasion+6 Dagger skill +5 Pet: \"Subtle Blow\"+9", 
        ["en"]="Gelai Earring", 
        ["Dagger skill"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["Evasion"]=6, 
        ["id"]=28518, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [257]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=13658, 
        ["DEF"]=15, 
        ["slots"]={
            [15]="Back"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:15 Occasionally annuls damage from physical attacks On Darksdays: VIT+20", 
        ["en"]="Shadow Mantle", 
        ["VIT"]=20
    }, 
    [258]={
        ["discription"]="STR+7 DEX+5 VIT+7 AGI+5 INT+7 MND+5 CHR+7", 
        ["category"]="Armor", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Latria Sash", 
        ["AGI"]=5, 
        ["CHR"]=7, 
        ["MND"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26324, 
        ["INT"]=7, 
        ["STR"]=7, 
        ["DEX"]=5, 
        ["VIT"]=7
    }, 
    [259]={
        ["discription"]="DEF:14 Pet: Evasion+10 \"Subtle Blow\"+5 \"Regen\"+1 Damage taken -3%", 
        ["DEF"]=14, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Isa Belt", 
        ["id"]=28451, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [260]={
        ["discription"]="+10 Increases \"Step\" accuracy", 
        ["en"]="Choreia Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=16055, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [261]={
        ["id"]=11732, 
        ["en"]="Nusku's Sash", 
        ["category"]="Armor", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["Dual Wield"]=5, 
        ["discription"]="Evasion+5 Enhances \"Dual Wield\" effect \"Subtle Blow\"+5", 
        ["Evasion"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH"
        }
    }, 
    [262]={
        ["discription"]="DEF:10 Magic Damage+15 \"Conserve MP\"+3", 
        ["DEF"]=10, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Sekhmet Corset", 
        ["id"]=28461, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [21]="GEO"
        }
    }, 
    [263]={
        ["discription"]="HP+20 MP+20 Accuracy+3 Damage taken -1%", 
        ["category"]="Weapon", 
        ["en"]="Umbra Strap", 
        ["Accuracy"]=3, 
        ["HP"]=20, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["MP"]=20, 
        ["id"]=18826, 
        ["DT"]=-1
    }, 
    [264]={
        ["id"]=28549, 
        ["en"]="Enlivened Ring", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=7, 
        ["discription"]="DEX+2 Accuracy+7", 
        ["DEX"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [265]={
        ["Parrying skill"]=7, 
        ["category"]="Weapon", 
        ["en"]="Balarama Grip", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["HP"]=50, 
        ["discription"]="HP+50 Great Sword skill +10 Parrying skill +7 Enmity+3", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21411, 
        ["Great Sword skill"]=10
    }, 
    [266]={
        ["discription"]="Accuracy+10 Pet: Accuracy+10 Ranged Accuracy+10 Attack+5 Ranged Attack+10 \"Regen\"+1", 
        ["category"]="Armor", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=27514, 
        ["en"]="Empath Necklace", 
        ["Accuracy"]=10, 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }
    }, 
    [267]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Archon Ring", 
        ["Magic Atk. Bonus"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Occasionally annuls severe magic damage taken Dark Elemental Magic Accuracy+5 Dark Elemental \"Magic Atk. Bonus\"+5", 
        ["id"]=11674, 
        ["Magic Accuracy"]=5
    }, 
    [268]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Vehemence Ring", 
        ["id"]=28550, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="STR+2 Attack+10", 
        ["STR"]=2, 
        ["Attack"]=10
    }, 
    [269]={
        ["discription"]="Enemy critical hit rate -5% \"Death\" resistance +10 Physical damage taken -3%", 
        ["en"]="Warden's Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=27555, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["PDT"]=-3
    }, 
    [270]={
        ["discription"]="MND+2 Magic Evasion+8", 
        ["MND"]=2, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28503, 
        ["en"]="Flashward Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [271]={
        ["INT"]=2, 
        ["en"]="Acumen Ring", 
        ["Magic Atk. Bonus"]=4, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="INT+2 \"Magic Atk. Bonus\"+4", 
        ["id"]=28554, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [272]={
        ["Evasion"]=15, 
        ["category"]="Weapon", 
        ["en"]="Kupayopl", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["HP"]=50, 
        ["discription"]="HP+50 Evasion+15 Parrying skill +5", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21422, 
        ["Parrying skill"]=5
    }, 
    [273]={
        ["discription"]="Accuracy+6 \"Store TP\"+6", 
        ["category"]="Weapon", 
        ["en"]="Bloodrain Strap", 
        ["Store TP"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21427, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["Accuracy"]=6, 
        ["skill"]="(N/A)"
    }, 
    [274]={
        ["discription"]="DEF:13 Accuracy+15 Haste+7% Pet: Accuracy+10 Ranged Accuracy+10 Haste+5%", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hurch'lan Sash", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28462, 
        ["DEF"]=13, 
        ["Accuracy"]=15, 
        ["Haste"]=7
    }, 
    [275]={
        ["discription"]="DEF:20 HP+100 +25 Darksday: STR+10 DEX+10 VIT+10 AGI+10 INT+10 MND+10 CHR+10", 
        ["STR"]=10, 
        ["MND"]=10, 
        ["category"]="Armor", 
        ["slots"]={
            [15]="Back"
        }, 
        ["AGI"]=10, 
        ["HP"]=100, 
        ["INT"]=10, 
        ["DEX"]=10, 
        ["en"]="Trepidity Mantle", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["CHR"]=10, 
        ["DEF"]=20, 
        ["id"]=28600, 
        ["VIT"]=10
    }, 
    [276]={
        ["discription"]="VIT+2 Converts 55 MP to HP", 
        ["en"]="Upsurge Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28500, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["VIT"]=2
    }, 
    [277]={
        ["id"]=28552, 
        ["en"]="Fistmele Ring", 
        ["discription"]="AGI+2 Ranged Attack+9", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["Ranged Attack"]=9, 
        ["AGI"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [278]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Hermetic Earring", 
        ["Magic Atk. Bonus"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Magic Accuracy+7 \"Magic Atk. Bonus\"+3 ", 
        ["id"]=28477, 
        ["Magic Accuracy"]=7
    }, 
    [279]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Perception Ring", 
        ["discription"]="MND+2 Magic Accuracy+6", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["MND"]=2, 
        ["id"]=28553, 
        ["Magic Accuracy"]=6
    }, 
    [280]={
        ["discription"]="DEF:16 HP+50 Accuracy+15 Attack+15 Ranged Accuracy+15 Magic Accuracy+15 Evasion+15 \"Double Attack\"+2%", 
        ["Ranged Accuracy"]=15, 
        ["Evasion"]=15, 
        ["category"]="Armor", 
        ["STR"]=3, 
        ["en"]="Yokaze Mantle", 
        ["HP"]=50, 
        ["id"]=28629, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Magic Accuracy"]=15, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=15, 
        ["DEF"]=16, 
        ["augments"]={
            [1]="STR+3", 
            [2]="Weapon skill damage +4%", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["Attack"]=15
    }, 
    [281]={
        ["discription"]="Dark magic skill +10 Spell interruption rate down 5% \"Drain\" and \"Aspir\" potency +10", 
        ["en"]="Evanescence Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26160, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [282]={
        ["discription"]="DEF:16 VIT+8 Accuracy+20 Attack+20  Wyvern: HP+100 Attack+20", 
        ["category"]="Armor", 
        ["Attack"]=20, 
        ["en"]="Updraft Mantle", 
        ["id"]=28630, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=16, 
        ["STR"]=3, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="STR+3", 
            [2]="Pet: Breath+9", 
            [3]="Pet: Damage taken -2%", 
            [4]="Weapon skill damage +4%", 
            [5]="none"
        }, 
        ["VIT"]=8
    }, 
    [283]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26245, 
        ["DEF"]=17, 
        ["slots"]={
            [15]="Back"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:17 \"Resist Charm\"+15 \"Conserve MP\"+5 \"Cure\" potency +7% Damage taken -4%", 
        ["en"]="Solemnity Cape", 
        ["DT"]=-4
    }, 
    [284]={
        ["discription"]="STR+5 DEX+5", 
        ["en"]="Potent Grip", 
        ["STR"]=5, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22198, 
        ["DEX"]=5
    }, 
    [285]={
        ["id"]=28475, 
        ["en"]="Infused Earring", 
        ["discription"]="AGI+4 Evasion+10 \"Regen\"+1", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["Evasion"]=10, 
        ["AGI"]=4, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [286]={
        ["discription"]="DEF:10 \"Reward\"+10 \"Spirit Link\"+50 \"Repair\" potency +10%", 
        ["DEF"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Pratik Earring", 
        ["id"]=28498, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [287]={
        ["discription"]="INT+10 MND+10 Magic Accuracy+10 Magic Evasion+10", 
        ["MND"]=10, 
        ["category"]="Weapon", 
        ["en"]="Enki Strap", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["INT"]=10, 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=22213, 
        ["Magic Accuracy"]=10
    }, 
    [288]={
        ["discription"]="MP+40 \"Resist Amnesia\"+10 Avatar: \"Magic Atk. Bonus\"+6", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26170, 
        ["en"]="Speaker's Ring", 
        ["MP"]=40, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [289]={
        ["discription"]="DEF:9 STR+8 DEX+8 VIT-5 AGI-5 INT+8 MND-5", 
        ["category"]="Armor", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Wanion Belt", 
        ["DEX"]=8, 
        ["AGI"]=-5, 
        ["MND"]=-5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=10834, 
        ["INT"]=8, 
        ["DEF"]=9, 
        ["STR"]=8, 
        ["VIT"]=-5
    }, 
    [290]={
        ["discription"]="HP+20 Accuracy+7 Attack+7 Evasion+7 \"Subtle Blow\"+3", 
        ["category"]="Armor", 
        ["en"]="Assuage Earring", 
        ["Evasion"]=7, 
        ["HP"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27536, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Accuracy"]=7, 
        ["Attack"]=7
    }, 
    [291]={
        ["id"]=10771, 
        ["en"]="Cacoethic Ring +1", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=11, 
        ["discription"]="Accuracy+11 Ranged Accuracy+16 Unity Ranking: Enmity-1～5", 
        ["Ranged Accuracy"]=16, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [292]={
        ["discription"]="Accuracy+10 Magic Accuracy+8 \"Double Attack\"+1%", 
        ["category"]="Weapon", 
        ["en"]="Flanged Grip", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22195, 
        ["skill"]="(N/A)", 
        ["Accuracy"]=10, 
        ["Magic Accuracy"]=8
    }, 
    [293]={
        ["discription"]="STR+3 INT+5 Attack+10", 
        ["category"]="Weapon", 
        ["en"]="Floestone", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["INT"]=5, 
        ["STR"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21366, 
        ["Attack"]=10
    }, 
    [294]={
        ["discription"]="INT+4 Magic Accuracy+8 \"Magic Atk. Bonus\"+4 \"Conserve MP\"+4", 
        ["category"]="Weapon", 
        ["en"]="Pemphredo Tathlum", 
        ["Magic Atk. Bonus"]=4, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["INT"]=4, 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22271, 
        ["Magic Accuracy"]=8
    }, 
    [295]={
        ["discription"]="Accuracy+5 Attack+10 \"Store TP\"+3", 
        ["category"]="Weapon", 
        ["en"]="Ginsen", 
        ["Store TP"]=3, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=21371, 
        ["skill"]="(N/A)", 
        ["Accuracy"]=5, 
        ["Attack"]=10
    }, 
    [296]={
        ["discription"]="MND+2 \"Magic Def. Bonus\"+2", 
        ["MND"]=2, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28504, 
        ["en"]="Spellbr. Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [297]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Succor Ring", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=30, 
        ["discription"]="MP+30 Damage taken -3%", 
        ["id"]=15859, 
        ["DT"]=-3
    }, 
    [298]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Iron Gobbet", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="VIT+5 Enmity+2 Enemy critical hit rate -2%", 
        ["id"]=19782, 
        ["VIT"]=5
    }, 
    [299]={
        ["discription"]="Attack+13 \"Magic Atk. Bonus\"+5", 
        ["en"]="Grenade Core", 
        ["Magic Atk. Bonus"]=5, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [13]="NIN", 
            [22]="RUN"
        }, 
        ["id"]=22251, 
        ["Attack"]=13
    }, 
    [300]={
        ["discription"]="HP+10 DEX+3 Accuracy+13 ", 
        ["category"]="Weapon", 
        ["en"]="Falcon Eye", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["HP"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=22253, 
        ["DEX"]=3, 
        ["Accuracy"]=13, 
        ["skill"]="(N/A)"
    }, 
    [301]={
        ["id"]=28539, 
        ["en"]="Globidonta Ring", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=20, 
        ["discription"]="MP+20 MND+6 Divine magic skill +5 Enfeebling magic skill +5 Summoning magic skill +5", 
        ["MND"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [302]={
        ["discription"]="MP+20 MND+3 Magic Accuracy+6", 
        ["MND"]=3, 
        ["category"]="Weapon", 
        ["en"]="Hydrocera", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22263, 
        ["skill"]="(N/A)", 
        ["MP"]=20, 
        ["Magic Accuracy"]=6
    }, 
    [303]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Gwati Earring", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["MP"]=10, 
        ["discription"]="MP+10 Magic Accuracy+8 \"Conserve MP\"+1", 
        ["id"]=28507, 
        ["Magic Accuracy"]=8
    }, 
    [304]={
        ["en"]="Pernicious Ring", 
        ["id"]=10767, 
        ["Store TP"]=4, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="HP+30 Enmity+5 \"Double Attack\"+1% \"Store TP\"+4", 
        ["HP"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [305]={
        ["discription"]="Occasionally annuls magic damage taken Enhances resistance against \"Death\" On Darksdays:  \"Magic Def. Bonus\"", 
        ["en"]="Shadow Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=14646, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [306]={
        ["discription"]="STR+3 DEX+3 VIT+3 AGI+3 Enmity+4 \"Double Attack\"+1% \"Store TP\"+5", 
        ["category"]="Armor", 
        ["en"]="Petrov Ring", 
        ["Store TP"]=5, 
        ["STR"]=3, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["AGI"]=3, 
        ["id"]=10772, 
        ["DEX"]=3, 
        ["VIT"]=3
    }, 
    [307]={
        ["id"]=26017, 
        ["en"]="Clotharius Torque", 
        ["category"]="Armor", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=8, 
        ["discription"]="Accuracy+8 Ranged Accuracy+8 Enmity-4 \"Triple Attack\"+1% \"Subtle Blow\"+4", 
        ["Ranged Accuracy"]=8, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [308]={
        ["discription"]="STR+3 Accuracy+13 \"Resist Amnesia\"+10", 
        ["category"]="Weapon", 
        ["en"]="Mantoptera Eye", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=22264, 
        ["STR"]=3, 
        ["Accuracy"]=13, 
        ["skill"]="(N/A)"
    }, 
    [309]={
        ["INT"]=6, 
        ["en"]="Satlada Necklace", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=27516, 
        ["discription"]="INT+6 Magic Damage+10", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [310]={
        ["Evasion"]=22, 
        ["MND"]=25, 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=102, 
        ["en"]="Macabre Gaunt. +1", 
        ["STR"]=10, 
        ["PDT"]=-4, 
        ["HP"]=89, 
        ["DEX"]=29, 
        ["VIT"]=33, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=4, 
        ["id"]=27994, 
        ["Unity Ranking Bonus Applied"]="HP + 60", 
        ["CHR"]=19, 
        ["INT"]=8, 
        ["category"]="Armor", 
        ["discription"]="DEF:102 HP+29 STR+10 DEX+29 VIT+33 INT+8 MND+25 CHR+19 Evasion+22 Magic Evasion+26 Haste+4% Enmity+7 \"Magic Def. Bonus\"+1 \"Cure\" potency +11% Physical damage taken -4% Unity Ranking: HP+20～60"
    }, 
    [311]={
        ["MDT"]=-3, 
        ["STR"]=35, 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["DEX"]=35, 
        ["en"]="Lugra Cloak +1", 
        ["MND"]=48, 
        ["Haste"]=9, 
        ["Evasion"]=77, 
        ["item_level"]=119, 
        ["Fast Cast"]=6, 
        ["HP"]=91, 
        ["id"]=26897, 
        ["category"]="Armor", 
        ["DEF"]=226, 
        ["MP"]=91, 
        ["discription"]="Cannot equip headgear DEF:226 HP+91 MP+91 STR+35 DEX+35 VIT+35 AGI+35 INT+48 MND+48 CHR+48 Evasion+77 Magic Evasion+156 \"Magic Def. Bonus\"+12 Haste+9% \"Regen\"+3 \"Refresh\"+3 \"Drain\" and \"Aspir\" potency +31 Magic damage taken -3% Unity Ranking: \"Fast Cast\"+3～6%", 
        ["VIT"]=35, 
        ["slots"]={
            [5]="Body"
        }, 
        ["INT"]=48, 
        ["Unity Ranking Bonus Applied"]="Fast Cast + 6", 
        ["CHR"]=48, 
        ["AGI"]=35
    }, 
    [312]={
        ["discription"]="DMG:313 Delay:492 Accuracy+35 Attack+35 Polearm skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Triple Attack\"+3% \"Subtle Blow\"+7 Damage taken -2%", 
        ["skill"]="Polearm", 
        ["Parrying skill"]=242, 
        ["category"]="Weapon", 
        ["en"]="Lembing", 
        ["item_level"]=119, 
        ["delay"]=492, 
        ["Polearm skill"]=242, 
        ["slots"]={
            [0]="Main"
        }, 
        ["DT"]=-2, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["Accuracy"]=35, 
        ["Attack"]=35, 
        ["id"]=21855, 
        ["damage"]=313
    }, 
    [313]={
        ["damage"]=298, 
        ["STR"]=20, 
        ["discription"]="DMG:268 Delay:492 Attack+20 Polearm skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Dragon Killer\"+10 Jump: \"Double Attack\"+7% \"TP Bonus\"+50", 
        ["skill"]="Polearm", 
        ["category"]="Weapon", 
        ["en"]="Rhomphaia", 
        ["item_level"]=119, 
        ["delay"]=492, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["id"]=20937, 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main"
        }, 
        ["Polearm skill"]=242, 
        ["augments"]={
            [1]="DMG:+30", 
            [2]="STR+20", 
            [3]="Accuracy+15"
        }, 
        ["Accuracy"]=15, 
        ["Attack"]=20
    }, 
    [314]={
        ["id"]=21452, 
        ["en"]="Divinator", 
        ["slots"]={
            [2]="Range"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="An animator crafted with ancient techniques that modern man cannot possibly hope to replicate. Automaton: Lv.. 119", 
        ["item_level"]=119, 
        ["jobs"]={
            [18]="PUP"
        }
    }, 
    [315]={
        ["discription"]="DMG:296 Delay:494 Attack+25 Great Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Store TP\"+8 Weapon Skill Accuracy+25 Chance for weapon skills not to consume TP +1%", 
        ["skill"]="Great Katana", 
        ["Parrying skill"]=242, 
        ["category"]="Weapon", 
        ["Store TP"]=8, 
        ["item_level"]=119, 
        ["delay"]=494, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["slots"]={
            [0]="Main"
        }, 
        ["damage"]=296, 
        ["Great Katana skill"]=242, 
        ["Accuracy"]=25, 
        ["en"]="Deacon Blade", 
        ["id"]=21028, 
        ["Attack"]=25
    }, 
    [316]={
        ["Evasion"]=41, 
        ["DEF"]=120, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEX"]=21, 
        ["discription"]="DEF:120 HP+54 MP+59 STR+21 DEX+21 VIT+21 AGI+21 INT+36 MND+36 CHR+29 Magic Accuracy+18 \"Magic Atk. Bonus\"+18 Evasion+41 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+3% \"Fast Cast\"+5%", 
        ["MND"]=36, 
        ["AGI"]=21, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Fast Cast"]=5, 
        ["item_level"]=119, 
        ["HP"]=54, 
        ["id"]=27887, 
        ["VIT"]=21, 
        ["STR"]=21, 
        ["Haste"]=3, 
        ["MP"]=59, 
        ["en"]="Vanir Cotehardie", 
        ["INT"]=36, 
        ["category"]="Armor", 
        ["CHR"]=29, 
        ["Magic Atk. Bonus"]=18, 
        ["Magic Accuracy"]=18
    }, 
    [317]={
        ["damage"]=317, 
        ["discription"]="DMG:317 Delay:528 STR+20 INT+20 Attack+25 \"Magic Atk. Bonus\"+25 Magic Damage+170 Scythe skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Endark\"+20", 
        ["slots"]={
            [0]="Main"
        }, 
        ["INT"]=20, 
        ["category"]="Weapon", 
        ["Magic Atk. Bonus"]=25, 
        ["item_level"]=119, 
        ["delay"]=528, 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["Scythe skill"]=242, 
        ["Parrying skill"]=242, 
        ["skill"]="Scythe", 
        ["STR"]=20, 
        ["id"]=20894, 
        ["en"]="Deacon Scythe", 
        ["Attack"]=25
    }, 
    [318]={
        ["Evasion"]=27, 
        ["MND"]=24, 
        ["DEF"]=107, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["PDT"]=-3, 
        ["STR"]=29, 
        ["AGI"]=17, 
        ["item_level"]=119, 
        ["discription"]="DEF:107 HP+43 MP+29 STR+29 VIT+12 AGI+17 INT+38 MND+24 CHR+19 Accuracy+22 Magic Accuracy+22 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% \"Conserve MP\"+4 Physical damage taken -3% Enchantment: \"Poison\"", 
        ["HP"]=43, 
        ["en"]="Miasmic Pants", 
        ["Accuracy"]=22, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=5, 
        ["MP"]=29, 
        ["id"]=27220, 
        ["INT"]=38, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["VIT"]=12, 
        ["Magic Accuracy"]=22
    }, 
    [319]={
        ["MDT"]=-5, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["discription"]="DMG:111 Delay:205 Accuracy+13 Evasion+22 Magic Damage+70 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Magic damage taken -5%", 
        ["category"]="Weapon", 
        ["en"]="Vanir Knife", 
        ["item_level"]=119, 
        ["delay"]=205, 
        ["Parrying skill"]=242, 
        ["skill"]="Dagger", 
        ["Evasion"]=22, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["Accuracy"]=13, 
        ["Dagger skill"]=242, 
        ["id"]=20632, 
        ["damage"]=111
    }, 
    [320]={
        ["Evasion"]=22, 
        ["MND"]=32, 
        ["discription"]="DEF:92 STR+14 DEX+34 VIT+29 AGI+16 INT+8 MND+32 CHR+15 Attack+32 Evasion+22 Magic Evasion+26 \"Magic Def. Bonus\"+1 Haste+5% \"Counter\"+4 \"Regen\"+1", 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEF"]=92, 
        ["AGI"]=16, 
        ["STR"]=14, 
        ["augments"]={
            [1]="Pet: HP+100", 
            [2]="Pet: Accuracy+15", 
            [3]="Pet: Damage taken -3%"
        }, 
        ["en"]="Rao Kote", 
        ["DEX"]=34, 
        ["id"]=27026, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=5, 
        ["item_level"]=119, 
        ["INT"]=8, 
        ["category"]="Armor", 
        ["CHR"]=15, 
        ["VIT"]=29, 
        ["Attack"]=32
    }, 
    [321]={
        ["discription"]="DMG:217 Delay:402 MP+88 Staff skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Blood Boon\"+5 Avatar: Magic Accuracy+35 \"Magic Atk. Bonus\"+110 \"Blood Pact\" damage +3", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Marquetry Staff", 
        ["Staff skill"]=242, 
        ["delay"]=402, 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["MP"]=88, 
        ["Parrying skill"]=242, 
        ["id"]=21155, 
        ["skill"]="Staff", 
        ["damage"]=217
    }, 
    [322]={
        ["id"]=22261, 
        ["en"]="Divinator II", 
        ["slots"]={
            [2]="Range"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="A long-range animator crafted with ancient techniques that modern man cannot possibly hope to replicate. Automaton: Lv. 119", 
        ["item_level"]=119, 
        ["jobs"]={
            [18]="PUP"
        }
    }, 
    [323]={
        ["Evasion"]=52, 
        ["MND"]=24, 
        ["DEF"]=129, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=25, 
        ["STR"]=37, 
        ["AGI"]=25, 
        ["en"]="Sweller's Harness", 
        ["item_level"]=119, 
        ["HP"]=59, 
        ["discription"]="DEF:129 HP+59 STR+37 DEX+25 VIT+21 AGI+25 INT+24 MND+24 CHR+24 Attack+25 Evasion+52 Magic Evasion+53 \"Magic Def. Bonus\"+4 Guarding skill +20 Haste+4% \"Counter\"+5", 
        ["VIT"]=21, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=4, 
        ["id"]=26958, 
        ["Guarding skill"]=20, 
        ["CHR"]=24, 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["Attack"]=25
    }, 
    [324]={
        ["discription"]="DEF:60 HP+57 MP+64 \"Magic Atk. Bonus\"+20 Magic Damage+75 Shield skill +107 Spell interruption rate down 10%", 
        ["category"]="Armor", 
        ["Shield skill"]=107, 
        ["en"]="Culminus", 
        ["Magic Atk. Bonus"]=20, 
        ["HP"]=57, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEF"]=60, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["MP"]=64, 
        ["id"]=26400, 
        ["item_level"]=119
    }, 
    [325]={
        ["discription"]="DMG:190 Delay:366 MP+100 Staff skill +242 Parrying skill +242 Magic Accuracy skill +188 Avatar: Magic Accuracy+20 \"Magic Atk. Bonus\"+120 Enmity+10", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Frazil Staff", 
        ["Staff skill"]=242, 
        ["delay"]=366, 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["MP"]=100, 
        ["Parrying skill"]=242, 
        ["id"]=21167, 
        ["skill"]="Staff", 
        ["damage"]=190
    }, 
    [326]={
        ["discription"]="DMG:288 Delay:528 Accuracy+15 Attack+15 Scythe skill +242 Parrying skill +242 Magic Accuracy skill +188 Enmity-10 Additional effect: HP drain", 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main"
        }, 
        ["category"]="Weapon", 
        ["en"]="Cronus", 
        ["item_level"]=119, 
        ["delay"]=528, 
        ["damage"]=288, 
        ["skill"]="Scythe", 
        ["Accuracy"]=15, 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["id"]=20904, 
        ["Scythe skill"]=242, 
        ["Attack"]=15
    }, 
    [327]={
        ["discription"]="DEF:63 HP+120 Shield skill +112 Chance of successful block +20 Damage taken -5% Physical damage taken: \"Reprisal\"", 
        ["category"]="Armor", 
        ["en"]="Adapa Shield", 
        ["item_level"]=119, 
        ["HP"]=120, 
        ["Shield skill"]=112, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [9]="BST"
        }, 
        ["id"]=26420, 
        ["DEF"]=63, 
        ["DT"]=-5
    }, 
    [328]={
        ["MDT"]=-7, 
        ["STR"]=14, 
        ["Evasion"]=38, 
        ["AGI"]=14, 
        ["Katana skill"]=242, 
        ["en"]="Raicho +1", 
        ["item_level"]=119, 
        ["delay"]=222, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=16, 
        ["skill"]="Katana", 
        ["discription"]="DMG:128 Delay:222 STR+14 AGI+14 Accuracy+16 Evasion+38 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 Magic damage taken -7% Unity Ranking: \"Double Attack\"+1～3%", 
        ["id"]=20981, 
        ["category"]="Weapon", 
        ["Parrying skill"]=242, 
        ["damage"]=128, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }
    }, 
    [329]={
        ["damage"]=282, 
        ["STR"]=20, 
        ["discription"]="DMG:282 Delay:480 STR+20 Accuracy+20 Attack+10 Polearm skill +242 Parrying skill +242 Magic Accuracy skill +188 Critical hit rate +3%", 
        ["skill"]="Polearm", 
        ["category"]="Weapon", 
        ["en"]="Reienkyo", 
        ["item_level"]=119, 
        ["delay"]=480, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["id"]=21854, 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main"
        }, 
        ["Polearm skill"]=242, 
        ["Critical hit rate"]=3, 
        ["Accuracy"]=20, 
        ["Attack"]=10
    }, 
    [330]={
        ["discription"]="DMG:298 Delay:551 HP+100 MP+100 Accuracy+18 Polearm skill +242 Parrying skill +242 Magic Accuracy skill +188 Absorbs ice elemental damage 3% Unity Ranking: Critical hit rate +1～5%", 
        ["MP"]=100, 
        ["HP"]=100, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["slots"]={
            [0]="Main"
        }, 
        ["id"]=20942, 
        ["item_level"]=119, 
        ["delay"]=551, 
        ["Critical hit rate"]=5, 
        ["Parrying skill"]=242, 
        ["skill"]="Polearm", 
        ["Polearm skill"]=242, 
        ["Accuracy"]=18, 
        ["Unity Ranking Bonus Applied"]="Critical hit rate + 5", 
        ["damage"]=298, 
        ["category"]="Weapon", 
        ["en"]="Gae Derg"
    }, 
    [331]={
        ["discription"]="DMG:157 Delay:290 Attack+26 Sword skill +228 Parrying skill +228 Magic Accuracy skill +188 \"Double Attack\"+2% \"Triple Attack\"+2% Unity Ranking: STR+1～7 Additional effect: HP Drain", 
        ["Parrying skill"]=228, 
        ["skill"]="Sword", 
        ["category"]="Weapon", 
        ["Sword skill"]=228, 
        ["en"]="Sangarius", 
        ["delay"]=290, 
        ["item_level"]=119, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=157, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK"
        }, 
        ["STR"]=7, 
        ["Unity Ranking Bonus Applied"]="STR + 7", 
        ["id"]=20611, 
        ["Attack"]=26
    }, 
    [332]={
        ["Evasion"]=24, 
        ["MND"]=30, 
        ["en"]="Regimen Mittens", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["Haste"]=5, 
        ["item_level"]=119, 
        ["STR"]=11, 
        ["AGI"]=5, 
        ["HP"]=25, 
        ["DEX"]=35, 
        ["VIT"]=32, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=90, 
        ["id"]=28025, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["discription"]="DEF:90 HP+25 STR+11 DEX+35 VIT+32 AGI+5 INT+12 MND+30 CHR+17 Evasion+24 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+5% Pet: Accuracy+20 Ranged Accuracy+20 Magic Accuracy+20 Haste+6%"
    }, 
    [333]={
        ["discription"]="DMG:+114 Delay:+90 DEX+12 INT+12 +25 Accuracy+20 Hand-to-Hand skill +242 Guarding skill +242 Magic Accuracy skill +188 \"Skillchain Bonus\"+5 Additional effect: Paralysis", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [13]="NIN", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["skill"]="Hand-to-Hand", 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["item_level"]=119, 
        ["delay"]=90, 
        ["INT"]=12, 
        ["DEX"]=12, 
        ["Hand-to-Hand skill"]=242, 
        ["Guarding skill"]=242, 
        ["Accuracy"]=20, 
        ["en"]="Calved Claws", 
        ["id"]=20529, 
        ["damage"]=114
    }, 
    [334]={
        ["Evasion"]=49, 
        ["MND"]=10, 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=12, 
        ["augments"]={
            [1]="STR+6", 
            [2]="Attack+12", 
            [3]="Phys. dmg. taken -1%", 
            [4]="none", 
            [5]="none"
        }, 
        ["AGI"]=29, 
        ["Haste"]=3, 
        ["en"]="Loyalist Sabatons", 
        ["HP"]=78, 
        ["VIT"]=17, 
        ["Accuracy"]=18, 
        ["CHR"]=26, 
        ["STR"]=22, 
        ["DEF"]=85, 
        ["id"]=27492, 
        ["category"]="Armor", 
        ["discription"]="DEF:85 HP+78 STR+16 DEX+12 VIT+17 AGI+29 MND+10 CHR+26 Accuracy+18 Attack+18 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+2 Haste+3% \"Double Attack\"+4% \"Reward\"+35", 
        ["PDT"]=-1, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Attack"]=30
    }, 
    [335]={
        ["Ranged Attack"]=33, 
        ["MND"]=17, 
        ["DEF"]=113, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [17]="COR"
        }, 
        ["STR"]=29, 
        ["AGI"]=34, 
        ["en"]="Darraigner's Brais", 
        ["Evasion"]=38, 
        ["HP"]=47, 
        ["discription"]="DEF:113 HP+47 STR+29 VIT+16 AGI+34 INT+30 MND+17 CHR+11 Ranged Attack+33 Evasion+38 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% Enmity-6 Critical hit damage +6%", 
        ["Critical hit damage"]=6, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=6, 
        ["id"]=25852, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["VIT"]=16, 
        ["item_level"]=119
    }, 
    [336]={
        ["Evasion"]=22, 
        ["Critical hit damage"]=5, 
        ["id"]=20598, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEX"]=15, 
        ["Critical hit rate"]=4, 
        ["en"]="Shijo", 
        ["Dual Wield"]=5, 
        ["item_level"]=119, 
        ["delay"]=195, 
        ["Dagger skill"]=242, 
        ["Accuracy"]=10, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["augments"]={
            [1]="DEX+15", 
            [2]="\"Dual Wield\"+5", 
            [3]="\"Triple Atk.\"+2"
        }, 
        ["damage"]=103, 
        ["Parrying skill"]=242, 
        ["discription"]="DMG:103 Delay:195 Accuracy+10 Attack+10 Evasion+22 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Critical hit rate +4% Critical hit damage +5% Additional effect: \"Flee\"", 
        ["skill"]="Dagger", 
        ["Attack"]=10
    }, 
    [337]={
        ["Ranged Attack"]=10, 
        ["STR"]=5, 
        ["id"]=20983, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=5, 
        ["Ranged Accuracy"]=25, 
        ["item_level"]=119, 
        ["Katana skill"]=228, 
        ["Store TP"]=5, 
        ["delay"]=190, 
        ["en"]="Mijin", 
        ["Accuracy"]=42, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["augments"]={
            [1]="Accuracy+15", 
            [2]="Rng.Acc.+15", 
            [3]="\"Store TP\"+5"
        }, 
        ["damage"]=107, 
        ["Parrying skill"]=228, 
        ["Evasion"]=34, 
        ["skill"]="Katana", 
        ["discription"]="DMG:107 Delay:190 STR+5 DEX+5 Accuracy+27 Ranged Accuracy+10 Ranged Attack+10 Evasion+34 Katana skill +228 Parrying skill +228 Magic Accuracy skill +215"
    }, 
    [338]={
        ["Evasion"]=24, 
        ["MND"]=23, 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["Haste"]=6, 
        ["en"]="Iktomi Dastanas", 
        ["STR"]=8, 
        ["discription"]="DEF:103 HP+27 STR+8 DEX+32 VIT+32 AGI+7 INT+6 MND+23 CHR+16 Evasion+24 Magic Evasion+32 \"Magic Def. Bonus\"+1 Haste+6% \"Double Attack\"+5% \"Subtle Blow\"+8 All Jumps: Accuracy+40", 
        ["HP"]=27, 
        ["DEX"]=32, 
        ["Accuracy"]=40, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=103, 
        ["id"]=25761, 
        ["INT"]=6, 
        ["category"]="Armor", 
        ["CHR"]=16, 
        ["VIT"]=32, 
        ["AGI"]=7
    }, 
    [339]={
        ["discription"]="DMG:110 Delay:236 STR+15 +25 Accuracy+20 Sword skill +242 Parrying skill +242 Magic Accuracy skill +188 Fire elemental \"Magic Atk. Bonus\"+15 Additional effect: Fire damage", 
        ["skill"]="Sword", 
        ["STR"]=15, 
        ["category"]="Weapon", 
        ["Magic Atk. Bonus"]=15, 
        ["en"]="Perfervid Sword", 
        ["delay"]=236, 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Sword skill"]=242, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [16]="BLU"
        }, 
        ["Accuracy"]=20, 
        ["item_level"]=119, 
        ["id"]=20716, 
        ["damage"]=110
    }, 
    [340]={
        ["discription"]="DMG:183 Delay:264 MP+45 VIT+25 INT+25 MND+25 Accuracy+35 Magic Accuracy+35 \"Magic Def. Bonus\"+8 Sword skill +242 Parrying skill +242 Magic Accuracy skill +228 \"Fast Cast\"+8% Resistance to all status ailments +10 \"Refresh\"+1", 
        ["MND"]=25, 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["damage"]=183, 
        ["en"]="Malignance Sword", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Fast Cast"]=8, 
        ["delay"]=264, 
        ["id"]=21635, 
        ["Parrying skill"]=242, 
        ["skill"]="Sword", 
        ["MP"]=45, 
        ["Accuracy"]=35, 
        ["INT"]=25, 
        ["Sword skill"]=242, 
        ["category"]="Weapon", 
        ["VIT"]=25, 
        ["Magic Accuracy"]=35
    }, 
    [341]={
        ["Evasion"]=27, 
        ["STR"]=25, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEF"]=105, 
        ["discription"]="DEF:105 HP+43 MP+29 STR+25 VIT+12 AGI+17 INT+34 MND+24 CHR+19 Evasion+27 Magic Evasion+107 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+6 Haste+5% \"Fast Cast\"+5% \"Conserve MP\"+5 Spell interruption rate down 10%", 
        ["MND"]=24, 
        ["Fast Cast"]=5, 
        ["augments"]={
            [1]="INT+7", 
            [2]="Mag. Acc.+7", 
            [3]="\"Mag.Atk.Bns.\"+3", 
            [4]="\"Refresh\"+1", 
            [5]="none"
        }, 
        ["AGI"]=17, 
        ["item_level"]=119, 
        ["HP"]=43, 
        ["id"]=27321, 
        ["VIT"]=12, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=5, 
        ["MP"]=29, 
        ["en"]="Lengo Pants", 
        ["INT"]=41, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["Magic Atk. Bonus"]=23, 
        ["Magic Accuracy"]=7
    }, 
    [342]={
        ["Evasion"]=69, 
        ["MND"]=16, 
        ["en"]="Rao Sune-Ate", 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["augments"]={
            [1]="Pet: HP+100", 
            [2]="Pet: Accuracy+15", 
            [3]="Pet: Damage taken -3%"
        }, 
        ["AGI"]=34, 
        ["Haste"]=4, 
        ["STR"]=17, 
        ["item_level"]=119, 
        ["DEX"]=25, 
        ["Accuracy"]=31, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=74, 
        ["id"]=27378, 
        ["CHR"]=28, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["discription"]="DEF:74 STR+17 DEX+25 VIT+12 AGI+34 MND+16 CHR+28 Accuracy+31 Evasion+69 Magic Evasion+64 \"Magic Def. Bonus\"+3 Haste+4% \"Subtle Blow\"+7 \"Regen\"+1"
    }, 
    [343]={
        ["damage"]=150, 
        ["en"]="Daybreak", 
        ["MND"]=30, 
        ["discription"]="DMG:150 Delay:216 MP+60 MND+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+40 Magic Damage+241 Magic Evasion+30 Club skill +228 Parrying skill +228 Magic Accuracy skill +242 \"Cure\" potency +30% \"Refresh\"+1 Light elemental damage +50 Main hand: \"Dispelga\"", 
        ["Club skill"]=228, 
        ["Magic Atk. Bonus"]=40, 
        ["item_level"]=119, 
        ["delay"]=216, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=228, 
        ["skill"]="Club", 
        ["category"]="Weapon", 
        ["id"]=22040, 
        ["MP"]=60, 
        ["Magic Accuracy"]=40
    }, 
    [344]={
        ["Evasion"]=27, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["HP"]=45, 
        ["en"]="Ternion Dagger +1", 
        ["AGI"]=15, 
        ["delay"]=175, 
        ["Dagger skill"]=228, 
        ["Accuracy"]=27, 
        ["Unity Ranking Bonus Applied"]="AGI + 15", 
        ["skill"]="Dagger", 
        ["id"]=20604, 
        ["category"]="Weapon", 
        ["Parrying skill"]=228, 
        ["damage"]=100, 
        ["discription"]="DMG:100 Delay:175 HP+45 Accuracy+27 Evasion+27 Dagger skill +228 Parrying skill +228 Magic Accuracy skill +188 \"Triple Attack\"+4% \"Subtle Blow\"+9 Unity Ranking: AGI+10～15"
    }, 
    [345]={
        ["Evasion"]=22, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["en"]="Tancho +1", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Ranged Accuracy"]=21, 
        ["AGI"]=10, 
        ["Katana skill"]=242, 
        ["discription"]="DMG:126 Delay:227 DEX+10 AGI+10 Accuracy+21 Ranged Accuracy+21 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 Spell interruption rate down 35% Unity Ranking: \"Subtle Blow\"+1～6", 
        ["delay"]=227, 
        ["DEX"]=10, 
        ["Accuracy"]=21, 
        ["skill"]="Katana", 
        ["Subtle Blow"]=6, 
        ["id"]=20988, 
        ["Unity Ranking Bonus Applied"]="Subtle Blow + 6", 
        ["damage"]=126, 
        ["category"]="Weapon", 
        ["Parrying skill"]=242, 
        ["item_level"]=119
    }, 
    [346]={
        ["discription"]="DMG:173 Delay:288 HP+50 Axe skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Subtle Blow\"+7 Pet: Magic Accuracy+10 \"Magic Atk. Bonus\"+20", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Deacon Tabar", 
        ["delay"]=288, 
        ["HP"]=50, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [9]="BST"
        }, 
        ["Axe skill"]=242, 
        ["Parrying skill"]=242, 
        ["id"]=20798, 
        ["skill"]="Axe", 
        ["damage"]=173
    }, 
    [347]={
        ["Evasion"]=53, 
        ["MND"]=17, 
        ["DEF"]=115, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["augments"]={
            [1]="Accuracy+3", 
            [2]="Mag. Evasion+15", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["item_level"]=119, 
        ["Critical hit rate"]=2, 
        ["en"]="Ta'lab Trousers", 
        ["HP"]=47, 
        ["AGI"]=20, 
        ["Accuracy"]=3, 
        ["INT"]=30, 
        ["STR"]=29, 
        ["Haste"]=6, 
        ["id"]=27322, 
        ["CHR"]=11, 
        ["VIT"]=16, 
        ["category"]="Armor", 
        ["discription"]="DEF:115 HP+47 STR+29 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Attack+15 Evasion+38 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% \"Triple Attack\"+3% \"Counter\"+3 Critical hit rate +2%", 
        ["Attack"]=15
    }, 
    [348]={
        ["Evasion"]=52, 
        ["MND"]=10, 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Accuracy+15", 
            [4]="Damage taken-2%", 
            [5]="none"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG"
        }, 
        ["DEX"]=17, 
        ["DEF"]=81, 
        ["en"]="Amm Greaves", 
        ["STR"]=15, 
        ["item_level"]=119, 
        ["HP"]=125, 
        ["discription"]="DEF:81 HP+75 STR+15 DEX+17 VIT+21 AGI+32 MND+10 CHR+26 Evasion+52 Magic Evasion+75 \"Magic Def. Bonus\"+2 Haste+3% \"Double Attack\"+3% Damage taken -3%", 
        ["Accuracy"]=15, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=3, 
        ["id"]=27491, 
        ["CHR"]=26, 
        ["VIT"]=31, 
        ["category"]="Armor", 
        ["AGI"]=32, 
        ["DT"]=-5
    }, 
    [349]={
        ["Evasion"]=52, 
        ["MND"]=10, 
        ["en"]="Maenadic Gambieras", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["Haste"]=3, 
        ["item_level"]=119, 
        ["STR"]=15, 
        ["AGI"]=32, 
        ["HP"]=15, 
        ["DEX"]=17, 
        ["Accuracy"]=58, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=83, 
        ["id"]=27502, 
        ["CHR"]=26, 
        ["VIT"]=22, 
        ["category"]="Armor", 
        ["discription"]="DEF:83 HP+15 STR+15 DEX+17 VIT+22 AGI+32 MND+10 CHR+26 Accuracy+23 Evasion+52 Magic Evasion+75 \"Magic Def. Bonus\"+2 Haste+3% All Jumps: Accuracy+58 \"Double Attack\"+5%"
    }, 
    [350]={
        ["Ranged Attack"]=25, 
        ["DEF"]=135, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=32, 
        ["discription"]="DEF:135 HP+63 MP+61 STR+26 DEX+32 VIT+23 AGI+32 INT+23 MND+19 CHR+19 Attack+25 Ranged Attack+25 Evasion+52 Magic Evasion+80 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+6 Haste+6% \"Subtle Blow\"+13", 
        ["MND"]=19, 
        ["item_level"]=119, 
        ["slots"]={
            [5]="Body"
        }, 
        ["AGI"]=32, 
        ["en"]="Lapidary Tunic", 
        ["HP"]=63, 
        ["id"]=26970, 
        ["VIT"]=23, 
        ["STR"]=26, 
        ["Haste"]=6, 
        ["MP"]=61, 
        ["Evasion"]=52, 
        ["INT"]=23, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["Magic Atk. Bonus"]=20, 
        ["Attack"]=25
    }, 
    [351]={
        ["damage"]=320, 
        ["skill"]="Scythe", 
        ["discription"]="DMG:290 Delay:528 Attack+20 Scythe skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Double Attack\"+4% \"Store TP\"+3 Weapon skill damage +5%", 
        ["STR"]=20, 
        ["category"]="Weapon", 
        ["Store TP"]=3, 
        ["item_level"]=119, 
        ["delay"]=528, 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["Scythe skill"]=242, 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main"
        }, 
        ["en"]="Deathbane", 
        ["augments"]={
            [1]="DMG:+30", 
            [2]="STR+20", 
            [3]="Attack+20"
        }, 
        ["id"]=20892, 
        ["Attack"]=40
    }, 
    [352]={
        ["DT"]=-3, 
        ["en"]="Jushimatsu", 
        ["discription"]="DMG:122 Delay:227 AGI+10 Accuracy+15 Evasion+37 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 Damage taken -3%", 
        ["Evasion"]=37, 
        ["category"]="Weapon", 
        ["Katana skill"]=242, 
        ["AGI"]=10, 
        ["delay"]=227, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=242, 
        ["skill"]="Katana", 
        ["item_level"]=119, 
        ["id"]=20990, 
        ["Accuracy"]=15, 
        ["damage"]=122
    }, 
    [353]={
        ["Evasion"]=41, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=10, 
        ["DEF"]=113, 
        ["MND"]=16, 
        ["augments"]={
            [1]="DEX+10", 
            [2]="AGI+10", 
            [3]="Accuracy+15"
        }, 
        ["Ranged Accuracy"]=24, 
        ["Store TP"]=7, 
        ["en"]="Adhemar Kecks", 
        ["HP"]=41, 
        ["id"]=27302, 
        ["item_level"]=119, 
        ["INT"]=28, 
        ["STR"]=32, 
        ["Haste"]=6, 
        ["Accuracy"]=39, 
        ["CHR"]=8, 
        ["VIT"]=15, 
        ["category"]="Armor", 
        ["AGI"]=40, 
        ["discription"]="DEF:113 HP+41 STR+32 VIT+15 AGI+30 INT+28 MND+16 CHR+8 Accuracy+24 Ranged Accuracy+24 Evasion+41 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% \"Recycle\"+15 \"Snapshot\"+9 \"Store TP\"+7"
    }, 
    [354]={
        ["Evasion"]=38, 
        ["MND"]=17, 
        ["STR"]=29, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [14]="DRG", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=111, 
        ["AGI"]=20, 
        ["en"]="Limbo Trousers", 
        ["discription"]="DEF:111 HP+47 STR+29 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Attack+26 \"Magic Atk. Bonus\"+17 Evasion+38 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% \"Double Attack\"+2% \"Fast Cast\"+3%", 
        ["Fast Cast"]=3, 
        ["HP"]=47, 
        ["item_level"]=119, 
        ["VIT"]=16, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=6, 
        ["id"]=27222, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["Magic Atk. Bonus"]=17, 
        ["Attack"]=26
    }, 
    [355]={
        ["discription"]="DMG:122 Delay:227 DEX+12 AGI+12 Accuracy+15 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188", 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=242, 
        ["Katana skill"]=242, 
        ["en"]="Raimitsukane", 
        ["AGI"]=12, 
        ["delay"]=227, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["skill"]="Katana", 
        ["Evasion"]=22, 
        ["DEX"]=12, 
        ["item_level"]=119, 
        ["id"]=20997, 
        ["Accuracy"]=15, 
        ["damage"]=122
    }, 
    [356]={
        ["Ranged Attack"]=24, 
        ["STR"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=33, 
        ["DEF"]=74, 
        ["MND"]=11, 
        ["augments"]={
            [1]="DEX+10", 
            [2]="AGI+10", 
            [3]="Accuracy+15"
        }, 
        ["id"]=27473, 
        ["en"]="Adhemar Gamashes", 
        ["item_level"]=119, 
        ["HP"]=11, 
        ["Critical hit rate"]=3, 
        ["Evasion"]=74, 
        ["CHR"]=25, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=4, 
        ["Accuracy"]=15, 
        ["category"]="Armor", 
        ["VIT"]=8, 
        ["Magic Atk. Bonus"]=25, 
        ["AGI"]=52, 
        ["discription"]="DEF:74 HP+11 STR+15 DEX+23 VIT+8 AGI+42 MND+11 CHR+25 Attack+24 Ranged Attack+24 Evasion+74 Magic Evasion+75 \"Magic Atk. Bonus\"+25 \"Magic Def. Bonus\"+5 Haste+4% \"True Shot\"+1 Critical hit rate +3%", 
        ["Attack"]=24
    }, 
    [357]={
        ["discription"]="DMG:125 Delay:222 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 Enmity+10 \"Counter\"+5 \"Fast Cast\"+5% Physical damage taken -3%", 
        ["Parrying skill"]=242, 
        ["skill"]="Katana", 
        ["Katana skill"]=242, 
        ["item_level"]=119, 
        ["Fast Cast"]=5, 
        ["delay"]=222, 
        ["en"]="Shuhansadamune", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["PDT"]=-3, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Evasion"]=22, 
        ["category"]="Weapon", 
        ["id"]=20982, 
        ["damage"]=125
    }, 
    [358]={
        ["Evasion"]=13, 
        ["discription"]="DMG:113 Delay:208 STR+13 DEX+13 VIT+13 AGI+13 INT+13 MND+13 CHR+13 Accuracy+13 Attack+13 Evasion+13 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Magic Evasion+13 Resistance against \"Death\"+13 Additional effect: \"Death\"", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=13, 
        ["Dagger skill"]=242, 
        ["MND"]=13, 
        ["AGI"]=13, 
        ["skill"]="Dagger", 
        ["item_level"]=119, 
        ["en"]="Odium", 
        ["delay"]=208, 
        ["id"]=20605, 
        ["damage"]=113, 
        ["CHR"]=13, 
        ["INT"]=13, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=13, 
        ["category"]="Weapon", 
        ["STR"]=13, 
        ["VIT"]=13, 
        ["Parrying skill"]=242, 
        ["Attack"]=13
    }, 
    [359]={
        ["Evasion"]=67, 
        ["MND"]=30, 
        ["DEF"]=114, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["STR"]=45, 
        ["AGI"]=21, 
        ["augments"]={
            [1]="Pet: HP+100", 
            [2]="Pet: Accuracy+15", 
            [3]="Pet: Damage taken -3%"
        }, 
        ["Store TP"]=7, 
        ["en"]="Rao Haidate", 
        ["discription"]="DEF:114 STR+45 VIT+15 AGI+21 INT+30 MND+30 CHR+8 Attack+33 Evasion+67 Magic Evasion+64 \"Magic Def. Bonus\"+3 Haste+6% \"Store TP\"+7 \"Regen\"+2", 
        ["id"]=27202, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=6, 
        ["item_level"]=119, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=8, 
        ["VIT"]=15, 
        ["Attack"]=33
    }, 
    [360]={
        ["Ranged Attack"]=25, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["DEX"]=28, 
        ["DEF"]=79, 
        ["MND"]=13, 
        ["id"]=27503, 
        ["en"]="Thereoid Greaves", 
        ["item_level"]=119, 
        ["AGI"]=38, 
        ["HP"]=13, 
        ["Critical hit rate"]=4, 
        ["discription"]="DEF:79 HP+13 STR+13 DEX+28 VIT+13 AGI+38 INT+1 MND+13 CHR+31 Attack+25 Ranged Attack+25 Evasion+72 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+4% Critical hit rate +4% Critical hit damage +5%", 
        ["INT"]=1, 
        ["STR"]=13, 
        ["Haste"]=4, 
        ["Evasion"]=72, 
        ["CHR"]=31, 
        ["VIT"]=13, 
        ["category"]="Armor", 
        ["Critical hit damage"]=5, 
        ["Attack"]=25
    }, 
    [361]={
        ["discription"]="DMG:142 Delay:278 VIT+15 INT+6 MND+6 Accuracy+27 Club skill +228 Parrying skill +228 Magic Accuracy skill +188 Enmity+6 Physical damage taken -10% Additional effect: Earth damage", 
        ["PDT"]=-10, 
        ["MND"]=6, 
        ["item_level"]=119, 
        ["Club skill"]=228, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["en"]="Mafic Cudgel", 
        ["delay"]=278, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=27, 
        ["INT"]=6, 
        ["skill"]="Club", 
        ["id"]=21102, 
        ["category"]="Weapon", 
        ["Parrying skill"]=228, 
        ["VIT"]=15, 
        ["damage"]=142
    }, 
    [362]={
        ["Evasion"]=38, 
        ["DEF"]=128, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=19, 
        ["en"]="Witching Robe", 
        ["MND"]=28, 
        ["augments"]={
            [1]="MP+25", 
            [2]="Mag. Acc.+1", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["STR"]=19, 
        ["item_level"]=119, 
        ["AGI"]=19, 
        ["HP"]=50, 
        ["id"]=25705, 
        ["VIT"]=19, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=3, 
        ["MP"]=92, 
        ["discription"]="DEF:128 HP+50 MP+67 STR+19 DEX+19 VIT+19 AGI+19 INT+35 MND+28 CHR+28 Magic Damage+10 Evasion+38 Magic Evasion+91 \"Magic Atk. Bonus\"+25 \"Magic Def. Bonus\"+7 Haste+3% \"Conserve MP\"+5 \"Refresh\"+2", 
        ["INT"]=35, 
        ["category"]="Armor", 
        ["CHR"]=28, 
        ["Magic Atk. Bonus"]=25, 
        ["Magic Accuracy"]=1
    }, 
    [363]={
        ["damage"]=156, 
        ["Club skill"]=242, 
        ["MND"]=20, 
        ["INT"]=6, 
        ["category"]="Weapon", 
        ["Magic Atk. Bonus"]=16, 
        ["item_level"]=119, 
        ["delay"]=288, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["discription"]="DMG:156 Delay:288 INT+6 MND+20 Magic Accuracy+13 \"Magic Atk. Bonus\"+16 Magic Damage+124 Club skill +242 Parrying skill +242 Magic Accuracy skill +215", 
        ["skill"]="Club", 
        ["Parrying skill"]=242, 
        ["id"]=21116, 
        ["en"]="Cagliostro's Rod", 
        ["Magic Accuracy"]=13
    }, 
    [364]={
        ["discription"]="DMG:147 Delay:300 HP+30 STR+5 Ranged Accuracy+27 Archery skill +228 Unity Ranking: Ranged Accuracy+10～20 Daytime: \"Regen\"+2", 
        ["Ranged Accuracy"]=27, 
        ["skill"]="Archery", 
        ["category"]="Weapon", 
        ["slots"]={
            [2]="Range"
        }, 
        ["en"]="Mengado", 
        ["HP"]=30, 
        ["id"]=21222, 
        ["STR"]=5, 
        ["delay"]=300, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["Archery skill"]=228, 
        ["item_level"]=119, 
        ["damage"]=147
    }, 
    [365]={
        ["Evasion"]=69, 
        ["DEF"]=141, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEX"]=39, 
        ["discription"]="DEF:141 HP+88 MP+44 STR+29 DEX+39 VIT+29 AGI+33 INT+28 MND+28 CHR+28 Accuracy+50 Evasion+69 Magic Evasion+84 \"Magic Def. Bonus\"+6 Haste+4% \"Triple Attack\"+4% \"Hide\" duration +100 Critical hit damage +5% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["Set Bonus"]={
            ["set id"]=47, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Magic Accuracy"]=15
                }, 
                [3]={
                    ["Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Magic Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Magic Accuracy"]=45
                }, 
                [5]={
                    ["Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Magic Accuracy"]=60
                }
            }
        }, 
        ["item_level"]=119, 
        ["STR"]=29, 
        ["AGI"]=33, 
        ["en"]="Pillager's Vest +2", 
        ["HP"]=88, 
        ["id"]=23112, 
        ["Critical hit damage"]=5, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=4, 
        ["MP"]=44, 
        ["Accuracy"]=50, 
        ["INT"]=28, 
        ["category"]="Armor", 
        ["CHR"]=28, 
        ["VIT"]=29, 
        ["MND"]=28
    }, 
    [366]={
        ["Evasion"]=41, 
        ["MND"]=40, 
        ["item_level"]=119, 
        ["jobs"]={
            [7]="PLD", 
            [22]="RUN"
        }, 
        ["DEX"]=30, 
        ["STR"]=30, 
        ["en"]="Regal Gauntlets", 
        ["Haste"]=4, 
        ["discription"]="DEF:126 HP+205 MP+29 STR+30 DEX+30 VIT+40 AGI+20 INT+30 MND+40 CHR+30 Accuracy+45 Evasion+41 Magic Evasion+48 \"Magic Def. Bonus\"+2 Haste+4% \"Regen\"+10 \"Refresh\"+1 Spell interruption rate down 10% Enhancing magic duration +20%", 
        ["HP"]=205, 
        ["id"]=25824, 
        ["VIT"]=40, 
        ["DEF"]=126, 
        ["MP"]=29, 
        ["Accuracy"]=45, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["CHR"]=30, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["AGI"]=20
    }, 
    [367]={
        ["DT"]=-20, 
        ["en"]="Malignance Pole", 
        ["HP"]=150, 
        ["discription"]="DMG:286 Delay:412 HP+150 VIT+40 Accuracy+40 Staff skill +255 Parrying skill +255 Magic Accuracy skill +215 Weapon skill damage +15% Damage taken -20%", 
        ["category"]="Weapon", 
        ["Staff skill"]=255, 
        ["item_level"]=119, 
        ["delay"]=412, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [7]="PLD", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["slots"]={
            [0]="Main"
        }, 
        ["Parrying skill"]=255, 
        ["skill"]="Staff", 
        ["VIT"]=40, 
        ["id"]=22087, 
        ["Accuracy"]=40, 
        ["damage"]=286
    }, 
    [368]={
        ["damage"]=273, 
        ["Great Sword skill"]=228, 
        ["discription"]="DMG:273 Delay:504 VIT+8 INT+13 Accuracy+15 Attack+26 Great Sword skill +228 Parrying skill +228 Magic Accuracy skill +188 \"Spinning Slash\" damage +35%", 
        ["INT"]=13, 
        ["category"]="Weapon", 
        ["en"]="Foreshock Sword", 
        ["item_level"]=119, 
        ["delay"]=504, 
        ["jobs"]={
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["slots"]={
            [0]="Main"
        }, 
        ["Parrying skill"]=228, 
        ["skill"]="Great Sword", 
        ["VIT"]=8, 
        ["id"]=20757, 
        ["Accuracy"]=15, 
        ["Attack"]=26
    }, 
    [369]={
        ["Evasion"]=49, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=35, 
        ["DEF"]=130, 
        ["MND"]=25, 
        ["augments"]={
            [1]="HP+50", 
            [2]="\"Subtle Blow\"+7", 
            [3]="\"Triple Atk.\"+2"
        }, 
        ["discription"]="DEF:130 HP+59 MP+44 STR+30 DEX+35 VIT+26 AGI+30 INT+25 MND+25 CHR+25 Accuracy+15 Attack+15 \"Magic Atk. Bonus\"+25 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+4% \"Triple Attack\"+2%", 
        ["en"]="Rawhide Vest", 
        ["AGI"]=30, 
        ["HP"]=109, 
        ["id"]=26950, 
        ["item_level"]=119, 
        ["STR"]=30, 
        ["Haste"]=4, 
        ["MP"]=44, 
        ["Accuracy"]=15, 
        ["INT"]=25, 
        ["category"]="Armor", 
        ["CHR"]=25, 
        ["VIT"]=26, 
        ["Magic Atk. Bonus"]=25, 
        ["Attack"]=15
    }, 
    [370]={
        ["discription"]="DMG:270 Delay:480 STR+15 DEX+15 VIT+15 Accuracy+15 Attack+15 Magic Evasion+25 Magic Accuracy skill +188 Great Sword skill +242 Parrying skill +242 Enmity+7", 
        ["skill"]="Great Sword", 
        ["damage"]=283, 
        ["jobs"]={
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["STR"]=23, 
        ["item_level"]=119, 
        ["Great Sword skill"]=242, 
        ["id"]=21697, 
        ["delay"]=480, 
        ["DEX"]=15, 
        ["augments"]={
            [1]="STR+8", 
            [2]="Accuracy+10", 
            [3]="Attack+9", 
            [4]="DMG:+13", 
            [5]="none"
        }, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["en"]="Humility", 
        ["VIT"]=15, 
        ["Accuracy"]=25, 
        ["Parrying skill"]=242, 
        ["Attack"]=24
    }, 
    [371]={
        ["discription"]="DMG:94 Delay:201 Magic Accuracy+25 \"Magic Atk. Bonus\"+34 Magic Damage+118 Magic Accuracy skill +201 Dagger skill +242 Parrying skill +242 \"Undead Killer\"+10", 
        ["id"]=20595, 
        ["en"]="Malevolence", 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Fast Cast"]=5, 
        ["item_level"]=119, 
        ["delay"]=201, 
        ["Dagger skill"]=242, 
        ["Parrying skill"]=242, 
        ["INT"]=10, 
        ["skill"]="Dagger", 
        ["augments"]={
            [1]="INT+10", 
            [2]="Mag. Acc.+10", 
            [3]="\"Mag.Atk.Bns.\"+8", 
            [4]="\"Fast Cast\"+5", 
            [5]="none"
        }, 
        ["category"]="Weapon", 
        ["damage"]=94, 
        ["Magic Atk. Bonus"]=42, 
        ["Magic Accuracy"]=35
    }, 
    [372]={
        ["MDT"]=-2, 
        ["MND"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["id"]=20734, 
        ["en"]="Anahera Sword", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["delay"]=264, 
        ["Parrying skill"]=228, 
        ["Sword skill"]=228, 
        ["MP"]=20, 
        ["discription"]="DMG:143 Delay:264 MP+20 MND+15 Attack+26 Sword skill +228 Shield skill +15 Parrying skill +228 Magic Accuracy skill +188 Magic damage taken -2%", 
        ["damage"]=143, 
        ["skill"]="Sword", 
        ["category"]="Weapon", 
        ["Shield skill"]=15, 
        ["Attack"]=26
    }, 
    [373]={
        ["discription"]="DMG:156 Delay:288 Axe skill +242 Parrying skill +242 Magic Accuracy skill +188 Enmity-6 Pet: Evasion+40 Enmity+6", 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["Parrying skill"]=242, 
        ["delay"]=288, 
        ["en"]="Anahera Tabar", 
        ["skill"]="Axe", 
        ["jobs"]={
            [9]="BST"
        }, 
        ["Axe skill"]=242, 
        ["id"]=20822, 
        ["damage"]=156
    }, 
    [374]={
        ["Attack"]=25, 
        ["Great Axe skill"]=242, 
        ["VIT"]=30, 
        ["discription"]="DMG:285 Delay:504 STR+20 VIT+20 Attack+25 Great Axe skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Double Attack\"+3% \"Regen\"+3", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Ferocity", 
        ["delay"]=504, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["slots"]={
            [0]="Main"
        }, 
        ["Parrying skill"]=242, 
        ["skill"]="Great Axe", 
        ["STR"]=30, 
        ["augments"]={
            [1]="STR+10", 
            [2]="VIT+10", 
            [3]="\"Dbl.Atk.\"+3", 
            [4]="DMG:+15", 
            [5]="none"
        }, 
        ["id"]=20844, 
        ["damage"]=300
    }, 
    [375]={
        ["discription"]="DMG:115 Delay:231 Sword skill +242 Parrying skill +242 Enhancing magic skill +10 Magic Accuracy skill +188 Sword enhancement spell damage +10 \"Stoneskin\" casting time -10% Unity Ranking: INT+5～15", 
        ["skill"]="Sword", 
        ["en"]="Pukulatmuj", 
        ["category"]="Weapon", 
        ["Sword skill"]=242, 
        ["item_level"]=119, 
        ["delay"]=231, 
        ["INT"]=15, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=242, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["id"]=20613, 
        ["Unity Ranking Bonus Applied"]="INT + 15", 
        ["damage"]=115
    }, 
    [376]={
        ["Evasion"]=41, 
        ["MND"]=29, 
        ["item_level"]=119, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEX"]=21, 
        ["STR"]=21, 
        ["en"]="Count's Garb", 
        ["Haste"]=7, 
        ["discription"]="DEF:130 HP+54 MP+59 STR+21 DEX+21 VIT+21 AGI+21 INT+38 MND+29 CHR+29 Evasion+41 Magic Evasion+80 \"Magic Atk. Bonus\"+30 \"Magic Def. Bonus\"+6 Haste+7% Magic critical hit rate +15 Magic critical hit damage +10%", 
        ["HP"]=54, 
        ["id"]=26945, 
        ["Magic Atk. Bonus"]=30, 
        ["DEF"]=130, 
        ["MP"]=59, 
        ["VIT"]=21, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=29, 
        ["INT"]=38, 
        ["category"]="Armor", 
        ["AGI"]=21
    }, 
    [377]={
        ["Evasion"]=66, 
        ["MND"]=19, 
        ["augments"]={
            [1]="Pet: HP+100", 
            [2]="Pet: Accuracy+15", 
            [3]="Pet: Damage taken -3%"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=19, 
        ["DEF"]=102, 
        ["AGI"]=17, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Rao Kabuto", 
        ["item_level"]=119, 
        ["discription"]="DEF:102 STR+35 DEX+19 VIT+24 AGI+17 INT+15 MND+19 CHR+15 Accuracy+32 Evasion+66 Magic Evasion+43 \"Magic Def. Bonus\"+4 Haste+8% Critical hit rate +4% \"Regen\"+2", 
        ["Accuracy"]=32, 
        ["STR"]=35, 
        ["Haste"]=8, 
        ["id"]=26674, 
        ["INT"]=15, 
        ["category"]="Armor", 
        ["CHR"]=15, 
        ["VIT"]=24, 
        ["Critical hit rate"]=4
    }, 
    [378]={
        ["MDT"]=-3, 
        ["MND"]=21, 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [13]="NIN", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=22, 
        ["STR"]=20, 
        ["en"]="Skormoth Mask", 
        ["Evasion"]=38, 
        ["Haste"]=8, 
        ["HP"]=36, 
        ["id"]=27783, 
        ["VIT"]=22, 
        ["DEF"]=100, 
        ["discription"]="DEF:100 HP+36 STR+20 DEX+22 VIT+22 AGI+22 INT+21 MND+21 CHR+21 Accuracy+26 Evasion+38 Magic Evasion+43 \"Magic Def. Bonus\"+4 Haste+8% \"Triple Attack\"+4% Magic damage taken -3%", 
        ["Accuracy"]=26, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=21, 
        ["INT"]=21, 
        ["category"]="Armor", 
        ["AGI"]=22
    }, 
    [379]={
        ["discription"]="DMG:120 Delay:227 STR+12 DEX+12 VIT+12 AGI+12 INT+12 MND+12 CHR+12 Accuracy+20 Ranged Accuracy+20 \"Magic Atk. Bonus\"+14 Magic Damage+108 Katana skill +242 Parrying skill +242 Magic Accuracy skill +201 Magic burst damage II +13 \"Subtle Blow\"+8", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["DEX"]=18, 
        ["item_level"]=119, 
        ["augments"]={
            [1]="STR+4", 
            [2]="DEX+6", 
            [3]="Ninjutsu skill +6", 
            [4]="DMG:+9", 
            [5]="none"
        }, 
        ["MND"]=12, 
        ["Katana skill"]=242, 
        ["Ranged Accuracy"]=20, 
        ["AGI"]=12, 
        ["en"]="Ochu", 
        ["delay"]=227, 
        ["Accuracy"]=20, 
        ["Parrying skill"]=242, 
        ["INT"]=12, 
        ["STR"]=16, 
        ["Ninjutsu skill"]=6, 
        ["damage"]=129, 
        ["CHR"]=12, 
        ["Magic Atk. Bonus"]=14, 
        ["category"]="Weapon", 
        ["id"]=20978, 
        ["VIT"]=12, 
        ["skill"]="Katana"
    }, 
    [380]={
        ["Evasion"]=22, 
        ["augments"]={
            [1]="DMG:+15", 
            [2]="STR+15", 
            [3]="Accuracy+10"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Katana skill"]=242, 
        ["Dual Wield"]=5, 
        ["en"]="Aizushintogo", 
        ["item_level"]=119, 
        ["delay"]=227, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=20979, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["discription"]="DMG:123 Delay:227 Accuracy+15 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Dual Wield\"+5 \"Utsusemi\" spellcasting time -7%  Attack based on number of Utsusemi shadow images +5", 
        ["damage"]=138, 
        ["Accuracy"]=25, 
        ["Parrying skill"]=242, 
        ["STR"]=15
    }, 
    [381]={
        ["Evasion"]=149, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEX"]=76, 
        ["DEF"]=428, 
        ["MND"]=60, 
        ["item_level"]=119, 
        ["discription"]="Cannot equip leggear DEF:428 HP+164 MP+88 STR+93 DEX+76 VIT+102 AGI+70 INT+51 MND+60 CHR+65 Accuracy+124 Attack+147 Evasion+149 Magic Evasion+252 \"Magic Def. Bonus\"+12 Haste+16% \"Double Attack\"+10% \"Resist Stun\"+90 Damage taken -10% Enchantment: Meteor", 
        ["AGI"]=70, 
        ["en"]="Onca Suit", 
        ["HP"]=164, 
        ["id"]=26963, 
        ["DT"]=-10, 
        ["STR"]=93, 
        ["Haste"]=16, 
        ["MP"]=88, 
        ["Accuracy"]=124, 
        ["INT"]=51, 
        ["category"]="Armor", 
        ["CHR"]=65, 
        ["VIT"]=102, 
        ["Attack"]=147
    }, 
    [382]={
        ["Evasion"]=82, 
        ["STR"]=39, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=35, 
        ["DEF"]=152, 
        ["MND"]=34, 
        ["Dual Wield"]=10, 
        ["AGI"]=35, 
        ["Critical hit rate"]=8, 
        ["en"]="Hachiya Chain. +3", 
        ["HP"]=98, 
        ["id"]=23454, 
        ["Set Bonus"]={
            ["set id"]=84, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Magic Accuracy"]=15
                }, 
                [3]={
                    ["Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Magic Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Magic Accuracy"]=45
                }, 
                [5]={
                    ["Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Magic Accuracy"]=60
                }
            }
        }, 
        ["INT"]=34, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=4, 
        ["Accuracy"]=50, 
        ["CHR"]=34, 
        ["VIT"]=36, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["discription"]="DEF:152 HP+98 STR+39 DEX+35 VIT+36 AGI+35 INT+34 MND+34 CHR+34 Accuracy+50 Evasion+82 Magic Evasion+73 \"Magic Def. Bonus\"+5 Haste+4% \"Dual Wield\"+10 \"Subtle Blow\"+9 Critical hit rate +8% Physical damage: \"Shock Spikes\" effect Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy"
    }, 
    [383]={
        ["Evasion"]=55, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["Critical hit rate"]=7, 
        ["DEX"]=11, 
        ["STR"]=33, 
        ["id"]=25887, 
        ["MND"]=15, 
        ["discription"]="DEF:123 HP+52 MP+25 STR+33 DEX+11 VIT+16 AGI+45 INT+29 MND+15 CHR+12 Accuracy+45 Ranged Accuracy+45 Magic Accuracy+45 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+6% Critical hit rate +7% Damage taken -5% Set: Increases Dexterity, Agility, and Charisma", 
        ["Ranged Accuracy"]=45, 
        ["en"]="Mummu Kecks +2", 
        ["item_level"]=119, 
        ["HP"]=52, 
        ["Accuracy"]=45, 
        ["Set Bonus"]={
            ["set id"]=477, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["INT"]=29, 
        ["DEF"]=123, 
        ["MP"]=25, 
        ["Haste"]=6, 
        ["CHR"]=12, 
        ["DT"]=-5, 
        ["category"]="Armor", 
        ["AGI"]=45, 
        ["VIT"]=16, 
        ["Magic Accuracy"]=45
    }, 
    [384]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["Magic Atk. Bonus"]=10, 
        ["augments"]={
            [1]="INT+20", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="Magic Damage +10", 
            [4]="\"Mag.Atk.Bns.\"+10", 
            [5]="none"
        }, 
        ["INT"]=20, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=26258, 
        ["DEF"]=16, 
        ["Magic Accuracy"]=20
    }, 
    [385]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["Attack"]=20, 
        ["en"]="Andartia's Mantle", 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="Accuracy+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["DEX"]=20, 
        ["Accuracy"]=30, 
        ["id"]=26258, 
        ["DT"]=-5
    }, 
    [386]={
        ["Ranged Attack"]=22, 
        ["MND"]=5, 
        ["augments"]={
            [1]="STR+10", 
            [2]="DEX+10", 
            [3]="Accuracy+15"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=29, 
        ["Haste"]=3, 
        ["item_level"]=119, 
        ["discription"]="DEF:87 HP+18 STR+26 DEX+19 VIT+11 AGI+38 MND+5 CHR+19 Attack+22 Ranged Attack+22 Evasion+55 Magic Evasion+80 \"Magic Def. Bonus\"+2 Haste+3% \"Zanshin\"+4 Zanshin: Occasionally attacks twice +10%", 
        ["en"]="Ryuo Sune-Ate", 
        ["HP"]=18, 
        ["Evasion"]=55, 
        ["Accuracy"]=15, 
        ["CHR"]=19, 
        ["STR"]=36, 
        ["DEF"]=87, 
        ["id"]=27471, 
        ["category"]="Armor", 
        ["AGI"]=38, 
        ["VIT"]=11, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Attack"]=22
    }, 
    [387]={
        ["Evasion"]=41, 
        ["DEF"]=97, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=39, 
        ["VIT"]=30, 
        ["MND"]=26, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Ranged Accuracy"]=12, 
        ["AGI"]=8, 
        ["item_level"]=119, 
        ["HP"]=20, 
        ["augments"]={
            [1]="Accuracy+14", 
            [2]="\"Triple Atk.\"+4", 
            [3]="STR+8", 
            [4]="Attack+15", 
            [5]="none"
        }, 
        ["id"]=27140, 
        ["INT"]=14, 
        ["STR"]=24, 
        ["Haste"]=5, 
        ["Accuracy"]=26, 
        ["CHR"]=19, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["en"]="Herculean Gloves", 
        ["discription"]="DEF:97 HP+20 STR+16 DEX+39 VIT+30 AGI+8 INT+14 MND+26 CHR+19 Accuracy+12 Ranged Accuracy+12 Evasion+41 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+2% \"Subtle Blow\"+5 Physical damage taken -2%", 
        ["Attack"]=15
    }, 
    [388]={
        ["Evasion"]=70, 
        ["MND"]=23, 
        ["id"]=26528, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=39, 
        ["Ranged Accuracy"]=47, 
        ["item_level"]=119, 
        ["DEF"]=150, 
        ["slots"]={
            [5]="Body"
        }, 
        ["HP"]=122, 
        ["en"]="Ken. Samue +1", 
        ["Accuracy"]=52, 
        ["INT"]=24, 
        ["STR"]=33, 
        ["Haste"]=4, 
        ["Critical hit rate"]=9, 
        ["CHR"]=21, 
        ["VIT"]=21, 
        ["category"]="Armor", 
        ["discription"]="DEF:150 HP+122 STR+33 DEX+39 VIT+21 AGI+37 INT+24 MND+23 CHR+21 Accuracy+52 Ranged Accuracy+47 Evasion+70 Magic Evasion+117 \"Magic Def. Bonus\"+9 Haste+4% \"Triple Attack\"+6% \"Subtle Blow\"+12 Critical hit rate +9%", 
        ["AGI"]=37
    }, 
    [389]={
        ["discription"]="DMG:154 Delay:222 HP+150 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Magic Damage+217 Katana skill +269 Parrying skill +269 Magic Accuracy skill +255 Attack+15 for each Utsusemi shadow image", 
        ["id"]=21917, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Ranged Accuracy"]=50, 
        ["item_level"]=119, 
        ["Katana skill"]=269, 
        ["en"]="Fudo Masamune", 
        ["delay"]=222, 
        ["HP"]=150, 
        ["augments"]={
            [1]="Path: B"
        }, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Magic Accuracy"]=50, 
        ["damage"]=154, 
        ["Accuracy"]=50, 
        ["Parrying skill"]=269, 
        ["Attack"]=15
    }, 
    [390]={
        ["discription"]="Accuracy+25 Ranged Accuracy+25 \"Store TP\"+7", 
        ["Ranged Accuracy"]=25, 
        ["category"]="Armor", 
        ["en"]="Ninja Nodowa +2", 
        ["Store TP"]=7, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=25, 
        ["id"]=25491
    }, 
    [391]={
        ["MDT"]=-3, 
        ["MND"]=18, 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Evasion+20"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=24, 
        ["Evasion"]=58, 
        ["AGI"]=19, 
        ["DEF"]=98, 
        ["STR"]=17, 
        ["HP"]=136, 
        ["en"]="Naga Somen", 
        ["Accuracy"]=18, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Haste"]=8, 
        ["discription"]="DEF:98 HP+86 STR+17 DEX+24 VIT+19 AGI+19 INT+18 MND+18 CHR+18 Accuracy+18 Evasion+38 Magic Evasion+43 \"Magic Def. Bonus\"+4 Haste+8% Magic damage taken -3%", 
        ["id"]=26793, 
        ["INT"]=18, 
        ["category"]="Armor", 
        ["CHR"]=18, 
        ["VIT"]=29, 
        ["item_level"]=119
    }, 
    [392]={
        ["discription"]="DMG:157 Delay:227 DEX+15 AGI+15 INT+15 Accuracy+40 Attack+30 Ranged Accuracy+40 Magic Accuracy+40 \"Magic Atk. Bonus\"+16 Magic Damage+217 Katana skill +250 Parrying skill +250 Magic Accuracy skill +250 Main hand: \"Blade: Ku\" \"Blade: Ku\" damage +60% Enhances \"Regain\" based on \"Dual Wield\" effect", 
        ["en"]="Gokotai", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=15, 
        ["Ranged Accuracy"]=40, 
        ["item_level"]=119, 
        ["Katana skill"]=250, 
        ["AGI"]=15, 
        ["delay"]=227, 
        ["Magic Accuracy"]=40, 
        ["Accuracy"]=40, 
        ["INT"]=15, 
        ["skill"]="Katana", 
        ["id"]=21922, 
        ["category"]="Weapon", 
        ["damage"]=157, 
        ["Magic Atk. Bonus"]=16, 
        ["Parrying skill"]=250, 
        ["Attack"]=30
    }, 
    [393]={
        ["Evasion"]=73, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=120, 
        ["DEX"]=31, 
        ["id"]=23410, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Yonin\" and \"Innin\" effect", 
            [4]="none"
        }, 
        ["MND"]=32, 
        ["item_level"]=119, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Mochi. Hatsuburi +3", 
        ["AGI"]=33, 
        ["HP"]=56, 
        ["Accuracy"]=44, 
        ["Parrying skill"]=20, 
        ["INT"]=32, 
        ["STR"]=31, 
        ["Haste"]=8, 
        ["discription"]="DEF:120 HP+56 STR+31 DEX+31 VIT+33 AGI+33 INT+32 MND+32 CHR+32 Accuracy+44 Attack+62 Magic Accuracy+37 Evasion+73 Magic Evasion+63 \"Magic Atk. Bonus\"+61 \"Magic Def. Bonus\"+6 Parrying skill +20 Haste+8% Ninjutsu damage +21", 
        ["CHR"]=32, 
        ["Magic Atk. Bonus"]=61, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=37, 
        ["VIT"]=33, 
        ["Attack"]=62
    }, 
    [394]={
        ["discription"]="DEF:73 HP+15 STR+14 DEX+26 VIT+12 AGI+39 MND+12 CHR+30 Evasion+80 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+5% \"Critical Parry\"+20 \"Utsusemi\"+1 Set: Augments \"Dual Wield\"", 
        ["MND"]=12, 
        ["AGI"]=39, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Haste"]=5, 
        ["en"]="Hattori Kyahan +1", 
        ["STR"]=14, 
        ["item_level"]=119, 
        ["HP"]=15, 
        ["DEX"]=26, 
        ["id"]=27436, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=73, 
        ["Evasion"]=80, 
        ["CHR"]=30, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=222, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }
    }, 
    [395]={
        ["discription"]="DEF:12 Enmity-2 Movement speed +12%", 
        ["DEF"]=12, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Danzo Sune-Ate", 
        ["id"]=12997, 
        ["category"]="Armor", 
        ["jobs"]={
            [12]="SAM", 
            [13]="NIN"
        }
    }, 
    [396]={
        ["Evasion"]=41, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=16, 
        ["DEF"]=116, 
        ["MND"]=16, 
        ["AGI"]=30, 
        ["Ranged Accuracy"]=15, 
        ["Store TP"]=7, 
        ["en"]="Samnuha Tights", 
        ["HP"]=41, 
        ["id"]=27295, 
        ["augments"]={
            [1]="STR+10", 
            [2]="DEX+10", 
            [3]="\"Dbl.Atk.\"+3", 
            [4]="\"Triple Atk.\"+3", 
            [5]="none"
        }, 
        ["INT"]=28, 
        ["STR"]=48, 
        ["Haste"]=6, 
        ["Accuracy"]=15, 
        ["CHR"]=8, 
        ["VIT"]=15, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["discription"]="DEF:116 HP+41 STR+38 DEX+6 VIT+15 AGI+30 INT+28 MND+16 CHR+8 +30 Accuracy+15 Ranged Accuracy+15 Evasion+41 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% \"Store TP\"+7"
    }, 
    [397]={
        ["Evasion"]=24, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEF"]=106, 
        ["DEX"]=50, 
        ["discription"]="DEF:106 HP+29 STR+12 DEX+38 VIT+30 AGI+13 INT+12 MND+30 CHR+17 Accuracy+33 Ranged Accuracy+33 Evasion+24 Magic Evasion+32 \"Magic Def. Bonus\"+1 Haste+4% Critical hit rate +5% Critical hit damage +5% Set: Increases Attack", 
        ["id"]=27116, 
        ["Set Bonus"]={
            ["set id"]=239, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Attack"]=20
                }, 
                [3]={
                    ["Attack"]=30
                }, 
                [4]={
                    ["Attack"]=40
                }, 
                [5]={
                    ["Attack"]=50
                }
            }
        }, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Ranged Accuracy"]=33, 
        ["en"]="Ryuo Tekko +1", 
        ["AGI"]=13, 
        ["HP"]=29, 
        ["Accuracy"]=58, 
        ["Critical hit damage"]=5, 
        ["INT"]=12, 
        ["STR"]=12, 
        ["Haste"]=4, 
        ["MND"]=30, 
        ["CHR"]=17, 
        ["item_level"]=119, 
        ["category"]="Armor", 
        ["Critical hit rate"]=5, 
        ["VIT"]=30, 
        ["augments"]={
            [1]="DEX+12", 
            [2]="Accuracy+25", 
            [3]="\"Dbl.Atk.\"+4"
        }
    }, 
    [398]={
        ["Evasion"]=44, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEX"]=24, 
        ["DEF"]=148, 
        ["augments"]={
            [1]="HP+65", 
            [2]="\"Store TP\"+8", 
            [3]="\"Dbl.Atk.\"+4"
        }, 
        ["MND"]=19, 
        ["en"]="Ryuo Domaru +1", 
        ["Set Bonus"]={
            ["set id"]=239, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Attack"]=20
                }, 
                [3]={
                    ["Attack"]=30
                }, 
                [4]={
                    ["Attack"]=40
                }, 
                [5]={
                    ["Attack"]=50
                }
            }
        }, 
        ["Store TP"]=8, 
        ["AGI"]=29, 
        ["HP"]=233, 
        ["Accuracy"]=37, 
        ["discription"]="DEF:148 HP+168 STR+28 DEX+24 VIT+23 AGI+29 INT+19 MND+19 CHR+19 Accuracy+37 Attack+37 Evasion+44 Magic Evasion+59 \"Magic Def. Bonus\"+4 Haste+3% Critical hit rate +5% Physical damage taken -5% Set: Increases Attack", 
        ["INT"]=19, 
        ["CHR"]=19, 
        ["STR"]=28, 
        ["Haste"]=3, 
        ["item_level"]=119, 
        ["category"]="Armor", 
        ["PDT"]=-5, 
        ["Critical hit rate"]=5, 
        ["id"]=25685, 
        ["VIT"]=23, 
        ["Attack"]=37
    }, 
    [399]={
        ["Evasion"]=49, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEX"]=53, 
        ["DEF"]=106, 
        ["Critical hit rate"]=6, 
        ["MND"]=26, 
        ["Set Bonus"]={
            ["set id"]=477, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }
        }, 
        ["Ranged Accuracy"]=43, 
        ["AGI"]=22, 
        ["en"]="Mummu Wrists +2", 
        ["HP"]=45, 
        ["Accuracy"]=43, 
        ["id"]=25836, 
        ["STR"]=16, 
        ["Haste"]=5, 
        ["MP"]=15, 
        ["discription"]="DEF:106 HP+45 MP+15 STR+16 DEX+53 VIT+30 AGI+22 INT+14 MND+26 CHR+21 Accuracy+43 Ranged Accuracy+43 Magic Accuracy+43 Evasion+49 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Double Attack\"+6% Critical hit rate +6% Set: Increases Dexterity, Agility, and Charisma", 
        ["INT"]=14, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["item_level"]=119, 
        ["VIT"]=30, 
        ["Magic Accuracy"]=43
    }, 
    [400]={
        ["Evasion"]=59, 
        ["MND"]=16, 
        ["id"]=25892, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=5, 
        ["Ranged Accuracy"]=46, 
        ["item_level"]=119, 
        ["DEF"]=132, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["HP"]=115, 
        ["en"]="Ken. Hakama +1", 
        ["Accuracy"]=51, 
        ["INT"]=32, 
        ["STR"]=37, 
        ["Haste"]=9, 
        ["Critical hit rate"]=7, 
        ["CHR"]=12, 
        ["VIT"]=25, 
        ["category"]="Armor", 
        ["discription"]="DEF:132 HP+115 STR+37 DEX+5 VIT+25 AGI+33 INT+32 MND+16 CHR+12 Accuracy+51 Ranged Accuracy+46 Evasion+59 Magic Evasion+139 \"Magic Def. Bonus\"+8 Haste+9% \"Triple Attack\"+5% \"Subtle Blow\"+10 Critical hit rate +7%", 
        ["AGI"]=33
    }, 
    [401]={
        ["Evasion"]=49, 
        ["MND"]=17, 
        ["STR"]=19, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=31, 
        ["AGI"]=22, 
        ["en"]="Hattori Zukin +1", 
        ["Dual Wield"]=7, 
        ["item_level"]=119, 
        ["HP"]=41, 
        ["DEF"]=101, 
        ["discription"]="DEF:101 HP+41 STR+19 DEX+31 VIT+18 AGI+22 INT+17 MND+17 CHR+17 Evasion+49 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+10% \"Dual Wield\"+7 Innin: \"Double Attack\"+9% Set: Augments \"Dual Wield\"", 
        ["slots"]={
            [4]="Head"
        }, 
        ["Haste"]=10, 
        ["id"]=26765, 
        ["INT"]=17, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["VIT"]=18, 
        ["Set Bonus"]={
            ["set id"]=222, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }
    }, 
    [402]={
        ["Evasion"]=68, 
        ["MND"]=31, 
        ["STR"]=33, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=33, 
        ["Set Bonus"]={
            ["set id"]=84, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Magic Accuracy"]=15
                }, 
                [3]={
                    ["Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Magic Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Magic Accuracy"]=45
                }, 
                [5]={
                    ["Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Magic Accuracy"]=60
                }
            }
        }, 
        ["AGI"]=32, 
        ["en"]="Hachiya Hatsu. +3", 
        ["item_level"]=119, 
        ["HP"]=64, 
        ["Haste"]=8, 
        ["discription"]="DEF:122 HP+64 STR+33 DEX+33 VIT+32 AGI+32 INT+31 MND+31 CHR+31 Magic Accuracy+54 Evasion+68 Magic Evasion+63 \"Magic Def. Bonus\"+5 Ninjutsu skill +17 Haste+8% \"Subtle Blow\"+9 Weapon skill damage +10% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=122, 
        ["Ninjutsu skill"]=17, 
        ["id"]=23387, 
        ["INT"]=31, 
        ["category"]="Armor", 
        ["CHR"]=31, 
        ["VIT"]=32, 
        ["Magic Accuracy"]=54
    }, 
    [403]={
        ["Ranged Attack"]=10, 
        ["DEX"]=24, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["discription"]="DEF:79 HP+9 STR+16 DEX+24 VIT+10 AGI+43 MND+11 CHR+26 Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+5 Evasion+80 Magic Evasion+75 Haste+4% \"Triple Attack\"+2 \"Subtle Blow\"+6 Physical damage taken -2%", 
        ["augments"]={
            [1]="Crit. hit damage +1%", 
            [2]="\"Fast Cast\"+4", 
            [3]="\"Treasure Hunter\"+2", 
            [4]="none", 
            [5]="none"
        }, 
        ["Accuracy"]=10, 
        ["Fast Cast"]=4, 
        ["Ranged Accuracy"]=10, 
        ["en"]="Herculean Boots", 
        ["MND"]=11, 
        ["AGI"]=43, 
        ["item_level"]=119, 
        ["HP"]=9, 
        ["STR"]=16, 
        ["DEF"]=79, 
        ["Magic Accuracy"]=10, 
        ["CHR"]=26, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=4, 
        ["Critical hit damage"]=1, 
        ["VIT"]=10, 
        ["id"]=27496, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["Evasion"]=80, 
        ["Magic Atk. Bonus"]=10, 
        ["Attack"]=10
    }, 
    [404]={
        ["Evasion"]=69, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["STR"]=28, 
        ["DEX"]=48, 
        ["DEF"]=141, 
        ["id"]=25798, 
        ["MND"]=20, 
        ["Set Bonus"]={
            ["set id"]=477, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }
        }, 
        ["Ranged Accuracy"]=46, 
        ["Store TP"]=6, 
        ["AGI"]=44, 
        ["HP"]=60, 
        ["Accuracy"]=46, 
        ["Critical hit rate"]=9, 
        ["slots"]={
            [5]="Body"
        }, 
        ["INT"]=21, 
        ["Haste"]=4, 
        ["MP"]=35, 
        ["discription"]="DEF:141 HP+60 MP+35 STR+28 DEX+48 VIT+24 AGI+44 INT+21 MND+20 CHR+24 Accuracy+46 Ranged Accuracy+46 Magic Accuracy+46 Evasion+69 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+4% \"Store TP\"+6 Critical hit rate +9% Set: Increases Dexterity, Agility, and Charisma", 
        ["CHR"]=24, 
        ["en"]="Mummu Jacket +2", 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["VIT"]=24, 
        ["Magic Accuracy"]=46
    }, 
    [405]={
        ["Evasion"]=62, 
        ["MND"]=17, 
        ["id"]=25552, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=47, 
        ["Ranged Accuracy"]=45, 
        ["item_level"]=119, 
        ["DEF"]=120, 
        ["slots"]={
            [4]="Head"
        }, 
        ["HP"]=88, 
        ["en"]="Ken. Jinpachi +1", 
        ["Accuracy"]=50, 
        ["INT"]=19, 
        ["STR"]=23, 
        ["Haste"]=6, 
        ["Critical hit rate"]=5, 
        ["CHR"]=19, 
        ["VIT"]=32, 
        ["category"]="Armor", 
        ["discription"]="DEF:120 HP+88 STR+23 DEX+47 VIT+32 AGI+34 INT+19 MND+17 CHR+19 Accuracy+50 Ranged Accuracy+45 Evasion+62 Magic Evasion+101 \"Magic Def. Bonus\"+6 Haste+6% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit rate +5%", 
        ["AGI"]=34
    }, 
    [406]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="STR+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="STR+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["STR"]=30, 
        ["Accuracy"]=20, 
        ["id"]=26258, 
        ["Attack"]=20
    }, 
    [407]={
        ["Evasion"]=51, 
        ["MND"]=28, 
        ["id"]=25979, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=62, 
        ["Ranged Accuracy"]=44, 
        ["item_level"]=119, 
        ["DEF"]=108, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["HP"]=61, 
        ["en"]="Ken. Tekko +1", 
        ["Accuracy"]=49, 
        ["INT"]=14, 
        ["STR"]=14, 
        ["Haste"]=4, 
        ["Critical hit rate"]=5, 
        ["CHR"]=21, 
        ["VIT"]=37, 
        ["category"]="Armor", 
        ["discription"]="DEF:108 HP+61 STR+14 DEX+62 VIT+37 AGI+5 INT+14 MND+28 CHR+21 Accuracy+49 Ranged Accuracy+44 Evasion+51 Magic Evasion+90 \"Magic Def. Bonus\"+5 Haste+4% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit rate +5%", 
        ["AGI"]=5
    }, 
    [408]={
        ["Evasion"]=55, 
        ["STR"]=30, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=37, 
        ["DEF"]=133, 
        ["MND"]=21, 
        ["Critical hit rate"]=6, 
        ["Set Bonus"]={
            ["set id"]=222, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }, 
        ["item_level"]=119, 
        ["en"]="Hattori Ningi +1", 
        ["HP"]=63, 
        ["id"]=26923, 
        ["AGI"]=28, 
        ["INT"]=21, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=4, 
        ["Accuracy"]=24, 
        ["CHR"]=21, 
        ["VIT"]=24, 
        ["category"]="Armor", 
        ["discription"]="DEF:133 HP+63 STR+30 DEX+37 VIT+24 AGI+28 INT+21 MND+21 CHR+21 Accuracy+24 Attack+24 Evasion+55 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% \"Migawari\"+12 Critical hit rate +6% Set: Augments \"Dual Wield\"", 
        ["Attack"]=24
    }, 
    [409]={
        ["Evasion"]=91, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["STR"]=11, 
        ["DEX"]=40, 
        ["DEF"]=121, 
        ["id"]=23732, 
        ["MND"]=16, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=8, 
        ["en"]="Malignance Chapeau", 
        ["HP"]=45, 
        ["Accuracy"]=50, 
        ["AGI"]=33, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Haste"]=6, 
        ["MP"]=29, 
        ["discription"]="DEF:121 HP+45 MP+29 STR+11 DEX+40 VIT+19 AGI+33 INT+25 MND+16 CHR+17 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+91 Magic Evasion+123 \"Magic Def. Bonus\"+5 Haste+6% \"Store TP\"+8 Physical damage limit +3% Damage taken -6%", 
        ["INT"]=25, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["DT"]=-6, 
        ["VIT"]=19, 
        ["Magic Accuracy"]=50
    }, 
    [410]={
        ["Evasion"]=72, 
        ["MND"]=26, 
        ["DEF"]=124, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=30, 
        ["slots"]={
            [5]="Body"
        }, 
        ["AGI"]=27, 
        ["en"]="Naga Samue", 
        ["Store TP"]=5, 
        ["HP"]=169, 
        ["id"]=26949, 
        ["discription"]="DEF:124 HP+119 STR+29 DEX+30 VIT+23 AGI+27 INT+26 MND+26 CHR+26 Attack+15 Evasion+52 Magic Evasion+53 \"Magic Def. Bonus\"+4 Haste+4% \"Store TP\"+5", 
        ["INT"]=26, 
        ["STR"]=29, 
        ["Haste"]=4, 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Evasion+20"
        }, 
        ["CHR"]=26, 
        ["VIT"]=33, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["Attack"]=15
    }, 
    [411]={
        ["Evasion"]=55, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=33, 
        ["DEF"]=138, 
        ["MND"]=20, 
        ["Dual Wield"]=3, 
        ["discription"]="DEF:138 HP+63 STR+26 DEX+33 VIT+23 AGI+29 INT+20 MND+20 CHR+20 Accuracy+23 Magic Accuracy+23 Evasion+55 Magic Evasion+69 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+6 Haste+4% Magic burst damage II +8 \"Death\" resistance +15", 
        ["augments"]={
            [1]="Mag. Acc.+12", 
            [2]="\"Mag.Atk.Bns.\"+12", 
            [3]="\"Dual Wield\"+3", 
            [4]="none", 
            [5]="none"
        }, 
        ["item_level"]=119, 
        ["HP"]=63, 
        ["id"]=26973, 
        ["AGI"]=29, 
        ["INT"]=20, 
        ["STR"]=26, 
        ["Haste"]=4, 
        ["Accuracy"]=23, 
        ["CHR"]=20, 
        ["Magic Atk. Bonus"]=32, 
        ["category"]="Armor", 
        ["en"]="Samnuha Coat", 
        ["VIT"]=23, 
        ["Magic Accuracy"]=35
    }, 
    [412]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="STR+20", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="INT+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["INT"]=10, 
        ["STR"]=20, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=26258, 
        ["DEF"]=16, 
        ["Magic Accuracy"]=20
    }, 
    [413]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["AGI"]=30, 
        ["augments"]={
            [1]="AGI+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="AGI+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["id"]=26258, 
        ["Attack"]=20
    }, 
    [414]={
        ["Ranged Attack"]=48, 
        ["DEF"]=110, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=44, 
        ["Throwing skill"]=14, 
        ["MND"]=38, 
        ["STR"]=20, 
        ["Ranged Accuracy"]=48, 
        ["Evasion"]=52, 
        ["AGI"]=26, 
        ["HP"]=47, 
        ["id"]=23521, 
        ["discription"]="DEF:110 HP+47 STR+20 DEX+44 VIT+38 AGI+26 INT+20 MND+38 CHR+26 Accuracy+48 Ranged Accuracy+48 Ranged Attack+48 Evasion+52 Magic Evasion+46 \"Magic Def. Bonus\"+2 Throwing skill +14 Haste+5% \"Subtle Blow\"+9 \"Daken\"+10 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["INT"]=20, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=5, 
        ["Accuracy"]=48, 
        ["CHR"]=26, 
        ["VIT"]=38, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["en"]="Hachiya Tekko +3", 
        ["Set Bonus"]={
            ["set id"]=84, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Magic Accuracy"]=15
                }, 
                [3]={
                    ["Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Magic Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Magic Accuracy"]=45
                }, 
                [5]={
                    ["Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Magic Accuracy"]=60
                }
            }
        }
    }, 
    [415]={
        ["Evasion"]=88, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=37, 
        ["DEF"]=85, 
        ["MND"]=11, 
        ["discription"]="DEF:85 HP+30 MP+10 STR+16 DEX+37 VIT+10 AGI+57 MND+11 CHR+29 Accuracy+42 Ranged Accuracy+42 Magic Accuracy+42 Evasion+88 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+4% \"Subtle Blow\"+9 Critical hit rate +5% Set: Increases Dexterity, Agility, and Charisma", 
        ["Ranged Accuracy"]=42, 
        ["Critical hit rate"]=5, 
        ["en"]="Mummu Gamash. +2", 
        ["HP"]=30, 
        ["id"]=25954, 
        ["AGI"]=57, 
        ["STR"]=16, 
        ["Haste"]=4, 
        ["MP"]=10, 
        ["Accuracy"]=42, 
        ["CHR"]=29, 
        ["VIT"]=10, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=477, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }
        }, 
        ["item_level"]=119, 
        ["Magic Accuracy"]=42
    }, 
    [416]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["augments"]={
            [1]="AGI+20", 
            [2]="Eva.+20 /Mag. Eva.+20", 
            [3]="Mag. Evasion+10", 
            [4]="Enmity+10", 
            [5]="Damage taken-5%"
        }, 
        ["AGI"]=20, 
        ["Evasion"]=10, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=26258, 
        ["DEF"]=16, 
        ["DT"]=-5
    }, 
    [417]={
        ["Evasion"]=114, 
        ["MND"]=3, 
        ["Haste"]=3, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=31, 
        ["Set Bonus"]={
            ["set id"]=281, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Counter"]=4
                }, 
                [3]={
                    ["Counter"]=8
                }, 
                [4]={
                    ["Counter"]=12
                }, 
                [5]={
                    ["Counter"]=16
                }
            }
        }, 
        ["item_level"]=119, 
        ["Dual Wield"]=8, 
        ["en"]="Hiza. Sune-Ate +2", 
        ["HP"]=30, 
        ["discription"]="DEF:85 HP+30 STR+28 DEX+31 VIT+23 AGI+34 MND+3 CHR+28 Accuracy+42 Attack+24 Evasion+114 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+3% \"Dual Wield\"+8 Set: Enhances \"Counter\" effect", 
        ["Accuracy"]=42, 
        ["CHR"]=28, 
        ["STR"]=28, 
        ["DEF"]=85, 
        ["id"]=25948, 
        ["category"]="Armor", 
        ["AGI"]=34, 
        ["VIT"]=23, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Attack"]=24
    }, 
    [418]={
        ["Evasion"]=59, 
        ["MND"]=30, 
        ["Haste"]=5, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=45, 
        ["STR"]=12, 
        ["AGI"]=14, 
        ["en"]="Hattori Tekko +1", 
        ["discription"]="DEF:91 HP+27 STR+12 DEX+45 VIT+29 AGI+14 INT+12 MND+30 CHR+17 Accuracy+23 Evasion+59 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Futae\"+24 Elemental ninjutsu damage +14% Set: Augments \"Dual Wield\"", 
        ["HP"]=27, 
        ["item_level"]=119, 
        ["Accuracy"]=23, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=91, 
        ["id"]=27077, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["VIT"]=29, 
        ["Set Bonus"]={
            ["set id"]=222, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }
    }, 
    [419]={
        ["discription"]="DMG:148 Delay:210 Attack+60 Magic Damage+186 Katana skill +269 Parrying skill +269 Magic Accuracy skill +242 \"Blade: Metsu\" Additional effect: Paralysis Aftermath: Attack+10% \"Subtle Blow\"+10 Afterglow", 
        ["skill"]="Katana", 
        ["Parrying skill"]=269, 
        ["Katana skill"]=269, 
        ["en"]="Kikoku", 
        ["item_level"]=119, 
        ["delay"]=210, 
        ["id"]=21906, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=148, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["category"]="Weapon", 
        ["Attack"]=10
    }, 
    [420]={
        ["Evasion"]=27, 
        ["Ranged Accuracy"]=50, 
        ["id"]=20994, 
        ["en"]="Shigi", 
        ["Katana skill"]=228, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["delay"]=190, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=77, 
        ["skill"]="Katana", 
        ["Ninjutsu skill"]=10, 
        ["augments"]={
            [1]="Accuracy+50", 
            [2]="Rng.Acc.+50", 
            [3]="Damage Taken -5%"
        }, 
        ["category"]="Weapon", 
        ["Parrying skill"]=228, 
        ["damage"]=98, 
        ["discription"]="DMG:98 Delay:190 Accuracy+27 Evasion+27 Katana skill +228 Parrying skill +228 Magic Accuracy skill +215 Ninjutsu skill +10 Enmity-10 Ninjutsu recast delay -3 \"Ninja Tool Expertise\"+5"
    }, 
    [421]={
        ["Evasion"]=47, 
        ["MND"]=17, 
        ["STR"]=29, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Haste"]=8, 
        ["AGI"]=20, 
        ["en"]="Hattori Hakama +1", 
        ["Katana skill"]=23, 
        ["item_level"]=119, 
        ["HP"]=50, 
        ["discription"]="DEF:113 HP+50 STR+29 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Accuracy+20 Evasion+47 Magic Evasion+75 \"Magic Def. Bonus\"+5 Katana skill +23 Haste+8% \"Yonin\": \"Counter\"+14 Set: Augments \"Dual Wield\"", 
        ["Accuracy"]=20, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=113, 
        ["id"]=27262, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["VIT"]=16, 
        ["Set Bonus"]={
            ["set id"]=222, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }
    }, 
    [422]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["Magic Atk. Bonus"]=10, 
        ["augments"]={
            [1]="INT+20", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="INT+10", 
            [4]="\"Mag.Atk.Bns.\"+10", 
            [5]="none"
        }, 
        ["INT"]=30, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=26258, 
        ["DEF"]=16, 
        ["Magic Accuracy"]=20
    }, 
    [423]={
        ["Evasion"]=41, 
        ["DEF"]=97, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=39, 
        ["item_level"]=119, 
        ["MND"]=26, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Ranged Accuracy"]=12, 
        ["id"]=27140, 
        ["en"]="Herculean Gloves", 
        ["HP"]=20, 
        ["augments"]={
            [1]="\"Mag.Atk.Bns.\"+24", 
            [2]="Magic burst dmg.+6%", 
            [3]="INT+8", 
            [4]="none", 
            [5]="none"
        }, 
        ["PDT"]=-2, 
        ["INT"]=22, 
        ["STR"]=16, 
        ["Haste"]=5, 
        ["Accuracy"]=12, 
        ["CHR"]=19, 
        ["Magic Atk. Bonus"]=24, 
        ["category"]="Armor", 
        ["discription"]="DEF:97 HP+20 STR+16 DEX+39 VIT+30 AGI+8 INT+14 MND+26 CHR+19 Accuracy+12 Ranged Accuracy+12 Evasion+41 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+2% \"Subtle Blow\"+5 Physical damage taken -2%", 
        ["VIT"]=30, 
        ["AGI"]=8
    }, 
    [424]={
        ["Evasion"]=63, 
        ["discription"]="DEF:134 HP+82 STR+42 VIT+24 AGI+36 INT+42 MND+27 CHR+20 Accuracy+39 Attack+64 Magic Accuracy+39 Evasion+63 Magic Evasion+84 \"Magic Def. Bonus\"+5 Haste+6% \"Dual Wield\"+10 Weapon skill damage +10%", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=134, 
        ["MND"]=27, 
        ["Dual Wield"]=10, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Mijin Gakure\" effect", 
            [4]="none"
        }, 
        ["en"]="Mochi. Hakama +3", 
        ["AGI"]=36, 
        ["HP"]=82, 
        ["id"]=23611, 
        ["item_level"]=119, 
        ["INT"]=42, 
        ["STR"]=42, 
        ["Haste"]=6, 
        ["Accuracy"]=39, 
        ["CHR"]=20, 
        ["VIT"]=24, 
        ["category"]="Armor", 
        ["Attack"]=64, 
        ["Magic Accuracy"]=39
    }, 
    [425]={
        ["discription"]="DMG:100 Delay:222 Accuracy+20 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 Occasionally attacks twice Additional effect: Haste", 
        ["Parrying skill"]=242, 
        ["skill"]="Katana", 
        ["Katana skill"]=242, 
        ["item_level"]=119, 
        ["en"]="Kujaku +1", 
        ["delay"]=222, 
        ["Evasion"]=22, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=20, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=20985, 
        ["category"]="Weapon", 
        ["damage"]=100
    }, 
    [426]={
        ["Ranged Attack"]=79, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["STR"]=34, 
        ["DEX"]=35, 
        ["DEF"]=154, 
        ["id"]=23477, 
        ["MND"]=34, 
        ["Dual Wield"]=9, 
        ["Ranged Accuracy"]=47, 
        ["en"]="Mochi. Chainmail +3", 
        ["AGI"]=35, 
        ["HP"]=79, 
        ["Accuracy"]=51, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Sange\" effect", 
            [4]="none"
        }, 
        ["INT"]=34, 
        ["CHR"]=34, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=4, 
        ["discription"]="DEF:154 HP+79 STR+34 DEX+35 VIT+31 AGI+35 INT+34 MND+34 CHR+34 Accuracy+51 Attack+87 Ranged Accuracy+47 Ranged Attack+79 Magic Accuracy+40 Evasion+72 Magic Evasion+73 \"Magic Def. Bonus\"+6 Haste+4% \"Dual Wield\"+9 \"Utsusemi\" spellcasting time -14% \"Daken\"+10", 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["Magic Accuracy"]=40, 
        ["Evasion"]=72, 
        ["VIT"]=31, 
        ["Attack"]=87
    }, 
    [427]={
        ["Evasion"]=80, 
        ["MND"]=14, 
        ["Critical hit rate"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=44, 
        ["Ranged Accuracy"]=43, 
        ["item_level"]=119, 
        ["DEF"]=81, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["HP"]=70, 
        ["en"]="Ken. Sune-Ate +1", 
        ["Accuracy"]=48, 
        ["STR"]=20, 
        ["Haste"]=3, 
        ["id"]=25959, 
        ["CHR"]=26, 
        ["VIT"]=21, 
        ["category"]="Armor", 
        ["discription"]="DEF:81 HP+70 STR+20 DEX+44 VIT+21 AGI+44 MND+14 CHR+26 Accuracy+48 Ranged Accuracy+43 Evasion+80 Magic Evasion+139 \"Magic Def. Bonus\"+6 Haste+3% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit rate +5%", 
        ["AGI"]=44
    }, 
    [428]={
        ["Evasion"]=42, 
        ["MND"]=30, 
        ["DEF"]=83, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=36, 
        ["STR"]=16, 
        ["en"]="Naga Tekko", 
        ["AGI"]=8, 
        ["item_level"]=119, 
        ["HP"]=115, 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Evasion+20"
        }, 
        ["discription"]="DEF:83 HP+65 STR+16 DEX+36 VIT+34 AGI+8 INT+12 MND+30 CHR+18 Evasion+22 Magic Evasion+26 \"Magic Def. Bonus\"+1 Haste+5% Damage taken -2% Pet: Attack+20 Ranged Attack+20", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=5, 
        ["id"]=27099, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=18, 
        ["VIT"]=44, 
        ["DT"]=-2
    }, 
    [429]={
        ["Evasion"]=99, 
        ["MND"]=22, 
        ["STR"]=24, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=25, 
        ["Set Bonus"]={
            ["set id"]=84, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Magic Accuracy"]=15
                }, 
                [3]={
                    ["Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Magic Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Magic Accuracy"]=45
                }, 
                [5]={
                    ["Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Magic Accuracy"]=60
                }
            }
        }, 
        ["AGI"]=44, 
        ["en"]="Hachiya Kyahan +3", 
        ["item_level"]=119, 
        ["HP"]=29, 
        ["DEF"]=92, 
        ["discription"]="DEF:92 HP+29 STR+24 DEX+25 VIT+21 AGI+44 INT+20 MND+22 CHR+39 Magic Accuracy+52 Evasion+99 Magic Evasion+84 \"Magic Atk. Bonus\"+23 \"Magic Def. Bonus\"+4 Haste+4% Magic burst damage +10 Dusk to dawn: Movement speed +25% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["INT"]=20, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=4, 
        ["id"]=23655, 
        ["CHR"]=39, 
        ["Magic Atk. Bonus"]=23, 
        ["category"]="Armor", 
        ["VIT"]=21, 
        ["Magic Accuracy"]=52
    }, 
    [430]={
        ["Evasion"]=102, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["STR"]=19, 
        ["DEX"]=49, 
        ["DEF"]=143, 
        ["id"]=23733, 
        ["MND"]=24, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=11, 
        ["en"]="Malignance Tabard", 
        ["HP"]=68, 
        ["Accuracy"]=50, 
        ["AGI"]=42, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=4, 
        ["MP"]=44, 
        ["discription"]="DEF:143 HP+68 MP+44 STR+19 DEX+49 VIT+25 AGI+42 INT+19 MND+24 CHR+24 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+102 Magic Evasion+139 \"Magic Def. Bonus\"+8 Haste+4% \"Store TP\"+11 Physical damage limit +6% Damage taken -9%", 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["CHR"]=24, 
        ["DT"]=-9, 
        ["VIT"]=25, 
        ["Magic Accuracy"]=50
    }, 
    [431]={
        ["Evasion"]=68, 
        ["AGI"]=26, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=124, 
        ["Set Bonus"]={
            ["set id"]=84, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Magic Accuracy"]=15
                }, 
                [3]={
                    ["Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Magic Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Magic Accuracy"]=45
                }, 
                [5]={
                    ["Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Magic Accuracy"]=60
                }
            }
        }, 
        ["Dual Wield"]=4, 
        ["Ranged Accuracy"]=25, 
        ["Store TP"]=3, 
        ["en"]="Hachiya Hakama +2", 
        ["HP"]=70, 
        ["id"]=23253, 
        ["MND"]=22, 
        ["INT"]=37, 
        ["STR"]=37, 
        ["Haste"]=6, 
        ["Accuracy"]=46, 
        ["CHR"]=15, 
        ["VIT"]=19, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["discription"]="DEF:124 HP+70 STR+37 VIT+19 AGI+26 INT+37 MND+22 CHR+15 Accuracy+46 Ranged Accuracy+25 Evasion+68 Magic Evasion+74 \"Magic Def. Bonus\"+3 Haste+6% \"Store TP\"+3 \"Dual Wield\"+4 \"Subtle Blow\"+8 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy"
    }, 
    [432]={
        ["Ranged Attack"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["discription"]="DEF:79 HP+9 STR+16 DEX+24 VIT+10 AGI+43 MND+11 CHR+26 Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+5 Evasion+80 Magic Evasion+75 Haste+4% \"Triple Attack\"+2 \"Subtle Blow\"+6 Physical damage taken -2%", 
        ["DEX"]=24, 
        ["Haste"]=4, 
        ["augments"]={
            [1]="Accuracy+20", 
            [2]="\"Triple Atk.\"+4", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=11, 
        ["en"]="Herculean Boots", 
        ["Ranged Accuracy"]=10, 
        ["item_level"]=119, 
        ["AGI"]=43, 
        ["HP"]=9, 
        ["Accuracy"]=30, 
        ["id"]=27496, 
        ["CHR"]=26, 
        ["category"]="Armor", 
        ["STR"]=16, 
        ["DEF"]=79, 
        ["Evasion"]=80, 
        ["Magic Accuracy"]=10, 
        ["VIT"]=10, 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["PDT"]=-2, 
        ["Attack"]=10
    }, 
    [433]={
        ["Ranged Attack"]=36, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=102, 
        ["DEX"]=33, 
        ["discription"]="DEF:102 HP+41 STR+19 DEX+21 VIT+15 AGI+19 INT+14 MND+14 CHR+14 Attack+36 Ranged Attack+36 Evasion+49 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+8% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit damage +6% Set: Increases rate of critical hits", 
        ["augments"]={
            [1]="DEX+12", 
            [2]="AGI+12", 
            [3]="Accuracy+20"
        }, 
        ["MND"]=14, 
        ["en"]="Adhemar Bonnet +1", 
        ["slots"]={
            [4]="Head"
        }, 
        ["AGI"]=31, 
        ["item_level"]=119, 
        ["HP"]=41, 
        ["Accuracy"]=20, 
        ["Critical hit damage"]=6, 
        ["INT"]=14, 
        ["STR"]=19, 
        ["Haste"]=8, 
        ["Evasion"]=49, 
        ["CHR"]=14, 
        ["id"]=25614, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=11, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }
        }, 
        ["VIT"]=15, 
        ["Attack"]=36
    }, 
    [434]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["DEX"]=30, 
        ["Accuracy"]=20, 
        ["id"]=26258, 
        ["Attack"]=20
    }, 
    [435]={
        ["Ranged Attack"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEX"]=28, 
        ["Haste"]=8, 
        ["augments"]={
            [1]="Accuracy+13", 
            [2]="\"Fast Cast\"+6", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=16, 
        ["en"]="Herculean Helm", 
        ["Evasion"]=55, 
        ["Fast Cast"]=13, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["Accuracy"]=13, 
        ["discription"]="DEF:108 HP+38 STR+22 DEX+28 VIT+18 AGI+25 INT+20 MND+16 CHR+17 Attack+15 Ranged Attack+15 \"Magic Atk. Bonus\"+10 Evasion+55 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+8% \"Fast Cast\"+7%", 
        ["INT"]=20, 
        ["STR"]=22, 
        ["DEF"]=108, 
        ["AGI"]=25, 
        ["CHR"]=17, 
        ["Magic Atk. Bonus"]=10, 
        ["category"]="Armor", 
        ["id"]=25642, 
        ["VIT"]=18, 
        ["Attack"]=15
    }, 
    [436]={
        ["Ranged Attack"]=10, 
        ["en"]="Kanaria", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Crit. hit damage +6%", 
            [2]="AGI+15", 
            [3]="Accuracy+9", 
            [4]="none", 
            [5]="none"
        }, 
        ["AGI"]=15, 
        ["Fast Cast"]=5, 
        ["Katana skill"]=242, 
        ["Ranged Accuracy"]=15, 
        ["Store TP"]=5, 
        ["item_level"]=119, 
        ["delay"]=227, 
        ["id"]=21904, 
        ["Evasion"]=22, 
        ["discription"]="DMG:127 Delay:227 Accuracy+15 Attack+10 Ranged Accuracy+15 Ranged Attack+10 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Store TP\"+5 \"Fast Cast\"+5%", 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=24, 
        ["Parrying skill"]=242, 
        ["skill"]="Katana", 
        ["damage"]=127, 
        ["Critical hit damage"]=6, 
        ["Attack"]=10
    }, 
    [437]={
        ["Evasion"]=89, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=29, 
        ["DEF"]=93, 
        ["MND"]=22, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enh. Ninj. Mag. Acc/Cast Time Red.", 
            [4]="none"
        }, 
        ["discription"]="DEF:93 HP+33 STR+28 DEX+29 VIT+25 AGI+48 MND+22 CHR+39 Accuracy+43 Attack+76 Magic Accuracy+36 Evasion+89 Magic Evasion+84 \"Magic Def. Bonus\"+5 Ninjutsu skill +23 Haste+4% Enmity+8", 
        ["item_level"]=119, 
        ["AGI"]=48, 
        ["HP"]=33, 
        ["id"]=23678, 
        ["en"]="Mochi. Kyahan +3", 
        ["STR"]=28, 
        ["Haste"]=4, 
        ["Ninjutsu skill"]=23, 
        ["Accuracy"]=43, 
        ["CHR"]=39, 
        ["VIT"]=25, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=36, 
        ["Attack"]=76
    }, 
    [438]={
        ["en"]="Date Shuriken", 
        ["Ranged Accuracy"]=5, 
        ["Throwing skill"]=242, 
        ["discription"]="DMG:125 Delay:192 DEX+5 AGI+5 Accuracy+5 Ranged Accuracy+5 Evasion+5 Throwing skill +242 Enmity +3", 
        ["category"]="Weapon", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["AGI"]=5, 
        ["delay"]=192, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["skill"]="Throwing", 
        ["Evasion"]=5, 
        ["DEX"]=5, 
        ["item_level"]=119, 
        ["id"]=22292, 
        ["Accuracy"]=5, 
        ["damage"]=125
    }, 
    [439]={
        ["discription"]="DMG:123 Delay:190 AGI+20 Accuracy+27 Attack+27 Ranged Accuracy+50 Evasion+27 Katana skill +228 Parrying skill +228 Magic Accuracy skill +215 Critical hit rate +3%", 
        ["Critical hit rate"]=3, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Ranged Accuracy"]=50, 
        ["AGI"]=20, 
        ["Katana skill"]=228, 
        ["en"]="Taka", 
        ["delay"]=190, 
        ["Evasion"]=27, 
        ["id"]=21905, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["damage"]=123, 
        ["Accuracy"]=27, 
        ["Parrying skill"]=228, 
        ["Attack"]=27
    }, 
    [440]={
        ["Evasion"]=63, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEX"]=39, 
        ["DEF"]=115, 
        ["Critical hit rate"]=5, 
        ["MND"]=14, 
        ["Set Bonus"]={
            ["set id"]=477, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }
        }, 
        ["Ranged Accuracy"]=44, 
        ["AGI"]=34, 
        ["en"]="Mummu Bonnet +2", 
        ["HP"]=37, 
        ["Accuracy"]=44, 
        ["id"]=25570, 
        ["STR"]=20, 
        ["Haste"]=8, 
        ["MP"]=20, 
        ["discription"]="DEF:115 HP+37 MP+20 STR+20 DEX+39 VIT+16 AGI+34 INT+15 MND+14 CHR+17 Accuracy+44 Ranged Accuracy+44 Magic Accuracy+44 Evasion+63 Magic Evasion+75 \"Magic Def. Bonus\"+3 Haste+8% Potency of \"Waltz\" effects received +9% Critical hit rate +5% Set: Increases Dexterity, Agility, and Charisma", 
        ["INT"]=15, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["item_level"]=119, 
        ["VIT"]=16, 
        ["Magic Accuracy"]=44
    }, 
    [441]={
        ["discription"]="DMG:159 Delay:227 Magic Damage+186 Katana skill +269 Parrying skill +269 Magic Accuracy skill +242 \"Store TP\"+10 \"TP Bonus\"+500 \"Blade: Shun\" Aftermath: Increases skillchain potency Increases magic burst potency Ultimate Skillchain", 
        ["skill"]="Katana", 
        ["category"]="Weapon", 
        ["Katana skill"]=269, 
        ["Store TP"]=10, 
        ["en"]="Heishi Shorinken", 
        ["delay"]=227, 
        ["id"]=20977, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=269, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["item_level"]=119, 
        ["damage"]=159
    }, 
    [442]={
        ["Evasion"]=53, 
        ["MND"]=17, 
        ["DEF"]=110, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["AGI"]=21, 
        ["Dual Wield"]=4, 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Evasion+20"
        }, 
        ["HP"]=147, 
        ["en"]="Naga Hakama", 
        ["id"]=27284, 
        ["STR"]=37, 
        ["Haste"]=6, 
        ["item_level"]=119, 
        ["INT"]=32, 
        ["category"]="Armor", 
        ["CHR"]=10, 
        ["VIT"]=29, 
        ["discription"]="DEF:110 HP+97 STR+37 VIT+19 AGI+21 INT+32 MND+17 CHR+10 Evasion+33 Magic Evasion+64 \"Magic Def. Bonus\"+3 Haste+6% \"Dual Wield\"+4 Pet: Accuracy+20 Ranged Accuracy+20"
    }, 
    [443]={
        ["Evasion"]=24, 
        ["MND"]=17, 
        ["en"]="Jokushu Haidate", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=120, 
        ["AGI"]=21, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Critical hit rate"]=4, 
        ["HP"]=50, 
        ["DEX"]=35, 
        ["id"]=27318, 
        ["STR"]=29, 
        ["Haste"]=20, 
        ["discription"]="DEF:120 HP+50 STR+29 DEX+35 VIT+15 AGI+21 INT+30 MND+17 CHR+11 +50 Evasion+24 Magic Evasion+80 \"Magic Def. Bonus\"+3 Haste+20% Critical hit rate +4%", 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["VIT"]=15, 
        ["item_level"]=119
    }, 
    [444]={
        ["Evasion"]=36, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=56, 
        ["DEF"]=93, 
        ["MND"]=30, 
        ["AGI"]=19, 
        ["Ranged Accuracy"]=32, 
        ["Store TP"]=7, 
        ["en"]="Adhemar Wrist. +1", 
        ["HP"]=22, 
        ["augments"]={
            [1]="DEX+12", 
            [2]="AGI+12", 
            [3]="Accuracy+20"
        }, 
        ["discription"]="DEF:93 HP+22 STR+15 DEX+44 VIT+29 AGI+7 INT+12 MND+30 CHR+17 Accuracy+32 Ranged Accuracy+32 Evasion+36 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+4% \"Store TP\"+7 Set: Increases rate of critical hits", 
        ["INT"]=12, 
        ["STR"]=15, 
        ["Haste"]=5, 
        ["Accuracy"]=52, 
        ["CHR"]=17, 
        ["VIT"]=29, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["id"]=27118, 
        ["Set Bonus"]={
            ["set id"]=11, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }
        }
    }, 
    [445]={
        ["Evasion"]=89, 
        ["MND"]=12, 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Evasion+20"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=15, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["AGI"]=34, 
        ["en"]="Naga Kyahan", 
        ["All skills"]=10, 
        ["HP"]=113, 
        ["discription"]="DEF:67 HP+63 STR+14 DEX+15 VIT+11 AGI+34 MND+12 CHR+29 Accuracy+18 Attack+18 Evasion+69 Magic Evasion+64 \"Magic Def. Bonus\"+3 Haste+4% \"Double Attack\"+3% Automaton: All skills +10", 
        ["Accuracy"]=18, 
        ["CHR"]=29, 
        ["STR"]=14, 
        ["Haste"]=4, 
        ["id"]=27459, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["VIT"]=21, 
        ["DEF"]=67, 
        ["Attack"]=18
    }, 
    [446]={
        ["Evasion"]=55, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEX"]=45, 
        ["DEF"]=133, 
        ["augments"]={
            [1]="DEX+12", 
            [2]="AGI+12", 
            [3]="Accuracy+20"
        }, 
        ["MND"]=20, 
        ["Dual Wield"]=6, 
        ["Ranged Accuracy"]=35, 
        ["Set Bonus"]={
            ["set id"]=11, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }
        }, 
        ["en"]="Adhemar Jacket +1", 
        ["HP"]=63, 
        ["Accuracy"]=55, 
        ["item_level"]=119, 
        ["INT"]=20, 
        ["CHR"]=20, 
        ["STR"]=26, 
        ["Haste"]=4, 
        ["id"]=25687, 
        ["category"]="Armor", 
        ["AGI"]=41, 
        ["discription"]="DEF:133 HP+63 STR+26 DEX+33 VIT+23 AGI+29 INT+20 MND+20 CHR+20 Accuracy+35 Attack+35 Ranged Accuracy+35 Ranged Attack+35 Evasion+55 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% \"Triple Attack\"+4% Enmity-8 \"Dual Wield\"+6 Set: Increases rate of critical hits", 
        ["Ranged Attack"]=35, 
        ["VIT"]=23, 
        ["Attack"]=35
    }, 
    [447]={
        ["discription"]="DMG:99 Delay:188 Accuracy+6 Attack+6 Ranged Accuracy+11 Throwing skill +228 Critical hit rate +2%", 
        ["Ranged Accuracy"]=11, 
        ["Throwing skill"]=228, 
        ["category"]="Weapon", 
        ["skill"]="Throwing", 
        ["item_level"]=118, 
        ["delay"]=188, 
        ["en"]="Happo Shuriken +1", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["damage"]=99, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=6, 
        ["id"]=21354, 
        ["Critical hit rate"]=2, 
        ["Attack"]=6
    }, 
    [448]={
        ["Evasion"]=36, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEX"]=17, 
        ["DEF"]=116, 
        ["augments"]={
            [1]="HP+65", 
            [2]="\"Store TP\"+5", 
            [3]="\"Subtle Blow\"+8"
        }, 
        ["MND"]=11, 
        ["Dual Wield"]=9, 
        ["Ranged Accuracy"]=35, 
        ["Store TP"]=12, 
        ["item_level"]=119, 
        ["HP"]=106, 
        ["Accuracy"]=35, 
        ["en"]="Ryuo Somen +1", 
        ["INT"]=11, 
        ["STR"]=21, 
        ["Haste"]=7, 
        ["AGI"]=20, 
        ["CHR"]=11, 
        ["discription"]="DEF:116 HP+41 STR+21 DEX+17 VIT+14 AGI+20 INT+11 MND+11 CHR+11 Accuracy+35 Ranged Accuracy+35 Evasion+36 Magic Evasion+48 \"Magic Def. Bonus\"+2 Haste+7% Enmity-6 \"Store TP\"+7 \"Dual Wield\"+9 Set: Increases Attack", 
        ["category"]="Armor", 
        ["id"]=25612, 
        ["VIT"]=14, 
        ["Set Bonus"]={
            ["set id"]=239, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Attack"]=20
                }, 
                [3]={
                    ["Attack"]=30
                }, 
                [4]={
                    ["Attack"]=40
                }, 
                [5]={
                    ["Attack"]=50
                }
            }
        }
    }, 
    [449]={
        ["Evasion"]=80, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["STR"]=25, 
        ["DEX"]=56, 
        ["DEF"]=108, 
        ["id"]=23734, 
        ["MND"]=42, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=12, 
        ["en"]="Malignance Gloves", 
        ["HP"]=57, 
        ["Accuracy"]=50, 
        ["AGI"]=24, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=4, 
        ["MP"]=36, 
        ["discription"]="DEF:108 HP+57 MP+36 STR+25 DEX+56 VIT+32 AGI+24 INT+11 MND+42 CHR+21 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+80 Magic Evasion+112 \"Magic Def. Bonus\"+4 Haste+4% \"Store TP\"+12 Physical damage limit +4% Damage taken -5%", 
        ["INT"]=11, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["DT"]=-5, 
        ["VIT"]=32, 
        ["Magic Accuracy"]=50
    }, 
    [450]={
        ["Evasion"]=119, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["DEX"]=40, 
        ["DEF"]=88, 
        ["MND"]=15, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=9, 
        ["AGI"]=49, 
        ["HP"]=34, 
        ["id"]=23736, 
        ["en"]="Malignance Boots", 
        ["STR"]=6, 
        ["Haste"]=3, 
        ["MP"]=22, 
        ["Accuracy"]=50, 
        ["CHR"]=40, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["discription"]="DEF:88 HP+34 MP+22 STR+6 DEX+40 VIT+12 AGI+49 MND+15 CHR+40 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+119 Magic Evasion+150 \"Magic Def. Bonus\"+5 Haste+3% \"Store TP\"+9 Physical damage limit +2% Damage taken -4%", 
        ["DT"]=-4, 
        ["Magic Accuracy"]=50
    }, 
    [451]={
        ["discription"]="DMG:90 Delay:180 Accuracy+34 Evasion+27 Katana skill +228 Parrying skill +228 Magic Accuracy skill +215 \"Double Attack\"+4% \"Store TP\"+5 \"Subtle Blow\"+8", 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["Katana skill"]=228, 
        ["Store TP"]=5, 
        ["en"]="Achiuchikapu", 
        ["delay"]=180, 
        ["Parrying skill"]=228, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Evasion"]=27, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=34, 
        ["item_level"]=119, 
        ["id"]=20986, 
        ["damage"]=90
    }, 
    [452]={
        ["discription"]="DMG:154 Delay:222 HP+150 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Magic Damage+217 Katana skill +269 Parrying skill +269 Magic Accuracy skill +255 Attack+15 for each Utsusemi shadow image", 
        ["id"]=21917, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Ranged Accuracy"]=50, 
        ["item_level"]=119, 
        ["Katana skill"]=269, 
        ["en"]="Fudo Masamune", 
        ["delay"]=222, 
        ["HP"]=150, 
        ["augments"]={
            [1]="Path: C"
        }, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Magic Accuracy"]=50, 
        ["damage"]=154, 
        ["Accuracy"]=50, 
        ["Parrying skill"]=269, 
        ["Attack"]=15
    }, 
    [453]={
        ["discription"]="DMG:154 Delay:222 HP+150 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Magic Damage+217 Katana skill +269 Parrying skill +269 Magic Accuracy skill +255 Attack+15 for each Utsusemi shadow image", 
        ["id"]=21917, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Ranged Accuracy"]=50, 
        ["item_level"]=119, 
        ["Katana skill"]=269, 
        ["en"]="Fudo Masamune", 
        ["delay"]=222, 
        ["HP"]=150, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Magic Accuracy"]=50, 
        ["damage"]=154, 
        ["Accuracy"]=50, 
        ["Parrying skill"]=269, 
        ["Attack"]=15
    }, 
    [454]={
        ["Evasion"]=85, 
        ["discription"]="DEF:125 HP+45 MP+29 STR+28 VIT+17 AGI+42 INT+26 MND+19 CHR+12 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+85 Magic Evasion+150 \"Magic Def. Bonus\"+7 Haste+9% \"Store TP\"+10 Physical damage limit +5% Damage taken -7%", 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=125, 
        ["MND"]=19, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=10, 
        ["AGI"]=42, 
        ["HP"]=45, 
        ["id"]=23735, 
        ["en"]="Malignance Tights", 
        ["STR"]=28, 
        ["Haste"]=9, 
        ["MP"]=29, 
        ["Accuracy"]=50, 
        ["INT"]=26, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["DT"]=-7, 
        ["VIT"]=17, 
        ["Magic Accuracy"]=50
    }, 
    [455]={
        ["Evasion"]=42, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=44, 
        ["Haste"]=5, 
        ["MND"]=38, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enh. \"Ninja Tool Expertise\" effect", 
            [4]="none"
        }, 
        ["discription"]="DEF:109 HP+45 STR+30 DEX+44 VIT+37 AGI+16 INT+20 MND+38 CHR+26 Accuracy+38 Attack+79 Magic Accuracy+38 Evasion+42 Magic Evasion+46 \"Magic Def. Bonus\"+3 Haste+5% \"Subtle Blow\"+9 \"Ninja tool expertise\"+38", 
        ["item_level"]=119, 
        ["AGI"]=16, 
        ["HP"]=45, 
        ["id"]=23544, 
        ["en"]="Mochizuki Tekko +3", 
        ["INT"]=20, 
        ["STR"]=30, 
        ["DEF"]=109, 
        ["Accuracy"]=38, 
        ["CHR"]=26, 
        ["VIT"]=37, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=38, 
        ["Attack"]=79
    }, 
    [456]={
        ["MDT"]=-4, 
        ["DEF"]=89, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR"
        }, 
        ["DEX"]=35, 
        ["Evasion"]=24, 
        ["MND"]=30, 
        ["Dual Wield"]=5, 
        ["Ranged Accuracy"]=36, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["AGI"]=12, 
        ["HP"]=25, 
        ["augments"]={
            [1]="Rng.Acc.+15", 
            [2]="Accuracy+15", 
            [3]="\"Triple Atk.\"+3", 
            [4]="Magic dmg. taken -4%", 
            [5]="none"
        }, 
        ["en"]="Floral Gauntlets", 
        ["STR"]=16, 
        ["Haste"]=5, 
        ["discription"]="DEF:89 HP+25 STR+16 DEX+35 VIT+29 AGI+12 INT+12 MND+30 CHR+17 +25 Accuracy+21 Ranged Accuracy+21 Evasion+24 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+5% \"Dual Wield\"+5", 
        ["Accuracy"]=36, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["item_level"]=119, 
        ["VIT"]=29, 
        ["id"]=27137
    }, 
    [457]={
        ["Ranged Attack"]=23, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=10, 
        ["DEF"]=127, 
        ["MND"]=17, 
        ["id"]=27300, 
        ["Evasion"]=24, 
        ["Store TP"]=7, 
        ["item_level"]=119, 
        ["HP"]=50, 
        ["augments"]={
            [1]="STR+10", 
            [2]="DEX+10", 
            [3]="Accuracy+15"
        }, 
        ["en"]="Ryuo Hakama", 
        ["INT"]=30, 
        ["STR"]=39, 
        ["Haste"]=5, 
        ["Accuracy"]=15, 
        ["CHR"]=11, 
        ["VIT"]=15, 
        ["category"]="Armor", 
        ["AGI"]=21, 
        ["discription"]="DEF:127 HP+50 STR+29 VIT+15 AGI+21 INT+30 MND+17 CHR+11 Attack+23 Ranged Attack+23 Evasion+24 Magic Evasion+80 \"Magic Def. Bonus\"+3 Haste+5% \"Double Attack\"+3% \"Store TP\"+7 \"Skillchain Bonus\"+10", 
        ["Attack"]=23
    }, 
    [458]={
        ["discription"]="DMG:101 Delay:192 HP+25 Attack+13 Throwing skill +242 \"Store TP\"+2", 
        ["skill"]="Throwing", 
        ["Throwing skill"]=242, 
        ["category"]="Weapon", 
        ["Store TP"]=2, 
        ["item_level"]=119, 
        ["HP"]=25, 
        ["delay"]=192, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["damage"]=101, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=21391, 
        ["en"]="Seki Shuriken", 
        ["Attack"]=13
    }, 
    [459]={
        ["Ranged Attack"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["augments"]={
            [1]="\"Mag.Atk.Bns.\"+24", 
            [2]="Magic burst dmg.+8%", 
            [3]="Mag. Acc.+15", 
            [4]="none", 
            [5]="none"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=114, 
        ["id"]=25842, 
        ["MND"]=15, 
        ["AGI"]=32, 
        ["discription"]="DEF:114 HP+38 STR+33 VIT+16 AGI+32 INT+29 MND+15 CHR+10 Attack+15 Ranged Attack+15 Evasion+62 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% Enmity-4 \"Store TP\"+4 Physical damage taken -2%", 
        ["Store TP"]=4, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["Evasion"]=62, 
        ["PDT"]=-2, 
        ["INT"]=29, 
        ["STR"]=33, 
        ["Haste"]=6, 
        ["en"]="Herculean Trousers", 
        ["CHR"]=10, 
        ["Magic Atk. Bonus"]=24, 
        ["category"]="Armor", 
        ["Attack"]=15, 
        ["VIT"]=16, 
        ["Magic Accuracy"]=15
    }, 
    [460]={
        ["discription"]="DMG:148 Delay:210 AGI+50 Magic Damage+186 Katana skill +269 Parrying skill +269 Magic Accuracy skill +242 \"Blade: Hi\" Aftermath: Occasionally attacks for triple damage Afterglow", 
        ["skill"]="Katana", 
        ["Parrying skill"]=269, 
        ["Katana skill"]=269, 
        ["en"]="Kannagi", 
        ["AGI"]=50, 
        ["delay"]=210, 
        ["id"]=21908, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["item_level"]=119, 
        ["damage"]=148
    }, 
    [461]={
        ["discription"]="STR+2～5 DEX+2～5 \"Store TP\"+5 \"Subtle Blow\"+5", 
        ["en"]="Rajas Ring", 
        ["Store TP"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["DEX"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15543, 
        ["STR"]=2
    }, 
    [462]={
        ["discription"]="DEF:28 Fellow: HP+10 MP+10 INT+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["INT"]=2, 
        ["category"]="Armor", 
        ["en"]="Hydra Cap", 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15263, 
        ["DEF"]=28, 
        ["MP"]=10, 
        ["HP"]=10
    }, 
    [463]={
        ["discription"]="INT+1 MND+1 CHR+1 Converts 25 HP to MP", 
        ["MND"]=1, 
        ["category"]="Armor", 
        ["en"]="Vilma's Ring", 
        ["INT"]=1, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15547, 
        ["CHR"]=1
    }, 
    [464]={
        ["discription"]="DEF:35 Fellow: HP+10 MP+10 STR+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hydra Hose", 
        ["HP"]=10, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15598, 
        ["DEF"]=35, 
        ["MP"]=10, 
        ["STR"]=2
    }, 
    [465]={
        ["discription"]="DEF:20 Fellow: HP+10 MP+10 DEX+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hydra Bracers", 
        ["HP"]=10, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=14927, 
        ["DEF"]=20, 
        ["MP"]=10, 
        ["DEX"]=2
    }, 
    [466]={
        ["discription"]="Reives: Damage taken -8% Auto-Reraise", 
        ["en"]="Adoulin's Refuge +1", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=28367, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["DT"]=-8
    }, 
    [467]={
        ["discription"]="Accuracy+4 Attack+4 Assault: STR+4 DEX+4 Adds \"Regen\" effect", 
        ["category"]="Armor", 
        ["en"]="Ulthalam's Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["DEX"]=4, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15808, 
        ["STR"]=4, 
        ["Accuracy"]=4, 
        ["Attack"]=4
    }, 
    [468]={
        ["discription"]="DEF:2 HP+50 MP-10", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Bloodbead Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=13302, 
        ["DEF"]=2, 
        ["MP"]=-10, 
        ["HP"]=50
    }, 
    [469]={
        ["discription"]="DEF:42 Fellow: HP+20 MP+20 VIT+2 ", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hydra Jupon", 
        ["HP"]=20, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=14518, 
        ["DEF"]=42, 
        ["MP"]=20, 
        ["VIT"]=2
    }, 
    [470]={
        ["discription"]="Experience point bonus: +100% Maximum duration: 720 min. Maximum bonus: 12000", 
        ["en"]="Duodec. Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28562, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [471]={
        ["discription"]="Slightly enhances chocobo digging skill", 
        ["en"]="Chocobo Rope", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=11767, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [472]={
        ["discription"]="DEF:31 INT+2 MND+2 CHR+2", 
        ["CHR"]=2, 
        ["category"]="Armor", 
        ["en"]="Tatsu. Sitagoromo", 
        ["augments"]={
            [1]="Pet: Accuracy+7 Pet: Rng. Acc.+7", 
            [2]="Movement speed +8%+2", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["INT"]=2, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=16371, 
        ["DEF"]=31, 
        ["MND"]=2
    }, 
    [473]={
        ["discription"]="MP+25 Depending on day: Enhances elemental magic", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15858, 
        ["en"]="Zodiac Ring", 
        ["MP"]=25, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [474]={
        ["discription"]="Attack+8 Enhances effect of \"Drain\" and \"Aspir\"", 
        ["en"]="Excelsis Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15857, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["Attack"]=8
    }, 
    [475]={
        ["discription"]="HP+25 Reduces enemy critical hit rate", 
        ["HP"]=25, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15856, 
        ["en"]="Griffon Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [476]={
        ["discription"]="DMG:47 Delay:190", 
        ["category"]="Weapon", 
        ["id"]=19873, 
        ["en"]="Thokcha", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=190, 
        ["DEX"]=11, 
        ["skill"]="Dagger", 
        ["jobs"]={
            [6]="THF", 
            [10]="BRD", 
            [19]="DNC"
        }, 
        ["Accuracy"]=16, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="DEX+11", 
            [4]="Accuracy+16"
        }, 
        ["damage"]=47
    }, 
    [477]={
        ["discription"]="DMG:51 Delay:201 \"Rudra's Storm\"", 
        ["category"]="Weapon", 
        ["en"]="Khandroma", 
        ["id"]=19871, 
        ["delay"]=201, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["skill"]="Dagger", 
        ["jobs"]={
            [6]="THF", 
            [10]="BRD", 
            [19]="DNC"
        }, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="none", 
            [4]="none"
        }, 
        ["damage"]=51
    }, 
    [478]={
        ["discription"]="DMG:140 Delay:492 \"Camlann's Torment\"", 
        ["category"]="Weapon", 
        ["en"]="Daboya", 
        ["id"]=19895, 
        ["delay"]=492, 
        ["slots"]={
            [0]="Main"
        }, 
        ["skill"]="Polearm", 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="none", 
            [4]="none"
        }, 
        ["damage"]=140
    }, 
    [479]={
        ["discription"]="DMG:58 Delay:227 \"Blade: Hi\"", 
        ["category"]="Weapon", 
        ["en"]="Kasasagi", 
        ["id"]=19899, 
        ["delay"]=227, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="none", 
            [4]="none"
        }, 
        ["damage"]=58
    }, 
    [480]={
        ["en"]="Stearc Subligar", 
        ["id"]=16372, 
        ["DEF"]=30, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:30", 
        ["augments"]={
            [1]="\"Refresh\"+1", 
            [2]="MP recovered while healing +1", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [481]={
        ["discription"]="Enchantment: Call chocobo", 
        ["en"]="Chocobo Whistle", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=15533, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [482]={
        ["discription"]="DMG:104 Delay:402 \"Myrkr\"", 
        ["category"]="Weapon", 
        ["en"]="Paikea", 
        ["id"]=19911, 
        ["delay"]=402, 
        ["slots"]={
            [0]="Main"
        }, 
        ["skill"]="Staff", 
        ["jobs"]={
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH"
        }, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="none", 
            [4]="none"
        }, 
        ["damage"]=104
    }, 
    [483]={
        ["discription"]="A magical pearl that allows you to send a signal to your adventuring fellow. Unlike a linkpearl, it is worn on the ear.", 
        ["en"]="Signal Pearl", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=14810, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [484]={
        ["discription"]="Experience point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["en"]="Caliber Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26164, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [485]={
        ["discription"]="A magical pearl that allows you to send a code to your adventuring fellow. Unlike a linkpearl, it is worn on the ear.", 
        ["en"]="Tactics Pearl", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=14811, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [486]={
        ["discription"]="DMG:42 Delay:186", 
        ["category"]="Weapon", 
        ["en"]="Centovente", 
        ["id"]=19874, 
        ["delay"]=186, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["skill"]="Dagger", 
        ["jobs"]={
            [6]="THF", 
            [10]="BRD", 
            [19]="DNC"
        }, 
        ["augments"]={
            [1]="DMG:+2", 
            [2]="none", 
            [3]="Weapon Skill:DMG:+10%", 
            [4]="none"
        }, 
        ["damage"]=54
    }, 
    [487]={
        ["discription"]="DEF:18 Fellow: HP+10 MP+10 AGI+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hydra Boots", 
        ["HP"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15683, 
        ["DEF"]=18, 
        ["MP"]=10, 
        ["AGI"]=2
    }, 
    [488]={
        ["discription"]="Experience point bonus: +50% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["en"]="Emperor Band", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15763, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [489]={
        ["discription"]="DMG:50 Delay:201", 
        ["category"]="Weapon", 
        ["id"]=19901, 
        ["en"]="Arisui", 
        ["Evasion"]=22, 
        ["delay"]=201, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["AGI"]=11, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="AGI+11", 
            [4]="Evasion+22"
        }, 
        ["skill"]="Katana", 
        ["damage"]=50
    }, 
    [490]={
        ["discription"]="DMG:50 Delay:201", 
        ["category"]="Weapon", 
        ["id"]=19901, 
        ["en"]="Arisui", 
        ["Evasion"]=22, 
        ["delay"]=201, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["AGI"]=11, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="AGI+11", 
            [4]="Evasion+22"
        }, 
        ["skill"]="Katana", 
        ["damage"]=50
    }, 
    [491]={
        ["discription"]="DMG:27 Delay:232", 
        ["category"]="Weapon", 
        ["en"]="Majimun", 
        ["id"]=19900, 
        ["delay"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="none", 
            [2]="Delay:+10", 
            [3]="Occ. atk. 2-4 times+12", 
            [4]="none"
        }, 
        ["damage"]=27
    }, 
    [492]={
        ["discription"]="Magic Atk. Bonus+5", 
        ["Magic Atk. Bonus"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Moldavite Earring", 
        ["id"]=14724, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [493]={
        ["discription"]="DMG:49 Delay:216", 
        ["category"]="Weapon", 
        ["en"]="Hitaki", 
        ["Store TP"]=15, 
        ["delay"]=216, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=19902, 
        ["augments"]={
            [1]="DMG:+2", 
            [2]="none", 
            [3]="\"Store TP\"+15", 
            [4]="none"
        }, 
        ["skill"]="Katana", 
        ["damage"]=51
    }, 
    [494]={
        ["discription"]="DMG:47 Delay:190", 
        ["category"]="Weapon", 
        ["id"]=19873, 
        ["en"]="Thokcha", 
        ["Evasion"]=22, 
        ["delay"]=190, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF", 
            [10]="BRD", 
            [19]="DNC"
        }, 
        ["AGI"]=11, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="AGI+11", 
            [4]="Evasion+22"
        }, 
        ["skill"]="Dagger", 
        ["damage"]=47
    }, 
    [495]={
        ["discription"]="DEX+3", 
        ["DEX"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=13415, 
        ["en"]="Pixie Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [496]={
        ["discription"]="DEF:21 HP+10 MP+10 \"Subtle Blow\"+3 ", 
        ["MP"]=10, 
        ["id"]=11488, 
        ["category"]="Armor", 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Anwig Salade", 
        ["HP"]=10, 
        ["STR"]=4, 
        ["DEX"]=4, 
        ["Accuracy"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["augments"]={
            [1]="STR+4", 
            [2]="Weapon Skill Acc.+15", 
            [3]="DEX+4", 
            [4]="Crit. hit damage +2%", 
            [5]="none"
        }, 
        ["DEF"]=21, 
        ["Critical hit damage"]=2
    }, 
    [497]={
        ["discription"]="DEF:42 HP+10 MP+10 STR+5 DEX+5 AGI+5", 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Mirke Wardecors", 
        ["category"]="Armor", 
        ["Store TP"]=4, 
        ["AGI"]=5, 
        ["HP"]=10, 
        ["augments"]={
            [1]="\"Dual Wield\"+3", 
            [2]="\"Store TP\"+4 \"Subtle Blow\"+4", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["DEX"]=5, 
        ["STR"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["MP"]=10, 
        ["DEF"]=42, 
        ["id"]=11314, 
        ["Dual Wield"]=3
    }, 
    [498]={
        ["discription"]="DMG:49 Delay:189 DEX+15 Critical hit rate +5% Occasionally ignores physical defense", 
        ["category"]="Weapon", 
        ["en"]="Coruscanti", 
        ["id"]=19144, 
        ["delay"]=189, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF", 
            [10]="BRD", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["skill"]="Dagger", 
        ["Critical hit rate"]=5, 
        ["DEX"]=15, 
        ["damage"]=49
    }, 
    [499]={
        ["discription"]="DEF:1 Dispense: Watermelon Snow Cone", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Citrullus Shirt", 
        ["id"]=26516, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [500]={
        ["discription"]="DMG:3 Delay:216  Extends chocobo riding time", 
        ["en"]="Chocobo Wand", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=216, 
        ["category"]="Weapon", 
        ["skill"]="Club", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=17074, 
        ["damage"]=3
    }, 
    [501]={
        ["Evasion"]=9, 
        ["category"]="Armor", 
        ["en"]="Vengeful Ring", 
        ["HP"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27592, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=20, 
        ["discription"]="HP+20 MP+20 Evasion+9 Magic Evasion+9 Enmity+3"
    }, 
    [502]={
        ["Ranged Attack"]=15, 
        ["Ranged Accuracy"]=15, 
        ["discription"]="DEF:9 HP+20 MP+20 Accuracy+15 Ranged Accuracy+15 Attack+15 Ranged Attack+15 Magic Accuracy+7 \"Magic Atk. Bonus\"+7", 
        ["category"]="Armor", 
        ["Magic Atk. Bonus"]=7, 
        ["en"]="Eschan Stone", 
        ["HP"]=20, 
        ["Accuracy"]=15, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["Magic Accuracy"]=7, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["MP"]=20, 
        ["DEF"]=9, 
        ["id"]=28415, 
        ["Attack"]=15
    }, 
    [503]={
        ["discription"]="Regain+5 Weapon Skill Accuracy+5 Weapon Skill Damage+3%", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=27587, 
        ["en"]="Karieyh Ring", 
        ["Accuracy"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [504]={
        ["discription"]="Double Attack+3% \"Triple Attack\"+3%", 
        ["en"]="Epona's Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=11651, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["Attack"]=3
    }, 
    [505]={
        ["id"]=22252, 
        ["en"]="Sapience Orb", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="Enmity+2 \"Fast Cast\"+2%", 
        ["Fast Cast"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [506]={
        ["Ranged Attack"]=10, 
        ["Ranged Accuracy"]=10, 
        ["discription"]="DEF:14 HP+35 MP+35 Attack+10 Accuracy+10 Ranged Attack+10 Ranged Accuracy+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Regen\"+2", 
        ["category"]="Armor", 
        ["Magic Atk. Bonus"]=10, 
        ["en"]="Sanctity Necklace", 
        ["HP"]=35, 
        ["Accuracy"]=10, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Magic Accuracy"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["MP"]=35, 
        ["DEF"]=14, 
        ["id"]=26023, 
        ["Attack"]=10
    }, 
    [507]={
        ["en"]="Inq. Bead Necklace", 
        ["id"]=28403, 
        ["DEF"]=13, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:13 HP+55 \"Magic Def. Bonus\"+8", 
        ["HP"]=55, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [508]={
        ["Ranged Attack"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["discription"]="DEF:79 HP+9 STR+16 DEX+24 VIT+10 AGI+43 MND+11 CHR+26 Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+5 Evasion+80 Magic Evasion+75 Haste+4% \"Triple Attack\"+2 \"Subtle Blow\"+6 Physical damage taken -2%", 
        ["DEX"]=24, 
        ["Haste"]=4, 
        ["augments"]={
            [1]="Weapon skill damage +5%", 
            [2]="AGI+9", 
            [3]="Accuracy+13", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=11, 
        ["en"]="Herculean Boots", 
        ["Ranged Accuracy"]=10, 
        ["item_level"]=119, 
        ["AGI"]=52, 
        ["HP"]=9, 
        ["Accuracy"]=23, 
        ["id"]=27496, 
        ["CHR"]=26, 
        ["category"]="Armor", 
        ["STR"]=16, 
        ["DEF"]=79, 
        ["Evasion"]=80, 
        ["Magic Accuracy"]=10, 
        ["VIT"]=10, 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["PDT"]=-2, 
        ["Attack"]=10
    }, 
    [509]={
        ["discription"]="TP not depleted when weapon skill used +1% Latent effect: Weapon Skill Accuracy+10 Weapon skill damage +10%", 
        ["en"]="Fotia Gorget", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=27510, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [510]={
        ["MDT"]=-4, 
        ["en"]="Purity Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=27554, 
        ["discription"]="Magic Evasion+10 Potency of \"Cursna\" effects received +7 Magic damage taken -4% \"Holy Water\"+7%", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [511]={
        ["discription"]="Magic Atk. Bonus+7", 
        ["Magic Atk. Bonus"]=7, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Novio Earring", 
        ["id"]=14808, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [512]={
        ["discription"]="DEF:7 \"Conserve TP\"+7 TP not depleted when weapon skill used +1% Latent effect: Weapon Skill Accuracy+10 Weapon skill damage +10%", 
        ["DEF"]=7, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Fotia Belt", 
        ["id"]=28420, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [513]={
        ["discription"]="MP+35 Magic Damage+11 Unity Ranking: INT+2～6", 
        ["INT"]=6, 
        ["category"]="Weapon", 
        ["en"]="Ghastly Tathlum +1", 
        ["Unity Ranking Bonus Applied"]="INT + 6", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21344, 
        ["skill"]="(N/A)", 
        ["MP"]=35, 
        ["slots"]={
            [3]="Ammo"
        }
    }, 
    [514]={
        ["discription"]="HP+90 -20", 
        ["HP"]=90, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=11637, 
        ["en"]="Meridian Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [515]={
        ["Ranged Attack"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["en"]="Herculean Trousers", 
        ["id"]=25842, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["augments"]={
            [1]="Mag. Acc.+14 \"Mag.Atk.Bns.\"+14", 
            [2]="\"Fast Cast\"+6", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=15, 
        ["Fast Cast"]=6, 
        ["AGI"]=32, 
        ["Store TP"]=4, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["DEF"]=114, 
        ["discription"]="DEF:114 HP+38 STR+33 VIT+16 AGI+32 INT+29 MND+15 CHR+10 Attack+15 Ranged Attack+15 Evasion+62 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% Enmity-4 \"Store TP\"+4 Physical damage taken -2%", 
        ["INT"]=29, 
        ["CHR"]=10, 
        ["STR"]=33, 
        ["Haste"]=6, 
        ["Evasion"]=62, 
        ["category"]="Armor", 
        ["Attack"]=15, 
        ["Magic Atk. Bonus"]=14, 
        ["PDT"]=-2, 
        ["VIT"]=16, 
        ["Magic Accuracy"]=14
    }, 
    [516]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Staunch Tathlum +1", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="Resistance to all status ailments +11 Spellcasting interruption rate -11% Damage taken -3%", 
        ["id"]=22279, 
        ["DT"]=-3
    }, 
    [517]={
        ["discription"]="Damage taken -10%", 
        ["en"]="Defending Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=13566, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["DT"]=-10
    }, 
    [518]={
        ["discription"]="Critical hit rate +2% Critical hit damage +6%", 
        ["en"]="Yetshila +1", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["Critical hit rate"]=2, 
        ["category"]="Weapon", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [13]="NIN", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["id"]=21379, 
        ["Critical hit damage"]=6
    }, 
    [519]={
        ["MDT"]=-2, 
        ["STR"]=19, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=12, 
        ["Fast Cast"]=4, 
        ["MND"]=25, 
        ["DEF"]=109, 
        ["Evasion"]=27, 
        ["item_level"]=119, 
        ["AGI"]=5, 
        ["HP"]=22, 
        ["id"]=27324, 
        ["Magic Atk. Bonus"]=40, 
        ["Haste"]=5, 
        ["MP"]=32, 
        ["discription"]="DEF:109 HP+22 MP+32 STR+19 DEX+12 VIT+19 AGI+5 INT+35 MND+25 CHR+23 \"Magic Atk. Bonus\"+40 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% \"Fast Cast\"+4% \"Cure\" potency +10% Magic damage taken -2%", 
        ["VIT"]=19, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["CHR"]=23, 
        ["INT"]=35, 
        ["category"]="Armor", 
        ["en"]="Gyve Trousers"
    }, 
    [520]={
        ["Evasion"]=41, 
        ["DEF"]=97, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=39, 
        ["VIT"]=30, 
        ["MND"]=26, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Ranged Accuracy"]=12, 
        ["AGI"]=8, 
        ["item_level"]=119, 
        ["HP"]=20, 
        ["augments"]={
            [1]="Accuracy+10", 
            [2]="Weapon skill damage +5%", 
            [3]="Attack+10", 
            [4]="none", 
            [5]="none"
        }, 
        ["id"]=27140, 
        ["INT"]=14, 
        ["STR"]=16, 
        ["Haste"]=5, 
        ["Accuracy"]=22, 
        ["CHR"]=19, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["en"]="Herculean Gloves", 
        ["discription"]="DEF:97 HP+20 STR+16 DEX+39 VIT+30 AGI+8 INT+14 MND+26 CHR+19 Accuracy+12 Ranged Accuracy+12 Evasion+41 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+2% \"Subtle Blow\"+5 Physical damage taken -2%", 
        ["Attack"]=10
    }, 
    [521]={
        ["en"]="Windbuffet Belt +1", 
        ["id"]=28440, 
        ["DEF"]=9, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:9 Accuracy+2 \"Triple Attack\"+2% \"Quadruple Attack\"+2%", 
        ["Accuracy"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [522]={
        ["discription"]="Increases all elemental attacks by 1-15 based on distance to target", 
        ["en"]="Orpheus's Sash", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=26359, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [523]={
        ["en"]="Combatant's Torque", 
        ["id"]=26015, 
        ["Store TP"]=4, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="Combat skills +15 \"Store TP\"+4", 
        ["Combat skills"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [524]={
        ["discription"]="Store TP-10 Weapon skill damage +5%", 
        ["en"]="Epaminondas's Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26214, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [525]={
        ["Parrying skill"]=5, 
        ["category"]="Armor", 
        ["en"]="Portus Annulet", 
        ["discription"]="Accuracy+7 Guarding skill +5 Evasion skill +5 Shield skill +5 Parrying skill +5", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Shield skill"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Guarding skill"]=5, 
        ["Accuracy"]=7, 
        ["id"]=10761, 
        ["Evasion skill"]=5
    }, 
    [526]={
        ["discription"]="DEF:13 Accuracy+20 Attack-5 \"Store TP\"+3", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Olseni Belt", 
        ["Store TP"]=3, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28442, 
        ["DEF"]=13, 
        ["Accuracy"]=20, 
        ["Attack"]=-5
    }, 
    [527]={
        ["Evasion"]=41, 
        ["MND"]=19, 
        ["DEF"]=142, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=19, 
        ["STR"]=29, 
        ["item_level"]=119, 
        ["AGI"]=19, 
        ["en"]="Uac Jerkin", 
        ["HP"]=63, 
        ["Critical hit rate"]=3, 
        ["discription"]="DEF:142 HP+63 MP+35 STR+29 DEX+19 VIT+29 AGI+19 INT+19 MND+19 CHR+19 Attack+20 Evasion+41 Magic Evasion+48 \"Magic Def. Bonus\"+4 Haste+3% \"Double Attack\"+3% Critical hit rate +3% \"Skillchain Bonus\"+5", 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=3, 
        ["MP"]=35, 
        ["id"]=25703, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["VIT"]=29, 
        ["Attack"]=20
    }, 
    [528]={
        ["Evasion"]=41, 
        ["DEF"]=97, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=39, 
        ["VIT"]=30, 
        ["MND"]=32, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Ranged Accuracy"]=12, 
        ["AGI"]=8, 
        ["item_level"]=119, 
        ["HP"]=20, 
        ["augments"]={
            [1]="Accuracy+16 Attack+16", 
            [2]="\"Waltz\" potency +11%", 
            [3]="MND+6", 
            [4]="none", 
            [5]="none"
        }, 
        ["id"]=27140, 
        ["INT"]=14, 
        ["STR"]=16, 
        ["Haste"]=5, 
        ["Accuracy"]=28, 
        ["CHR"]=19, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["en"]="Herculean Gloves", 
        ["discription"]="DEF:97 HP+20 STR+16 DEX+39 VIT+30 AGI+8 INT+14 MND+26 CHR+19 Accuracy+12 Ranged Accuracy+12 Evasion+41 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+2% \"Subtle Blow\"+5 Physical damage taken -2%", 
        ["Attack"]=16
    }, 
    [529]={
        ["discription"]="DEF:7 Hand-to-Hand skill +5 Evasion skill +5", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Nesanica Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28454, 
        ["DEF"]=7, 
        ["Hand-to-Hand skill"]=5, 
        ["Evasion skill"]=5
    }, 
    [530]={
        ["Evasion"]=38, 
        ["MND"]=17, 
        ["DEF"]=111, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["item_level"]=119, 
        ["en"]="Zoar Subligar +1", 
        ["Store TP"]=-5, 
        ["HP"]=47, 
        ["discription"]="DEF:111 HP+47 STR+29 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Evasion+38 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% Enmity+6 \"Triple Attack\"+3% \"Store TP\"-5 Unity Ranking: \"Double Attack\"+1～5%", 
        ["VIT"]=16, 
        ["STR"]=29, 
        ["Haste"]=6, 
        ["id"]=27231, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["AGI"]=20
    }, 
    [531]={
        ["Evasion"]=49, 
        ["MND"]=26, 
        ["DEF"]=131, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=37, 
        ["STR"]=27, 
        ["AGI"]=36, 
        ["Fast Cast"]=7, 
        ["item_level"]=119, 
        ["HP"]=59, 
        ["discription"]="DEF:131 HP+59 MP+44 STR+27 DEX+37 VIT+27 AGI+36 INT+26 MND+26 CHR+26 Accuracy+10 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+4% \"Double Attack\"+2% \"Fast Cast\"+7%", 
        ["Accuracy"]=10, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=4, 
        ["MP"]=44, 
        ["id"]=27858, 
        ["INT"]=26, 
        ["category"]="Armor", 
        ["CHR"]=26, 
        ["VIT"]=27, 
        ["en"]="Dread Jupon"
    }, 
    [532]={
        ["discription"]="AGI+2 \"Utsusemi\" spellcasting time -10%", 
        ["en"]="Magoraga Beads", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["AGI"]=2, 
        ["id"]=11627, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [533]={
        ["Ranged Attack"]=15, 
        ["item_level"]=119, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=114, 
        ["MND"]=15, 
        ["AGI"]=32, 
        ["id"]=25842, 
        ["Store TP"]=4, 
        ["en"]="Herculean Trousers", 
        ["HP"]=38, 
        ["augments"]={
            [1]="\"Waltz\" potency +11%", 
            [2]="INT+4", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["Evasion"]=62, 
        ["INT"]=33, 
        ["STR"]=33, 
        ["Haste"]=6, 
        ["VIT"]=16, 
        ["CHR"]=10, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["discription"]="DEF:114 HP+38 STR+33 VIT+16 AGI+32 INT+29 MND+15 CHR+10 Attack+15 Ranged Attack+15 Evasion+62 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% Enmity-4 \"Store TP\"+4 Physical damage taken -2%", 
        ["Attack"]=15
    }, 
    [534]={
        ["Evasion"]=60, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEX"]=34, 
        ["DEF"]=133, 
        ["augments"]={
            [1]="Weapon skill damage +5%", 
            [2]="STR+9", 
            [3]="Attack+13", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=20, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=15, 
        ["Store TP"]=3, 
        ["en"]="Herculean Vest", 
        ["HP"]=61, 
        ["Accuracy"]=15, 
        ["discription"]="DEF:133 HP+61 STR+28 DEX+34 VIT+24 AGI+30 INT+21 MND+20 CHR+21 Accuracy+15 Ranged Accuracy+15 Evasion+60 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% Enmity-4 \"Store TP\"+3 Critical hit rate +3%", 
        ["INT"]=21, 
        ["STR"]=37, 
        ["Haste"]=4, 
        ["AGI"]=30, 
        ["CHR"]=21, 
        ["id"]=25718, 
        ["category"]="Armor", 
        ["Critical hit rate"]=3, 
        ["VIT"]=24, 
        ["Attack"]=13
    }, 
    [535]={
        ["discription"]="DEF:35 HP+275 Damage taken -6%", 
        ["category"]="Armor", 
        ["en"]="Moonlight Cape", 
        ["HP"]=275, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=35, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=26269, 
        ["DT"]=-6
    }, 
    [536]={
        ["Evasion"]=15, 
        ["category"]="Weapon", 
        ["en"]="Yamarang", 
        ["Store TP"]=3, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["discription"]="Accuracy+15 Magic Accuracy+15 Evasion+15 Magic Evasion+15 \"Store TP\"+3 \"Waltz\" potency +5%", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Accuracy"]=15, 
        ["id"]=22280, 
        ["Magic Accuracy"]=15
    }, 
    [537]={
        ["discription"]="+20 +20 +20 +20 +20 +20 Occasionally absorbs magic damage taken Unity Ranking: Enmity+1～8", 
        ["en"]="Warder's Charm +1", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=27505, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [538]={
        ["discription"]="Skillchain Bonus+5 Magic burst damage II +5", 
        ["en"]="Mujin Band", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=11672, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [539]={
        ["discription"]="MND+2 \"Magic Def. Bonus\"+2  Bonus damage added to magic burst", 
        ["MND"]=2, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=15962, 
        ["en"]="Static Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [540]={
        ["discription"]="MP+30 Enhances \"Fast Cast\" effect", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=14812, 
        ["en"]="Loquac. Earring", 
        ["MP"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [541]={
        ["discription"]="Dusk to dawn: STR+7 DEX+7 VIT+7 INT+7 Unity Ranking: \"Double Attack\"+1～3%", 
        ["category"]="Armor", 
        ["en"]="Lugra Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["STR"]=7, 
        ["INT"]=7, 
        ["DEX"]=7, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["id"]=28481, 
        ["VIT"]=7
    }, 
    [542]={
        ["discription"]="Weapon skill damage +2%", 
        ["en"]="Ishvara Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=27537, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [543]={
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [13]="NIN", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Kishar Ring", 
        ["id"]=26188, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Magic Accuracy+5 \"Fast Cast\"+4% Enfeebling magic effect duration +10% \"Absorb\" effect duration +10%", 
        ["Fast Cast"]=4, 
        ["Magic Accuracy"]=5
    }, 
    [544]={
        ["discription"]="Dusk to dawn: STR+8 DEX+8 VIT+8 INT+8 Unity Ranking: \"Double Attack\"+1～3%", 
        ["category"]="Armor", 
        ["en"]="Lugra Earring +1", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["STR"]=8, 
        ["INT"]=8, 
        ["DEX"]=8, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["id"]=28482, 
        ["VIT"]=8
    }, 
    [545]={
        ["discription"]="AGI+5 CHR+5 \"Dual Wield\"+6 Latent effect: Attack+10 Evasion+10", 
        ["category"]="Armor", 
        ["en"]="Shetal Stone", 
        ["AGI"]=5, 
        ["CHR"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=28445, 
        ["Dual Wield"]=6
    }, 
    [546]={
        ["discription"]="DEF:12 STR+7 INT+7 MND+7 +20 +20 +20 +20 +20 +20 +30 +30 Accuracy+10 Attack+10", 
        ["MND"]=7, 
        ["INT"]=7, 
        ["category"]="Armor", 
        ["en"]="Engraved Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [13]="NIN", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=12, 
        ["STR"]=7, 
        ["Accuracy"]=10, 
        ["id"]=28414, 
        ["Attack"]=10
    }, 
    [547]={
        ["discription"]="AGI+2 Enhances \"Dual Wield\" effect Sword skill +5", 
        ["en"]="Suppanomimi", 
        ["Sword skill"]=5, 
        ["AGI"]=2, 
        ["Dual Wield"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=14739, 
        ["category"]="Armor"
    }, 
    [548]={
        ["Evasion"]=70, 
        ["MND"]=23, 
        ["PDT"]=-6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=24, 
        ["DEF"]=131, 
        ["AGI"]=23, 
        ["STR"]=25, 
        ["item_level"]=119, 
        ["HP"]=61, 
        ["en"]="Emet Harness +1", 
        ["Accuracy"]=20, 
        ["Unity Ranking Bonus Applied"]="Accuracy + 20", 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=4, 
        ["id"]=26871, 
        ["INT"]=23, 
        ["category"]="Armor", 
        ["CHR"]=23, 
        ["VIT"]=25, 
        ["discription"]="DEF:131 HP+61 STR+25 DEX+24 VIT+25 AGI+23 INT+23 MND+23 CHR+23 Evasion+70 Magic Evasion+64 \"Magic Def. Bonus\"+5 Haste+4% Enmity+10 Physical damage taken -6% Unity Ranking: Accuracy+10～20"
    }, 
    [549]={
        ["Evasion"]=44, 
        ["MND"]=30, 
        ["DEF"]=92, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=35, 
        ["STR"]=11, 
        ["AGI"]=5, 
        ["item_level"]=119, 
        ["en"]="Kurys Gloves", 
        ["HP"]=25, 
        ["discription"]="DEF:92 HP+25 STR+11 DEX+35 VIT+32 AGI+5 INT+12 MND+30 CHR+17 Accuracy+20 Evasion+44 Magic Evasion+57 \"Magic Def. Bonus\"+2 Haste+5% Enmity+9 Damage taken -2%", 
        ["Accuracy"]=20, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=5, 
        ["id"]=27134, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["VIT"]=32, 
        ["DT"]=-2
    }, 
    [550]={
        ["discription"]="DEF:8 HP+55 STR+3", 
        ["category"]="Armor", 
        ["en"]="Oneiros Belt", 
        ["HP"]=55, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=11773, 
        ["STR"]=3
    }, 
    [551]={
        ["discription"]="Accuracy+3 \"Waltz\" potency +3%", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=10751, 
        ["en"]="Valseur's Ring", 
        ["Accuracy"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [552]={
        ["discription"]="DEF:7 Accuracy+6 Ranged Accuracy+6 Magic Accuracy+6 Critical hit rate +3% Set: Increases Dexterity, Agility, and Charisma", 
        ["Ranged Accuracy"]=6, 
        ["Set Bonus"]={
            ["set id"]=477, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Mummu Ring", 
        ["id"]=26212, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEF"]=7, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=6, 
        ["Critical hit rate"]=3, 
        ["Magic Accuracy"]=6
    }, 
    [553]={
        ["discription"]="DEF:11 VIT+9 CHR+9 \"Resist Charm\"+9 Enmity+10 Unity Ranking: Accuracy+1～5", 
        ["CHR"]=9, 
        ["category"]="Armor", 
        ["en"]="Unmoving Collar +1", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Unity Ranking Bonus Applied"]="Accuracy + 5", 
        ["DEF"]=11, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=5, 
        ["id"]=27509, 
        ["VIT"]=9
    }, 
    [554]={
        ["discription"]="DEX+10 Accuracy+10 Critical hit rate +5%", 
        ["category"]="Armor", 
        ["en"]="Odr Earring", 
        ["Critical hit rate"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26108, 
        ["DEX"]=10, 
        ["Accuracy"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }
    }, 
    [555]={
        ["discription"]="Accuracy+10 Magic Accuracy+10 \"Subtle Blow\"+5 \"Store TP\"+3", 
        ["category"]="Armor", 
        ["en"]="Digni. Earring", 
        ["Store TP"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27547, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Accuracy"]=10, 
        ["Magic Accuracy"]=10
    }, 
    [556]={
        ["discription"]="Accuracy+13 Attack+13 \"Magic Atk. Bonus\"+7 Unity ranking: STR+1～5", 
        ["category"]="Weapon", 
        ["en"]="Seeth. Bomblet +1", 
        ["Magic Atk. Bonus"]=7, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["STR"]=1, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [13]="NIN", 
            [22]="RUN"
        }, 
        ["Accuracy"]=13, 
        ["id"]=22255, 
        ["Attack"]=13
    }, 
    [557]={
        ["id"]=11697, 
        ["en"]="Moonshade Earring", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Accuracy"]=4, 
        ["discription"]="none", 
        ["augments"]={
            [1]="Accuracy+4", 
            [2]="TP Bonus +250", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [558]={
        ["discription"]="Katana skill +5 Enmity+5 \"Double Attack\"+3%", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28515, 
        ["en"]="Trux Earring", 
        ["Katana skill"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [559]={
        ["Ranged Attack"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["discription"]="DEF:79 HP+9 STR+16 DEX+24 VIT+10 AGI+43 MND+11 CHR+26 Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+5 Evasion+80 Magic Evasion+75 Haste+4% \"Triple Attack\"+2 \"Subtle Blow\"+6 Physical damage taken -2%", 
        ["DEX"]=24, 
        ["Haste"]=4, 
        ["augments"]={
            [1]="Attack+7", 
            [2]="\"Waltz\" potency +11%", 
            [3]="AGI+6", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=11, 
        ["en"]="Herculean Boots", 
        ["Ranged Accuracy"]=10, 
        ["item_level"]=119, 
        ["AGI"]=49, 
        ["HP"]=9, 
        ["Accuracy"]=10, 
        ["id"]=27496, 
        ["CHR"]=26, 
        ["category"]="Armor", 
        ["STR"]=16, 
        ["DEF"]=79, 
        ["Evasion"]=80, 
        ["Magic Accuracy"]=10, 
        ["VIT"]=10, 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["PDT"]=-2, 
        ["Attack"]=17
    }, 
    [560]={
        ["discription"]="Magic Evasion+6 \"Magic Def. Bonus\"+4 Club skill +5", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28516, 
        ["en"]="Sanare Earring", 
        ["Club skill"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [561]={
        ["MDT"]=-2, 
        ["category"]="Armor", 
        ["en"]="Odnowa Earring +1", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Unity Ranking Bonus Applied"]="Accuracy + 10", 
        ["id"]=27549, 
        ["STR"]=3, 
        ["discription"]="STR+3 VIT+3 Converts 100 MP to HP Magic damage taken -2% Unity Ranking: Accuracy+5～10", 
        ["Accuracy"]=10, 
        ["VIT"]=3
    }, 
    [562]={
        ["Evasion"]=15, 
        ["en"]="Eabani Earring", 
        ["discription"]="HP+45 Evasion+15 Magic Evasion+8 \"Dual Wield\"+4", 
        ["HP"]=45, 
        ["Dual Wield"]=4, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27540, 
        ["category"]="Armor"
    }, 
    [563]={
        ["en"]="Trance Belt", 
        ["id"]=15895, 
        ["DEF"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:5 HP+14 Enmity+4", 
        ["HP"]=14, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [564]={
        ["discription"]="MND+5 Magic Accuracy+8 All magic skills +5", 
        ["category"]="Armor", 
        ["en"]="Stikini Ring", 
        ["MND"]=5, 
        ["All magic skills"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26183, 
        ["Magic Accuracy"]=8
    }, 
    [565]={
        ["category"]="Armor", 
        ["en"]="Cessance Earring", 
        ["Store TP"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Accuracy"]=6, 
        ["discription"]="Accuracy+6 \"Double Attack\"+3% \"Store TP\"+3", 
        ["id"]=27541, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [566]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26089, 
        ["DEF"]=20, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:20 Evasion skill +10", 
        ["en"]="Ran Earring", 
        ["Evasion skill"]=10
    }, 
    [567]={
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [13]="NIN", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["en"]="Gere Ring", 
        ["id"]=28471, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="STR+10 Attack+16 \"Triple Attack\"+5%", 
        ["STR"]=10, 
        ["Attack"]=16
    }, 
    [568]={
        ["Evasion"]=24, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=35, 
        ["DEF"]=91, 
        ["MND"]=30, 
        ["augments"]={
            [1]="Accuracy+15", 
            [2]="Mag. Acc.+15", 
            [3]="\"Mag.Atk.Bns.\"+15", 
            [4]="\"Fast Cast\"+3", 
            [5]="none"
        }, 
        ["en"]="Leyline Gloves", 
        ["AGI"]=5, 
        ["item_level"]=119, 
        ["HP"]=25, 
        ["id"]=27135, 
        ["discription"]="DEF:91 HP+25 STR+11 DEX+35 VIT+32 AGI+5 INT+12 MND+30 CHR+17 Accuracy+18 Magic Accuracy+18 Evasion+24 Magic Evasion+62 \"Magic Atk. Bonus\"+15 \"Magic Def. Bonus\"+2 Haste+5% \"Fast Cast\"+5%", 
        ["INT"]=12, 
        ["STR"]=11, 
        ["Haste"]=5, 
        ["Accuracy"]=33, 
        ["CHR"]=17, 
        ["Magic Atk. Bonus"]=30, 
        ["category"]="Armor", 
        ["Fast Cast"]=8, 
        ["VIT"]=32, 
        ["Magic Accuracy"]=33
    }, 
    [569]={
        ["discription"]="MND+8 Magic Accuracy+11 All magic skills +8 \"Refresh\"+1", 
        ["category"]="Armor", 
        ["en"]="Stikini Ring +1", 
        ["MND"]=8, 
        ["All magic skills"]=8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26184, 
        ["Magic Accuracy"]=11
    }, 
    [570]={
        ["discription"]="Magic Atk. Bonus+10 Enmity+2", 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Friomisi Earring", 
        ["id"]=28514, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [571]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Begrudging Ring", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=7, 
        ["discription"]="Accuracy+7 Attack+7 Enmity+5 \"Tonberry's Grudge\"", 
        ["id"]=26172, 
        ["Attack"]=7
    }, 
    [572]={
        ["discription"]="Enhances \"Double Attack\" effect \"Store TP\"+1", 
        ["Store TP"]=1, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Brutal Earring", 
        ["id"]=14813, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [573]={
        ["discription"]="AGI+10 Ranged Attack+25 \"Magic Atk. Bonus\"+10 \"Recycle\"+10", 
        ["en"]="Dingir Ring", 
        ["Magic Atk. Bonus"]=10, 
        ["AGI"]=10, 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR"
        }, 
        ["id"]=26187, 
        ["Ranged Attack"]=25
    }, 
    [574]={
        ["discription"]="HP+30 MP+30 VIT+5 Accuracy+7 Enmity+5", 
        ["category"]="Armor", 
        ["en"]="Supershear Ring", 
        ["Accuracy"]=7, 
        ["HP"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=28535, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=30, 
        ["VIT"]=5
    }, 
    [575]={
        ["discription"]="Magic critical hit rate +5% Bonus damage added to magic burst", 
        ["en"]="Locus Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28582, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [576]={
        ["Ranged Attack"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEX"]=28, 
        ["Haste"]=8, 
        ["augments"]={
            [1]="Weapon skill damage +5%", 
            [2]="AGI+4", 
            [3]="Accuracy+4", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=16, 
        ["en"]="Herculean Helm", 
        ["Evasion"]=55, 
        ["Fast Cast"]=7, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["Accuracy"]=4, 
        ["discription"]="DEF:108 HP+38 STR+22 DEX+28 VIT+18 AGI+25 INT+20 MND+16 CHR+17 Attack+15 Ranged Attack+15 \"Magic Atk. Bonus\"+10 Evasion+55 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+8% \"Fast Cast\"+7%", 
        ["INT"]=20, 
        ["STR"]=22, 
        ["DEF"]=108, 
        ["AGI"]=29, 
        ["CHR"]=17, 
        ["Magic Atk. Bonus"]=10, 
        ["category"]="Armor", 
        ["id"]=25642, 
        ["VIT"]=18, 
        ["Attack"]=15
    }, 
    [577]={
        ["en"]="Baetyl Pendant", 
        ["id"]=26003, 
        ["Magic Atk. Bonus"]=13, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="Magic Atk. Bonus+13 \"Fast Cast\"+4%", 
        ["Fast Cast"]=4, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [578]={
        ["discription"]="HP+40 Enmity+4 \"Counter\"+3", 
        ["HP"]=40, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28483, 
        ["en"]="Cryptic Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [579]={
        ["discription"]="Magic Atk. Bonus+6 Magic critical hit rate +3%", 
        ["Magic Atk. Bonus"]=6, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Hecate's Earring", 
        ["id"]=11698, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [580]={
        ["discription"]="DEF:10 HP+60 DEX+10 AGI+10 Attack+25 \"Store TP\"+5 ", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Ilabrat Ring", 
        ["Store TP"]=5, 
        ["HP"]=60, 
        ["AGI"]=10, 
        ["DEX"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26186, 
        ["DEF"]=10, 
        ["Attack"]=25
    }, 
    [581]={
        ["discription"]="Pet: Accuracy+15 Magic Accuracy+15 \"Store TP\"+8 Damage taken -3%", 
        ["en"]="Enmerkar Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=26083, 
        ["category"]="Armor", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }
    }, 
    [582]={
        ["discription"]="DMG:204 Delay:366 MP+88 Staff skill +242 Parrying skill +242 Magic Accuracy skill +188 Avatar perpetuation cost -5 Avatar: Accuracy+25 Haste+3%", 
        ["skill"]="Staff", 
        ["id"]=21174, 
        ["Staff skill"]=242, 
        ["item_level"]=119, 
        ["en"]="Gridarvor", 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["MP"]=88, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["augments"]={
            [1]="Pet: Accuracy+70", 
            [2]="Pet: Attack+70", 
            [3]="Pet: \"Dbl. Atk.\"+15"
        }, 
        ["Parrying skill"]=242, 
        ["damage"]=204
    }, 
    [583]={
        ["discription"]="Summoning magic skill +3", 
        ["en"]="Smn. Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=14777, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [584]={
        ["discription"]="HP+50 Damage taken -5% Avatar: Accuracy+25 Ranged Accuracy+25 Magic Accuracy+25", 
        ["en"]="Smn. Collar +2", 
        ["id"]=25503, 
        ["HP"]=50, 
        ["category"]="Armor", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["DT"]=-5
    }, 
    [585]={
        ["Evasion"]=33, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=15, 
        ["DEF"]=95, 
        ["MND"]=28, 
        ["augments"]={
            [1]="Blood Pact Dmg.+10", 
            [2]="Pet: \"Mag.Atk.Bns.\"+13", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["Fast Cast"]=8, 
        ["item_level"]=119, 
        ["en"]="Merlinic Hood", 
        ["HP"]=22, 
        ["id"]=25643, 
        ["discription"]="DEF:95 HP+22 MP+56 STR+15 DEX+15 VIT+15 AGI+6 INT+29 MND+28 CHR+26 Evasion+33 Magic Evasion+86 Magic Accuracy+15 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+6 Haste+6% \"Fast Cast\"+8%", 
        ["STR"]=15, 
        ["Haste"]=6, 
        ["MP"]=56, 
        ["AGI"]=6, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["CHR"]=26, 
        ["VIT"]=15, 
        ["Magic Atk. Bonus"]=10, 
        ["Magic Accuracy"]=15
    }, 
    [586]={
        ["Evasion"]=33, 
        ["MND"]=23, 
        ["STR"]=24, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["Haste"]=5, 
        ["item_level"]=119, 
        ["en"]="Beck. Spats +1", 
        ["AGI"]=17, 
        ["HP"]=41, 
        ["discription"]="DEF:102 HP+41 MP+116 STR+24 VIT+12 AGI+17 INT+35 MND+23 CHR+20 Evasion+33 Magic Evasion+107 \"Magic Def. Bonus\"+6 Summoning magic skill +20 Haste+5% \"Blood Boon\"+12 Avatar: TP Bonus +600 Set: Augments \"Blood Boon\"", 
        ["VIT"]=12, 
        ["DEF"]=102, 
        ["MP"]=116, 
        ["id"]=27266, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["CHR"]=20, 
        ["INT"]=35, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=365, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }
    }, 
    [587]={
        ["id"]=21395, 
        ["en"]="Sancus Sachet +1", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="\"Blood Pact\" recast time II -7 Avatar: Lv119 \"Blood Pact\" damage +15 Accuracy+20 Ranged Accuracy+20 Magic Accuracy+20", 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [588]={
        ["discription"]="Adds \"Regen\" effect Latent effect: Adds \"Refresh\" effect", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["id"]=18811, 
        ["en"]="Oneiros Grip", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [589]={
        ["discription"]="Summoning magic skill +3", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["id"]=19058, 
        ["en"]="Vox Grip", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [590]={
        ["discription"]="Spell interruption rate down 10% Occ. quickens spellcasting +2%", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=19761, 
        ["en"]="Impatiens", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [591]={
        ["Evasion"]=56, 
        ["MND"]=29, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=24, 
        ["STR"]=22, 
        ["en"]="Convoker's Horn +3", 
        ["Haste"]=6, 
        ["discription"]="DEF:112 HP+56 MP+98 STR+22 DEX+24 VIT+24 AGI+24 INT+29 MND+29 CHR+29 Accuracy+47 Evasion+56 Magic Evasion+95 \"Magic Def. Bonus\"+6 Summoning magic skill +19 Haste+6% \"Refresh\"+3 Avatar: Accuracy+41 Magic Accuracy+41 Haste+10% Set (Avatar): Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["HP"]=56, 
        ["id"]=23389, 
        ["VIT"]=24, 
        ["DEF"]=112, 
        ["MP"]=98, 
        ["Accuracy"]=47, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=29, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["AGI"]=24
    }, 
    [592]={
        ["Evasion"]=41, 
        ["MND"]=29, 
        ["STR"]=21, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=20, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Reduces Sp. \"Blood Pact\" MP cost", 
            [4]="none"
        }, 
        ["AGI"]=21, 
        ["DEF"]=123, 
        ["en"]="Glyphic Doublet +1", 
        ["HP"]=50, 
        ["discription"]="DEF:123 HP+50 MP+115 STR+21 DEX+20 VIT+21 AGI+21 INT+29 MND+29 CHR+29 Evasion+41 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+3% \"Blood Pact\" ability delay II -2 Avatar perpetuation cost -5 Avatar: Critical hit rate +12%", 
        ["VIT"]=21, 
        ["Haste"]=3, 
        ["MP"]=115, 
        ["id"]=26829, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=29, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [593]={
        ["Evasion"]=41, 
        ["MND"]=29, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["STR"]=21, 
        ["en"]="Shomonjijoe +1", 
        ["Haste"]=3, 
        ["discription"]="DEF:127 HP+50 MP+85 STR+21 DEX+20 VIT+21 AGI+21 INT+29 MND+29 CHR+29 Evasion+41 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+3%  \"Blood Pact\" ability delay -8 \"Refresh\"+3 Avatar: Enmity+14 Unity Ranking: Avatar: \"Magic Atk. Bonus\"+25～30", 
        ["HP"]=50, 
        ["DEX"]=20, 
        ["VIT"]=21, 
        ["DEF"]=127, 
        ["MP"]=85, 
        ["id"]=26888, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=29, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["AGI"]=21
    }, 
    [594]={
        ["Evasion"]=22, 
        ["MND"]=33, 
        ["STR"]=6, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=28, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Inc. Sp. \"Blood Pact\" magic burst dmg.", 
            [4]="none"
        }, 
        ["AGI"]=5, 
        ["DEF"]=81, 
        ["en"]="Glyphic Bracers +1", 
        ["HP"]=18, 
        ["discription"]="DEF:81 HP+18 MP+41 STR+6 DEX+28 VIT+24 AGI+5 INT+19 MND+33 CHR+19 Evasion+22 Magic Evasion+37 \"Magic Def. Bonus\"+3 Summoning magic skill +19 Haste+3% \"Blood Pact\" ability delay -6 Avatar: Accuracy+28 Haste+3%", 
        ["VIT"]=24, 
        ["Haste"]=3, 
        ["MP"]=41, 
        ["id"]=27005, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["CHR"]=19, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [595]={
        ["Evasion"]=61, 
        ["MND"]=39, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=30, 
        ["STR"]=31, 
        ["en"]="Con. Doublet +3", 
        ["Haste"]=3, 
        ["discription"]="DEF:142 HP+85 MP+211 STR+31 DEX+30 VIT+31 AGI+31 INT+39 MND+39 CHR+39 Accuracy+50 Evasion+61 Magic Evasion+100 \"Magic Def. Bonus\"+7 Haste+3% \"Blood Pact\" ability delay -15 Resistance to current avatar's element +50 Avatar: Acc.+45 Magic Acc.+45 \"Blood Pact\" damage +16 Set (Avatar): Inc. Acc., R. Acc., and M. Acc.", 
        ["HP"]=85, 
        ["id"]=23456, 
        ["VIT"]=31, 
        ["DEF"]=142, 
        ["MP"]=211, 
        ["Accuracy"]=50, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=39, 
        ["INT"]=39, 
        ["category"]="Armor", 
        ["AGI"]=31
    }, 
    [596]={
        ["Evasion"]=27, 
        ["MND"]=26, 
        ["en"]="Assid. Pants +1", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [10]="BRD", 
            [15]="SMN", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["Refresh"]=2, 
        ["STR"]=25, 
        ["item_level"]=119, 
        ["Haste"]=5, 
        ["AGI"]=17, 
        ["HP"]=43, 
        ["id"]=28135, 
        ["category"]="Armor", 
        ["DEF"]=105, 
        ["MP"]=29, 
        ["VIT"]=12, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["INT"]=36, 
        ["Unity Ranking Bonus Applied"]="Refresh + 2", 
        ["CHR"]=19, 
        ["discription"]="DEF:105 HP+43 MP+29 STR+25 VIT+12 AGI+17 INT+36 MND+26 CHR+19 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% Enmity-6 Avatar perpetuation cost-3 Unity Ranking: \"Refresh\"+1～2"
    }, 
    [597]={
        ["discription"]="DEF:100 HP+37 MP+86 STR+16 DEX+38 VIT+34 AGI+15 INT+29 MND+43 CHR+29 Acc.+48 Eva.+42 Magic Evasion+57 \"Magic Def. Bonus\"+4 Haste+3% Occasionally converts damage taken of avatar's element to MP Avatar: Accuracy+43 Magic Accuracy+43 Enmity+15 \"Double Attack\"+10% Set (Avatar): Inc. Acc., Ranged Acc., and Magic Acc.", 
        ["MND"]=43, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=38, 
        ["AGI"]=15, 
        ["en"]="Convo. Bracers +3", 
        ["STR"]=16, 
        ["Haste"]=3, 
        ["HP"]=37, 
        ["id"]=23523, 
        ["VIT"]=34, 
        ["DEF"]=100, 
        ["MP"]=86, 
        ["Accuracy"]=48, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["CHR"]=29, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [598]={
        ["discription"]="DEF:16 MP+12 Evasion+8 Movement speed +12%", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["category"]="Armor", 
        ["en"]="Crier's Gaiters", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=27456, 
        ["DEF"]=16, 
        ["MP"]=12, 
        ["Evasion"]=8
    }, 
    [599]={
        ["discription"]="Summoning magic skill +9 Avatar: \"Regain\"+25 Weather: Avatar perpetuation cost -1", 
        ["en"]="Caller's Pendant", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=11619, 
        ["category"]="Armor", 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [600]={
        ["discription"]="DEF:17 Accuracy+20 Haste+9% Pet: Accuracy+20 Ranged Accuracy+20 Haste+9%", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["category"]="Armor", 
        ["en"]="Klouskap Sash +1", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=26336, 
        ["DEF"]=17, 
        ["Accuracy"]=20, 
        ["Haste"]=9
    }, 
    [601]={
        ["en"]="Fucho-no-Obi", 
        ["id"]=28452, 
        ["DEF"]=10, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:10 MP+30 \"Drain\" and \"Aspir\" potency +8 Latent effect: \"Refresh\"+1", 
        ["MP"]=30, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [602]={
        ["en"]="Campestres's Cape", 
        ["id"]=26260, 
        ["DEF"]=15, 
        ["slots"]={
            [15]="Back"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:15 Avatar: Lv.+1 \"Blood Pact\" damage +5", 
        ["augments"]={
            [1]="Pet: Acc.+20 Pet: R.Acc.+20 Pet: Atk.+20 Pet: R.Atk.+20", 
            [2]="none", 
            [3]="Pet: Accuracy+10 Pet: Rng. Acc.+10", 
            [4]="Pet: Haste+10", 
            [5]="Pet: \"Regen\"+5"
        }, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [603]={
        ["Evasion"]=22, 
        ["MND"]=33, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=28, 
        ["Haste"]=3, 
        ["en"]="Asteria Mitts +1", 
        ["STR"]=6, 
        ["discription"]="DEF:82 HP+18 MP+44 STR+6 DEX+28 VIT+24 AGI+5 INT+19 MND+33 CHR+20 Evasion+22 Magic Evasion+43 \"Magic Def. Bonus\"+3 Haste+3% Carbuncle: Halves perpetuation cost Lv.+1 Avatar: \"Magic Atk. Bonus\"+26 Unity Ranking: \"Refresh\"+1～2", 
        ["HP"]=18, 
        ["Refresh"]=2, 
        ["VIT"]=24, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=82, 
        ["MP"]=44, 
        ["id"]=27107, 
        ["Unity Ranking Bonus Applied"]="Refresh + 2", 
        ["CHR"]=20, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["AGI"]=5
    }, 
    [604]={
        ["discription"]="DEF:3 Magic Evasion+10 \"Magic Def. Bonus\"+5 Avatar: Accuracy+15 Ranged Accuracy+15 Magic Accuracy+15 \"Blood Pact\" damage +10", 
        ["DEF"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Lugalbanda Earring", 
        ["id"]=26082, 
        ["category"]="Armor", 
        ["jobs"]={
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [605]={
        ["discription"]="DMG:217 Delay:402 MP+88 Staff skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Blood Pact\" ability delay II -2 Avatar: Magic Accuracy+15 \"Magic Atk. Bonus\"+120 \"Blood Pact\" damage +3", 
        ["skill"]="Staff", 
        ["id"]=21149, 
        ["Staff skill"]=242, 
        ["item_level"]=119, 
        ["en"]="Espiritus", 
        ["delay"]=402, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["MP"]=88, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["augments"]={
            [1]="Summoning magic skill +15", 
            [2]="Pet: Mag. Acc.+30", 
            [3]="Pet: Damage taken -4%"
        }, 
        ["Parrying skill"]=242, 
        ["damage"]=217
    }, 
    [606]={
        ["Evasion"]=60, 
        ["MND"]=17, 
        ["item_level"]=119, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=8, 
        ["STR"]=8, 
        ["en"]="Inspirited Boots", 
        ["Haste"]=3, 
        ["discription"]="DEF:70 HP+9 MP+20 STR+8 DEX+8 VIT+8 AGI+29 INT+25 MND+17 CHR+32 \"Magic Atk. Bonus\"+20 Magic Damage+10 Evasion+60 Magic Evasion+118 \"Magic Def. Bonus\"+6 Haste+3% Duration of Refresh effects received +15", 
        ["HP"]=9, 
        ["id"]=27464, 
        ["Magic Atk. Bonus"]=20, 
        ["DEF"]=70, 
        ["MP"]=20, 
        ["VIT"]=8, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["CHR"]=32, 
        ["INT"]=25, 
        ["category"]="Armor", 
        ["AGI"]=29
    }, 
    [607]={
        ["discription"]="DEF:7 MP+20 Divine magic skill +8 Summoning magic skill +8 Singing skill +8 Geomancy skill +5", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["category"]="Armor", 
        ["en"]="Kobo Obi", 
        ["Singing skill"]=8, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=26320, 
        ["DEF"]=7, 
        ["MP"]=20, 
        ["Geomancy skill"]=5
    }, 
    [608]={
        ["Evasion"]=27, 
        ["MND"]=24, 
        ["STR"]=25, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["augments"]={
            [1]="MP+45", 
            [2]="Pet: Accuracy+14 Pet: Rng. Acc.+14", 
            [3]="Pet: Mag. Acc.+13", 
            [4]="Pet: Damage taken -3%", 
            [5]="none"
        }, 
        ["AGI"]=17, 
        ["DEF"]=102, 
        ["en"]="Enticer's Pants", 
        ["HP"]=38, 
        ["discription"]="DEF:102 HP+38 MP+56 STR+25 VIT+11 AGI+17 INT+34 MND+24 CHR+19 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% Avatar: \"Double Attack\"+3% Critical hit rate +5% TP Bonus +650 \"Blood Pact\" damage +12", 
        ["VIT"]=11, 
        ["Haste"]=5, 
        ["MP"]=101, 
        ["id"]=27323, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["CHR"]=19, 
        ["INT"]=34, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [609]={
        ["discription"]="DEF:7 INT+3 MND+3 Increases duration of \"Refresh\" effect received", 
        ["INT"]=3, 
        ["MND"]=3, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEF"]=7, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=11575, 
        ["en"]="Grapevine Cape"
    }, 
    [610]={
        ["discription"]="MP+30 Enhancing magic skill +5 Summoning magic skill +5", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28506, 
        ["en"]="Andoaa Earring", 
        ["MP"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [611]={
        ["MDT"]=-8, 
        ["DEF"]=129, 
        ["jobs"]={
            [3]="WHM", 
            [10]="BRD", 
            [15]="SMN"
        }, 
        ["DEX"]=19, 
        ["Evasion"]=38, 
        ["MND"]=43, 
        ["item_level"]=119, 
        ["Set Bonus"]={
            ["set id"]=16, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Refresh"]=1
                }, 
                [3]={
                    ["Refresh"]=2
                }, 
                [4]={
                    ["Refresh"]=3
                }, 
                [5]={
                    ["Refresh"]=4
                }
            }
        }, 
        ["Fast Cast"]=14, 
        ["en"]="Inyanga Jubbah +2", 
        ["HP"]=85, 
        ["id"]=25793, 
        ["AGI"]=23, 
        ["Haste"]=2, 
        ["MP"]=90, 
        ["discription"]="DEF:129 HP+85 MP+90 STR+16 DEX+19 VIT+24 AGI+23 INT+48 MND+43 CHR+42 Magic Accuracy+46 Evasion+38 Magic Evasion+120 \"Magic Def. Bonus\"+11 Haste+2% \"Fast Cast\"+14% Magic damage taken -8% Set: Enhances \"Refresh\" effect", 
        ["STR"]=16, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=42, 
        ["INT"]=48, 
        ["VIT"]=24, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=46
    }, 
    [612]={
        ["Evasion"]=38, 
        ["MND"]=25, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["STR"]=15, 
        ["en"]="Baayami Hat", 
        ["Haste"]=6, 
        ["discription"]="DEF:102 HP+34 MP+44 STR+15 DEX+16 VIT+29 AGI+19 INT+33 MND+25 CHR+20 Evasion+38 Magic Evasion+96 \"Magic Def. Bonus\"+5 Summoning magic skill +26 Haste+6% Avatar: \"Regain\"+3", 
        ["HP"]=34, 
        ["DEX"]=16, 
        ["VIT"]=29, 
        ["DEF"]=102, 
        ["MP"]=44, 
        ["id"]=25565, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=20, 
        ["INT"]=33, 
        ["category"]="Armor", 
        ["AGI"]=19
    }, 
    [613]={
        ["discription"]="MP+45 \"Conserve MP\"+3 \"Blood Boon\"+3", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=11700, 
        ["en"]="Gifted Earring", 
        ["MP"]=45, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [614]={
        ["Evasion"]=22, 
        ["MND"]=37, 
        ["STR"]=6, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=28, 
        ["augments"]={
            [1]="MP+60", 
            [2]="Pet: \"Mag.Atk.Bns.\"+30", 
            [3]="Blood Pact Dmg.+7"
        }, 
        ["AGI"]=5, 
        ["DEF"]=83, 
        ["en"]="Apogee Mitts", 
        ["HP"]=-80, 
        ["discription"]="DEF:83 HP-80 MP+41 STR+6 DEX+28 VIT+25 AGI+5 INT+23 MND+37 CHR+23 Evasion+22 Magic Evasion+48 \"Magic Def. Bonus\"+4 Haste+3% Avatar: HP+80 Accuracy+28 Magic Accuracy+28", 
        ["VIT"]=25, 
        ["Haste"]=3, 
        ["MP"]=101, 
        ["id"]=27028, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["CHR"]=23, 
        ["INT"]=23, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [615]={
        ["Evasion"]=55, 
        ["MND"]=19, 
        ["DEF"]=65, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=11, 
        ["STR"]=10, 
        ["AGI"]=33, 
        ["en"]="Regal Pumps", 
        ["item_level"]=119, 
        ["HP"]=13, 
        ["discription"]="DEF:65 HP+13 MP+34 STR+10 DEX+11 VIT+10 AGI+33 INT+17 MND+19 CHR+34 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Healing magic skill +10 Enhancing magic skill +10 Haste+3% \"Fast Cast\"+3% Unity Ranking: \"Fast Cast\"+1～3%", 
        ["VIT"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=3, 
        ["MP"]=34, 
        ["id"]=28273, 
        ["Unity Ranking Bonus Applied"]="Fast Cast + 3", 
        ["CHR"]=34, 
        ["INT"]=17, 
        ["category"]="Armor", 
        ["Fast Cast"]=6
    }, 
    [616]={
        ["discription"]="Accuracy+10 Pet: Accuracy+10 Ranged Accuracy+10 \"Store TP\"+6 Avatar: \"Blood Pact\" damage +4", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26180, 
        ["en"]="Varar Ring +1", 
        ["Accuracy"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [617]={
        ["Evasion"]=55, 
        ["MND"]=23, 
        ["STR"]=10, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=11, 
        ["augments"]={
            [1]="MP+60", 
            [2]="Pet: \"Mag.Atk.Bns.\"+30", 
            [3]="Blood Pact Dmg.+7"
        }, 
        ["AGI"]=33, 
        ["DEF"]=62, 
        ["en"]="Apogee Pumps", 
        ["HP"]=-80, 
        ["discription"]="DEF:62 HP-80 MP+41 STR+10 DEX+11 VIT+10 AGI+33 INT+21 MND+23 CHR+38 Evasion+55 Magic Evasion+118 \"Magic Def. Bonus\"+6 Haste+3% Avatar perpetuation cost -8 Avatar: HP+80 \"Blood Pact\" damage +1", 
        ["VIT"]=10, 
        ["Haste"]=3, 
        ["MP"]=101, 
        ["id"]=27380, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["CHR"]=38, 
        ["INT"]=21, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [618]={
        ["discription"]="MP+25 Summoning magic skill +10 Avatar perpetuation cost -1", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=14625, 
        ["en"]="Evoker's Ring", 
        ["MP"]=25, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [619]={
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["en"]="Elan Strap +1", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="Magic Attack+7 Avatar: \"Blood Pact\" damage +5", 
        ["id"]=22211, 
        ["Attack"]=7
    }, 
    [620]={
        ["discription"]="DEF:12 HP+88 Damage taken -3% Avatar: Attack+20 \"Magic Atk. Bonus\"+10 Set (avatar only): Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["category"]="Armor", 
        ["en"]="Regal Belt", 
        ["HP"]=88, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEF"]=12, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=26342, 
        ["DT"]=-3
    }, 
    [621]={
        ["Evasion"]=19, 
        ["MND"]=37, 
        ["STR"]=3, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=23, 
        ["augments"]={
            [1]="Pet: \"Mag.Atk.Bns.\"+15", 
            [2]="Blood Pact Dmg.+10", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["AGI"]=2, 
        ["DEF"]=84, 
        ["en"]="Merlinic Dastanas", 
        ["HP"]=9, 
        ["discription"]="DEF:84 HP+9 MP+20 STR+3 DEX+23 VIT+20 AGI+2 INT+26 MND+37 CHR+21 Evasion+19 Magic Evasion+48 \"Magic Def. Bonus\"+3 Haste+3% Avatar: Attack+20 \"Magic Atk. Bonus\"+20 Enmity+5 \"Blood Pact\" damage +5", 
        ["VIT"]=20, 
        ["Haste"]=3, 
        ["MP"]=20, 
        ["id"]=27141, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["CHR"]=21, 
        ["INT"]=26, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [622]={
        ["discription"]="Accuracy+10 Pet: Accuracy+10 Ranged Accuracy+10 \"Store TP\"+6 Avatar: \"Blood Pact\" damage +4", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26180, 
        ["en"]="Varar Ring +1", 
        ["Accuracy"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [623]={
        ["Evasion"]=27, 
        ["MND"]=30, 
        ["STR"]=25, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEF"]=101, 
        ["AGI"]=17, 
        ["Fast Cast"]=7, 
        ["discription"]="DEF:101 HP+43 MP+29 STR+25 VIT+12 AGI+17 INT+40 MND+30 CHR+19 Magic Accuracy+20 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Enfeebling magic skill +18 Haste+5% Pet: Damage taken -4%", 
        ["en"]="Psycloth Lappas", 
        ["HP"]=43, 
        ["augments"]={
            [1]="MP+80", 
            [2]="Mag. Acc.+15", 
            [3]="\"Fast Cast\"+7"
        }, 
        ["item_level"]=119, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=5, 
        ["MP"]=109, 
        ["id"]=27287, 
        ["INT"]=40, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["VIT"]=12, 
        ["Magic Accuracy"]=35
    }, 
    [624]={
        ["discription"]="DMG:208 Delay:366 INT+19 MND+19 \"Magic Atk. Bonus\"+38 Magic Damage+217 Staff skill +242 Parrying skill +242 Magic Accuracy skill +228 \"Fast Cast\"+4% Pet: \"Magic Atk. Bonus\"+110", 
        ["id"]=21156, 
        ["MND"]=19, 
        ["en"]="Nibiru Staff", 
        ["Staff skill"]=242, 
        ["slots"]={
            [0]="Main"
        }, 
        ["Fast Cast"]=4, 
        ["delay"]=366, 
        ["jobs"]={
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH"
        }, 
        ["Parrying skill"]=242, 
        ["INT"]=19, 
        ["skill"]="Staff", 
        ["augments"]={
            [1]="Pet: Mag. Acc.+20", 
            [2]="Pet: \"Mag.Atk.Bns.\"+20", 
            [3]="Pet: \"Regen\"+2"
        }, 
        ["category"]="Weapon", 
        ["damage"]=208, 
        ["Magic Atk. Bonus"]=38, 
        ["item_level"]=119
    }, 
    [625]={
        ["Evasion"]=27, 
        ["MND"]=28, 
        ["STR"]=25, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["augments"]={
            [1]="Pet: STR+15", 
            [2]="Blood Pact Dmg.+13", 
            [3]="Pet: \"Dbl. Atk.\"+3"
        }, 
        ["AGI"]=17, 
        ["DEF"]=103, 
        ["en"]="Apogee Slacks", 
        ["HP"]=-100, 
        ["discription"]="DEF:103 HP-100 MP+56 STR+25 VIT+12 AGI+17 INT+38 MND+28 CHR+23 Evasion+27 Magic Evasion+118 \"Magic Def. Bonus\"+6 Haste+5% Avatar: HP+100 Enmity+5 \"Blood Pact\" damage +6", 
        ["VIT"]=12, 
        ["Haste"]=5, 
        ["MP"]=56, 
        ["id"]=27204, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["CHR"]=23, 
        ["INT"]=38, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [626]={
        ["discription"]="MP+30 Magic Accuracy+5 \"Fast Cast\"+2%", 
        ["category"]="Armor", 
        ["en"]="Rahab Ring", 
        ["Fast Cast"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26162, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=30, 
        ["Magic Accuracy"]=5
    }, 
    [627]={
        ["Evasion"]=19, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [9]="BST", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["DEX"]=50, 
        ["DEF"]=88, 
        ["MND"]=26, 
        ["Critical hit rate"]=8, 
        ["Set Bonus"]={
            ["set id"]=154, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["CHR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["CHR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["CHR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["CHR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["AGI"]=11, 
        ["en"]="Tali'ah Gages +2", 
        ["HP"]=27, 
        ["id"]=25834, 
        ["item_level"]=119, 
        ["STR"]=16, 
        ["Haste"]=5, 
        ["MP"]=20, 
        ["Accuracy"]=43, 
        ["INT"]=14, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["discription"]="DEF:88 HP+27 MP+20 STR+16 DEX+50 VIT+44 AGI+11 INT+14 MND+26 CHR+19 Accuracy+43 Magic Accuracy+43 Evasion+19 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+5% Critical hit rate +8% Pet: Accuracy+43 Ranged Accuracy+43 Magic Accuracy+43 Set: Increases Dexterity, Vitality, and Charisma", 
        ["VIT"]=44, 
        ["Magic Accuracy"]=43
    }, 
    [628]={
        ["Evasion"]=36, 
        ["MND"]=32, 
        ["STR"]=14, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=14, 
        ["augments"]={
            [1]="MP+60", 
            [2]="Pet: \"Mag.Atk.Bns.\"+30", 
            [3]="Blood Pact Dmg.+7"
        }, 
        ["AGI"]=14, 
        ["DEF"]=94, 
        ["en"]="Apogee Crown", 
        ["HP"]=-100, 
        ["discription"]="DEF:94 HP-100 MP+59 STR+14 DEX+14 VIT+14 AGI+14 INT+32 MND+32 CHR+32 Evasion+36 Magic Evasion+86 \"Magic Def. Bonus\"+6 Haste+6% Avatar: HP+100 Accuracy+25 Enmity+9", 
        ["VIT"]=14, 
        ["Haste"]=6, 
        ["MP"]=119, 
        ["id"]=26676, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=32, 
        ["INT"]=32, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [629]={
        ["Evasion"]=60, 
        ["MND"]=11, 
        ["Haste"]=4, 
        ["jobs"]={
            [9]="BST", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["DEX"]=35, 
        ["STR"]=16, 
        ["AGI"]=46, 
        ["Set Bonus"]={
            ["set id"]=154, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["CHR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["CHR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["CHR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["CHR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["en"]="Tali'ah Crackows +2", 
        ["HP"]=15, 
        ["discription"]="DEF:70 HP+15 MP+20 STR+16 DEX+35 VIT+23 AGI+46 MND+11 CHR+26 Accuracy+42 Magic Accuracy+42 Evasion+60 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+4% Pet: Accuracy+42 Ranged Accuracy+42 Magic Accuracy+42 Haste+7% Set: Increases Dexterity, Vitality, and Charisma", 
        ["Accuracy"]=42, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=70, 
        ["MP"]=20, 
        ["id"]=25952, 
        ["CHR"]=26, 
        ["VIT"]=23, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["Magic Accuracy"]=42
    }, 
    [630]={
        ["discription"]="Evasion+3 Enmity-5 Pet: Enmity+5 \"Double Attack\"+3%", 
        ["Evasion"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28505, 
        ["en"]="Domes. Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [631]={
        ["Evasion"]=44, 
        ["MND"]=29, 
        ["STR"]=23, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=19, 
        ["Haste"]=3, 
        ["AGI"]=20, 
        ["en"]="Beck. Doublet +1", 
        ["discription"]="DEF:123 HP+54 MP+151 STR+23 DEX+19 VIT+23 AGI+20 INT+29 MND+29 CHR+29 Evasion+44 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+3% Summoning magic skill +14 Avatar perpetuation cost -6 Avatar: \"Blood Pact\" damage +11 Set: Augments \"Blood Boon\"", 
        ["HP"]=54, 
        ["item_level"]=119, 
        ["VIT"]=23, 
        ["DEF"]=123, 
        ["MP"]=151, 
        ["id"]=26927, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=29, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=365, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }
    }, 
    [632]={
        ["MDT"]=-3, 
        ["MND"]=33, 
        ["STR"]=6, 
        ["jobs"]={
            [3]="WHM", 
            [10]="BRD", 
            [15]="SMN"
        }, 
        ["DEX"]=6, 
        ["Evasion"]=60, 
        ["AGI"]=33, 
        ["Haste"]=2, 
        ["en"]="Inyan. Crackows +2", 
        ["HP"]=25, 
        ["item_level"]=119, 
        ["VIT"]=14, 
        ["DEF"]=70, 
        ["MP"]=30, 
        ["discription"]="DEF:70 HP+25 MP+30 STR+6 DEX+6 VIT+14 AGI+33 INT+32 MND+33 CHR+46 Evasion+60 Magic Evasion+147 \"Magic Def. Bonus\"+8 Haste+2% Magic damage taken -3% Avatar: \"Blood Pact\" damage +9 Set: Enhances \"Refresh\" effect", 
        ["id"]=25949, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["CHR"]=46, 
        ["INT"]=32, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=16, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Refresh"]=1
                }, 
                [3]={
                    ["Refresh"]=2
                }, 
                [4]={
                    ["Refresh"]=3
                }, 
                [5]={
                    ["Refresh"]=4
                }
            }
        }
    }, 
    [633]={
        ["Evasion"]=24, 
        ["STR"]=33, 
        ["jobs"]={
            [9]="BST", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["DEX"]=11, 
        ["DEF"]=110, 
        ["MND"]=15, 
        ["item_level"]=119, 
        ["discription"]="DEF:110 HP+57 MP+53 STR+33 DEX+11 VIT+30 AGI+34 INT+29 MND+15 CHR+10 Accuracy+45 Magic Accuracy+45 Evasion+24 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% Pet: Accuracy+45 Ranged Accuracy+45 Magic Accuracy+45 Damage taken -5% Set: Increases Dexterity, Vitality, and Charisma", 
        ["AGI"]=34, 
        ["en"]="Tali'ah Sera. +2", 
        ["HP"]=57, 
        ["id"]=25885, 
        ["Set Bonus"]={
            ["set id"]=154, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["CHR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["CHR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["CHR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["CHR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=6, 
        ["MP"]=53, 
        ["Accuracy"]=45, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["CHR"]=10, 
        ["VIT"]=30, 
        ["Magic Accuracy"]=45
    }, 
    [634]={
        ["Evasion"]=22, 
        ["MND"]=33, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=28, 
        ["STR"]=6, 
        ["en"]="Lamassu Mitts +1", 
        ["Haste"]=3, 
        ["discription"]="DEF:82 HP+18 MP+44 STR+6 DEX+28 VIT+24 AGI+5 INT+19 MND+33 CHR+20 Evasion+22 Magic Evasion+43 \"Magic Def. Bonus\"+3 Haste+3% Summoning magic skill +22 Cait Sith: Lv.+1 Avatar: Magic Accuracy+26 Unity Ranking: MP+10～50", 
        ["HP"]=18, 
        ["id"]=27109, 
        ["category"]="Armor", 
        ["DEF"]=82, 
        ["MP"]=94, 
        ["VIT"]=24, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["INT"]=19, 
        ["Unity Ranking Bonus Applied"]="MP + 50", 
        ["CHR"]=20, 
        ["AGI"]=5
    }, 
    [635]={
        ["Evasion"]=22, 
        ["MND"]=33, 
        ["STR"]=6, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=28, 
        ["Haste"]=3, 
        ["AGI"]=5, 
        ["en"]="Beck. Bracers +1", 
        ["discription"]="DEF:82 HP+18 MP+94 STR+6 DEX+28 VIT+24 AGI+5 INT+19 MND+33 CHR+20 Evasion+22 Magic Evasion+43 \"Magic Def. Bonus\"+3 Haste+3% \"Mana Cede\"+120 Depending on day or weather: Halves avatar perpetuation cost Avatar: Accuracy+30  Set: Augments \"Blood Boon\"", 
        ["HP"]=18, 
        ["item_level"]=119, 
        ["VIT"]=24, 
        ["DEF"]=82, 
        ["MP"]=94, 
        ["id"]=27081, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["CHR"]=20, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=365, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }
    }, 
    [636]={
        ["discription"]="MP+35 Avatar: \"Blood Pact\" damage +5", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=27528, 
        ["en"]="Gelos Earring", 
        ["MP"]=35, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [637]={
        ["Haste"]=3, 
        ["en"]="Witful Belt", 
        ["DEF"]=8, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:8  Enhances \"Fast Cast\" effect Haste+3% Occ. quickens spellcasting +3%", 
        ["id"]=10826, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [638]={
        ["Evasion"]=45, 
        ["MND"]=34, 
        ["STR"]=23, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=24, 
        ["DEF"]=132, 
        ["AGI"]=25, 
        ["en"]="Baayami Robe", 
        ["item_level"]=119, 
        ["HP"]=68, 
        ["discription"]="DEF:132 HP+68 MP+103 STR+23 DEX+24 VIT+34 AGI+25 INT+42 MND+34 CHR+30 Evasion+45 Magic Evasion+112 \"Magic Def. Bonus\"+8 Summoning magic skill +32 Haste+3% \"Fast Cast\"+11% Summoning magic interruption rate down 100%", 
        ["VIT"]=34, 
        ["Haste"]=3, 
        ["MP"]=103, 
        ["id"]=26541, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=30, 
        ["INT"]=42, 
        ["category"]="Armor", 
        ["Fast Cast"]=11
    }, 
    [639]={
        ["discription"]="MP+50 Avatar perpetuation cost -2 \"Blood Pact\" ability delay -2", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=27534, 
        ["en"]="Evans Earring", 
        ["MP"]=50, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [640]={
        ["Evasion"]=37, 
        ["MND"]=29, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["STR"]=30, 
        ["en"]="Convo. Spats +2", 
        ["Haste"]=5, 
        ["discription"]="DEF:114 HP+57 MP+99 STR+30 VIT+16 AGI+22 INT+39 MND+29 CHR+24 Accuracy+39 Evasion+37 Magic Evasion+117 \"Magic Def. Bonus\"+6 Haste+5% Enmity-7 Avatar: Accuracy+40 Magic Accuracy+40 Enmity+8 \"Store TP\"+5 Set (Avatar): Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["HP"]=57, 
        ["id"]=23255, 
        ["VIT"]=16, 
        ["DEF"]=114, 
        ["MP"]=99, 
        ["Accuracy"]=39, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["CHR"]=24, 
        ["INT"]=39, 
        ["category"]="Armor", 
        ["AGI"]=22
    }, 
    [641]={
        ["Evasion"]=36, 
        ["MND"]=19, 
        ["STR"]=12, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=14, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Astral Flow\" effect", 
            [4]="none"
        }, 
        ["AGI"]=14, 
        ["DEF"]=93, 
        ["en"]="Glyphic Horn +1", 
        ["HP"]=31, 
        ["discription"]="DEF:93 HP+31 MP+95 STR+12 DEX+14 VIT+14 AGI+14 INT+19 MND+19 CHR+19 Evasion+36 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% \"Blood Pact\" ability delay -8 Avatar perpetuation cost -4 Avatar: \"Magic Atk. Bonus\"+23", 
        ["VIT"]=14, 
        ["Haste"]=6, 
        ["MP"]=95, 
        ["id"]=26653, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=19, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [642]={
        ["Evasion"]=65, 
        ["MND"]=24, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=16, 
        ["STR"]=15, 
        ["en"]="Convo. Pigaches +2", 
        ["Haste"]=3, 
        ["discription"]="DEF:72 HP+13 MP+61 STR+15 DEX+16 VIT+15 AGI+37 INT+22 MND+24 CHR+39 Accuracy+36 Evasion+65 Magic Evasion+117 \"Magic Def. Bonus\"+5 Haste+3% Avatar perpetuation cost -5 Avatar: Accuracy+30 Magic Accuracy+30 Evasion+30 \"Blood Pact\" damage +8 Set (Avatar): Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["HP"]=13, 
        ["id"]=23322, 
        ["VIT"]=15, 
        ["DEF"]=72, 
        ["MP"]=61, 
        ["Accuracy"]=36, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["CHR"]=39, 
        ["INT"]=22, 
        ["category"]="Armor", 
        ["AGI"]=37
    }, 
    [643]={
        ["discription"]="CHR+4 Pet: Haste+3% Enmity+5 Damage taken -1%", 
        ["CHR"]=4, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28495, 
        ["en"]="Rimeice Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [644]={
        ["Evasion"]=27, 
        ["MND"]=24, 
        ["STR"]=25, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Increases Sp. \"Blood Pact\" accuracy", 
            [4]="none"
        }, 
        ["AGI"]=17, 
        ["DEF"]=103, 
        ["en"]="Glyphic Spats +1", 
        ["HP"]=38, 
        ["discription"]="DEF:103 HP+38 MP+85 STR+25 VIT+11 AGI+17 INT+34 MND+24 CHR+19 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% Shortens magic recast time for spirits \"Blood Pact\" ability delay -6 Avatar: Magic Accuracy+13", 
        ["VIT"]=11, 
        ["Haste"]=5, 
        ["MP"]=85, 
        ["id"]=27181, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["CHR"]=19, 
        ["INT"]=34, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [645]={
        ["Evasion"]=55, 
        ["MND"]=19, 
        ["STR"]=10, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=11, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Inc. Sp. \"Blood Pact\" magic crit. dmg.", 
            [4]="none"
        }, 
        ["AGI"]=32, 
        ["DEF"]=60, 
        ["en"]="Glyph. Pigaches +1", 
        ["HP"]=9, 
        ["discription"]="DEF:60 HP+9 MP+75 STR+10 DEX+11 VIT+10 AGI+32 INT+17 MND+19 CHR+34 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+3% \"Blood Pact\" ability delay II -1 Avatar: Attack+28 Magic critical hit rate +9%", 
        ["VIT"]=10, 
        ["Haste"]=3, 
        ["MP"]=75, 
        ["id"]=27357, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["CHR"]=34, 
        ["INT"]=17, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [646]={
        ["discription"]="DEF:13 MP+100 Summoning magic skill +8 Enhances \"Elemental Siphon\" effect", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["category"]="Armor", 
        ["en"]="Conveyance Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=28631, 
        ["DEF"]=13, 
        ["MP"]=100, 
        ["augments"]={
            [1]="Summoning magic skill +5", 
            [2]="Pet: Enmity+8", 
            [3]="Blood Pact Dmg.+2", 
            [4]="Blood Pact ab. del. II -1", 
            [5]="none"
        }
    }, 
    [647]={
        ["Evasion"]=33, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=10, 
        ["DEF"]=95, 
        ["MND"]=20, 
        ["augments"]={
            [1]="MP+60", 
            [2]="Mag. Acc.+15", 
            [3]="\"Mag.Atk.Bns.\"+15"
        }, 
        ["Fast Cast"]=10, 
        ["item_level"]=119, 
        ["AGI"]=1, 
        ["HP"]=27, 
        ["id"]=25615, 
        ["discription"]="DEF:95 HP+27 MP+61 STR+10 DEX+10 VIT+10 AGI+1 INT+24 MND+20 CHR+19 Magic Accuracy+26 Evasion+33 Magic Evasion+86 \"Magic Def. Bonus\"+6 Haste+6% \"Fast Cast\"+10% \"Refresh\" potency +1 \"Aquaveil\"+1", 
        ["STR"]=10, 
        ["Haste"]=6, 
        ["MP"]=121, 
        ["en"]="Amalric Coif", 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["VIT"]=10, 
        ["Magic Atk. Bonus"]=15, 
        ["Magic Accuracy"]=41
    }, 
    [648]={
        ["Evasion"]=66, 
        ["MND"]=30, 
        ["en"]="Baaya. Sabots +1", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["STR"]=12, 
        ["item_level"]=119, 
        ["Haste"]=3, 
        ["AGI"]=37, 
        ["HP"]=30, 
        ["DEX"]=14, 
        ["VIT"]=29, 
        ["DEF"]=82, 
        ["MP"]=49, 
        ["id"]=25973, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["category"]="Armor", 
        ["CHR"]=35, 
        ["discription"]="DEF:82 HP+30 MP+49 STR+12 DEX+14 VIT+29 AGI+37 MND+30 CHR+35 Evasion+66 Magic Evasion+139 \"Magic Def. Bonus\"+6 Summoning magic skill +29 Haste+3% \"Refresh\"+3 Avatar: \"Regen\"+5"
    }, 
    [649]={
        ["discription"]="Pet: Accuracy+15 Ranged Accuracy+15 Magic Accuracy+15 \"Double Attack\"+3% Damage taken +10% Avatar: \"Blood Pact\" damage +1", 
        ["en"]="Kyrene's Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=26078, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [650]={
        ["discription"]="DMG:251 Delay:402 Accuracy+30 Magic Damage+279 Staff skill +269 Parrying skill +269 Magic Accuracy skill +269 Avatar perpetuation cost -8 Avatar: Lv.+2 \"Blood Pact\" damage +40 \"Garland of Bliss\" Aftermath (including avatar): Increases Accuracy and Attack Occasionally attacks twice or thrice Afterglow", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Nirvana", 
        ["Staff skill"]=269, 
        ["delay"]=402, 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["Accuracy"]=30, 
        ["Parrying skill"]=269, 
        ["id"]=22063, 
        ["skill"]="Staff", 
        ["damage"]=251
    }, 
    [651]={
        ["Evasion"]=27, 
        ["MND"]=38, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=30, 
        ["en"]="Baayami Cuffs", 
        ["item_level"]=119, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=3, 
        ["HP"]=6, 
        ["id"]=25992, 
        ["category"]="Armor", 
        ["DEF"]=90, 
        ["MP"]=35, 
        ["VIT"]=37, 
        ["STR"]=7, 
        ["CHR"]=20, 
        ["INT"]=30, 
        ["discription"]="DEF:90 HP+6 MP+35 STR+7 DEX+30 VIT+37 INT+30 MND+38 CHR+20 Evasion+27 Magic Evasion+83 \"Magic Def. Bonus\"+4 Summoning magic skill +28 Haste+3% \"Blood Pact\" ability delay -6 Avatar: \"Regen\"+5"
    }, 
    [652]={
        ["discription"]="DEF:8 HP+25 Damage taken -4% Pet: Magic Accuracy+20 \"Magic Atk. Bonus\"+10", 
        ["category"]="Armor", 
        ["en"]="Adad Amulet", 
        ["HP"]=25, 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=26028, 
        ["DT"]=-4
    }, 
    [653]={
        ["Evasion"]=60, 
        ["DEF"]=67, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=6, 
        ["AGI"]=26, 
        ["MND"]=23, 
        ["augments"]={
            [1]="Pet: \"Mag.Atk.Bns.\"+12", 
            [2]="Blood Pact Dmg.+10", 
            [3]="Pet: STR+5", 
            [4]="none", 
            [5]="none"
        }, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Fast Cast"]=5, 
        ["item_level"]=119, 
        ["HP"]=4, 
        ["id"]=27497, 
        ["VIT"]=6, 
        ["STR"]=6, 
        ["Haste"]=3, 
        ["MP"]=20, 
        ["discription"]="DEF:67 HP+4 MP+20 STR+6 DEX+6 VIT+6 AGI+26 INT+24 MND+23 CHR+35 Evasion+60 Magic Evasion+118 \"Magic Atk. Bonus\"+15 \"Magic Def. Bonus\"+6 Haste+3% \"Fast Cast\"+5% \"Conserve MP\"+4 \"Drain\" and \"Aspir\" potency +7", 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["CHR"]=35, 
        ["Magic Atk. Bonus"]=15, 
        ["en"]="Merlinic Crackows"
    }, 
    [654]={
        ["Evasion"]=37, 
        ["MND"]=29, 
        ["en"]="Baayami Slops", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["STR"]=26, 
        ["item_level"]=119, 
        ["Haste"]=5, 
        ["AGI"]=23, 
        ["HP"]=61, 
        ["id"]=25905, 
        ["category"]="Armor", 
        ["DEF"]=114, 
        ["MP"]=53, 
        ["VIT"]=24, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["CHR"]=20, 
        ["INT"]=47, 
        ["discription"]="DEF:114 HP+61 MP+53 STR+26 VIT+24 AGI+23 INT+47 MND+29 CHR+20 Evasion+37 Magic Evasion+129 \"Magic Def. Bonus\"+7 Summoning magic skill +30 Haste+5% \"Blood Pact\" ability delay -7 Avatar: \"Regen\"+6"
    }, 
    [655]={
        ["Evasion"]=55, 
        ["MND"]=19, 
        ["STR"]=11, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=11, 
        ["Haste"]=3, 
        ["AGI"]=30, 
        ["en"]="Beck. Pigaches +1", 
        ["discription"]="DEF:61 HP+9 MP+97 STR+11 DEX+11 VIT+11 AGI+30 INT+19 MND+19 CHR+35 Evasion+55 Magic Evasion+118 \"Magic Def. Bonus\"+6 Haste+3% \"Elemental Siphon\"+60 Avatar perpetuation cost -7 Avatar: Magic Accuracy+27 Set: Augments \"Blood Boon\"", 
        ["HP"]=9, 
        ["item_level"]=119, 
        ["VIT"]=11, 
        ["DEF"]=61, 
        ["MP"]=97, 
        ["id"]=27440, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["CHR"]=35, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=365, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }
    }, 
    [656]={
        ["discription"]="DEF:15 Avatar: Lv.+1 \"Blood Pact\" damage +5", 
        ["category"]="Armor", 
        ["en"]="Campestres's Cape", 
        ["id"]=26260, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEF"]=15, 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="Pet: M.Acc.+20 Pet: M.Dmg.+20", 
            [2]="none", 
            [3]="Pet: Magic Damage+10", 
            [4]="\"Fast Cast\"+10", 
            [5]="none"
        }, 
        ["Fast Cast"]=10
    }, 
    [657]={
        ["discription"]="DEF:15 Pet: Accuracy+15 Ranged Accuracy+15 Magic Accuracy+15 \"Double Attack\"+4%", 
        ["DEF"]=15, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Incarnation Sash", 
        ["id"]=28418, 
        ["category"]="Armor", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }
    }, 
    [658]={
        ["Evasion"]=36, 
        ["MND"]=20, 
        ["STR"]=14, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=15, 
        ["Haste"]=6, 
        ["AGI"]=15, 
        ["en"]="Beckoner's Horn +1", 
        ["discription"]="DEF:93 HP+31 MP+134 STR+14 DEX+15 VIT+15 AGI+15 INT+20 MND+20 CHR+20 Evasion+36 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+6% Summoning magic skill +13 \"Avatar's Favor\"+3 \"Refresh\"+2 Set: Augments \"Blood Boon\"", 
        ["HP"]=31, 
        ["item_level"]=119, 
        ["VIT"]=15, 
        ["DEF"]=93, 
        ["MP"]=134, 
        ["id"]=26769, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=20, 
        ["INT"]=20, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=365, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }
    }, 
    [659]={
        ["discription"]="Potency of \"Cure\" effect received +10% Potency of \"Cursna\" effects received +10 Duration of Refresh effects received +20", 
        ["en"]="Gishdubar Sash", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=26323, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [660]={
        ["discription"]="Magic skills +10 MP not depleted when magic used +1%", 
        ["en"]="Incanter's Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Magic skills"]=10, 
        ["id"]=26016, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [661]={
        ["discription"]="MND+7 Magic Accuracy+15 Enfeebling magic effect +10", 
        ["category"]="Weapon", 
        ["en"]="Regal Gem", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["MND"]=7, 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["id"]=21396, 
        ["Magic Accuracy"]=15
    }, 
    [662]={
        ["discription"]="DMG:127 Delay:240 STR+15 Attack+23 \"Magic Atk. Bonus\"+34 Magic Damage+108 Magic Accuracy skill +201 Sword skill +242 Parrying skill +242 \"Fast Cast\"+7% Additional effect: HP, MP, or TP Drain", 
        ["augments"]={
            [1]="STR+6", 
            [2]="INT+5", 
            [3]="\"Occult Acumen\"+6", 
            [4]="DMG:+10", 
            [5]="none"
        }, 
        ["Sword skill"]=242, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["skill"]="Sword", 
        ["Fast Cast"]=7, 
        ["delay"]=240, 
        ["en"]="Vampirism", 
        ["Parrying skill"]=242, 
        ["INT"]=5, 
        ["STR"]=21, 
        ["id"]=20706, 
        ["category"]="Weapon", 
        ["damage"]=137, 
        ["Magic Atk. Bonus"]=34, 
        ["Attack"]=23
    }, 
    [663]={
        ["Evasion"]=41, 
        ["MND"]=21, 
        ["DEF"]=144, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG"
        }, 
        ["DEX"]=21, 
        ["STR"]=26, 
        ["item_level"]=119, 
        ["AGI"]=21, 
        ["en"]="Vatic Byrnie", 
        ["HP"]=61, 
        ["Critical hit rate"]=3, 
        ["discription"]="DEF:144 HP+61 MP+44 STR+26 DEX+21 VIT+26 AGI+21 INT+21 MND+21 CHR+21 Attack+40 Evasion+41 Magic Evasion+53 \"Magic Def. Bonus\"+4 Haste+3% Enmity+6 \"Double Attack\"+3% Critical hit rate +3%", 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=3, 
        ["MP"]=44, 
        ["id"]=25729, 
        ["INT"]=21, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["VIT"]=26, 
        ["Attack"]=40
    }, 
    [664]={
        ["damage"]=66, 
        ["Ranged Accuracy"]=20, 
        ["Throwing skill"]=242, 
        ["discription"]="DMG:66 Delay:240 HP+15 MP+15 Ranged Accuracy+20 Ranged Attack+20 Magic Accuracy+5 Throwing skill +242", 
        ["category"]="Weapon", 
        ["HP"]=15, 
        ["item_level"]=119, 
        ["delay"]=240, 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["slots"]={
            [2]="Range"
        }, 
        ["Ranged Attack"]=20, 
        ["skill"]="Throwing", 
        ["en"]="Albin Bane", 
        ["id"]=21390, 
        ["MP"]=15, 
        ["Magic Accuracy"]=5
    }, 
    [665]={
        ["discription"]="DEF:9 STR+5 DEX+5 Accuracy+10 Attack+20 \"Double Attack\"+2%", 
        ["category"]="Armor", 
        ["en"]="Grunfeld Rope", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["DEX"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=9, 
        ["STR"]=5, 
        ["Accuracy"]=10, 
        ["id"]=28408, 
        ["Attack"]=20
    }, 
    [666]={
        ["MDT"]=-5, 
        ["STR"]=24, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=8, 
        ["item_level"]=119, 
        ["MND"]=12, 
        ["Evasion"]=36, 
        ["Ranged Accuracy"]=23, 
        ["DEF"]=111, 
        ["en"]="Terminal Helm", 
        ["HP"]=41, 
        ["id"]=25634, 
        ["VIT"]=19, 
        ["Haste"]=7, 
        ["MP"]=29, 
        ["discription"]="DEF:111 HP+41 MP+29 STR+24 DEX+8 VIT+19 AGI+14 INT+16 MND+12 CHR+14 Accuracy+23 Ranged Accuracy+23 \"Magic Atk. Bonus\"+15 Magic Damage+15 Evasion+36 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+7% Magic damage taken -5%", 
        ["Accuracy"]=23, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=14, 
        ["INT"]=16, 
        ["Magic Atk. Bonus"]=15, 
        ["category"]="Armor", 
        ["AGI"]=14
    }, 
    [667]={
        ["discription"]="Accuracy+20 Magic Accuracy+20 \"Triple Attack\" damage +4", 
        ["category"]="Armor", 
        ["en"]="Asn. Gorget +1", 
        ["id"]=25448, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=20, 
        ["Magic Accuracy"]=20
    }, 
    [668]={
        ["Evasion"]=44, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=16, 
        ["DEF"]=143, 
        ["MND"]=20, 
        ["en"]="Terminal Plate", 
        ["discription"]="DEF:143 HP+63 MP+59 STR+32 DEX+16 VIT+29 AGI+19 INT+20 MND+20 CHR+20 Attack+25 Ranged Attack+25 \"Magic Atk. Bonus\"+20 Magic Damage+15 Evasion+44 Magic Evasion+53 \"Magic Def. Bonus\"+4 Haste+3% Physical damage taken -5%", 
        ["AGI"]=19, 
        ["item_level"]=119, 
        ["HP"]=63, 
        ["id"]=25707, 
        ["Ranged Attack"]=25, 
        ["STR"]=32, 
        ["Haste"]=3, 
        ["MP"]=59, 
        ["PDT"]=-5, 
        ["INT"]=20, 
        ["category"]="Armor", 
        ["CHR"]=20, 
        ["VIT"]=29, 
        ["Magic Atk. Bonus"]=20, 
        ["Attack"]=25
    }, 
    [669]={
        ["Evasion"]=36, 
        ["DEF"]=153, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=17, 
        ["PDT"]=-10, 
        ["MND"]=16, 
        ["en"]="Kubira Meikogai", 
        ["slots"]={
            [5]="Body"
        }, 
        ["item_level"]=119, 
        ["AGI"]=17, 
        ["HP"]=166, 
        ["id"]=26959, 
        ["discription"]="DEF:153 HP+166 MP+59 STR+29 DEX+17 VIT+32 AGI+17 INT+16 MND+16 CHR+16 Accuracy+25 Attack+25 Evasion+36 Magic Evasion+69 \"Magic Def. Bonus\"+4 Haste+3% Physical damage taken -10% Sphere: \"Double Attack\"+4%", 
        ["STR"]=29, 
        ["Haste"]=3, 
        ["MP"]=59, 
        ["Accuracy"]=25, 
        ["INT"]=16, 
        ["category"]="Armor", 
        ["CHR"]=16, 
        ["VIT"]=32, 
        ["Attack"]=25
    }, 
    [670]={
        ["Evasion"]=16, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["DEF"]=111, 
        ["MND"]=32, 
        ["discription"]="DEF:111 HP+30 MP+30 STR+23 DEX+34 VIT+45 INT+6 MND+32 CHR+27 Accuracy+43 Attack+47 Evasion+16 Magic Evasion+37 Haste+3% \"Double Attack\"+6% Damage taken -5% Set: Enhances \"Subtle Blow\" effect", 
        ["Set Bonus"]={
            ["set id"]=161, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }
        }, 
        ["item_level"]=119, 
        ["en"]="Sulev. Gauntlets +2", 
        ["HP"]=30, 
        ["id"]=25828, 
        ["DT"]=-5, 
        ["STR"]=23, 
        ["Haste"]=3, 
        ["MP"]=30, 
        ["Accuracy"]=43, 
        ["INT"]=6, 
        ["category"]="Armor", 
        ["CHR"]=27, 
        ["VIT"]=45, 
        ["Attack"]=47
    }, 
    [671]={
        ["discription"]="DEF:18 Attack-4 Evasion+4 Movement speed +18%", 
        ["category"]="Armor", 
        ["en"]="Fajin Boots", 
        ["Evasion"]=4, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG"
        }, 
        ["DEF"]=18, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=11460, 
        ["Attack"]=-4
    }, 
    [672]={
        ["discription"]="DEF:6 Accuracy+20 Attack+20 \"Double Attack\"+3% Pet: Accuracy+20 Attack+20 \"Double Attack\"+5%", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["category"]="Armor", 
        ["en"]="Shulmanu Collar", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=26026, 
        ["DEF"]=6, 
        ["Accuracy"]=20, 
        ["Attack"]=20
    }, 
    [673]={
        ["discription"]="DEF:13 \"Cure\" potency +6% Magic Damage+6 Sword enhancement spell damage +5", 
        ["category"]="Armor", 
        ["en"]="Ghostfyre Cape", 
        ["augments"]={
            [1]="Enfb.mag. skill +8", 
            [2]="Enha.mag. skill +8", 
            [3]="Mag. Acc.+8", 
            [4]="none", 
            [5]="none"
        }, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["DEF"]=13, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=28621, 
        ["Magic Accuracy"]=8
    }, 
    [674]={
        ["Evasion"]=16, 
        ["Set Bonus"]={
            ["set id"]=161, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["STR"]=47, 
        ["DEF"]=135, 
        ["MND"]=20, 
        ["item_level"]=119, 
        ["en"]="Sulev. Cuisses +2", 
        ["discription"]="DEF:135 HP+50 MP+50 STR+47 VIT+33 AGI+14 INT+24 MND+20 CHR+18 Accuracy+45 Attack+49 Evasion+16 Magic Evasion+75 \"Magic Def. Bonus\"+2 Haste+2% \"Triple Attack\"+4% Damage taken -7% Set: Enhances \"Subtle Blow\" effect", 
        ["AGI"]=14, 
        ["HP"]=50, 
        ["id"]=25879, 
        ["DT"]=-7, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=2, 
        ["MP"]=50, 
        ["Accuracy"]=45, 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["CHR"]=18, 
        ["VIT"]=33, 
        ["Attack"]=49
    }, 
    [675]={
        ["discription"]="DMG:65 Delay:286 AGI+6 +20 Throwing skill +242 Critical hit rate +2% Unity Ranking: DEX+1～5", 
        ["en"]="Wingcutter +1", 
        ["Throwing skill"]=242, 
        ["category"]="Weapon", 
        ["skill"]="Throwing", 
        ["item_level"]=119, 
        ["delay"]=286, 
        ["Unity Ranking Bonus Applied"]="DEX + 5", 
        ["slots"]={
            [2]="Range"
        }, 
        ["AGI"]=6, 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN"
        }, 
        ["id"]=21350, 
        ["DEX"]=5, 
        ["Critical hit rate"]=2, 
        ["damage"]=65
    }, 
    [676]={
        ["Evasion"]=44, 
        ["STR"]=29, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEX"]=19, 
        ["DEF"]=93, 
        ["MND"]=18, 
        ["item_level"]=119, 
        ["discription"]="DEF:93 HP+20 MP+20 STR+29 DEX+19 VIT+29 AGI+26 MND+18 CHR+32 Accuracy+42 Attack+46 Evasion+44 Magic Evasion+75 \"Magic Def. Bonus\"+1 Haste+1% Weapon skill damage +7% Damage taken -4% Set: Enhances \"Subtle Blow\" effect", 
        ["AGI"]=26, 
        ["en"]="Sulev. Leggings +2", 
        ["HP"]=20, 
        ["id"]=25946, 
        ["Set Bonus"]={
            ["set id"]=161, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }
        }, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=1, 
        ["MP"]=20, 
        ["Accuracy"]=42, 
        ["CHR"]=32, 
        ["VIT"]=29, 
        ["category"]="Armor", 
        ["DT"]=-4, 
        ["Attack"]=46
    }, 
    [677]={
        ["Evasion"]=72, 
        ["MND"]=12, 
        ["en"]="Pill. Poulaines +1", 
        ["jobs"]={
            [6]="THF"
        }, 
        ["Ranged Accuracy"]=13, 
        ["AGI"]=37, 
        ["Haste"]=4, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["HP"]=13, 
        ["DEX"]=24, 
        ["id"]=28249, 
        ["STR"]=12, 
        ["DEF"]=71, 
        ["item_level"]=119, 
        ["CHR"]=30, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["Accuracy"]=13, 
        ["discription"]="DEF:71 HP+13 STR+12 DEX+24 VIT+12 AGI+37 MND+12 CHR+30 Accuracy+13 Ranged Accuracy+13 Evasion+72 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+4% \"Steal\"+3 \"Flee\" duration +16 Movement speed +12%"
    }, 
    [678]={
        ["discription"]="DMG:128 Delay:240 Accuracy+10 Attack+10 \"Magic Atk. Bonus\"+14 Magic Damage+108 Sword skill +242 Parrying skill +242 Blue Magic skill +15 Magic Accuracy skill +201 \"Chain Affinity\"+25 Blue magic spellcasting time -7%", 
        ["id"]=20701, 
        ["Sword skill"]=242, 
        ["Blue Magic skill"]=30, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["en"]="Iris", 
        ["jobs"]={
            [16]="BLU"
        }, 
        ["delay"]=240, 
        ["Attack"]=10, 
        ["Accuracy"]=10, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["augments"]={
            [1]="Blue Magic skill +15", 
            [2]="Mag. Acc.+15", 
            [3]="\"Mag.Atk.Bns.\"+15"
        }, 
        ["Magic Atk. Bonus"]=29, 
        ["Parrying skill"]=242, 
        ["damage"]=128, 
        ["Magic Accuracy"]=15
    }, 
    [679]={
        ["discription"]="DEF:16 \"Sneak Attack\"+10 \"Triple Attack\" damage +20", 
        ["category"]="Armor", 
        ["Attack"]=20, 
        ["en"]="Toutatis's Cape", 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=16, 
        ["DEX"]=30, 
        ["Accuracy"]=20, 
        ["id"]=26251, 
        ["DT"]=-5
    }, 
    [680]={
        ["Evasion"]=49, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=32, 
        ["DEF"]=123, 
        ["MND"]=12, 
        ["en"]="Flam. Zucchetto +2", 
        ["Set Bonus"]={
            ["set id"]=218, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["STR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["STR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["STR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["STR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["Store TP"]=6, 
        ["AGI"]=16, 
        ["HP"]=80, 
        ["id"]=25569, 
        ["item_level"]=119, 
        ["STR"]=36, 
        ["Haste"]=4, 
        ["MP"]=20, 
        ["Accuracy"]=44, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["discription"]="DEF:123 HP+80 MP+20 STR+36 DEX+32 VIT+24 AGI+16 INT+12 MND+12 CHR+12 Accuracy+44 Magic Accuracy+44 Evasion+49 Magic Evasion+53 \"Magic Def. Bonus\"+3 Haste+4% \"Triple Attack\"+5% \"Store TP\"+6 Set: Increases Strength, Dexterity, and Vitality", 
        ["VIT"]=24, 
        ["Magic Accuracy"]=44
    }, 
    [681]={
        ["discription"]="HP+70 Accuracy+30 Attack+30 Weapon skill DEX +10%", 
        ["category"]="Weapon", 
        ["en"]="Utu Grip", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["HP"]=70, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [22]="RUN"
        }, 
        ["id"]=22212, 
        ["skill"]="(N/A)", 
        ["Accuracy"]=30, 
        ["Attack"]=30
    }, 
    [682]={
        ["Evasion"]=55, 
        ["MND"]=21, 
        ["Critical hit rate"]=4, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=42, 
        ["DEF"]=135, 
        ["AGI"]=28, 
        ["STR"]=25, 
        ["en"]="Enforcer's Harness", 
        ["HP"]=63, 
        ["discription"]="DEF:135 HP+63 STR+25 DEX+42 VIT+24 AGI+28 INT+21 MND+21 CHR+21 Evasion+55 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% Critical hit rate +4% Critical hit damage +5% Sphere: Critical hit rate +4%", 
        ["Critical hit damage"]=5, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=4, 
        ["id"]=26962, 
        ["INT"]=21, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["VIT"]=24, 
        ["item_level"]=119
    }, 
    [683]={
        ["discription"]="DEF:10 Accuracy+6 Attack+6 Damage taken -3% Set: Enhances \"Subtle Blow\" effect", 
        ["Set Bonus"]={
            ["set id"]=161, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Sulevia's Ring", 
        ["DT"]=-3, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEF"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=6, 
        ["id"]=26204, 
        ["Attack"]=6
    }, 
    [684]={
        ["discription"]="DMG:123 Delay:240 Accuracy+15 \"Magic Atk. Bonus\"+14 Magic Damage+130 Magic Accuracy skill +201 Sword skill +242 Parrying skill +242 \"Fast Cast\"+10% Physical damage taken -3%", 
        ["Sword skill"]=242, 
        ["PDT"]=-3, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["id"]=20702, 
        ["en"]="Emissary", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["delay"]=240, 
        ["Fast Cast"]=10, 
        ["Accuracy"]=15, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["augments"]={
            [1]="Mag. Acc.+15", 
            [2]="\"Mag.Atk.Bns.\"+20", 
            [3]="\"Refresh\"+1"
        }, 
        ["Magic Atk. Bonus"]=34, 
        ["Parrying skill"]=242, 
        ["damage"]=123, 
        ["Magic Accuracy"]=15
    }, 
    [685]={
        ["discription"]="DMG:71 Delay:252 HP+40 MP+40 +16 +16 Ranged Accuracy+21 Ranged Attack+21 Throwing skill +242 Unity Ranking: \"Double Attack\"+1～3%", 
        ["Ranged Accuracy"]=21, 
        ["Throwing skill"]=242, 
        ["category"]="Weapon", 
        ["skill"]="Throwing", 
        ["en"]="Antitail +1", 
        ["HP"]=40, 
        ["delay"]=252, 
        ["slots"]={
            [2]="Range"
        }, 
        ["Ranged Attack"]=21, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [11]="RNG"
        }, 
        ["MP"]=40, 
        ["item_level"]=119, 
        ["id"]=22267, 
        ["damage"]=71
    }, 
    [686]={
        ["Katana skill"]=7, 
        ["Ranged Accuracy"]=17, 
        ["Set Bonus"]={
            ["set id"]=278, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Haste"]=8
                }, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }, 
        ["Marksmanship skill"]=7, 
        ["Dual Wield"]=3, 
        ["Sword skill"]=7, 
        ["en"]="Mextli Harness", 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=57, 
        ["discription"]="DEF:57 Accuracy+17 Ranged Accuracy+17 Sword skill +7 Katana skill +7 Marksmanship skill +7 Enhances \"Dual Wield\" effect Sphere: Critical hit rate +3% Set: Haste+8%", 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=11855, 
        ["Critical hit rate"]=3, 
        ["Accuracy"]=17, 
        ["Haste"]=8
    }, 
    [687]={
        ["discription"]="DEF:18 All Jumps: \"Double Attack\"+20% Wyvern: \"Breath\" attacks +15", 
        ["category"]="Armor", 
        ["en"]="Brigantia's Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="STR+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="STR+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=18, 
        ["STR"]=30, 
        ["Accuracy"]=20, 
        ["id"]=26259, 
        ["Attack"]=20
    }, 
    [688]={
        ["discription"]="DEF:2 Enchantment: Teleport (the place of parting)", 
        ["DEF"]=2, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Cumulus Masque +1", 
        ["id"]=10385, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [689]={
        ["discription"]="Critical hit rate +3% Magic critical hit rate +3% Increases magic critical hit damage", 
        ["en"]="Nefarious Collar", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Critical hit rate"]=3, 
        ["id"]=10958, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [690]={
        ["discription"]="Accuracy+3 \"Double Attack\"+3%", 
        ["category"]="Armor", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=10944, 
        ["en"]="Portus Collar", 
        ["Accuracy"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [691]={
        ["discription"]="INT+8 MND+8 Magic Accuracy+10 \"Magic Atk. Bonus\"+8 \"Fast Cast\"+4%", 
        ["category"]="Armor", 
        ["en"]="Malignance Earring", 
        ["Magic Atk. Bonus"]=8, 
        ["Fast Cast"]=4, 
        ["MND"]=8, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [8]="DRK", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["INT"]=8, 
        ["id"]=26088, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Magic Accuracy"]=10
    }, 
    [692]={
        ["slots"]={
            [15]="Back"
        }, 
        ["STR"]=5, 
        ["MND"]=5, 
        ["INT"]=5, 
        ["category"]="Armor", 
        ["Magic Atk. Bonus"]=15, 
        ["en"]="Cornflower Cape", 
        ["jobs"]={
            [16]="BLU"
        }, 
        ["Blue Magic skill"]=10, 
        ["DEF"]=16, 
        ["discription"]="DEF:16 STR+5 INT+5 MND+5 Magic Accuracy+15 \"Magic Atk. Bonus\"+15 Blue magic skill +5", 
        ["DEX"]=5, 
        ["id"]=28632, 
        ["augments"]={
            [1]="MP+20", 
            [2]="DEX+5", 
            [3]="Blue Magic skill +10", 
            [4]="none", 
            [5]="none"
        }, 
        ["MP"]=20, 
        ["Magic Accuracy"]=15
    }, 
    [693]={
        ["MDT"]=-3, 
        ["DEF"]=116, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=26, 
        ["Evasion"]=36, 
        ["MND"]=14, 
        ["AGI"]=17, 
        ["STR"]=24, 
        ["augments"]={
            [1]="DEX+6", 
            [2]="Accuracy+10", 
            [3]="Magic dmg. taken -3%", 
            [4]="none", 
            [5]="none"
        }, 
        ["en"]="Founder's Corona", 
        ["HP"]=47, 
        ["id"]=27764, 
        ["item_level"]=119, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Haste"]=7, 
        ["discription"]="DEF:116 HP+47 STR+24 DEX+20 VIT+23 AGI+17 INT+14 MND+14 CHR+14 Resist all elements +25 Accuracy+20 Magic Accuracy+20 Evasion+36 Magic Evasion+48 \"Magic Def. Bonus\"+2 Haste+7% \"Double Attack\"+2% \"Killer\" effects +2", 
        ["Accuracy"]=30, 
        ["INT"]=14, 
        ["category"]="Armor", 
        ["CHR"]=14, 
        ["VIT"]=23, 
        ["Magic Accuracy"]=20
    }, 
    [694]={
        ["discription"]="DEF:67 STR+14 Attack+14 Great Sword skill +7 Polearm skill +7 Shield skill +7 Haste+2% Sphere: \"Store TP\"+6 Set: \"Double Attack\"+5%", 
        ["Haste"]=2, 
        ["Set Bonus"]={
            ["set id"]=398, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Double Attack"]=5
                }, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }, 
        ["category"]="Armor", 
        ["Store TP"]=6, 
        ["en"]="Fazheluo R. Mail", 
        ["Great Sword skill"]=7, 
        ["Shield skill"]=7, 
        ["STR"]=14, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["Polearm skill"]=7, 
        ["DEF"]=67, 
        ["id"]=11857, 
        ["Attack"]=14
    }, 
    [695]={
        ["Evasion"]=74, 
        ["STR"]=31, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["DEF"]=93, 
        ["MND"]=6, 
        ["en"]="Flam. Gambieras +2", 
        ["Set Bonus"]={
            ["set id"]=218, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["STR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["STR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["STR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["STR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["Store TP"]=6, 
        ["AGI"]=26, 
        ["HP"]=40, 
        ["id"]=25953, 
        ["discription"]="DEF:93 HP+40 MP+10 STR+31 DEX+34 VIT+20 AGI+26 MND+6 CHR+20 Accuracy+42 Magic Accuracy+42 Evasion+74 Magic Evasion+86 \"Magic Def. Bonus\"+5 Haste+2% \"Double Attack\"+6% \"Store TP\"+6 Set: Increases Strength, Dexterity, and Vitality", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=2, 
        ["MP"]=10, 
        ["Accuracy"]=42, 
        ["CHR"]=20, 
        ["VIT"]=20, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["Magic Accuracy"]=42
    }, 
    [696]={
        ["discription"]="DEF:18 All Jumps: \"Double Attack\"+20% Wyvern: \"Breath\" attacks +15", 
        ["category"]="Armor", 
        ["en"]="Brigantia's Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="none"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=18, 
        ["DEX"]=30, 
        ["Accuracy"]=20, 
        ["id"]=26259, 
        ["Attack"]=20
    }, 
    [697]={
        ["INT"]=9, 
        ["en"]="Shiva Ring +1", 
        ["Magic Atk. Bonus"]=3, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="INT+9 +16 \"Magic Atk. Bonus\"+3", 
        ["id"]=27575, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [698]={
        ["discription"]="Accuracy+20 Attack+20 Critical hit rate +3% Wyvern: Lv.+1", 
        ["category"]="Armor", 
        ["en"]="Dgn. Collar +1", 
        ["id"]=25496, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["Critical hit rate"]=3, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=20, 
        ["Attack"]=20
    }, 
    [699]={
        ["discription"]="\"Double Attack\"+3%", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["id"]=18820, 
        ["en"]="Duplus Grip", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [700]={
        ["Ranged Attack"]=15, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=114, 
        ["VIT"]=16, 
        ["MND"]=15, 
        ["id"]=25842, 
        ["discription"]="DEF:114 HP+38 STR+33 VIT+16 AGI+32 INT+29 MND+15 CHR+10 Attack+15 Ranged Attack+15 Evasion+62 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% Enmity-4 \"Store TP\"+4 Physical damage taken -2%", 
        ["Store TP"]=4, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["augments"]={
            [1]="Accuracy+17", 
            [2]="Weapon skill damage +5%", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["en"]="Herculean Trousers", 
        ["INT"]=29, 
        ["STR"]=33, 
        ["Haste"]=6, 
        ["Accuracy"]=17, 
        ["CHR"]=10, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["AGI"]=32, 
        ["Evasion"]=62, 
        ["Attack"]=15
    }, 
    [701]={
        ["discription"]="DMG:130 Delay:240 Accuracy+15 Magic Accuracy+15 Magic Damage+96 Sword skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Chain Affinity\"+10 \"Skillchain Bonus\"+10", 
        ["Parrying skill"]=242, 
        ["skill"]="Sword", 
        ["category"]="Weapon", 
        ["Sword skill"]=242, 
        ["en"]="Acclimator", 
        ["delay"]=240, 
        ["item_level"]=119, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=15, 
        ["jobs"]={
            [5]="RDM", 
            [7]="PLD", 
            [16]="BLU"
        }, 
        ["id"]=20715, 
        ["damage"]=130, 
        ["Magic Accuracy"]=15
    }, 
    [702]={
        ["discription"]="Damage taken -5%", 
        ["en"]="Twilight Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=11625, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["DT"]=-5
    }, 
    [703]={
        ["discription"]="HP+60 MP+60 Accuracy+7 Magic Accuracy+7 ", 
        ["category"]="Armor", 
        ["en"]="Etana Ring", 
        ["Accuracy"]=7, 
        ["HP"]=60, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26163, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=60, 
        ["Magic Accuracy"]=7
    }, 
    [704]={
        ["discription"]="DEF:8 Accuracy+6 Magic Accuracy+6 \"Store TP\"+5 Set: Increases Strength, Dexterity, and Vitality", 
        ["Set Bonus"]={
            ["set id"]=218, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["STR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["STR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["STR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["STR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Flamma Ring", 
        ["Store TP"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=6, 
        ["id"]=26211, 
        ["Magic Accuracy"]=6
    }, 
    [705]={
        ["discription"]="DMG:145 Delay:240 STR+15 AGI+15 \"Magic Atk. Bonus\"+14 Magic Damage+108 Sword skill +242 Parrying skill +242 Magic Accuracy skill +201 \"Double Attack\"+2% \"Dual Wield\"+3 Critical hit rate +2%", 
        ["skill"]="Sword", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Sword skill"]=242, 
        ["Dual Wield"]=3, 
        ["Critical hit rate"]=2, 
        ["en"]="Deacon Saber", 
        ["delay"]=240, 
        ["jobs"]={
            [5]="RDM", 
            [16]="BLU"
        }, 
        ["id"]=20703, 
        ["category"]="Weapon", 
        ["STR"]=15, 
        ["AGI"]=15, 
        ["Magic Atk. Bonus"]=14, 
        ["Parrying skill"]=242, 
        ["damage"]=145, 
        ["item_level"]=119
    }, 
    [706]={
        ["Evasion"]=47, 
        ["MND"]=30, 
        ["DEF"]=106, 
        ["jobs"]={
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=40, 
        ["Ranged Accuracy"]=45, 
        ["item_level"]=119, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Regal Gloves", 
        ["HP"]=342, 
        ["discription"]="DEF:106 HP+342 STR+30 DEX+40 VIT+30 AGI+20 INT+30 MND+30 CHR+40 Accuracy+45 Ranged Accuracy+45 Evasion+47 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+4% Converts damage taken to TP +20 Damage taken +20%", 
        ["Accuracy"]=45, 
        ["INT"]=30, 
        ["STR"]=30, 
        ["Haste"]=4, 
        ["id"]=25826, 
        ["CHR"]=40, 
        ["VIT"]=30, 
        ["category"]="Armor", 
        ["AGI"]=20, 
        ["DT"]=20
    }, 
    [707]={
        ["discription"]="Critical hit rate +1% \"Triple Attack\"+2% \"Triple Attack\" damage +5", 
        ["en"]="Hetairoi Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Critical hit rate"]=1, 
        ["id"]=26175, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [708]={
        ["damage"]=82, 
        ["discription"]="DMG:82 Delay:142 +20 Evasion+22 Magic Accuracy+21 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Triple Attack\"+3% Additional effect: Wind damage Unity Ranking: AGI+10～15", 
        ["Evasion"]=22, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["en"]="Jugo Kukri +1", 
        ["item_level"]=119, 
        ["delay"]=142, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["Dagger skill"]=242, 
        ["Parrying skill"]=242, 
        ["skill"]="Dagger", 
        ["AGI"]=15, 
        ["id"]=20609, 
        ["Unity Ranking Bonus Applied"]="AGI + 15", 
        ["Magic Accuracy"]=21
    }, 
    [709]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [22]="RUN"
        }, 
        ["en"]="Knobkierrie", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="Attack+23 Weapon skill damage +6%", 
        ["id"]=22281, 
        ["Attack"]=23
    }, 
    [710]={
        ["INT"]=9, 
        ["en"]="Shiva Ring +1", 
        ["Magic Atk. Bonus"]=3, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="INT+9 +16 \"Magic Atk. Bonus\"+3", 
        ["id"]=27575, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [711]={
        ["Evasion"]=39, 
        ["MND"]=28, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Perfect Dodge\" effect", 
            [4]="none"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEX"]=33, 
        ["DEF"]=90, 
        ["AGI"]=3, 
        ["STR"]=9, 
        ["en"]="Plun. Armlets +1", 
        ["HP"]=25, 
        ["discription"]="DEF:90 HP+25 STR+9 DEX+33 VIT+30 AGI+3 INT+10 MND+28 CHR+24 Accuracy+15 Evasion+39 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+5% Enmity+6 \"Treasure Hunter\"+3", 
        ["Accuracy"]=15, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=5, 
        ["id"]=26987, 
        ["INT"]=10, 
        ["category"]="Armor", 
        ["CHR"]=24, 
        ["VIT"]=30, 
        ["item_level"]=119
    }, 
    [712]={
        ["discription"]="Accuracy-10 Attack+10 \"Double Attack\"+2%", 
        ["category"]="Weapon", 
        ["en"]="Focal Orb", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=21345, 
        ["skill"]="(N/A)", 
        ["Accuracy"]=-10, 
        ["Attack"]=10
    }, 
    [713]={
        ["Evasion"]=12, 
        ["Set Bonus"]={
            ["set id"]=281, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Counter"]=4
                }, 
                [3]={
                    ["Counter"]=8
                }, 
                [4]={
                    ["Counter"]=12
                }, 
                [5]={
                    ["Counter"]=16
                }
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Hizamaru Ring", 
        ["Store TP"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=6, 
        ["id"]=26206, 
        ["discription"]="DEF:8 Accuracy+6 Evasion+12 \"Store TP\"+5 Set: Enhances \"Counter\" effect"
    }, 
    [714]={
        ["discription"]="DEF:11 Divine magic skill +10 Healing magic skill +10 Magic Evasion+20 \"Magic Def. Bonus\"+3", 
        ["DEF"]=11, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Asklepian Belt", 
        ["id"]=26327, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [14]="DRG"
        }
    }, 
    [715]={
        ["Evasion"]=22, 
        ["augments"]={
            [1]="Accuracy+50", 
            [2]="Crit. hit rate+5%", 
            [3]="\"Triple Atk.\"+3"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=20618, 
        ["en"]="Sandung", 
        ["item_level"]=119, 
        ["AGI"]=10, 
        ["delay"]=200, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["Critical hit rate"]=5, 
        ["category"]="Weapon", 
        ["skill"]="Dagger", 
        ["Dagger skill"]=242, 
        ["damage"]=102, 
        ["Accuracy"]=50, 
        ["Parrying skill"]=242, 
        ["discription"]="DMG:102 Delay:200 AGI+10 Evasion+22 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Enmity-10 \"Treasure Hunter\"+1 Weapon skill damage +5"
    }, 
    [716]={
        ["discription"]="DMG:333 Delay:480 DEX+20 INT+20 MND+20 Accuracy+40 Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+21 Magic Damage+226 Polearm skill +250 Parrying skill +250 Magic Accuracy skill +250 \"Impulse Drive\" \"Impulse Drive\" damage +40% Weapon Skill: Increases critical hit rate based on amount of TP consumed", 
        ["MND"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=20, 
        ["Magic Accuracy"]=40, 
        ["en"]="Shining One", 
        ["slots"]={
            [0]="Main"
        }, 
        ["item_level"]=119, 
        ["delay"]=480, 
        ["id"]=21883, 
        ["Parrying skill"]=250, 
        ["skill"]="Polearm", 
        ["Polearm skill"]=250, 
        ["Accuracy"]=40, 
        ["INT"]=20, 
        ["Magic Atk. Bonus"]=21, 
        ["category"]="Weapon", 
        ["damage"]=333, 
        ["Attack"]=30
    }, 
    [717]={
        ["discription"]="Latent effect: Fishing skill +1", 
        ["en"]="Trainee's Specs.", 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=11499, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [718]={
        ["discription"]="STR+10 DEX+10 VIT+10 \"Quad Attack\"+3% \"Subtle Blow II\"+5", 
        ["en"]="Niqmaddu Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["STR"]=10, 
        ["category"]="Armor", 
        ["DEX"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [18]="PUP", 
            [22]="RUN"
        }, 
        ["id"]=26185, 
        ["VIT"]=10
    }, 
    [719]={
        ["INT"]=10, 
        ["en"]="Freke Ring", 
        ["Magic Atk. Bonus"]=8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="INT+10 \"Magic Atk. Bonus\"+8 Spell interruption rate down 10%", 
        ["id"]=28472, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [720]={
        ["discription"]="DEF:73 HP+15 STR+12 DEX+24 VIT+12 AGI+44 MND+12 CHR+30 Evasion+107 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+4% \"Treasure Hunter\"+3 \"Despoil\" effect +6 Set: Augments \"Triple Attack\"", 
        ["MND"]=12, 
        ["AGI"]=44, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["Haste"]=4, 
        ["en"]="Skulk. Poulaines +1", 
        ["STR"]=12, 
        ["item_level"]=119, 
        ["HP"]=15, 
        ["DEX"]=24, 
        ["id"]=27422, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=73, 
        ["Evasion"]=107, 
        ["CHR"]=30, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=65, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }
        }
    }, 
    [721]={
        ["Evasion"]=44, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=26, 
        ["Haste"]=3, 
        ["MND"]=21, 
        ["augments"]={
            [1]="Accuracy+14", 
            [2]="Mag. Acc.+13", 
            [3]="Attack+14", 
            [4]="\"Mag.Atk.Bns.\"+14", 
            [5]="none"
        }, 
        ["discription"]="DEF:146 HP+70 STR+30 DEX+26 VIT+30 AGI+21 INT+21 MND+21 CHR+21 Accuracy+20 Attack+20 Magic Accuracy+20 Evasion+44 Magic Evasion+59 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+4 Haste+3% \"Double Attack\"+3% Augments \"Killer\" effects Annuls damage taken +2%", 
        ["AGI"]=21, 
        ["item_level"]=119, 
        ["HP"]=70, 
        ["id"]=27910, 
        ["en"]="Found. Breastplate", 
        ["INT"]=21, 
        ["STR"]=30, 
        ["DEF"]=146, 
        ["Accuracy"]=34, 
        ["CHR"]=21, 
        ["Magic Atk. Bonus"]=34, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=33, 
        ["VIT"]=30, 
        ["Attack"]=34
    }, 
    [722]={
        ["discription"]="DEF:2 \"Treasure Hunter\"+1 Enchantment: Reraise", 
        ["DEF"]=2, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Wh. Rarab Cap +1", 
        ["id"]=25679, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [723]={
        ["Evasion"]=10, 
        ["category"]="Weapon", 
        ["en"]="Amar Cluster", 
        ["discription"]="STR+2 Accuracy+10 Evasion+10 \"Counter\"+2", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22262, 
        ["skill"]="(N/A)", 
        ["Accuracy"]=10, 
        ["STR"]=2
    }, 
    [724]={
        ["discription"]="DEF:1", 
        ["CHR"]=1, 
        ["category"]="Armor", 
        ["en"]="Mecisto. Mantle", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=6, 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="Cap. Point+50%", 
            [2]="CHR+1", 
            [3]="DEF+5", 
            [4]="none", 
            [5]="none"
        }, 
        ["id"]=27596
    }, 
    [725]={
        ["Evasion"]=44, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [14]="DRG"
        }, 
        ["DEX"]=29, 
        ["DEF"]=147, 
        ["MND"]=24, 
        ["augments"]={
            [1]="HP+50", 
            [2]="STR+10", 
            [3]="Attack+15"
        }, 
        ["discription"]="DEF:147 HP+63 MP+29 STR+28 DEX+29 VIT+24 AGI+29 INT+25 MND+24 CHR+24 Accuracy+27 Attack+27 Evasion+44 Magic Evasion+53 \"Magic Def. Bonus\"+4 Haste+3% \"Double Attack\"+4% Pet: \"Magic Atk. Bonus\"+25 Damage taken -3%", 
        ["en"]="Emicho Haubert", 
        ["AGI"]=29, 
        ["HP"]=113, 
        ["id"]=25682, 
        ["item_level"]=119, 
        ["STR"]=38, 
        ["Haste"]=3, 
        ["MP"]=29, 
        ["Accuracy"]=27, 
        ["INT"]=25, 
        ["category"]="Armor", 
        ["CHR"]=24, 
        ["VIT"]=24, 
        ["Attack"]=42
    }, 
    [726]={
        ["discription"]="DEX+8 Accuracy+10 \"Double Attack\"+2% \"Martial Arts\"+13", 
        ["category"]="Armor", 
        ["en"]="Mache Earring +1", 
        ["Martial Arts"]=13, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26081, 
        ["DEX"]=8, 
        ["Accuracy"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }
    }, 
    [727]={
        ["Evasion"]=36, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [14]="DRG"
        }, 
        ["DEX"]=17, 
        ["DEF"]=153, 
        ["MND"]=16, 
        ["augments"]={
            [1]="HP+50", 
            [2]="Attack+15", 
            [3]="Enmity+9", 
            [4]="\"Refresh\"+2", 
            [5]="none"
        }, 
        ["discription"]="DEF:153 HP+66 MP+59 STR+29 DEX+17 VIT+32 AGI+17 INT+16 MND+16 CHR+16 Attack+20 Evasion+36 Magic Evasion+69 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+4 Haste+3% \"Cure\" potency +15% \"Cure\" spellcasting time -10% Damage taken -8%", 
        ["item_level"]=119, 
        ["en"]="Jumalik Mail", 
        ["HP"]=116, 
        ["id"]=26972, 
        ["DT"]=-8, 
        ["STR"]=29, 
        ["Haste"]=3, 
        ["MP"]=59, 
        ["AGI"]=17, 
        ["INT"]=16, 
        ["category"]="Armor", 
        ["CHR"]=16, 
        ["VIT"]=32, 
        ["Magic Atk. Bonus"]=20, 
        ["Attack"]=35
    }, 
    [728]={
        ["discription"]="DEX+8 Accuracy+10 \"Double Attack\"+2% \"Martial Arts\"+13", 
        ["category"]="Armor", 
        ["en"]="Mache Earring +1", 
        ["Martial Arts"]=13, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26081, 
        ["DEX"]=8, 
        ["Accuracy"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }
    }, 
    [729]={
        ["category"]="Armor", 
        ["en"]="Chirich Ring +1", 
        ["Store TP"]=6, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=10, 
        ["discription"]="Accuracy+10 \"Store TP\"+6 \"Subtle Blow\"+10 \"Regen\"+2", 
        ["id"]=26182, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [730]={
        ["Evasion"]=24, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["Haste"]=4, 
        ["MND"]=25, 
        ["augments"]={
            [1]="STR+6", 
            [2]="Attack+10", 
            [3]="Phys. dmg. taken -3%", 
            [4]="none", 
            [5]="none"
        }, 
        ["discription"]="DEF:102 HP+31 STR+11 DEX+34 VIT+34 AGI+10 INT+8 MND+25 CHR+19 Attack+20 Evasion+24 Magic Evasion+32 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+1 Haste+4% \"Double Attack\"+2% \"Counter\"+3 \"Killer\" effects +2", 
        ["en"]="Founder's Gauntlets", 
        ["item_level"]=119, 
        ["HP"]=31, 
        ["id"]=28049, 
        ["AGI"]=10, 
        ["INT"]=8, 
        ["STR"]=17, 
        ["DEF"]=102, 
        ["VIT"]=34, 
        ["CHR"]=19, 
        ["Magic Atk. Bonus"]=20, 
        ["category"]="Armor", 
        ["PDT"]=-3, 
        ["Attack"]=30
    }, 
    [731]={
        ["Evasion"]=24, 
        ["MND"]=17, 
        ["STR"]=40, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEF"]=127, 
        ["discription"]="DEF:127 HP+54 STR+40 VIT+28 AGI+17 INT+25 MND+15 CHR+12 Attack+20 Magic Accuracy+20 Evasion+24 Magic Evasion+80 \"Magic Def. Bonus\"+3 Haste+5% \"Double Attack\"+2% Spell interruption rate down 30% \"Killer\" effects +2", 
        ["item_level"]=119, 
        ["en"]="Founder's Hose", 
        ["BDT"]=-1, 
        ["HP"]=54, 
        ["id"]=28191, 
        ["AGI"]=17, 
        ["INT"]=25, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=5, 
        ["augments"]={
            [1]="MND+2", 
            [2]="Mag. Acc.+4", 
            [3]="Breath dmg. taken -1%", 
            [4]="none", 
            [5]="none"
        }, 
        ["CHR"]=12, 
        ["VIT"]=28, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=24, 
        ["Attack"]=20
    }, 
    [732]={
        ["Evasion"]=65, 
        ["MND"]=7, 
        ["augments"]={
            [1]="VIT+7", 
            [2]="Accuracy+10", 
            [3]="\"Mag.Atk.Bns.\"+9", 
            [4]="Mag. Evasion+10", 
            [5]="none"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=21, 
        ["Haste"]=3, 
        ["AGI"]=28, 
        ["STR"]=19, 
        ["en"]="Founder's Greaves", 
        ["HP"]=20, 
        ["discription"]="DEF:84 HP+20 STR+19 DEX+21 VIT+19 AGI+28 MND+7 CHR+21 Accuracy+20 Evasion+55 Magic Evasion+80 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+2 Haste+3% \"Double Attack\"+2% Terror resistance +50 \"Killer\" effects +2", 
        ["Accuracy"]=30, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=84, 
        ["id"]=28330, 
        ["CHR"]=21, 
        ["Magic Atk. Bonus"]=29, 
        ["category"]="Armor", 
        ["VIT"]=26, 
        ["item_level"]=119
    }, 
    [733]={
        ["Evasion"]=85, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEX"]=23, 
        ["DEF"]=85, 
        ["MND"]=23, 
        ["en"]="Volte Boots", 
        ["Ranged Accuracy"]=37, 
        ["item_level"]=119, 
        ["AGI"]=23, 
        ["HP"]=57, 
        ["id"]=23729, 
        ["discription"]="DEF:85 HP+57 MP+59 STR+23 DEX+23 VIT+23 AGI+23 INT+23 MND+23 CHR+23 Accuracy+37 Ranged Accuracy+37 Magic Accuracy+37 Evasion+85 Magic Evasion+102 \"Magic Def. Bonus\"+7 Haste+5% \"Treasure Hunter\"+1 Resistance to all status ailments +10", 
        ["STR"]=23, 
        ["Haste"]=5, 
        ["MP"]=59, 
        ["Accuracy"]=37, 
        ["INT"]=23, 
        ["category"]="Armor", 
        ["CHR"]=23, 
        ["VIT"]=23, 
        ["Magic Accuracy"]=37
    }, 
    [734]={
        ["category"]="Armor", 
        ["en"]="Chirich Ring +1", 
        ["Store TP"]=6, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=10, 
        ["discription"]="Accuracy+10 \"Store TP\"+6 \"Subtle Blow\"+10 \"Regen\"+2", 
        ["id"]=26182, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [735]={
        ["Evasion"]=27, 
        ["discription"]="DEF:122 HP+50 STR+30 VIT+17 AGI+17 INT+29 MND+16 CHR+16 Accuracy+35 Attack+35 Evasion+27 Magic Evasion+80 \"Magic Def. Bonus\"+4 Healing magic skill +18 Enhancing magic skill +18 Spell interruption rate down 20% Movement speed +18% Haste+6% Set: Increases Accuracy", 
        ["jobs"]={
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [11]="RNG", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["STR"]=30, 
        ["Haste"]=6, 
        ["MND"]=16, 
        ["Dual Wield"]=6, 
        ["augments"]={
            [1]="Accuracy+20", 
            [2]="Attack+12", 
            [3]="\"Dual Wield\"+6"
        }, 
        ["AGI"]=17, 
        ["en"]="Carmine Cuisses +1", 
        ["HP"]=50, 
        ["id"]=27207, 
        ["item_level"]=119, 
        ["INT"]=29, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=122, 
        ["Accuracy"]=55, 
        ["CHR"]=16, 
        ["VIT"]=17, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=51, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=20
                }, 
                [3]={
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=40
                }, 
                [5]={
                    ["Accuracy"]=50
                }
            }
        }, 
        ["Attack"]=47
    }, 
    [736]={
        ["discription"]="DEF:30 AGI+10 Evasion+5 Enhances \"Zanshin\" effect Set: Enhances \"Store TP\" effect", 
        ["Set Bonus"]={
            ["set id"]=86, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Store TP"]=5
                }, 
                [3]={
                    ["Store TP"]=10
                }, 
                [4]={
                    ["Store TP"]=15
                }, 
                [5]={}
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Hachiryu Sune-Ate", 
        ["AGI"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=30, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=11364, 
        ["Evasion"]=5
    }, 
    [737]={
        ["discription"]="DEF:26 DEX+10 Accuracy+5 Enhances \"Zanshin\" effect Set: Enhances \"Store TP\" effect", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["Set Bonus"]={
            ["set id"]=86, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Store TP"]=5
                }, 
                [3]={
                    ["Store TP"]=10
                }, 
                [4]={
                    ["Store TP"]=15
                }, 
                [5]={}
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Hachiryu Kote", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=15015, 
        ["DEF"]=26, 
        ["Accuracy"]=5, 
        ["DEX"]=10
    }, 
    [738]={
        ["discription"]="STR+5 DEX+5 \"Double Attack\"+5% \"Store TP\"+5 \"Subtle Blow II\"+5", 
        ["en"]="Sherida Earring", 
        ["Store TP"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["DEX"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [14]="DRG", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26084, 
        ["STR"]=5
    }, 
    [739]={
        ["discription"]="DEF:13 DEX+5 AGI+5 CHR+5 \"Treasure Hunter\"+1", 
        ["CHR"]=5, 
        ["category"]="Armor", 
        ["en"]="Chaac Belt", 
        ["AGI"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=13, 
        ["DEX"]=5, 
        ["id"]=28450, 
        ["slots"]={
            [10]="Waist"
        }
    }, 
    [740]={
        ["discription"]="DMG:125 Delay:180 DEX+15 INT+15 MND+15 Accuracy+40 Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+16 Magic Damage+217 Dagger skill +250 Parrying skill +250 Magic Accuracy skill +250 Main hand: \"Evisceration\" \"Evisceration\" damage +50% Increases critical hit rate based with lower TP.", 
        ["MND"]=15, 
        ["jobs"]={
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["DEX"]=15, 
        ["Magic Accuracy"]=40, 
        ["en"]="Tauret", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["delay"]=180, 
        ["Dagger skill"]=250, 
        ["Accuracy"]=40, 
        ["INT"]=15, 
        ["skill"]="Dagger", 
        ["id"]=21565, 
        ["category"]="Weapon", 
        ["damage"]=125, 
        ["Magic Atk. Bonus"]=16, 
        ["Parrying skill"]=250, 
        ["Attack"]=30
    }, 
    [741]={
        ["discription"]="DEF:25 HP+16 STR+4 +10 Enhances effect of wyvern's breath", 
        ["category"]="Armor", 
        ["en"]="Wyrm Armet", 
        ["HP"]=16, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=25, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15085, 
        ["STR"]=4
    }, 
    [742]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["id"]=26258, 
        ["AGI"]=20, 
        ["Evasion"]=15, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="AGI+20", 
            [2]="Eva.+20 /Mag. Eva.+20", 
            [3]="none", 
            [4]="\"Dual Wield\"+10", 
            [5]="Evasion+15"
        }, 
        ["DEF"]=16, 
        ["Dual Wield"]=10
    }, 
    [743]={
        ["discription"]="DEF:49 HP+24 Parrying skill +15 Enhances \"Resist Blind\" effect  Adds support job abilities to wyvern", 
        ["category"]="Armor", 
        ["en"]="Wyrm Mail", 
        ["HP"]=24, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=49, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=15100, 
        ["Parrying skill"]=15
    }, 
    [744]={
        ["discription"]="DEF:19 HP+16 AGI+3 Accuracy+5 Wyvern: Magic damage taken -5%", 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["category"]="Armor", 
        ["en"]="Wyrm Fng.Gnt.", 
        ["HP"]=16, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=15115, 
        ["DEF"]=19, 
        ["Accuracy"]=5, 
        ["AGI"]=3
    }, 
    [745]={
        ["discription"]="DEF:32 HP+13 DEX+5  Enhances \"High Jump\" effect Wyvern: Physical damage taken -5%", 
        ["category"]="Armor", 
        ["en"]="Wyrm Brais", 
        ["HP"]=13, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=32, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15130, 
        ["DEX"]=5
    }, 
    [746]={
        ["discription"]="Chocobo riding time +4", 
        ["en"]="Chocobo Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=10924, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [747]={
        ["Evasion"]=4, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Furia Harness", 
        ["discription"]="DEF:45 DEX+2 Accuracy+4 Evasion+4", 
        ["DEX"]=2, 
        ["id"]=12157, 
        ["DEF"]=45, 
        ["Accuracy"]=4, 
        ["slots"]={
            [5]="Body"
        }
    }, 
    [748]={
        ["discription"]="Enchantment: Warp", 
        ["en"]="Warp Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28540, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [749]={
        ["discription"]="DEF:16 HP+10 VIT+4 +10 Wyvern: HP recovered while healing +6", 
        ["category"]="Armor", 
        ["en"]="Wyrm Greaves", 
        ["HP"]=10, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15145, 
        ["VIT"]=4
    }, 
    [750]={
        ["discription"]="Enchantment: Teleport (Crag of Holla) Destination is close to the dimensional portal in La Theine Plateau.", 
        ["en"]="Dim. Ring (Holla)", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26176, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [751]={
        ["Evasion"]=44, 
        ["DEF"]=146, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=35, 
        ["VIT"]=29, 
        ["MND"]=20, 
        ["AGI"]=20, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Store TP"]=3, 
        ["item_level"]=119, 
        ["HP"]=61, 
        ["augments"]={
            [1]="Weapon skill damage +5%", 
            [2]="DEX+10", 
            [3]="Accuracy+15", 
            [4]="Attack+10", 
            [5]="none"
        }, 
        ["id"]=25717, 
        ["INT"]=20, 
        ["STR"]=29, 
        ["Haste"]=3, 
        ["Accuracy"]=35, 
        ["CHR"]=20, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["en"]="Valorous Mail", 
        ["discription"]="DEF:146 HP+61 STR+29 DEX+25 VIT+29 AGI+20 INT+20 MND+20 CHR+20 Accuracy+20 Evasion+44 Magic Evasion+59 \"Magic Def. Bonus\"+4 Haste+3% \"Store TP\"+3 \"Double Attack\"+2% Physical damage taken -2%", 
        ["Attack"]=10
    }, 
    [752]={
        ["discription"]="DMG:134 Delay:231 STR+12 MND+12 Accuracy+27 Ranged Accuracy+27 Magic Accuracy+15 \"Magic Atk. Bonus\"+14 Magic Damage+108 Sword skill +242 Parrying skill +242 Magic Accuracy skill +201 Critical hit rate +4%", 
        ["MND"]=12, 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["Ranged Accuracy"]=27, 
        ["en"]="Fettering Blade", 
        ["STR"]=12, 
        ["Critical hit rate"]=4, 
        ["delay"]=231, 
        ["Sword skill"]=242, 
        ["id"]=20698, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["Magic Atk. Bonus"]=14, 
        ["Parrying skill"]=242, 
        ["damage"]=134, 
        ["Accuracy"]=27, 
        ["Magic Accuracy"]=15
    }, 
    [753]={
        ["Evasion"]=36, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["DEF"]=116, 
        ["MND"]=14, 
        ["augments"]={
            [1]="Weapon skill damage +4%", 
            [2]="DEX+10", 
            [3]="Accuracy+15", 
            [4]="Attack+12", 
            [5]="none"
        }, 
        ["en"]="Valorous Mask", 
        ["AGI"]=18, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["id"]=25641, 
        ["discription"]="DEF:116 HP+38 STR+28 DEX+24 VIT+23 AGI+18 INT+14 MND+14 CHR+14 Accuracy+13 Evasion+36 Magic Evasion+48 \"Magic Def. Bonus\"+2 Haste+7% \"Regain\"+3 Critical hit rate +2%", 
        ["INT"]=14, 
        ["STR"]=28, 
        ["Haste"]=7, 
        ["Accuracy"]=28, 
        ["CHR"]=14, 
        ["VIT"]=23, 
        ["category"]="Armor", 
        ["Critical hit rate"]=2, 
        ["Attack"]=12
    }, 
    [754]={
        ["discription"]="DMG:243 Delay:600 Archery skill +242 Minuet: Ranged Attack+35 \"Conserve TP\"+5 \"Skillchain Bonus\"+5", 
        ["category"]="Weapon", 
        ["id"]=22118, 
        ["en"]="Venery Bow", 
        ["item_level"]=119, 
        ["delay"]=600, 
        ["slots"]={
            [2]="Range"
        }, 
        ["jobs"]={
            [11]="RNG"
        }, 
        ["Ranged Attack"]=35, 
        ["Archery skill"]=242, 
        ["skill"]="Archery", 
        ["damage"]=243
    }, 
    [755]={
        ["Evasion"]=24, 
        ["MND"]=24, 
        ["augments"]={
            [1]="Weapon skill damage +5%", 
            [2]="VIT+3", 
            [3]="Accuracy+2", 
            [4]="none", 
            [5]="none"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=33, 
        ["DEF"]=102, 
        ["item_level"]=119, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Valorous Mitts", 
        ["HP"]=22, 
        ["discription"]="DEF:102 HP+22 STR+13 DEX+33 VIT+33 AGI+8 INT+7 MND+24 CHR+17 Accuracy+10 Attack+10 Evasion+24 Magic Evasion+32 \"Magic Def. Bonus\"+1 Haste+4% \"Zanshin\"+10 \"Skillchain Bonus\"+5", 
        ["Accuracy"]=12, 
        ["INT"]=7, 
        ["STR"]=13, 
        ["Haste"]=4, 
        ["id"]=27139, 
        ["CHR"]=17, 
        ["VIT"]=36, 
        ["category"]="Armor", 
        ["AGI"]=8, 
        ["Attack"]=10
    }, 
    [756]={
        ["Evasion"]=24, 
        ["MND"]=14, 
        ["augments"]={
            [1]="Accuracy+21", 
            [2]="Weapon skill damage +4%", 
            [3]="VIT+2", 
            [4]="none", 
            [5]="none"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["VIT"]=28, 
        ["DEF"]=127, 
        ["AGI"]=16, 
        ["STR"]=39, 
        ["item_level"]=119, 
        ["HP"]=95, 
        ["discription"]="DEF:127 HP+95 STR+39 VIT+26 AGI+16 INT+24 MND+14 CHR+11 Attack+15 Evasion+24 Magic Evasion+80 \"Magic Def. Bonus\"+3 Haste+5% \"Double Attack\"+3% Physical damage taken -2%", 
        ["Accuracy"]=21, 
        ["INT"]=24, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=5, 
        ["id"]=25841, 
        ["CHR"]=11, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["en"]="Valor. Hose", 
        ["Attack"]=15
    }, 
    [757]={
        ["discription"]="MP+20 INT+10 MND+10 CHR+10 \"Magic Atk. Bonus\"+7 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["category"]="Armor", 
        ["CHR"]=10, 
        ["en"]="Regal Earring", 
        ["Magic Atk. Bonus"]=7, 
        ["MND"]=10, 
        ["INT"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["MP"]=20, 
        ["id"]=26085, 
        ["Set Bonus"]={
            ["set id"]={
                [1]=7, 
                [2]=8, 
                [3]=48, 
                [4]=49, 
                [5]=53, 
                [6]=89, 
                [7]=112
            }, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Magic Accuracy"]=15
                }, 
                [3]={
                    ["Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Magic Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Magic Accuracy"]=45
                }, 
                [5]={
                    ["Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Magic Accuracy"]=60
                }
            }
        }
    }, 
    [758]={
        ["Evasion"]=49, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=33, 
        ["DEF"]=133, 
        ["MND"]=27, 
        ["en"]="Mekosu. Harness", 
        ["Ranged Accuracy"]=20, 
        ["item_level"]=119, 
        ["AGI"]=32, 
        ["HP"]=59, 
        ["id"]=27856, 
        ["discription"]="DEF:133 HP+59 MP+44 STR+24 DEX+33 VIT+24 AGI+32 INT+27 MND+27 CHR+23 Accuracy+20 Rng. Acc.+20 Magic Accuracy+20 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+4% \"Refresh\"+2 Sphere: \"Refresh\"+1", 
        ["STR"]=24, 
        ["Haste"]=4, 
        ["MP"]=44, 
        ["Accuracy"]=20, 
        ["INT"]=27, 
        ["category"]="Armor", 
        ["CHR"]=23, 
        ["VIT"]=24, 
        ["Magic Accuracy"]=20
    }, 
    [759]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Patricius Ring", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=7, 
        ["discription"]="Accuracy+7 Physical damage taken -5%", 
        ["id"]=28578, 
        ["PDT"]=-5
    }, 
    [760]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["Fast Cast"]=10, 
        ["augments"]={
            [1]="INT+20", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="Mag. Acc.+10", 
            [4]="\"Fast Cast\"+10", 
            [5]="none"
        }, 
        ["INT"]=20, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=26258, 
        ["DEF"]=16, 
        ["Magic Accuracy"]=30
    }, 
    [761]={
        ["discription"]="DEF:16 \"Sneak Attack\"+10 \"Triple Attack\" damage +20", 
        ["category"]="Armor", 
        ["en"]="Toutatis's Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="none", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=16, 
        ["DEX"]=20, 
        ["Accuracy"]=20, 
        ["id"]=26251, 
        ["Attack"]=20
    }, 
    [762]={
        ["discription"]="DEF:30 STR+7 DEX+7 VIT+7  AGI+7 INT+7 MND+7 CHR+7 Elemental weapon skill damage increases depending on day Set: Increases rate of critical hits", 
        ["Set Bonus"]={
            ["set id"]=375, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=3
                }, 
                [3]={
                    ["Critical Hit Rate"]=4
                }, 
                [4]={
                    ["Critical Hit Rate"]=5
                }, 
                [5]={
                    ["Critical Hit Rate"]=6
                }
            }
        }, 
        ["MND"]=7, 
        ["category"]="Armor", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["AGI"]=7, 
        ["DEX"]=7, 
        ["INT"]=7, 
        ["STR"]=7, 
        ["en"]="Athos's Gloves", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["CHR"]=7, 
        ["DEF"]=30, 
        ["id"]=10501, 
        ["VIT"]=7
    }, 
    [763]={
        ["discription"]="DEF:13 MP+100 Summoning magic skill +8 Enhances \"Elemental Siphon\" effect", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["category"]="Armor", 
        ["en"]="Conveyance Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=28631, 
        ["DEF"]=13, 
        ["MP"]=100, 
        ["augments"]={
            [1]="Summoning magic skill +3", 
            [2]="Pet: Enmity+5", 
            [3]="Blood Pact Dmg.+2", 
            [4]="none", 
            [5]="none"
        }
    }, 
    [764]={
        ["Ranged Attack"]=20, 
        ["STR"]=10, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]={
                [1]=91, 
                [2]=9, 
                [3]=47, 
                [4]=87, 
                [5]=6, 
                [6]=46, 
                [7]=133, 
                [8]=45, 
                [9]=84, 
                [10]=129, 
                [11]=92, 
                [12]=10, 
                [13]=50, 
                [14]=88
            }
        }, 
        ["category"]="Armor", 
        ["DEX"]=10, 
        ["AGI"]=10, 
        ["HP"]=50, 
        ["en"]="Regal Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["VIT"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26191, 
        ["discription"]="HP+50 STR+10 DEX+10 VIT+10 AGI+10 Attack+20 Ranged Attack+20 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["Attack"]=20
    }, 
    [765]={
        ["id"]=26100, 
        ["en"]="Hnoss Earring", 
        ["DEF"]=20, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:20 Ninjutsu skill +10", 
        ["Ninjutsu skill"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [766]={
        ["Evasion"]=55, 
        ["MND"]=19, 
        ["DEF"]=66, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=11, 
        ["STR"]=10, 
        ["AGI"]=33, 
        ["discription"]="DEF:66 HP+13 MP+39 STR+10 DEX+11 VIT+10 AGI+33 INT+17 MND+19 CHR+34 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Healing magic skill +11 Enhancing magic skill +11 Haste+3% \"Fast Cast\"+4% Unity Ranking: \"Fast Cast\"+1～3%", 
        ["item_level"]=119, 
        ["HP"]=13, 
        ["Fast Cast"]=7, 
        ["VIT"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=3, 
        ["MP"]=39, 
        ["id"]=28274, 
        ["Unity Ranking Bonus Applied"]="Fast Cast + 3", 
        ["CHR"]=34, 
        ["INT"]=17, 
        ["category"]="Armor", 
        ["en"]="Regal Pumps +1"
    }, 
    [767]={
        ["discription"]="DEX+5 AGI+5 \"Store TP\"+5 \"Dual Wield\"+3 Critical hit rate +3%", 
        ["category"]="Armor", 
        ["en"]="Gerdr Belt", 
        ["Store TP"]=5, 
        ["Critical hit rate"]=3, 
        ["DEX"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["AGI"]=5, 
        ["id"]=26360, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["Dual Wield"]=3
    }, 
    [768]={
        ["discription"]="STR+5 DEX+5 CHR+5 Accuracy+10 Attack+10 Pet: Accuracy+15 Ranged Accuracy+15 Magic Accuracy+15", 
        ["category"]="Weapon", 
        ["STR"]=5, 
        ["en"]="Voluspa Tathlum", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["DEX"]=5, 
        ["CHR"]=5, 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Accuracy"]=10, 
        ["id"]=22296, 
        ["Attack"]=10
    }, 
    [769]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["augments"]={
            [1]="AGI+20", 
            [2]="Eva.+20 /Mag. Eva.+20", 
            [3]="Evasion+10", 
            [4]="\"Dual Wield\"+10", 
            [5]="Evasion+15"
        }, 
        ["Evasion"]=25, 
        ["Dual Wield"]=10, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=26258, 
        ["DEF"]=16, 
        ["AGI"]=20
    }, 
    [770]={
        ["discription"]="DEF:13 MP+100 Summoning magic skill +8 Enhances \"Elemental Siphon\" effect", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["category"]="Armor", 
        ["en"]="Conveyance Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=28631, 
        ["DEF"]=13, 
        ["MP"]=100, 
        ["augments"]={
            [1]="Summoning magic skill +5", 
            [2]="Pet: Enmity+13", 
            [3]="Blood Pact Dmg.+5", 
            [4]="none", 
            [5]="none"
        }
    }, 
    [771]={
        ["discription"]="DEF:15 Enfeebling magic effect +10 Enhancing magic effect duration +20%", 
        ["DEF"]=15, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Sucellos's Cape", 
        ["id"]=26250, 
        ["category"]="Armor", 
        ["jobs"]={
            [5]="RDM"
        }
    }, 
    [772]={
        ["discription"]="DMG:166 Delay:240 DEX+15 INT+15 MND+15 Accuracy+40 Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+16 Magic Damage+217 Sword skill +250 Parrying skill +250 Magic Accuracy skill +250 Main hand: \"Savage Blade\" \"Savage Blade\" damage +15% Weapon Skill: Attack Bonus based on the number of upgrades", 
        ["MND"]=15, 
        ["Attack"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["Magic Atk. Bonus"]=16, 
        ["en"]="Naegling", 
        ["skill"]="Sword", 
        ["item_level"]=119, 
        ["delay"]=240, 
        ["DEX"]=15, 
        ["Accuracy"]=40, 
        ["INT"]=15, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=21621, 
        ["category"]="Weapon", 
        ["damage"]=166, 
        ["Sword skill"]=250, 
        ["Parrying skill"]=250, 
        ["Magic Accuracy"]=40
    }, 
    [773]={
        ["discription"]="DEF:16 Monster correlation effects +10 \"Efflux\" TP bonus +250", 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Rosmerta's Cape", 
        ["id"]=26261, 
        ["category"]="Armor", 
        ["jobs"]={
            [16]="BLU"
        }
    }, 
    [774]={
        ["discription"]="Accuracy+15 Magic Accuracy+15 Blue magic skill +10", 
        ["category"]="Armor", 
        ["en"]="Mirage Stole", 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["jobs"]={
            [16]="BLU"
        }, 
        ["id"]=25507, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=15, 
        ["Magic Accuracy"]=15
    }, 
    [775]={
        ["discription"]="CHR+5 Magic Accuracy+6 \"Fast Cast\"+2%", 
        ["category"]="Armor", 
        ["en"]="Enchntr. Earring +1", 
        ["Fast Cast"]=2, 
        ["CHR"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=28494, 
        ["Magic Accuracy"]=6
    }, 
    [776]={
        ["discription"]="DMG:122 Delay:227 Katana skill +215 Parrying skill +215 Magic Accuracy skill +215", 
        ["category"]="Weapon", 
        ["Katana skill"]=215, 
        ["en"]="Tokko Katana", 
        ["Parrying skill"]=215, 
        ["delay"]=227, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["item_level"]=119, 
        ["id"]=21918, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=122
    }, 
    [777]={
        ["Evasion"]=74, 
        ["MND"]=20, 
        ["DEF"]=71, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=30, 
        ["Ranged Accuracy"]=20, 
        ["en"]="Heidrek Boots", 
        ["STR"]=20, 
        ["item_level"]=119, 
        ["HP"]=22, 
        ["discription"]="DEF:71 HP+22 STR+14 DEX+25 VIT+14 AGI+38 MND+14 CHR+32 Accuracy+20 Ranged Accuracy+20 Magic Accuracy+20 Evasion+74 Magic Evasion+96 \"Magic Def. Bonus\"+5 Haste+4% Domain Invasion: STR+20 DEX+30 VIT+20 AGI+30 INT+20 MND+20 CHR+30 Weapon skill damage +50% Trust: Lv.+1", 
        ["Accuracy"]=20, 
        ["INT"]=20, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=4, 
        ["id"]=23751, 
        ["CHR"]=30, 
        ["VIT"]=20, 
        ["category"]="Armor", 
        ["AGI"]=30, 
        ["Magic Accuracy"]=20
    }, 
    [778]={
        ["Evasion"]=60, 
        ["STR"]=20, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=30, 
        ["Haste"]=8, 
        ["MND"]=20, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=20, 
        ["Fast Cast"]=50, 
        ["AGI"]=30, 
        ["HP"]=45, 
        ["id"]=23739, 
        ["en"]="Heidrek Mask", 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=101, 
        ["MP"]=41, 
        ["Accuracy"]=20, 
        ["INT"]=20, 
        ["category"]="Armor", 
        ["CHR"]=30, 
        ["discription"]="DEF:101 HP+45 MP+41 STR+16 DEX+21 VIT+16 AGI+20 INT+16 MND+16 CHR+16 Accuracy+20 Ranged Accuracy+20 Magic Accuracy+20 Evasion+60 Magic Evasion+80 \"Magic Def. Bonus\"+4 Haste+8% Domain Invasion: STR+20 DEX+30 VIT+20 AGI+30 INT+20 MND+20 CHR+30 \"Fast Cast\"+50% Trust: Lv.+1", 
        ["VIT"]=20, 
        ["Magic Accuracy"]=20
    }, 
    [779]={
        ["Evasion"]=69, 
        ["STR"]=20, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=30, 
        ["Haste"]=4, 
        ["MND"]=20, 
        ["AGI"]=30, 
        ["Ranged Accuracy"]=20, 
        ["en"]="Heidrek Harness", 
        ["item_level"]=119, 
        ["HP"]=68, 
        ["id"]=23742, 
        ["discription"]="DEF:131 HP+68 MP+61 STR+26 DEX+33 VIT+26 AGI+30 INT+25 MND+25 CHR+25 Accuracy+20 Ranged Accuracy+20 Magic Accuracy+20 Evasion+69 Magic Evasion+91 \"Magic Def. Bonus\"+7 Haste+4% Domain Invasion: STR+20 DEX+30 VIT+20 AGI+30 INT+20 MND+20 CHR+30 Damage taken -50% Trust: Lv.+1", 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=131, 
        ["MP"]=61, 
        ["Accuracy"]=20, 
        ["INT"]=20, 
        ["category"]="Armor", 
        ["CHR"]=30, 
        ["Magic Accuracy"]=20, 
        ["VIT"]=20, 
        ["DT"]=-50
    }, 
    [780]={
        ["Magic Accuracy"]=80, 
        ["Ranged Accuracy"]=80, 
        ["category"]="Weapon", 
        ["Parrying skill"]=215, 
        ["Katana skill"]=215, 
        ["item_level"]=119, 
        ["en"]="Voluspa Katana", 
        ["delay"]=227, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["skill"]="Katana", 
        ["discription"]="DMG:122 Delay:227 Katana skill +215 Parrying skill +215 Magic Accuracy skill +215 Domain Invasion: DMG:+57 Accuracy+80 Attack+80 Ranged Accuracy+80 Magic Accuracy+80 \"Triple Attack\"+30%", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Attack"]=80, 
        ["id"]=21912, 
        ["Accuracy"]=80, 
        ["damage"]=57
    }, 
    [781]={
        ["Evasion"]=74, 
        ["STR"]=20, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=30, 
        ["DEF"]=89, 
        ["MND"]=20, 
        ["AGI"]=30, 
        ["Ranged Accuracy"]=20, 
        ["Store TP"]=50, 
        ["item_level"]=119, 
        ["HP"]=34, 
        ["id"]=23745, 
        ["discription"]="DEF:89 HP+34 STR+14 DEX+38 VIT+34 AGI+8 INT+15 MND+33 CHR+21 Accuracy+20 Ranged Accuracy+20 Magic Accuracy+20 Evasion+74 Magic Evasion+64 \"Magic Def. Bonus\"+4 Haste+5% Domain Invasion: STR+20 DEX+30 VIT+20 AGI+30 INT+20 MND+20 CHR+30 \"Store TP\"+50 Trust: Lv.+1", 
        ["INT"]=20, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=5, 
        ["Accuracy"]=20, 
        ["CHR"]=30, 
        ["VIT"]=20, 
        ["category"]="Armor", 
        ["en"]="Heidrek Gloves", 
        ["Magic Accuracy"]=20
    }, 
    [782]={
        ["Evasion"]=52, 
        ["MND"]=20, 
        ["DEF"]=113, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=30, 
        ["Ranged Accuracy"]=20, 
        ["en"]="Heidrek Brais", 
        ["STR"]=20, 
        ["item_level"]=119, 
        ["HP"]=57, 
        ["discription"]="DEF:113 HP+57 STR+30 VIT+19 AGI+21 INT+32 MND+19 CHR+12 Accuracy+20 Ranged Accuracy+20 Magic Accuracy+20 Evasion+52 Magic Evasion+96 \"Magic Def. Bonus\"+5 Haste+6% Domain Invasion: STR+20 DEX+30 VIT+20 AGI+30 INT+20 MND+20 CHR+30 \"Subtle Blow II\"+50 Trust: Lv.+1", 
        ["Accuracy"]=20, 
        ["INT"]=20, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=6, 
        ["id"]=23748, 
        ["CHR"]=30, 
        ["VIT"]=20, 
        ["category"]="Armor", 
        ["AGI"]=30, 
        ["Magic Accuracy"]=20
    }, 
    [783]={
        ["discription"]="DMG:88 Delay:190 Accuracy+24 Evasion+24 Katana skill +203 Parrying skill +203 Magic Accuracy skill +167 Latent effect: DMG:92 Accuracy+39 Attack+10", 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["Katana skill"]=203, 
        ["item_level"]=117, 
        ["en"]="Kaitsuburi", 
        ["delay"]=190, 
        ["Parrying skill"]=203, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=24, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=20998, 
        ["Evasion"]=24, 
        ["damage"]=88
    }, 
    [784]={
        ["Evasion"]=10, 
        ["category"]="Armor", 
        ["discription"]="DEF:14 HP+20 DEX+7 AGI+7 Accuracy+10 Evasion+10", 
        ["en"]="Meanagh Cape +1", 
        ["slots"]={
            [15]="Back"
        }, 
        ["HP"]=20, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=14, 
        ["DEX"]=7, 
        ["Accuracy"]=10, 
        ["id"]=28597, 
        ["AGI"]=7
    }, 
    [785]={
        ["discription"]="DEF:7 \"Triple Attack\"+2%  \"Quadruple Attack\"+1%", 
        ["DEF"]=7, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Windbuffet Belt", 
        ["id"]=10828, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [786]={
        ["Evasion"]=63, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=28, 
        ["DEF"]=105, 
        ["MND"]=14, 
        ["discription"]="DEF:105 HP+37 MP+20 STR+20 DEX+28 VIT+16 AGI+23 INT+15 MND+14 CHR+17 Accuracy+26 Ranged Accuracy+26 Magic Accuracy+26 Evasion+63 Magic Evasion+75 \"Magic Def. Bonus\"+3 Haste+8% Potency of \"Waltz\" effects received +5% Critical hit rate +2%", 
        ["Ranged Accuracy"]=26, 
        ["Critical hit rate"]=2, 
        ["AGI"]=23, 
        ["HP"]=37, 
        ["id"]=25581, 
        ["en"]="Mummu Bonnet", 
        ["STR"]=20, 
        ["Haste"]=8, 
        ["MP"]=20, 
        ["Accuracy"]=26, 
        ["INT"]=15, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["item_level"]=119, 
        ["VIT"]=16, 
        ["Magic Accuracy"]=26
    }, 
    [787]={
        ["Evasion"]=69, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["STR"]=28, 
        ["DEX"]=37, 
        ["DEF"]=131, 
        ["id"]=25781, 
        ["MND"]=20, 
        ["en"]="Mummu Jacket", 
        ["Ranged Accuracy"]=28, 
        ["Store TP"]=3, 
        ["AGI"]=33, 
        ["HP"]=60, 
        ["Accuracy"]=28, 
        ["item_level"]=119, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=4, 
        ["MP"]=35, 
        ["discription"]="DEF:131 HP+60 MP+35 STR+28 DEX+37 VIT+24 AGI+33 INT+21 MND+20 CHR+24 Accuracy+28 Ranged Accuracy+28 Magic Accuracy+28 Evasion+69 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+4% \"Store TP\"+3 Critical hit rate +5%", 
        ["INT"]=21, 
        ["category"]="Armor", 
        ["CHR"]=24, 
        ["Critical hit rate"]=5, 
        ["VIT"]=24, 
        ["Magic Accuracy"]=28
    }, 
    [788]={
        ["Evasion"]=76, 
        ["MND"]=21, 
        ["Haste"]=4, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=43, 
        ["STR"]=20, 
        ["AGI"]=16, 
        ["en"]="Hizamaru Kote +2", 
        ["item_level"]=119, 
        ["HP"]=40, 
        ["Set Bonus"]={
            ["set id"]=281, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Counter"]=4
                }, 
                [3]={
                    ["Counter"]=8
                }, 
                [4]={
                    ["Counter"]=12
                }, 
                [5]={
                    ["Counter"]=16
                }
            }
        }, 
        ["Accuracy"]=43, 
        ["INT"]=7, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=106, 
        ["id"]=25830, 
        ["CHR"]=25, 
        ["VIT"]=38, 
        ["category"]="Armor", 
        ["discription"]="DEF:106 HP+40 STR+20 DEX+43 VIT+38 AGI+16 INT+7 MND+21 CHR+25 Accuracy+43 Attack+25 Evasion+76 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+4% \"Critical Parry\"+25 Set: Enhances \"Counter\" effect", 
        ["Attack"]=25
    }, 
    [789]={
        ["Evasion"]=49, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=42, 
        ["DEF"]=96, 
        ["MND"]=26, 
        ["discription"]="DEF:96 HP+45 MP+15 STR+16 DEX+42 VIT+30 AGI+11 INT+14 MND+26 CHR+21 Accuracy+25 Ranged Accuracy+25 Magic Accuracy+25 Evasion+49 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Double Attack\"+3% Critical hit rate +3%", 
        ["Ranged Accuracy"]=25, 
        ["Critical hit rate"]=3, 
        ["AGI"]=11, 
        ["HP"]=45, 
        ["id"]=25820, 
        ["en"]="Mummu Wrists", 
        ["STR"]=16, 
        ["Haste"]=5, 
        ["MP"]=15, 
        ["Accuracy"]=25, 
        ["INT"]=14, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["item_level"]=119, 
        ["VIT"]=30, 
        ["Magic Accuracy"]=25
    }, 
    [790]={
        ["discription"]="DEF:14 \"Empty Killer\"", 
        ["DEF"]=14, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Shade Tights", 
        ["id"]=14327, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [791]={
        ["Evasion"]=55, 
        ["discription"]="DEF:113 HP+52 MP+25 STR+33 VIT+16 AGI+34 INT+29 MND+15 CHR+12 Accuracy+27 Ranged Accuracy+27 Magic Accuracy+27 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+6% Critical hit rate +4% Damage taken -3%", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=113, 
        ["MND"]=15, 
        ["Critical hit rate"]=4, 
        ["Ranged Accuracy"]=27, 
        ["AGI"]=34, 
        ["en"]="Mummu Kecks", 
        ["HP"]=52, 
        ["id"]=25875, 
        ["item_level"]=119, 
        ["STR"]=33, 
        ["Haste"]=6, 
        ["MP"]=25, 
        ["Accuracy"]=27, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["DT"]=-3, 
        ["VIT"]=16, 
        ["Magic Accuracy"]=27
    }, 
    [792]={
        ["Evasion"]=88, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=26, 
        ["DEF"]=75, 
        ["MND"]=11, 
        ["discription"]="DEF:75 HP+30 MP+10 STR+16 DEX+26 VIT+10 AGI+46 MND+11 CHR+29 Accuracy+24 Ranged Accuracy+24 Magic Accuracy+24 Evasion+88 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+4% \"Subtle Blow\"+5 Critical hit rate +2%", 
        ["Ranged Accuracy"]=24, 
        ["Critical hit rate"]=2, 
        ["AGI"]=46, 
        ["HP"]=30, 
        ["id"]=25942, 
        ["item_level"]=119, 
        ["STR"]=16, 
        ["Haste"]=4, 
        ["MP"]=10, 
        ["Accuracy"]=24, 
        ["CHR"]=29, 
        ["VIT"]=10, 
        ["category"]="Armor", 
        ["en"]="Mummu Gamashes", 
        ["Magic Accuracy"]=24
    }, 
    [793]={
        ["Evasion"]=63, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=35, 
        ["DEF"]=110, 
        ["MND"]=14, 
        ["discription"]="DEF:110 HP+37 MP+20 STR+20 DEX+35 VIT+16 AGI+30 INT+15 MND+14 CHR+17 Accuracy+38 Ranged Accuracy+38 Magic Accuracy+38 Evasion+63 Magic Evasion+75 \"Magic Def. Bonus\"+3 Haste+8% Potency of \"Waltz\" effects received +8% Critical hit rate +4%", 
        ["Ranged Accuracy"]=38, 
        ["Critical hit rate"]=4, 
        ["AGI"]=30, 
        ["HP"]=37, 
        ["id"]=25582, 
        ["en"]="Mummu Bonnet +1", 
        ["STR"]=20, 
        ["Haste"]=8, 
        ["MP"]=20, 
        ["Accuracy"]=38, 
        ["INT"]=15, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["item_level"]=119, 
        ["VIT"]=16, 
        ["Magic Accuracy"]=38
    }, 
    [794]={
        ["discription"]="DMG:202 Delay:366 INT+19 MND+19 Magic Accuracy+14 \"Magic Atk. Bonus\"+30 Magic Damage+217 Staff skill +242 Parrying skill +242 Magic Accuracy skill +228 \"Conserve MP\"+5 \"Fast Cast\"+4% Avatar: Magic Accuracy+35 \"Magic Atk. Bonus\"+115", 
        ["MND"]=19, 
        ["augments"]={
            [1]="Blood Pact Dmg.+9", 
            [2]="Pet: VIT+1", 
            [3]="Pet: \"Mag.Atk.Bns.\"+20", 
            [4]="DMG:+7", 
            [5]="none"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["skill"]="Staff", 
        ["item_level"]=119, 
        ["Staff skill"]=242, 
        ["en"]="Grioavolr", 
        ["delay"]=366, 
        ["Fast Cast"]=4, 
        ["Parrying skill"]=242, 
        ["INT"]=19, 
        ["slots"]={
            [0]="Main"
        }, 
        ["id"]=22054, 
        ["category"]="Weapon", 
        ["damage"]=209, 
        ["Magic Atk. Bonus"]=30, 
        ["Magic Accuracy"]=14
    }, 
    [795]={
        ["discription"]="DEF:13 MP+100 Summoning magic skill +8 Enhances \"Elemental Siphon\" effect", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["category"]="Armor", 
        ["en"]="Conveyance Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=28631, 
        ["DEF"]=13, 
        ["MP"]=100, 
        ["augments"]={
            [1]="Summoning magic skill +1", 
            [2]="Pet: Enmity+15", 
            [3]="Blood Pact Dmg.+1", 
            [4]="Blood Pact ab. del. II -3", 
            [5]="none"
        }
    }, 
    [796]={
        ["discription"]="DEF:20 Summoning magic skill +10", 
        ["DEF"]=20, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Lodurr Earring", 
        ["id"]=26099, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [797]={
        ["Evasion"]=75, 
        ["MND"]=29, 
        ["AGI"]=42, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=21, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["item_level"]=119, 
        ["DEF"]=82, 
        ["discription"]="DEF:82 HP+23 MP+71 STR+20 DEX+21 VIT+20 AGI+42 INT+27 MND+29 CHR+44 Accuracy+46 Evasion+75 Magic Evasion+127 \"Magic Def. Bonus\"+6 Haste+3% Avatar perpetuation cost -6 Avatar: Accuracy+40 Magic Accuracy+40 Evasion+40 \"Blood Pact\" damage +10 Set (Avatar): Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["HP"]=23, 
        ["id"]=23657, 
        ["VIT"]=20, 
        ["Haste"]=3, 
        ["MP"]=71, 
        ["Accuracy"]=46, 
        ["STR"]=20, 
        ["CHR"]=44, 
        ["INT"]=27, 
        ["category"]="Armor", 
        ["en"]="Convo. Pigaches +3"
    }, 
    [798]={
        ["Evasion"]=90, 
        ["STR"]=33, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=29, 
        ["DEF"]=115, 
        ["MND"]=10, 
        ["en"]="Hiza. Somen　+2", 
        ["Set Bonus"]={
            ["set id"]=281, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Counter"]=4
                }, 
                [3]={
                    ["Counter"]=8
                }, 
                [4]={
                    ["Counter"]=12
                }, 
                [5]={
                    ["Counter"]=16
                }
            }
        }, 
        ["AGI"]=24, 
        ["item_level"]=119, 
        ["HP"]=60, 
        ["id"]=25576, 
        ["discription"]="DEF:115 HP+60 STR+33 DEX+29 VIT+27 AGI+24 INT+12 MND+10 CHR+20 Accuracy+44 Attack+26 Evasion+90 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+6% \"Martial Arts\"+13 Set: Enhances \"Counter\" effect", 
        ["slots"]={
            [4]="Head"
        }, 
        ["Haste"]=6, 
        ["Martial Arts"]=13, 
        ["Accuracy"]=44, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=20, 
        ["VIT"]=27, 
        ["Attack"]=26
    }, 
    [799]={
        ["Evasion"]=95, 
        ["MND"]=17, 
        ["Haste"]=4, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=36, 
        ["STR"]=40, 
        ["AGI"]=28, 
        ["Set Bonus"]={
            ["set id"]=281, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Counter"]=4
                }, 
                [3]={
                    ["Counter"]=8
                }, 
                [4]={
                    ["Counter"]=12
                }, 
                [5]={
                    ["Counter"]=16
                }
            }
        }, 
        ["item_level"]=119, 
        ["HP"]=100, 
        ["discription"]="DEF:141 HP+100 STR+40 DEX+36 VIT+34 AGI+28 INT+20 MND+17 CHR+28 Accuracy+46 Attack+28 Evasion+95 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% \"Regen\"+12 Set: Enhances \"Counter\" effect", 
        ["Accuracy"]=46, 
        ["INT"]=20, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=141, 
        ["id"]=25792, 
        ["CHR"]=28, 
        ["VIT"]=34, 
        ["category"]="Armor", 
        ["en"]="Hiza. Haramaki +2", 
        ["Attack"]=28
    }, 
    [800]={
        ["Evasion"]=81, 
        ["MND"]=11, 
        ["STR"]=50, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["Haste"]=9, 
        ["Set Bonus"]={
            ["set id"]=281, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Counter"]=4
                }, 
                [3]={
                    ["Counter"]=8
                }, 
                [4]={
                    ["Counter"]=12
                }, 
                [5]={
                    ["Counter"]=16
                }
            }
        }, 
        ["AGI"]=24, 
        ["en"]="Hiza. Hizayoroi +2", 
        ["item_level"]=119, 
        ["HP"]=60, 
        ["discription"]="DEF:123 HP+60 STR+50 VIT+32 AGI+24 INT+24 MND+11 CHR+19 Accuracy+45 Attack+27 Evasion+81 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+9% Weapon skill damage +7% Set: Enhances \"Counter\" effect", 
        ["Accuracy"]=45, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=123, 
        ["id"]=25881, 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["VIT"]=32, 
        ["Attack"]=27
    }, 
    [801]={
        ["Evasion"]=96, 
        ["MND"]=3, 
        ["DEF"]=75, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=23, 
        ["STR"]=20, 
        ["AGI"]=26, 
        ["Dual Wield"]=5, 
        ["item_level"]=119, 
        ["HP"]=30, 
        ["en"]="Hiza. Sune-Ate", 
        ["Accuracy"]=24, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=3, 
        ["id"]=25929, 
        ["CHR"]=20, 
        ["VIT"]=15, 
        ["category"]="Armor", 
        ["discription"]="DEF:75 HP+30 STR+20 DEX+23 VIT+15 AGI+26 MND+3 CHR+20 Accuracy+24 Attack+24 Evasion+96 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+3% \"Dual Wield\"+5", 
        ["Attack"]=24
    }, 
    [802]={
        ["Evasion"]=72, 
        ["MND"]=10, 
        ["Haste"]=6, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=21, 
        ["slots"]={
            [4]="Head"
        }, 
        ["AGI"]=16, 
        ["item_level"]=119, 
        ["discription"]="DEF:105 HP+60 STR+25 DEX+21 VIT+19 AGI+16 INT+12 MND+10 CHR+12 Accuracy+26 Attack+26 Evasion+72 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+6% \"Martial Arts\"+7", 
        ["HP"]=60, 
        ["en"]="Hizamaru Somen", 
        ["Accuracy"]=26, 
        ["STR"]=25, 
        ["DEF"]=105, 
        ["Martial Arts"]=7, 
        ["id"]=25663, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["VIT"]=19, 
        ["Attack"]=26
    }, 
    [803]={
        ["Evasion"]=77, 
        ["MND"]=17, 
        ["DEF"]=131, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=28, 
        ["slots"]={
            [5]="Body"
        }, 
        ["AGI"]=20, 
        ["discription"]="DEF:131 HP+100 STR+32 DEX+28 VIT+26 AGI+20 INT+20 MND+17 CHR+20 Accuracy+28 Attack+28 Evasion+77 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% \"Regen\"+7", 
        ["item_level"]=119, 
        ["HP"]=100, 
        ["en"]="Hizamaru Haramaki", 
        ["Accuracy"]=28, 
        ["STR"]=32, 
        ["Haste"]=4, 
        ["id"]=25749, 
        ["INT"]=20, 
        ["category"]="Armor", 
        ["CHR"]=20, 
        ["VIT"]=26, 
        ["Attack"]=28
    }, 
    [804]={
        ["Evasion"]=58, 
        ["MND"]=21, 
        ["DEF"]=96, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=35, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["AGI"]=8, 
        ["discription"]="DEF:96 HP+40 STR+12 DEX+35 VIT+30 AGI+8 INT+7 MND+21 CHR+17 Accuracy+25 Attack+25 Evasion+58 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+4% \"Critical Parry\"+15", 
        ["item_level"]=119, 
        ["HP"]=40, 
        ["en"]="Hizamaru Kote", 
        ["Accuracy"]=25, 
        ["STR"]=12, 
        ["Haste"]=4, 
        ["id"]=25804, 
        ["INT"]=7, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["VIT"]=30, 
        ["Attack"]=25
    }, 
    [805]={
        ["Evasion"]=63, 
        ["MND"]=11, 
        ["DEF"]=113, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["AGI"]=16, 
        ["discription"]="DEF:113 HP+60 STR+42 VIT+24 AGI+16 INT+24 MND+11 CHR+11 Accuracy+27 Attack+27 Evasion+63 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+9% Weapon skill damage +3%", 
        ["item_level"]=119, 
        ["HP"]=60, 
        ["en"]="Hiza. Hizayoroi", 
        ["Accuracy"]=27, 
        ["STR"]=42, 
        ["Haste"]=9, 
        ["id"]=25862, 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["VIT"]=24, 
        ["Attack"]=27
    }, 
    [806]={
        ["Evasion"]=70, 
        ["MND"]=14, 
        ["Critical hit rate"]=3, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=39, 
        ["Ranged Accuracy"]=33, 
        ["item_level"]=119, 
        ["DEF"]=80, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["HP"]=50, 
        ["discription"]="DEF:80 HP+50 STR+20 DEX+39 VIT+21 AGI+39 MND+14 CHR+26 Accuracy+38 Ranged Accuracy+33 Evasion+70 Magic Evasion+129 \"Magic Def. Bonus\"+5 Haste+3% \"Triple Attack\"+3% \"Subtle Blow\"+5 Critical hit rate +3%", 
        ["Accuracy"]=38, 
        ["STR"]=20, 
        ["Haste"]=3, 
        ["id"]=25958, 
        ["CHR"]=26, 
        ["VIT"]=21, 
        ["category"]="Armor", 
        ["AGI"]=39, 
        ["en"]="Ken. Sune-Ate"
    }, 
    [807]={
        ["Evasion"]=52, 
        ["MND"]=17, 
        ["id"]=25551, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=42, 
        ["Ranged Accuracy"]=35, 
        ["item_level"]=119, 
        ["DEF"]=110, 
        ["slots"]={
            [4]="Head"
        }, 
        ["HP"]=68, 
        ["discription"]="DEF:110 HP+68 STR+23 DEX+42 VIT+32 AGI+29 INT+19 MND+17 CHR+19 Accuracy+40 Ranged Accuracy+35 Evasion+52 Magic Evasion+91 \"Magic Def. Bonus\"+5 Haste+6% \"Triple Attack\"+3% \"Subtle Blow\"+5 Critical hit rate +3%", 
        ["Accuracy"]=40, 
        ["INT"]=19, 
        ["STR"]=23, 
        ["Haste"]=6, 
        ["Critical hit rate"]=3, 
        ["CHR"]=19, 
        ["VIT"]=32, 
        ["category"]="Armor", 
        ["AGI"]=29, 
        ["en"]="Ken. Jinpachi"
    }, 
    [808]={
        ["Evasion"]=60, 
        ["MND"]=23, 
        ["id"]=26527, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=34, 
        ["Ranged Accuracy"]=37, 
        ["item_level"]=119, 
        ["DEF"]=140, 
        ["slots"]={
            [5]="Body"
        }, 
        ["HP"]=102, 
        ["discription"]="DEF:140 HP+102 STR+33 DEX+34 VIT+21 AGI+32 INT+24 MND+23 CHR+21 Accuracy+42 Ranged Accuracy+37 Evasion+60 Magic Evasion+107 \"Magic Def. Bonus\"+8 Haste+4% \"Triple Attack\"+5% \"Subtle Blow\"+9 Critical hit rate +7%", 
        ["Accuracy"]=42, 
        ["INT"]=24, 
        ["STR"]=33, 
        ["Haste"]=4, 
        ["Critical hit rate"]=7, 
        ["CHR"]=21, 
        ["VIT"]=21, 
        ["category"]="Armor", 
        ["AGI"]=32, 
        ["en"]="Ken. Samue"
    }, 
    [809]={
        ["Evasion"]=41, 
        ["MND"]=28, 
        ["Critical hit rate"]=3, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=57, 
        ["Ranged Accuracy"]=34, 
        ["item_level"]=119, 
        ["DEF"]=98, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["HP"]=41, 
        ["en"]="Ken. Tekko", 
        ["Accuracy"]=39, 
        ["STR"]=14, 
        ["Haste"]=4, 
        ["id"]=25978, 
        ["INT"]=14, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["VIT"]=37, 
        ["discription"]="DEF:98 HP+41 STR+14 DEX+57 VIT+37 INT+14 MND+28 CHR+21 Accuracy+39 Ranged Accuracy+34 Evasion+41 Magic Evasion+80 \"Magic Def. Bonus\"+4 Haste+4% \"Triple Attack\"+3% \"Subtle Blow\"+5 Critical hit rate +3%"
    }, 
    [810]={
        ["Evasion"]=49, 
        ["MND"]=16, 
        ["DEF"]=122, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["Critical hit rate"]=5, 
        ["Ranged Accuracy"]=36, 
        ["AGI"]=28, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["item_level"]=119, 
        ["HP"]=95, 
        ["discription"]="DEF:122 HP+95 STR+37 VIT+25 AGI+28 INT+32 MND+16 CHR+12 Accuracy+41 Ranged Accuracy+36 Evasion+49 Magic Evasion+129 \"Magic Def. Bonus\"+7 Haste+9% \"Triple Attack\"+4% \"Subtle Blow\"+7 Critical hit rate +5%", 
        ["Accuracy"]=41, 
        ["STR"]=37, 
        ["Haste"]=9, 
        ["id"]=25891, 
        ["INT"]=32, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["VIT"]=25, 
        ["en"]="Ken. Hakama"
    }, 
    [811]={
        ["discription"]="Accuracy+15 Ranged Accuracy+15 Evasion+15", 
        ["Ranged Accuracy"]=15, 
        ["category"]="Armor", 
        ["en"]="Ej Necklace", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=28404, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=15, 
        ["Evasion"]=15
    }, 
    [812]={
        ["discription"]="Critical hit rate +1% Critical hit damage +5%", 
        ["en"]="Yetshila", 
        ["skill"]="(N/A)", 
        ["Critical hit rate"]=1, 
        ["category"]="Weapon", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [13]="NIN", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["id"]=21378, 
        ["Critical hit damage"]=5
    }, 
    [813]={
        ["Ranged Attack"]=10, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=29, 
        ["DEF"]=128, 
        ["MND"]=21, 
        ["augments"]={
            [1]="none", 
            [2]="\"Fast Cast\"+5", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["item_level"]=119, 
        ["en"]="Taeon Tabard", 
        ["Fast Cast"]=9, 
        ["HP"]=59, 
        ["id"]=26893, 
        ["discription"]="DEF:128 HP+59 MP+44 STR+22 DEX+29 VIT+22 AGI+28 INT+21 MND+21 CHR+21 Attack+10 Ranged Attack+10 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+4% \"Fast Cast\"+4%", 
        ["STR"]=22, 
        ["Haste"]=4, 
        ["MP"]=44, 
        ["AGI"]=28, 
        ["INT"]=21, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["Evasion"]=49, 
        ["VIT"]=22, 
        ["Attack"]=10
    }, 
    [814]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["AGI"]=30, 
        ["augments"]={
            [1]="AGI+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="AGI+10", 
            [4]="Crit.hit rate+10", 
            [5]="none"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["id"]=26258, 
        ["Attack"]=20
    }, 
    [815]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Staunch Tathlum", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="Resistance to all status ailments +10 Spellcasting interruption rate -10% Damage taken -2%", 
        ["id"]=22278, 
        ["DT"]=-2
    }, 
    [816]={
        ["discription"]="DEF:11 MND+4 Magic Accuracy+8 \"Magic Atk. Bonus\"-10", 
        ["MND"]=4, 
        ["category"]="Armor", 
        ["en"]="Ovate Rope", 
        ["Magic Atk. Bonus"]=-10, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEF"]=11, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28455, 
        ["Magic Accuracy"]=8
    }, 
    [817]={
        ["discription"]="Ninjutsu skill +5 Enhances \"Resist Silence\" effect", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=14815, 
        ["en"]="Stealth Earring", 
        ["Ninjutsu skill"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [818]={
        ["INT"]=8, 
        ["en"]="Shiva Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=27574, 
        ["discription"]="INT+8 +15", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [819]={
        ["discription"]="DEF:4 MP+25 MND+5 Magic Accuracy+4 \"Magic Atk. Bonus\"+4", 
        ["MND"]=5, 
        ["category"]="Armor", 
        ["en"]="Salire Belt", 
        ["Magic Atk. Bonus"]=4, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=4, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["MP"]=25, 
        ["id"]=28425, 
        ["Magic Accuracy"]=4
    }, 
    [820]={
        ["Evasion"]=38, 
        ["MND"]=17, 
        ["Haste"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["STR"]=29, 
        ["AGI"]=20, 
        ["id"]=27231, 
        ["Store TP"]=-5, 
        ["HP"]=47, 
        ["en"]="Zoar Subligar +1", 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=111, 
        ["discription"]="DEF:111 HP+47 STR+29 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Evasion+38 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% Enmity+6 \"Triple Attack\"+3% \"Store TP\"-5 Unity Ranking: \"Double Attack\"+1～5%", 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["VIT"]=16, 
        ["item_level"]=119
    }, 
    [821]={
        ["discription"]="DEF:15 Enfeebling magic effect +10 Enhancing magic effect duration +20%", 
        ["category"]="Armor", 
        ["en"]="Sucellos's Cape", 
        ["Fast Cast"]=10, 
        ["augments"]={
            [1]="INT+20", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="Mag. Acc.+10", 
            [4]="\"Fast Cast\"+10", 
            [5]="none"
        }, 
        ["INT"]=20, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["id"]=26250, 
        ["DEF"]=15, 
        ["Magic Accuracy"]=30
    }, 
    [822]={
        ["jobs"]={
            [5]="RDM"
        }, 
        ["en"]="Duelist's Torque", 
        ["id"]=25441, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="Magic Accuracy+20 Enfeebling Magic effect +5 \"Dispel\"+1", 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["Magic Accuracy"]=20
    }, 
    [823]={
        ["discription"]="Dusk to dawn: STR+8 DEX+8 VIT+8 INT+8 Unity Ranking: \"Double Attack\"+1～3%", 
        ["category"]="Armor", 
        ["en"]="Lugra Earring +1", 
        ["DEX"]=8, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["STR"]=8, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["INT"]=8, 
        ["id"]=28482, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["VIT"]=8
    }, 
    [824]={
        ["discription"]="Haste+9% \"Triple Attack\"+2% Unity Ranking: Attack+10～15", 
        ["category"]="Armor", 
        ["en"]="Sailfi Belt +1", 
        ["Unity Ranking Bonus Applied"]="Attack + 15", 
        ["id"]=28428, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=9, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["Attack"]=15
    }, 
    [825]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Andartia's Mantle", 
        ["Store TP"]=10, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+13 Attack+13", 
            [3]="none", 
            [4]="\"Store TP\"+10", 
            [5]="none"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["DEX"]=20, 
        ["Accuracy"]=13, 
        ["id"]=26258, 
        ["Attack"]=13
    }, 
    [826]={
        ["discription"]="DEF:11 VIT+9 CHR+9 \"Resist Charm\"+9 Enmity+10 Unity Ranking: Accuracy+1～5", 
        ["category"]="Armor", 
        ["CHR"]=9, 
        ["en"]="Unmoving Collar +1", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["Unity Ranking Bonus Applied"]="Accuracy + 5", 
        ["DEF"]=11, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=5, 
        ["id"]=27509, 
        ["VIT"]=9
    }, 
    [827]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["id"]=26258, 
        ["en"]="Andartia's Mantle", 
        ["Store TP"]=10, 
        ["DEX"]=25, 
        ["DT"]=-5, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+5", 
            [4]="\"Store TP\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["DEF"]=16, 
        ["Attack"]=20
    }, 
    [828]={
        ["Evasion"]=27, 
        ["MND"]=26, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [10]="BRD", 
            [15]="SMN", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["en"]="Assid. Pants +1", 
        ["DEF"]=105, 
        ["AGI"]=17, 
        ["STR"]=25, 
        ["item_level"]=119, 
        ["HP"]=43, 
        ["Refresh"]=2, 
        ["VIT"]=12, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=5, 
        ["MP"]=29, 
        ["id"]=28135, 
        ["Unity Ranking Bonus Applied"]="Refresh + 2", 
        ["CHR"]=19, 
        ["INT"]=36, 
        ["category"]="Armor", 
        ["discription"]="DEF:105 HP+43 MP+29 STR+25 VIT+12 AGI+17 INT+36 MND+26 CHR+19 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% Enmity-6 Avatar perpetuation cost-3 Unity Ranking: \"Refresh\"+1～2"
    }, 
    [829]={
        ["id"]=28517, 
        ["en"]="Crematio Earring", 
        ["Magic Atk. Bonus"]=6, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Magic Atk. Bonus+6 Magic Damage+6 Staff skill +5", 
        ["Staff skill"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [830]={
        ["discription"]="DEX+27 AGI+27 Evasion+70 Unity Ranking: DEX+1～7 AGI+1～7", 
        ["category"]="Armor", 
        ["id"]=26710, 
        ["en"]="Imp. Wing Hair. +1", 
        ["AGI"]=27, 
        ["Unity Ranking Bonus Applied"]="DEX + 7", 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["item_level"]=119, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["DEX"]=34, 
        ["Evasion"]=70
    }, 
    [831]={
        ["discription"]="DEF:18 All Jumps: \"Double Attack\"+20% Wyvern: \"Breath\" attacks +15", 
        ["category"]="Armor", 
        ["DT"]=-5, 
        ["en"]="Brigantia's Mantle", 
        ["id"]=26259, 
        ["DEX"]=30, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=18, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["Attack"]=20
    }, 
    [832]={
        ["discription"]="DMG:345 Delay:492 Magic Damage+155 Polearm skill +269 Parrying skill +269 Magic Accuracy skill +228 \"Store TP\"+10 \"TP Bonus\"+500 \"Stardiver\" Aftermath: Increases skillchain potency Increases magic burst potency Ultimate Skillchain", 
        ["category"]="Weapon", 
        ["Parrying skill"]=269, 
        ["item_level"]=119, 
        ["Store TP"]=10, 
        ["delay"]=492, 
        ["skill"]="Polearm", 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["Polearm skill"]=269, 
        ["en"]="Trishula", 
        ["id"]=20935, 
        ["slots"]={
            [0]="Main"
        }, 
        ["damage"]=345
    }, 
    [833]={
        ["discription"]="DEX+7 AGI+7 \"Store TP\"+6 \"Dual Wield\"+4 Critical hit rate +4%", 
        ["category"]="Armor", 
        ["en"]="Gerdr Belt +1", 
        ["Store TP"]=6, 
        ["id"]=26361, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Dual Wield"]=4, 
        ["Critical hit rate"]=4, 
        ["DEX"]=7, 
        ["AGI"]=7
    }, 
    [834]={
        ["discription"]="INT+6 MND+6 CHR+6 Converts 60 HP to MP Unity Ranking: Magic Accuracy+1～5", 
        ["MND"]=6, 
        ["category"]="Armor", 
        ["en"]="Metamor. Ring +1", 
        ["CHR"]=6, 
        ["INT"]=6, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27563, 
        ["augments"]={
            [1]="Path: A"
        }
    }, 
    [835]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="\"Store TP\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["en"]="Andartia's Mantle", 
        ["Store TP"]=10, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Attack"]=20, 
        ["DEX"]=30, 
        ["Accuracy"]=20, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=26258, 
        ["DEF"]=16, 
        ["DT"]=-5
    }, 
    [836]={
        ["Evasion"]=36, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["discription"]="DEF:93 HP+22 STR+15 DEX+44 VIT+29 AGI+7 INT+12 MND+30 CHR+17 Accuracy+32 Ranged Accuracy+32 Evasion+36 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+4% \"Store TP\"+7 Set: Increases rate of critical hits", 
        ["DEX"]=56, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=27118, 
        ["MND"]=30, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=32, 
        ["Store TP"]=7, 
        ["en"]="Adhemar Wrist. +1", 
        ["HP"]=22, 
        ["Accuracy"]=32, 
        ["augments"]={
            [1]="STR+12", 
            [2]="DEX+12", 
            [3]="Attack+20"
        }, 
        ["INT"]=12, 
        ["STR"]=27, 
        ["DEF"]=93, 
        ["Haste"]=5, 
        ["CHR"]=17, 
        ["AGI"]=7, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=11, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }
        }, 
        ["VIT"]=29, 
        ["Attack"]=20
    }, 
    [837]={
        ["Ranged Attack"]=34, 
        ["STR"]=27, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=35, 
        ["DEF"]=75, 
        ["MND"]=11, 
        ["augments"]={
            [1]="STR+12", 
            [2]="DEX+12", 
            [3]="Attack+20"
        }, 
        ["Set Bonus"]={
            ["set id"]=11, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }
        }, 
        ["AGI"]=42, 
        ["item_level"]=119, 
        ["HP"]=11, 
        ["Critical hit rate"]=4, 
        ["discription"]="DEF:75 HP+11 STR+15 DEX+23 VIT+8 AGI+42 MND+11 CHR+25 Attack+34 Ranged Attack+34 Evasion+74 Magic Evasion+75 \"Magic Atk. Bonus\"+35 \"Magic Def. Bonus\"+5 Haste+4% \"True Shot\"+2 Critical hit rate +4% Set: Increases rate of critical hits", 
        ["CHR"]=25, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=4, 
        ["en"]="Adhe. Gamashes +1", 
        ["category"]="Armor", 
        ["VIT"]=8, 
        ["Magic Atk. Bonus"]=35, 
        ["id"]=27474, 
        ["Evasion"]=74, 
        ["Attack"]=54
    }, 
    [838]={
        ["Ranged Attack"]=36, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=33, 
        ["DEF"]=102, 
        ["MND"]=14, 
        ["id"]=25614, 
        ["Evasion"]=49, 
        ["item_level"]=119, 
        ["AGI"]=19, 
        ["HP"]=41, 
        ["augments"]={
            [1]="STR+12", 
            [2]="DEX+12", 
            [3]="Attack+20"
        }, 
        ["discription"]="DEF:102 HP+41 STR+19 DEX+21 VIT+15 AGI+19 INT+14 MND+14 CHR+14 Attack+36 Ranged Attack+36 Evasion+49 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+8% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit damage +6% Set: Increases rate of critical hits", 
        ["INT"]=14, 
        ["STR"]=31, 
        ["Haste"]=8, 
        ["en"]="Adhemar Bonnet +1", 
        ["CHR"]=14, 
        ["VIT"]=15, 
        ["category"]="Armor", 
        ["Critical hit damage"]=6, 
        ["Set Bonus"]={
            ["set id"]=11, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }
        }, 
        ["Attack"]=56
    }, 
    [839]={
        ["Evasion"]=55, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEX"]=45, 
        ["DEF"]=133, 
        ["augments"]={
            [1]="STR+12", 
            [2]="DEX+12", 
            [3]="Attack+20"
        }, 
        ["MND"]=20, 
        ["Dual Wield"]=6, 
        ["Ranged Accuracy"]=35, 
        ["discription"]="DEF:133 HP+63 STR+26 DEX+33 VIT+23 AGI+29 INT+20 MND+20 CHR+20 Accuracy+35 Attack+35 Ranged Accuracy+35 Ranged Attack+35 Evasion+55 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% \"Triple Attack\"+4% Enmity-8 \"Dual Wield\"+6 Set: Increases rate of critical hits", 
        ["AGI"]=29, 
        ["HP"]=63, 
        ["Accuracy"]=35, 
        ["Set Bonus"]={
            ["set id"]=11, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }
        }, 
        ["INT"]=20, 
        ["CHR"]=20, 
        ["STR"]=38, 
        ["Haste"]=4, 
        ["id"]=25687, 
        ["category"]="Armor", 
        ["en"]="Adhemar Jacket +1", 
        ["Ranged Attack"]=35, 
        ["item_level"]=119, 
        ["VIT"]=23, 
        ["Attack"]=55
    }, 
    [840]={
        ["discription"]="Attack+6 Polearm skill +5 \"Store TP\"+5", 
        ["category"]="Armor", 
        ["en"]="Tripudio Earring", 
        ["Store TP"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=28519, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Polearm skill"]=5, 
        ["Attack"]=6
    }, 
    [841]={
        ["Evasion"]=49, 
        ["STR"]=37, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=45, 
        ["Haste"]=4, 
        ["MND"]=25, 
        ["id"]=26950, 
        ["item_level"]=119, 
        ["AGI"]=30, 
        ["en"]="Rawhide Vest", 
        ["HP"]=59, 
        ["augments"]={
            [1]="DEX+10", 
            [2]="STR+7", 
            [3]="INT+7"
        }, 
        ["discription"]="DEF:130 HP+59 MP+44 STR+30 DEX+35 VIT+26 AGI+30 INT+25 MND+25 CHR+25 Accuracy+15 Attack+15 \"Magic Atk. Bonus\"+25 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+4% \"Triple Attack\"+2%", 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=130, 
        ["MP"]=44, 
        ["Accuracy"]=15, 
        ["INT"]=32, 
        ["category"]="Armor", 
        ["CHR"]=25, 
        ["VIT"]=26, 
        ["Magic Atk. Bonus"]=25, 
        ["Attack"]=15
    }, 
    [842]={
        ["Evasion"]=44, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=25, 
        ["DEF"]=146, 
        ["MND"]=20, 
        ["en"]="Valorous Mail", 
        ["id"]=25717, 
        ["Store TP"]=3, 
        ["AGI"]=20, 
        ["HP"]=61, 
        ["augments"]={
            [1]="\"Dbl.Atk.\"+5", 
            [2]="Accuracy+15", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["VIT"]=29, 
        ["INT"]=20, 
        ["STR"]=29, 
        ["Haste"]=3, 
        ["Accuracy"]=35, 
        ["CHR"]=20, 
        ["PDT"]=-2, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["discription"]="DEF:146 HP+61 STR+29 DEX+25 VIT+29 AGI+20 INT+20 MND+20 CHR+20 Accuracy+20 Evasion+44 Magic Evasion+59 \"Magic Def. Bonus\"+4 Haste+3% \"Store TP\"+3 \"Double Attack\"+2% Physical damage taken -2%"
    }, 
    [843]={
        ["discription"]="DMG:345 Delay:492 Magic Damage+155 Polearm skill +269 Parrying skill +269 Magic Accuracy skill +228 \"Store TP\"+10 \"TP Bonus\"+500 \"Stardiver\" Aftermath: Increases skillchain potency Increases magic burst potency Ultimate Skillchain", 
        ["item_level"]=119, 
        ["id"]=20935, 
        ["category"]="Weapon", 
        ["Store TP"]=10, 
        ["en"]="Trishula", 
        ["delay"]=492, 
        ["skill"]="Polearm", 
        ["slots"]={
            [0]="Main"
        }, 
        ["Polearm skill"]=269, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["Parrying skill"]=269, 
        ["damage"]=345
    }, 
    [844]={
        ["discription"]="DEF:18 All Jumps: \"Double Attack\"+20% Wyvern: \"Breath\" attacks +15", 
        ["category"]="Armor", 
        ["en"]="Brigantia's Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="STR+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="STR+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="none"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=18, 
        ["STR"]=30, 
        ["Accuracy"]=20, 
        ["id"]=26259, 
        ["Attack"]=20
    }, 
    [845]={
        ["Evasion"]=24, 
        ["MND"]=14, 
        ["DEF"]=127, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["augments"]={
            [1]="\"Dbl.Atk.\"+5", 
            [2]="Attack+4", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["STR"]=39, 
        ["AGI"]=16, 
        ["en"]="Valor. Hose", 
        ["item_level"]=119, 
        ["HP"]=95, 
        ["PDT"]=-2, 
        ["discription"]="DEF:127 HP+95 STR+39 VIT+26 AGI+16 INT+24 MND+14 CHR+11 Attack+15 Evasion+24 Magic Evasion+80 \"Magic Def. Bonus\"+3 Haste+5% \"Double Attack\"+3% Physical damage taken -2%", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=5, 
        ["id"]=25841, 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["VIT"]=26, 
        ["Attack"]=19
    }, 
    [846]={
        ["discription"]="STR+5 DEX+5 VIT+5 Attack+7 \"Store TP\"+4", 
        ["category"]="Weapon", 
        ["skill"]="(N/A)", 
        ["en"]="Aurgelmir Orb", 
        ["Store TP"]=4, 
        ["STR"]=5, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Attack"]=7, 
        ["id"]=22297, 
        ["DEX"]=5, 
        ["VIT"]=5
    }, 
    [847]={
        ["discription"]="VIT+4 \"Subtle Blow\"-4 \"Quadruple Attack\"+2%", 
        ["en"]="Ganesha's Mala", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=10928, 
        ["jobs"]={
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["category"]="Armor", 
        ["VIT"]=4
    }, 
    [848]={
        ["MDT"]=1, 
        ["category"]="Armor", 
        ["en"]="Gelatinous Ring +1", 
        ["id"]=10769, 
        ["HP"]=35, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Unity Ranking Bonus Applied"]="HP + 35", 
        ["discription"]="Physical damage taken -7% Magic damage taken +1% Unity Ranking: HP+10～35", 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["PDT"]=-7
    }, 
    [849]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["Attack"]=20, 
        ["en"]="Andartia's Mantle", 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["DEX"]=30, 
        ["Accuracy"]=20, 
        ["id"]=26258, 
        ["DT"]=-5
    }, 
    [850]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Orunmila's Torque", 
        ["category"]="Armor", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["MP"]=30, 
        ["discription"]="MP+30 Magic Accuracy+1 \"Fast Cast\" effect+5 Enmity-3", 
        ["id"]=10394, 
        ["Magic Accuracy"]=1
    }, 
    [851]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="Accuracy+10", 
            [4]="\"Store TP\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["en"]="Andartia's Mantle", 
        ["Store TP"]=10, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Attack"]=20, 
        ["DEX"]=20, 
        ["Accuracy"]=30, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=26258, 
        ["DEF"]=16, 
        ["DT"]=-5
    }, 
    [852]={
        ["discription"]="Accuracy-10 Attack-10 Ranged Accuracy-10 Ranged Attack-10 \"Store TP\"+8", 
        ["category"]="Armor", 
        ["en"]="Dedition Earring", 
        ["Store TP"]=8, 
        ["Ranged Attack"]=-10, 
        ["Ranged Accuracy"]=-10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=-10, 
        ["id"]=27544, 
        ["Attack"]=-10
    }, 
    [853]={
        ["Evasion"]=76, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEX"]=39, 
        ["DEF"]=161, 
        ["MND"]=31, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Spirit Surge\" effect", 
            [4]="none"
        }, 
        ["discription"]="DEF:161 HP+102 MP+64 STR+44 DEX+39 VIT+36 AGI+31 INT+31 MND+31 CHR+31 Accuracy+40 Attack+80 Magic Accuracy+40 Evasion+76 Magic Evasion+73 \"Magic Def. Bonus\"+6 Haste+3% All Jumps: Adds 100% of wyvern's max HP as additional damage Wyvern: Adds support job abilities to wyvern", 
        ["en"]="Ptero. Mail +3", 
        ["AGI"]=31, 
        ["HP"]=102, 
        ["id"]=23478, 
        ["item_level"]=119, 
        ["STR"]=44, 
        ["Haste"]=3, 
        ["MP"]=64, 
        ["Accuracy"]=40, 
        ["INT"]=31, 
        ["category"]="Armor", 
        ["CHR"]=31, 
        ["Magic Accuracy"]=40, 
        ["VIT"]=36, 
        ["Attack"]=80
    }, 
    [854]={
        ["Ranged Attack"]=10, 
        ["DEX"]=24, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Evasion"]=80, 
        ["augments"]={
            [1]="Mag. Acc.+4", 
            [2]="\"Fast Cast\"+6", 
            [3]="INT+7", 
            [4]="none", 
            [5]="none"
        }, 
        ["Accuracy"]=10, 
        ["PDT"]=-2, 
        ["Ranged Accuracy"]=10, 
        ["item_level"]=119, 
        ["MND"]=11, 
        ["en"]="Herculean Boots", 
        ["discription"]="DEF:79 HP+9 STR+16 DEX+24 VIT+10 AGI+43 MND+11 CHR+26 Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+5 Evasion+80 Magic Evasion+75 Haste+4% \"Triple Attack\"+2 \"Subtle Blow\"+6 Physical damage taken -2%", 
        ["HP"]=9, 
        ["Haste"]=4, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["INT"]=7, 
        ["CHR"]=26, 
        ["STR"]=16, 
        ["DEF"]=79, 
        ["AGI"]=43, 
        ["Fast Cast"]=6, 
        ["Attack"]=10, 
        ["VIT"]=10, 
        ["category"]="Armor", 
        ["id"]=27496, 
        ["Magic Atk. Bonus"]=10, 
        ["Magic Accuracy"]=14
    }
}