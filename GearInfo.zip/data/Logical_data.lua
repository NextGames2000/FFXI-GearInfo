return {
    [1]={
        ["discription"]="A legendary fishing rod that appears in Far Eastern mythology.", 
        ["en"]="Ebisu Fishing Rod", 
        ["skill"]="Fishing", 
        ["id"]=17011, 
        ["slots"]={
            [2]="Range"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [2]={
        ["discription"]="Dispense: Angelwing", 
        ["id"]=16120, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Redeyes", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [3]={
        ["discription"]="A fishing apparatus comprised of  several hooks. The hooks are designed to latch on  to the fish's scales.", 
        ["en"]="Rogue Rig", 
        ["skill"]="Fishing", 
        ["id"]=17398, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [4]={
        ["discription"]="DEF:4 +2 +2 Fishing skill +1 Reduces chances of fishing up items ", 
        ["DEF"]=4, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Fisherman's Smock", 
        ["id"]=11337, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [5]={
        ["discription"]="Enchantment: Increases skill at tiring fish", 
        ["id"]=15556, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Penguin Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [6]={
        ["discription"]="A fishing apparatus comprised of  several baited hooks. Designed for catching small fish.", 
        ["en"]="Sabiki Rig", 
        ["skill"]="Fishing", 
        ["id"]=17399, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [7]={
        ["discription"]="Fishing support: Reduces fish stamina recovery", 
        ["id"]=15846, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Heron Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [8]={
        ["discription"]="DEF:1  Fishing skill +1", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Fsh. Gloves", 
        ["id"]=14070, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [9]={
        ["discription"]="DEF:1 +2 +2", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Fisherman's Cuffs", 
        ["id"]=15051, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [10]={
        ["discription"]="Enchantment: Increases skill at tiring fish", 
        ["id"]=15556, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Penguin Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [11]={
        ["discription"]="DEF:1 Fishing skill +1", 
        ["DEF"]=1, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Fisherman's Hose", 
        ["id"]=14292, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [12]={
        ["discription"]="DEF:2 +1 Fishing skill +2", 
        ["DEF"]=2, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Waders", 
        ["id"]=14195, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [13]={
        ["discription"]="Enchantment: Increases stamina while fishing", 
        ["id"]=15555, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Albatross Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [14]={
        ["discription"]="A small cephalopod with a characteristic pointed shell. Bait.", 
        ["en"]="Drill Calamary", 
        ["skill"]="Fishing", 
        ["id"]=17006, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [15]={
        ["discription"]="Fishing skill +2", 
        ["id"]=10925, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Fisher's Torque", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [16]={
        ["discription"]="An extremely rare species of tiny pugil. Bait.", 
        ["en"]="Dwarf Pugil", 
        ["skill"]="Fishing", 
        ["id"]=17007, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [17]={
        ["discription"]="A fishing lure made in the shape of  a small fish. Designed for catching bottom fish.", 
        ["en"]="Sinking Minnow", 
        ["skill"]="Fishing", 
        ["id"]=17400, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [18]={
        ["discription"]="A fishing lure made in the shape of  a frog. ", 
        ["en"]="Frog Lure", 
        ["skill"]="Fishing", 
        ["id"]=17403, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [19]={
        ["discription"]="A fishing lure made in the shape of  a shrimp. ", 
        ["en"]="Shrimp Lure", 
        ["skill"]="Fishing", 
        ["id"]=17402, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [20]={
        ["discription"]="Angler's Discernment +1", 
        ["id"]=11768, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Fisher's Rope", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [21]={
        ["discription"]="A fishing lure made in the shape of  a worm. ", 
        ["en"]="Worm Lure", 
        ["skill"]="Fishing", 
        ["id"]=17404, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [22]={
        ["discription"]="A fishing lure made in the shape of  a caterpillar. ", 
        ["en"]="Fly Lure", 
        ["skill"]="Fishing", 
        ["id"]=17405, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [23]={
        ["discription"]="Fishing skill (journeyman and above): Increases chances of fishing up large prey. ", 
        ["id"]=11654, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Puffin Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [24]={
        ["discription"]="Fishing skill (artisan and above): Reduces chances of fishing up monsters.", 
        ["id"]=11655, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Noddy Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [25]={
        ["discription"]="Enchantment: Increases stamina while fishing", 
        ["id"]=15555, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Albatross Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [26]={
        ["discription"]="Fishing support: Increases fish stamina reduction", 
        ["id"]=15845, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Seagull Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [27]={
        ["discription"]="Enchantment: Fishy Intuition", 
        ["id"]=28570, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Duck Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [28]={
        ["discription"]="A legendary fishing rod believed to  have caught a sea dragon. ", 
        ["en"]="Lu Shang's F. Rod", 
        ["skill"]="Fishing", 
        ["id"]=17386, 
        ["slots"]={
            [2]="Range"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [29]={
        ["discription"]="Campaign: STR+2 DEX+2", 
        ["en"]="Fullmetal Bullet", 
        ["DEX"]=2, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["STR"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=19214, 
        ["slots"]={
            [3]="Ammo"
        }
    }, 
    [30]={
        ["discription"]="DMG:19 Delay:183 AGI+3 Attack+7 Additional effect: Silence", 
        ["category"]="Weapon", 
        ["en"]="Garuda's Dagger", 
        ["AGI"]=3, 
        ["delay"]=183, 
        ["skill"]="Dagger", 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["Attack"]=7, 
        ["id"]=17627, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=19
    }, 
    [31]={
        ["discription"]="Daytime: HP+30 Nighttime: Evasion+10", 
        ["en"]="Fenrir's Stone", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["HP"]=30, 
        ["category"]="Weapon", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18165, 
        ["Evasion"]=10
    }, 
    [32]={
        ["discription"]="DEF:2 Enhances chocobo digging endurance", 
        ["DEF"]=2, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Blue Race Silks", 
        ["id"]=11325, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [33]={
        ["id"]=14062, 
        ["en"]="Carbuncle Mitts", 
        ["DEF"]=5, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:5 MP+14", 
        ["MP"]=14, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [34]={
        ["discription"]="DMG:65 Delay:420 Latent effect: DMG:78 Critical hit rate +6%", 
        ["en"]="Michishiba", 
        ["skill"]="Great Katana", 
        ["delay"]=420, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["id"]=17827, 
        ["damage"]=65
    }, 
    [35]={
        ["discription"]="DEF:2 Enhances chocobo caring ability", 
        ["DEF"]=2, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Green Race Silks", 
        ["id"]=11328, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [36]={
        ["discription"]="DMG:57 Delay:402 Dark weather: Enhances effect of \"Drain\" and \"Aspir\" Additional effect: \"Slow\"", 
        ["en"]="Diabolos's Pole", 
        ["skill"]="Staff", 
        ["delay"]=402, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=17599, 
        ["damage"]=57
    }, 
    [37]={
        ["discription"]="DMG:16 Delay:150 DEX+1 AGI+1", 
        ["category"]="Weapon", 
        ["en"]="Hornetneedle", 
        ["AGI"]=1, 
        ["delay"]=150, 
        ["DEX"]=1, 
        ["jobs"]={
            [5]="RDM", 
            [6]="THF", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=17980, 
        ["skill"]="Dagger", 
        ["damage"]=16
    }, 
    [38]={
        ["discription"]="DEF:1 +3", 
        ["DEF"]=1, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Straw Hat", 
        ["id"]=27733, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [39]={
        ["discription"]="DMG:22 Delay:278 VIT+3  Additional effect: Earth damage", 
        ["category"]="Weapon", 
        ["en"]="Titan's Cudgel", 
        ["skill"]="Club", 
        ["delay"]=278, 
        ["VIT"]=3, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=17438, 
        ["damage"]=22
    }, 
    [40]={
        ["en"]="Peacock Amulet", 
        ["id"]=15515, 
        ["Accuracy"]=10, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="-10 Accuracy+10 Ranged Accuracy+10", 
        ["Ranged Accuracy"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [41]={
        ["MDT"]=-5, 
        ["en"]="Resentment Cape", 
        ["DEF"]=8, 
        ["slots"]={
            [15]="Back"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:8 Enmity+2 In areas outside own nation's control: Magic damage taken -5%", 
        ["id"]=15468, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [42]={
        ["discription"]="DEF:11", 
        ["DEF"]=11, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Dune Boots", 
        ["id"]=14168, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [9]="BST", 
            [10]="BRD", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [43]={
        ["discription"]="DMG:11 Delay:600 AGI+1", 
        ["category"]="Weapon", 
        ["en"]="Firefly", 
        ["skill"]="Marksmanship", 
        ["delay"]=600, 
        ["AGI"]=1, 
        ["slots"]={
            [2]="Range"
        }, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR"
        }, 
        ["id"]=19221, 
        ["damage"]=11
    }, 
    [44]={
        ["Attack"]=8, 
        ["id"]=11546, 
        ["DEF"]=6, 
        ["slots"]={
            [15]="Back"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:6 Attack+8 \"Double Attack\"+1% On Darksdays: \"Double Attack\"+2%", 
        ["en"]="Aesir Mantle", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [45]={
        ["discription"]="DMG:+11 Delay:+60 INT+3 Accuracy+8  Additional effect: Paralysis", 
        ["category"]="Weapon", 
        ["en"]="Shiva's Claws", 
        ["skill"]="Hand-to-Hand", 
        ["delay"]=60, 
        ["INT"]=3, 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [13]="NIN", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["Accuracy"]=8, 
        ["id"]=17492, 
        ["damage"]=11
    }, 
    [46]={
        ["discription"]="Woodworking skill +2", 
        ["id"]=10948, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Carver's Torque", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [47]={
        ["discription"]="Improves mining, logging, and harvesting success rate", 
        ["id"]=11769, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Field Rope", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [48]={
        ["discription"]="+20 Elemental magic skill +7 Dark magic skill +7 On Darksdays: Elemental magic skill +10 Dark magic skill +10", 
        ["id"]=11589, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Aesir Torque", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [49]={
        ["discription"]="Enchantment: Teleport (Party Leader)", 
        ["id"]=11538, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Nexus Cape", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [50]={
        ["discription"]="+20 Healing magic skill +7 Enhancing magic skill +7 On Lightsdays: Healing magic skill +10 Enhancing magic skill +10", 
        ["id"]=11590, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Colossus's Torque", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [51]={
        ["discription"]="DMG:36 Delay:236 STR+3 Attack+10 Additional effect: Fire damage", 
        ["category"]="Weapon", 
        ["en"]="Ifrit's Blade", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=236, 
        ["STR"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [16]="BLU"
        }, 
        ["Attack"]=10, 
        ["id"]=17665, 
        ["skill"]="Sword", 
        ["damage"]=36
    }, 
    [52]={
        ["en"]="Matre Bell", 
        ["id"]=21460, 
        ["skill"]="Handbell", 
        ["slots"]={
            [2]="Range"
        }, 
        ["category"]="Weapon", 
        ["discription"]="MP+5", 
        ["MP"]=5, 
        ["jobs"]={
            [21]="GEO"
        }
    }, 
    [53]={
        ["discription"]="Attack+7 \"Conserve TP\"+3 Dark weather: \"Conserve TP\"+6", 
        ["id"]=16057, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Aesir Ear Pendant", 
        ["Attack"]=7, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [54]={
        ["discription"]="HP+10 MP+10 Physical damage taken -1% Light weather: Physical damage taken -2%", 
        ["category"]="Armor", 
        ["en"]="Colossus's Earring", 
        ["HP"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=16058, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["MP"]=10, 
        ["PDT"]=-2
    }, 
    [55]={
        ["Attack"]=10, 
        ["en"]="Volunteer's Dart", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["discription"]="Besieged: Attack+10 ", 
        ["id"]=18689, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [56]={
        ["MDT"]=-2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Lieutenant's Sash", 
        ["BDT"]=-2, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=15912, 
        ["DEF"]=5, 
        ["discription"]="DEF:5 HP+15 MP+15 Magic damage taken -2% Breath damage taken -2% Enchantment: Removes food effect", 
        ["MP"]=15, 
        ["HP"]=15
    }, 
    [57]={
        ["discription"]="Enchantment: Costume", 
        ["id"]=15929, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Goblin Belt", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [58]={
        ["discription"]="DMG:9 Delay:286 AGI+1", 
        ["category"]="Weapon", 
        ["en"]="Rogetsurin", 
        ["skill"]="Throwing", 
        ["delay"]=286, 
        ["AGI"]=1, 
        ["slots"]={
            [2]="Range"
        }, 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["id"]=18246, 
        ["damage"]=9
    }, 
    [59]={
        ["discription"]="DEF:26 Adds \"Regen\" effect Light Spirit perpetuation cost -1", 
        ["DEF"]=26, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Nimbus Doublet", 
        ["id"]=14410, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [15]="SMN"
        }
    }, 
    [60]={
        ["discription"]="DEF:32 Ranged Accuracy+2 Haste+4%", 
        ["Ranged Accuracy"]=2, 
        ["category"]="Armor", 
        ["en"]="Rapparee Harness", 
        ["jobs"]={
            [6]="THF", 
            [19]="DNC"
        }, 
        ["DEF"]=32, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=14403, 
        ["Haste"]=4
    }, 
    [61]={
        ["discription"]="DMG:1 Delay:999 +3", 
        ["en"]="Hoe", 
        ["skill"]="Scythe", 
        ["delay"]=999, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=20909, 
        ["damage"]=1
    }, 
    [62]={
        ["discription"]="DEF:3 DEX+3 AGI+3", 
        ["category"]="Armor", 
        ["en"]="Bounding Boots", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=3, 
        ["DEX"]=3, 
        ["id"]=15351, 
        ["AGI"]=3
    }, 
    [63]={
        ["Parrying skill"]=5, 
        ["category"]="Armor", 
        ["en"]="Prf. Gloves", 
        ["VIT"]=2, 
        ["discription"]="DEF:11  In areas outside own nation's control:  VIT+2 Evasion skill +5  Parrying skill +5", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=11, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=14015, 
        ["Evasion skill"]=5
    }, 
    [64]={
        ["discription"]="DEF:15  In areas outside own nation's control:  AGI+2 Evasion skill +10", 
        ["category"]="Armor", 
        ["en"]="Mst.Cst. Mitts", 
        ["AGI"]=2, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [9]="BST", 
            [10]="BRD", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=15, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=14016, 
        ["Evasion skill"]=10
    }, 
    [65]={
        ["discription"]="DEF:28 MP+20 Accuracy+6 Besieged: MP+100", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["category"]="Armor", 
        ["en"]="Volunteer's Brais", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15623, 
        ["DEF"]=28, 
        ["Accuracy"]=6, 
        ["MP"]=100
    }, 
    [66]={
        ["discription"]="In areas outside own nation's control:  MP+50", 
        ["MP"]=50, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=13141, 
        ["en"]="Rep.Gold Medal", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [67]={
        ["discription"]="DEF:36 Wyvern: HP+65 HP recovered while healing +1", 
        ["DEF"]=36, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Wyvern Mail", 
        ["id"]=14405, 
        ["category"]="Armor", 
        ["jobs"]={
            [14]="DRG"
        }
    }, 
    [68]={
        ["discription"]="DEF:9 STR+2 MND+2", 
        ["MND"]=2, 
        ["category"]="Armor", 
        ["en"]="Ryl. Army Mantle", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=9, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=13580, 
        ["STR"]=2
    }, 
    [69]={
        ["discription"]="DEF:6 HP+6 DEX+2 VIT+2", 
        ["category"]="Armor", 
        ["en"]="Rep. Army Mantle", 
        ["DEX"]=2, 
        ["HP"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=6, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=13582, 
        ["VIT"]=2
    }, 
    [70]={
        ["discription"]="DEF:18  In areas outside own nation's control:  Adds \"Regen\" effect", 
        ["DEF"]=18, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="President. Hairpin", 
        ["id"]=13880, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [13]="NIN", 
            [14]="DRG", 
            [19]="DNC"
        }
    }, 
    [71]={
        ["discription"]="DMG:1 Delay:288  Enchantment: Give gift to party member (Cannot target self)", 
        ["en"]="Nmd. Moogle Rod", 
        ["skill"]="Club", 
        ["delay"]=288, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18842, 
        ["damage"]=1
    }, 
    [72]={
        ["discription"]="DMG:1 Delay:366 Enchantment: \"Retrace\" (San d'Oria)", 
        ["en"]="Ram Staff", 
        ["skill"]="Staff", 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18612, 
        ["damage"]=1
    }, 
    [73]={
        ["discription"]="DMG:55 Delay:402 CHR+4 TP Bonus Latent effect: Light damage Enchantment: Recover HP", 
        ["category"]="Weapon", 
        ["en"]="Carbuncle's Pole", 
        ["skill"]="Staff", 
        ["delay"]=402, 
        ["CHR"]=4, 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18581, 
        ["damage"]=55
    }, 
    [74]={
        ["discription"]="DMG:1 Delay:366 Enchantment: \"Retrace\" (Windurst)", 
        ["en"]="Cobra Staff", 
        ["skill"]="Staff", 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18614, 
        ["damage"]=1
    }, 
    [75]={
        ["discription"]="DEF:3～", 
        ["DEF"]=3, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Variable Mantle", 
        ["id"]=13680, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [76]={
        ["discription"]="DEF:28 Accuracy+3 Attack+3", 
        ["jobs"]={
            [5]="RDM", 
            [10]="BRD", 
            [16]="BLU", 
            [18]="PUP", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Cerise Doublet", 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=14407, 
        ["DEF"]=28, 
        ["Accuracy"]=3, 
        ["Attack"]=3
    }, 
    [77]={
        ["discription"]="Enchantment: DEX+1～8", 
        ["en"]="Random Ring", 
        ["DEX"]=1, 
        ["id"]=15770, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [78]={
        ["discription"]="Enchantment: Fishing support", 
        ["id"]=15452, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Fisherman's Belt", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [79]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Yoran Unity Shirt", 
        ["id"]=25743, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [80]={
        ["discription"]="DEF:6 MP+6 AGI+2 INT+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["INT"]=2, 
        ["category"]="Armor", 
        ["en"]="Fed. Army Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=13581, 
        ["DEF"]=6, 
        ["MP"]=6, 
        ["AGI"]=2
    }, 
    [81]={
        ["Attack"]=10, 
        ["en"]="Fenrir's Earring", 
        ["id"]=13399, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Daytime: Attack+10 Nighttime: Ranged Attack+10", 
        ["Ranged Attack"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [82]={
        ["id"]=15880, 
        ["en"]="Key Ring Belt", 
        ["DEF"]=2, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:2 DEX+1 \"Steal\"+1 Dispense: Skeleton Key", 
        ["DEX"]=1, 
        ["jobs"]={
            [6]="THF"
        }
    }, 
    [83]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Councilor's Cuffs", 
        ["id"]=28063, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [84]={
        ["Magic Accuracy"]=2, 
        ["en"]="Diabolos's Earring", 
        ["Accuracy"]=-3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Accuracy+3 Dark weather: Accuracy-3 Magic Accuracy+2", 
        ["id"]=14814, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [85]={
        ["discription"]="DEF:1 While in Adoulin: Movement speed +25%", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Councilor's Garb", 
        ["id"]=27923, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [86]={
        ["discription"]="DMG:1 Delay:366 Enchantment: \"Retrace\" (Bastok)", 
        ["en"]="Fourth Staff", 
        ["skill"]="Staff", 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18613, 
        ["damage"]=1
    }, 
    [87]={
        ["discription"]="A dark orichalcum crown set with glittering painites. The message \"Gifted to the champion of Aht Urhgan by Her Magnificence, Nashmeira II\" is inscribed on the inside of the crown.", 
        ["id"]=16070, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Glory Crown", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [88]={
        ["discription"]="DEF:33 Enhances \"Souleater\" effect", 
        ["DEF"]=33, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Gloom Breastplate", 
        ["id"]=14409, 
        ["category"]="Armor", 
        ["jobs"]={
            [8]="DRK"
        }
    }, 
    [89]={
        ["discription"]="HP+10 Increases combat skill gain rate", 
        ["en"]="Terminus Earring", 
        ["HP"]=10, 
        ["id"]=11040, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [90]={
        ["discription"]="MP+10 Increases magic skill gain rate", 
        ["MP"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=11041, 
        ["en"]="Liminus Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [91]={
        ["en"]="Prouesse Ring", 
        ["id"]=11677, 
        ["MP"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="HP+10 MP+10 Increases combat skill gain rate", 
        ["HP"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [92]={
        ["discription"]="Enchantment: \"Teleport\" (Wajaom Woodlands)", 
        ["id"]=15769, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Olduum Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [93]={
        ["discription"]="Cannot Equip Leggear DEF:2 +3", 
        ["DEF"]=2, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Overalls", 
        ["id"]=27879, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [94]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Alliance Shirt", 
        ["id"]=27899, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [95]={
        ["discription"]="DEF:6 DEX+1 AGI+1 In areas outside own nation's control: Converts 40 MP to HP", 
        ["category"]="Armor", 
        ["en"]="Intruder Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=6, 
        ["DEX"]=1, 
        ["id"]=14806, 
        ["AGI"]=1
    }, 
    [96]={
        ["discription"]="DEF:1 +3", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Work Gloves", 
        ["id"]=28023, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [97]={
        ["discription"]="DEF:1 Enchantment: \"Teleport\" (Castle Zvahl Keep)", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Shadow Lord Shirt", 
        ["id"]=26517, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [98]={
        ["discription"]="DEF:10 +10 +10 +10 +10 +10 +10 -50 +10 Enchantment: Calls Choplix", 
        ["DEF"]=10, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Choplix's Coif", 
        ["id"]=15217, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [99]={
        ["discription"]="DEF:6 MP+12 INT+1 MND+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["INT"]=1, 
        ["MND"]=2, 
        ["category"]="Armor", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=12973, 
        ["DEF"]=6, 
        ["MP"]=12, 
        ["en"]="Mannequin Pumps"
    }, 
    [100]={
        ["discription"]="DEF:1 +3", 
        ["DEF"]=1, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Thatch Boots", 
        ["id"]=28302, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [101]={
        ["discription"]="STR+1 INT+1", 
        ["category"]="Weapon", 
        ["en"]="Balm Sachet", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["INT"]=1, 
        ["STR"]=1, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18247, 
        ["skill"]="(N/A)"
    }, 
    [102]={
        ["discription"]="STR+1 DEX+1 VIT+1  AGI+1 INT+1 MND+1 CHR-7", 
        ["category"]="Armor", 
        ["DEX"]=1, 
        ["en"]="Opo-opo Crown", 
        ["STR"]=1, 
        ["MND"]=1, 
        ["CHR"]=-7, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=13870, 
        ["INT"]=1, 
        ["AGI"]=1, 
        ["slots"]={
            [4]="Head"
        }, 
        ["VIT"]=1
    }, 
    [103]={
        ["discription"]="DEF:26 \"Conserve MP\"+4 Dark Spirit perpetuation cost -1", 
        ["DEF"]=26, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Duende Cotehardie", 
        ["id"]=14401, 
        ["category"]="Armor", 
        ["jobs"]={
            [4]="BLM", 
            [15]="SMN", 
            [21]="GEO"
        }
    }, 
    [104]={
        ["id"]=14402, 
        ["en"]="Nokizaru Gi", 
        ["DEF"]=31, 
        ["slots"]={
            [5]="Body"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:31 AGI+4 Enmity+1", 
        ["AGI"]=4, 
        ["jobs"]={
            [13]="NIN"
        }
    }, 
    [105]={
        ["discription"]="DEF:50 INT+13 MND+13 CHR+13 Summoning magic skill +10 Light Elemental Magic Accuracy+10 Enmity-5", 
        ["MND"]=13, 
        ["category"]="Armor", 
        ["en"]="Augur's Jaseran", 
        ["CHR"]=13, 
        ["INT"]=13, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=14365, 
        ["DEF"]=50, 
        ["Magic Accuracy"]=10
    }, 
    [106]={
        ["id"]=11799, 
        ["en"]="Zelus Tiara", 
        ["Haste"]=8, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="Evasion-5 Haste+8%", 
        ["Evasion"]=-5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [107]={
        ["discription"]="DMG:55 Delay:224 HP+50 MP+50 STR+10 VIT+10 Resistance against terror", 
        ["category"]="Weapon", 
        ["HP"]=50, 
        ["en"]="Talekeeper", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=224, 
        ["STR"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [14]="DRG", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["MP"]=50, 
        ["VIT"]=10, 
        ["id"]=18903, 
        ["skill"]="Sword", 
        ["damage"]=55
    }, 
    [108]={
        ["Haste"]=5, 
        ["en"]="Goading Belt", 
        ["Store TP"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="Haste+5% \"Store TP\"+5 Enmity+3", 
        ["id"]=11729, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [109]={
        ["discription"]="Haste+6%", 
        ["Haste"]=6, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Velocious Belt", 
        ["id"]=15899, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [110]={
        ["id"]=10537, 
        ["en"]="Auspex Gages", 
        ["DEF"]=28, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:28 MP+50 Spell interruption rate down 17% Enhances avatar attack Increases \"Blood Pact\" damage", 
        ["MP"]=50, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [111]={
        ["discription"]="HP+30 MP+30 Haste+5%", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Walahra Turban", 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15270, 
        ["Haste"]=5, 
        ["MP"]=30, 
        ["HP"]=30
    }, 
    [112]={
        ["discription"]="DMG:45 Delay:222 DEX+10 Enhances \"Fast Cast\" effect", 
        ["category"]="Weapon", 
        ["en"]="Hochomasamune", 
        ["DEX"]=10, 
        ["delay"]=222, 
        ["skill"]="Katana", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=19282, 
        ["damage"]=45
    }, 
    [113]={
        ["discription"]="DEF:39 STR+3 DEX+3 AGI-3 Accuracy+7 Attack+7", 
        ["category"]="Armor", 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Thrk. Breastplate", 
        ["STR"]=3, 
        ["AGI"]=-3, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=39, 
        ["DEX"]=3, 
        ["Accuracy"]=7, 
        ["id"]=11343, 
        ["Attack"]=7
    }, 
    [114]={
        ["discription"]="DMG:46 Delay:210 AGI+3 Attack+5", 
        ["category"]="Weapon", 
        ["en"]="Angr Harpe", 
        ["AGI"]=3, 
        ["delay"]=210, 
        ["skill"]="Dagger", 
        ["jobs"]={
            [6]="THF", 
            [19]="DNC"
        }, 
        ["Attack"]=5, 
        ["id"]=19137, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=46
    }, 
    [115]={
        ["discription"]="DEF:59 Accuracy+25 +15 \"Store TP\"+5", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Taranis's Harness", 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=11360, 
        ["DEF"]=59, 
        ["Accuracy"]=25, 
        ["Store TP"]=5
    }, 
    [116]={
        ["PDT"]=-2, 
        ["en"]="Eisen Grip", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["discription"]="Physical damage taken -2%", 
        ["id"]=19050, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }
    }, 
    [117]={
        ["discription"]="STR+4 Great Axe skill +4 Scythe skill +4", 
        ["category"]="Weapon", 
        ["en"]="Uther's Grip", 
        ["STR"]=4, 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Scythe skill"]=4, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["id"]=18804, 
        ["Great Axe skill"]=4
    }, 
    [118]={
        ["Ranged Attack"]=7, 
        ["category"]="Armor", 
        ["en"]="Loki's Kaftan", 
        ["Store TP"]=7, 
        ["DEX"]=11, 
        ["AGI"]=11, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=14337, 
        ["DEF"]=58, 
        ["discription"]="DEF:58 DEX+11 AGI+11 Ranged Attack+7 \"Store TP\"+7 Increases critical hit damage"
    }, 
    [119]={
        ["discription"]="DEF:28 STR+3 AGI+3 Critical hit rate +3%", 
        ["category"]="Armor", 
        ["en"]="Leonine Mask", 
        ["slots"]={
            [4]="Head"
        }, 
        ["Critical hit rate"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [13]="NIN", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=28, 
        ["STR"]=3, 
        ["id"]=16151, 
        ["AGI"]=3
    }, 
    [120]={
        ["discription"]="DEF:80 HP+100 Damage taken -11%  Enmity+9 \"Slow\"+2%", 
        ["category"]="Armor", 
        ["en"]="Laeradr Breastplate", 
        ["Slow"]=2, 
        ["HP"]=100, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK"
        }, 
        ["DEF"]=80, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=10280, 
        ["DT"]=-11
    }, 
    [121]={
        ["discription"]="DEF:49 STR+10 DEX+10 VIT+10 Accuracy+12 \"Triple Attack\"+1% Occasionally absorbs magic damage taken", 
        ["category"]="Armor", 
        ["en"]="Nocturnus Mail", 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEX"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEF"]=49, 
        ["STR"]=10, 
        ["Accuracy"]=12, 
        ["id"]=11354, 
        ["VIT"]=10
    }, 
    [122]={
        ["id"]=15736, 
        ["en"]="Trotter Boots", 
        ["DEF"]=4, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:4 AGI+2 Movement speed +12%", 
        ["AGI"]=2, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG"
        }
    }, 
    [123]={
        ["id"]=14468, 
        ["en"]="Yinyang Robe", 
        ["DEF"]=43, 
        ["slots"]={
            [5]="Body"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:43 MP+25 Adds \"Refresh\" effect \"Blood Pact\" ability delay -5 Avatar: Enmity+5", 
        ["MP"]=25, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [124]={
        ["discription"]="DEF:42 HP-1% Accuracy+3 Attack+18", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Assault Jerkin", 
        ["HP"]=-1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=13805, 
        ["DEF"]=42, 
        ["Accuracy"]=3, 
        ["Attack"]=18
    }, 
    [125]={
        ["Evasion"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Ocelot Trousers", 
        ["DEF"]=23, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15428, 
        ["Haste"]=4, 
        ["Accuracy"]=6, 
        ["discription"]="DEF:23 Accuracy+6 Evasion+10 Haste+4% Enmity+6"
    }, 
    [126]={
        ["discription"]="DEF:20 Garuda: Perpetuation cost -2 Attack Bonus Defense Bonus", 
        ["DEF"]=20, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Karura Hachigane", 
        ["id"]=16154, 
        ["category"]="Armor", 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [127]={
        ["discription"]="Accuracy+3 Attack-5 Haste+4%", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Swift Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=15457, 
        ["Haste"]=4, 
        ["Accuracy"]=3, 
        ["Attack"]=-5
    }, 
    [128]={
        ["discription"]="DMG:23 Delay:231 Latent effect: DMG:36 Critical hit rate +6%", 
        ["en"]="Dissector", 
        ["skill"]="Sword", 
        ["delay"]=231, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["id"]=17699, 
        ["damage"]=23
    }, 
    [129]={
        ["Evasion"]=-7, 
        ["category"]="Armor", 
        ["en"]="Ace's Helm", 
        ["DEF"]=28, 
        ["STR"]=4, 
        ["jobs"]={
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["Haste"]=4, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Accuracy"]=7, 
        ["id"]=15223, 
        ["discription"]="DEF:28 STR+4 Accuracy+7 Evasion-7 Haste+4%"
    }, 
    [130]={
        ["MDT"]=-5, 
        ["category"]="Weapon", 
        ["en"]="Narigitsune", 
        ["discription"]="DMG:38 Delay:227 Evasion+5 Magic damage taken -5%", 
        ["delay"]=227, 
        ["skill"]="Katana", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Evasion"]=5, 
        ["id"]=19280, 
        ["damage"]=38
    }, 
    [131]={
        ["discription"]="DMG:38 Delay:176 \"Triple Attack\"+3% Increases \"Triple Attack\" damage", 
        ["en"]="Triplus Dagger", 
        ["skill"]="Dagger", 
        ["delay"]=176, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["id"]=19133, 
        ["damage"]=38
    }, 
    [132]={
        ["discription"]="DMG:35 Delay:224 +14 Occasionally attacks twice", 
        ["en"]="Joyeuse", 
        ["skill"]="Sword", 
        ["delay"]=224, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [14]="DRG", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["id"]=17652, 
        ["damage"]=35
    }, 
    [133]={
        ["discription"]="DMG:85 Delay:489 Attack+3 \"Triple Attack\"+3% Additional effect: Fire damage", 
        ["category"]="Weapon", 
        ["en"]="Algol", 
        ["skill"]="Great Sword", 
        ["delay"]=489, 
        ["Attack"]=3, 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["id"]=18385, 
        ["damage"]=85
    }, 
    [134]={
        ["discription"]="HP-15 DEX+3 AGI+3 Evasion+10", 
        ["category"]="Armor", 
        ["en"]="Empress Hairpin", 
        ["DEX"]=3, 
        ["HP"]=-15, 
        ["Evasion"]=10, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15224, 
        ["AGI"]=3
    }, 
    [135]={
        ["Evasion"]=3, 
        ["category"]="Weapon", 
        ["en"]="Shiranui", 
        ["skill"]="Katana", 
        ["delay"]=227, 
        ["discription"]="DMG:37 Delay:227 Evasion+3  Additional effect: Light damage", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=17774, 
        ["damage"]=37
    }, 
    [136]={
        ["id"]=11496, 
        ["en"]="Fenrir's Crown", 
        ["DEF"]=10, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:10 MP+12 Fenrir: Enhances accuracy", 
        ["MP"]=12, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [137]={
        ["discription"]="DMG:85 Delay:444 \"Regain\"+10 Additional effect: Terror", 
        ["en"]="Nightfall", 
        ["skill"]="Great Sword", 
        ["delay"]=444, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["id"]=19163, 
        ["damage"]=85
    }, 
    [138]={
        ["Evasion"]=8, 
        ["category"]="Weapon", 
        ["skill"]="Throwing", 
        ["en"]="Ungur Boomerang", 
        ["discription"]="DMG:30 Delay:220 HP+8 MP+8 +8 Evasion+8", 
        ["delay"]=220, 
        ["HP"]=8, 
        ["slots"]={
            [2]="Range"
        }, 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN"
        }, 
        ["MP"]=8, 
        ["id"]=18141, 
        ["damage"]=30
    }, 
    [139]={
        ["discription"]="DMG:33 Delay:312 Latent effect: DMG:46 Critical hit rate +6%", 
        ["en"]="Retributor", 
        ["skill"]="Axe", 
        ["delay"]=312, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [22]="RUN"
        }, 
        ["id"]=17944, 
        ["damage"]=33
    }, 
    [140]={
        ["discription"]="DMG:25 Delay:227 Latent effect: DMG:38 Critical hit rate +6%", 
        ["en"]="Senjuinrikio", 
        ["skill"]="Katana", 
        ["delay"]=227, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=17793, 
        ["damage"]=25
    }, 
    [141]={
        ["discription"]="DMG:24 Delay:185 Accuracy+3 Latent effect: Parrying skill +5", 
        ["category"]="Weapon", 
        ["en"]="Hototogisu", 
        ["skill"]="Katana", 
        ["delay"]=185, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=16899, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=3, 
        ["damage"]=24
    }, 
    [142]={
        ["Evasion"]=-2, 
        ["en"]="Anger Bomblet", 
        ["discription"]="Attack+2 Evasion-2 \"Double Attack\"+1%", 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [8]="DRK", 
            [13]="NIN"
        }, 
        ["id"]=19760, 
        ["Attack"]=2
    }, 
    [143]={
        ["discription"]="DEF:36 STR+4 VIT+4 Haste+3%", 
        ["category"]="Armor", 
        ["en"]="Barb. Zerehs", 
        ["DEF"]=36, 
        ["STR"]=4, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["Haste"]=3, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15617, 
        ["VIT"]=4
    }, 
    [144]={
        ["discription"]="DMG:11 Delay:264", 
        ["en"]="Octave Club", 
        ["skill"]="Club", 
        ["delay"]=264, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN"
        }, 
        ["id"]=18852, 
        ["damage"]=11
    }, 
    [145]={
        ["discription"]="DEF:8 Enhances pet accuracy", 
        ["DEF"]=8, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Herder's Subligar", 
        ["id"]=16368, 
        ["category"]="Armor", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }
    }, 
    [146]={
        ["discription"]="DMG:55 Delay:366 MP+30 Summoning magic skill +5 Avatar perpetuation cost -3", 
        ["category"]="Weapon", 
        ["en"]="Bahamut's Staff", 
        ["skill"]="Staff", 
        ["delay"]=366, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["id"]=17598, 
        ["slots"]={
            [0]="Main"
        }, 
        ["MP"]=30, 
        ["damage"]=55
    }, 
    [147]={
        ["discription"]="DMG:4 Delay:366 MP+30 Occasionally attacks 2 to 5 times", 
        ["category"]="Weapon", 
        ["en"]="Mercurial Pole", 
        ["skill"]="Staff", 
        ["delay"]=366, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [7]="PLD", 
            [10]="BRD", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=17586, 
        ["slots"]={
            [0]="Main"
        }, 
        ["MP"]=30, 
        ["damage"]=4
    }, 
    [148]={
        ["discription"]="DMG:30 Delay:150 AGI+6 Increases critical hit damage", 
        ["category"]="Weapon", 
        ["en"]="Oneiros Knife", 
        ["skill"]="Dagger", 
        ["delay"]=150, 
        ["AGI"]=6, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [5]="RDM", 
            [6]="THF", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN"
        }, 
        ["id"]=19141, 
        ["damage"]=30
    }, 
    [149]={
        ["discription"]="DMG:32 Delay:150 Accuracy+12 Haste+1%", 
        ["category"]="Weapon", 
        ["en"]="Rapidus Sax", 
        ["skill"]="Dagger", 
        ["delay"]=150, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["Haste"]=1, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=12, 
        ["id"]=19129, 
        ["damage"]=32
    }, 
    [150]={
        ["discription"]="DMG:39 Delay:201 \"Subtle Blow\"+10 Enhances \"Dual Wield\" effect", 
        ["category"]="Weapon", 
        ["en"]="Auric Dagger", 
        ["skill"]="Dagger", 
        ["delay"]=201, 
        ["Dual Wield"]=5, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF", 
            [19]="DNC"
        }, 
        ["id"]=17626, 
        ["damage"]=39
    }, 
    [151]={
        ["discription"]="DEF:24 STR+6 DEX+4 Attack+8 Slow +5%", 
        ["category"]="Armor", 
        ["en"]="Gnadbhod's Helm", 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEX"]=4, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=24, 
        ["STR"]=6, 
        ["id"]=16158, 
        ["Attack"]=8
    }, 
    [152]={
        ["discription"]="DMG:37 Delay:210 Enhances \"Resist Petrify\" effect", 
        ["en"]="Perseus's Harpe", 
        ["skill"]="Dagger", 
        ["delay"]=210, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF"
        }, 
        ["id"]=18002, 
        ["damage"]=37
    }, 
    [153]={
        ["discription"]="DMG:15 Delay:205 Latent effect: DMG:30 Critical hit rate +6%", 
        ["en"]="Heart Snatcher", 
        ["skill"]="Dagger", 
        ["delay"]=205, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["id"]=18005, 
        ["damage"]=15
    }, 
    [154]={
        ["discription"]="DMG:60 Delay:366 Summoning magic skill +7 \"Blood Boon\"+5 Avatar: Attack+10 \"Magic Atk. Bonus\"+5", 
        ["en"]="Soulscourge", 
        ["skill"]="Staff", 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["id"]=17105, 
        ["damage"]=60
    }, 
    [155]={
        ["discription"]="DMG:40 Delay:236 Occasionally attacks 2 to 3 times", 
        ["en"]="Ridill", 
        ["skill"]="Sword", 
        ["delay"]=236, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM"
        }, 
        ["id"]=16555, 
        ["damage"]=40
    }, 
    [156]={
        ["discription"]="DMG:104 Delay:504 STR+8 Additional effect: Amnesia", 
        ["category"]="Weapon", 
        ["en"]="Vermeil Bhuj", 
        ["STR"]=8, 
        ["delay"]=504, 
        ["skill"]="Great Axe", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["id"]=18510, 
        ["damage"]=104
    }, 
    [157]={
        ["discription"]="DMG:34 Delay:201 Increases critical hit damage", 
        ["en"]="X's Knife", 
        ["skill"]="Dagger", 
        ["delay"]=201, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF", 
            [9]="BST"
        }, 
        ["id"]=18019, 
        ["damage"]=34
    }, 
    [158]={
        ["discription"]="DMG:+22 Delay:+96 Critical hit rate +3% Additional effect: \"Kick Attacks\"+7", 
        ["category"]="Weapon", 
        ["en"]="Afflictors", 
        ["Critical hit rate"]=3, 
        ["delay"]=96, 
        ["skill"]="Hand-to-Hand", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [9]="BST", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["id"]=16428, 
        ["damage"]=22
    }, 
    [159]={
        ["id"]=11728, 
        ["en"]="Bullwhip Belt", 
        ["Haste"]=7, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="HP-75 -50 -50 -50 -50 -50 -50 Haste+7%", 
        ["HP"]=-75, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }
    }, 
    [160]={
        ["discription"]="Accuracy+10 Ranged Accuracy+10  Evasion+10", 
        ["Ranged Accuracy"]=10, 
        ["category"]="Armor", 
        ["en"]="Optical Hat", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=13915, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Accuracy"]=10, 
        ["Evasion"]=10
    }, 
    [161]={
        ["discription"]="Magic Accuracy+6 Enfeebling magic skill +15 Elemental magic skill +15 Dark magic skill +15", 
        ["id"]=11919, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Avesta Bangles", 
        ["Magic Accuracy"]=6, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [162]={
        ["VIT"]=4, 
        ["en"]="Bibiki Seashell", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["discription"]="VIT+4 +3  Enhances \"Aquan Killer\" effect", 
        ["id"]=18257, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [163]={
        ["discription"]="DMG:27 Delay:200 AGI+2 +8  \"Steal\"+2 Additional effect: Water damage", 
        ["category"]="Weapon", 
        ["en"]="Btm. Knife", 
        ["skill"]="Dagger", 
        ["delay"]=200, 
        ["AGI"]=2, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["id"]=17623, 
        ["damage"]=27
    }, 
    [164]={
        ["discription"]="DMG:26 Delay:150 -7 +7 Additional effect: Wind damage", 
        ["en"]="Sirocco Kukri", 
        ["skill"]="Dagger", 
        ["delay"]=150, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["id"]=18018, 
        ["damage"]=26
    }, 
    [165]={
        ["discription"]="DEF:22 DEX+4 AGI+8 Haste+3% Enmity+3", 
        ["category"]="Armor", 
        ["en"]="Ocelot Gloves", 
        ["DEF"]=22, 
        ["DEX"]=4, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=3, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=14887, 
        ["AGI"]=8
    }, 
    [166]={
        ["discription"]="DMG:49 Delay:236 MP+25 Additional effect: Damage varies with MP", 
        ["category"]="Weapon", 
        ["en"]="Tyrfing", 
        ["skill"]="Sword", 
        ["delay"]=236, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [16]="BLU"
        }, 
        ["id"]=16540, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["MP"]=25, 
        ["damage"]=49
    }, 
    [167]={
        ["discription"]="DMG:44 Delay:190 DEX+5 \"Ninja tool expertise\" Additional effect: Lowers enemy critical hit evasion", 
        ["category"]="Weapon", 
        ["en"]="Oirandori", 
        ["DEX"]=5, 
        ["delay"]=190, 
        ["skill"]="Katana", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=19291, 
        ["damage"]=44
    }, 
    [168]={
        ["discription"]="DMG:46 Delay:210 Latent effect: \"Blade: Metsu\"", 
        ["en"]="Sekirei", 
        ["skill"]="Katana", 
        ["delay"]=210, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=19288, 
        ["damage"]=46
    }, 
    [169]={
        ["Evasion"]=-10, 
        ["category"]="Armor", 
        ["en"]="Bandomusha Kote", 
        ["discription"]="DEF:21 HP+3% -5 +5 -5 +5 -5 +5 -5 +5 Attack+22 Evasion-10", 
        ["HP"]=3, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=21, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=14873, 
        ["Attack"]=22
    }, 
    [170]={
        ["discription"]="HP+30 CHR+1 -30", 
        ["category"]="Weapon", 
        ["en"]="Verthandi's Gem", 
        ["HP"]=30, 
        ["CHR"]=1, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=19244, 
        ["skill"]="(N/A)"
    }, 
    [171]={
        ["INT"]=-7, 
        ["en"]="Andvaranauts", 
        ["DEF"]=12, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:12 INT-7  \"Gilfinder\"+1", 
        ["id"]=14075, 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH"
        }
    }, 
    [172]={
        ["discription"]="DEF:18 DEX+2 INT+2 Accuracy+4 Enmity-4 Set: Increases pet defense and enmity", 
        ["INT"]=2, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=554
        }, 
        ["category"]="Armor", 
        ["en"]="Breeder Mufflers", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["DEF"]=18, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Accuracy"]=4, 
        ["id"]=15001, 
        ["DEX"]=2
    }, 
    [173]={
        ["discription"]="DMG:39 Delay:180 Accuracy+8 Attack+8 Increases critical hit damage", 
        ["category"]="Weapon", 
        ["en"]="Kamome", 
        ["skill"]="Katana", 
        ["delay"]=180, 
        ["Attack"]=8, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=8, 
        ["id"]=19287, 
        ["damage"]=39
    }, 
    [174]={
        ["discription"]="DMG:35 Delay:210 Accuracy+7 Magnus stone equipped: Occ. deals double damage", 
        ["category"]="Weapon", 
        ["en"]="Toki", 
        ["skill"]="Katana", 
        ["delay"]=210, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=19289, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=7, 
        ["damage"]=35
    }, 
    [175]={
        ["id"]=27656, 
        ["en"]="Nabu's Tiara", 
        ["DEF"]=30, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:30 MP+50 Enhancing magic skill +10 Avatar: Increases magic accuracy and  \"Magic Atk. Bonus\"", 
        ["MP"]=50, 
        ["jobs"]={
            [3]="WHM", 
            [10]="BRD", 
            [15]="SMN"
        }
    }, 
    [176]={
        ["en"]="Voyager Sallet", 
        ["id"]=15184, 
        ["DEX"]=4, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="STR+3 DEX+4", 
        ["STR"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [177]={
        ["discription"]="DMG:106 Delay:528 Additional effect: Darkness damage", 
        ["en"]="Plaga Scythe", 
        ["skill"]="Scythe", 
        ["delay"]=528, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["id"]=18961, 
        ["damage"]=106
    }, 
    [178]={
        ["discription"]="STR+1 Accuracy+3", 
        ["category"]="Weapon", 
        ["en"]="Astrolabe", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [14]="DRG", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=19239, 
        ["STR"]=1, 
        ["Accuracy"]=3, 
        ["skill"]="(N/A)"
    }, 
    [179]={
        ["discription"]="DEF:15 MND+7 CHR+7 Spell interruption rate down 10%", 
        ["CHR"]=7, 
        ["category"]="Armor", 
        ["en"]="Muse Tariqah", 
        ["jobs"]={
            [1]="WAR", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [9]="BST", 
            [12]="SAM"
        }, 
        ["DEF"]=15, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["id"]=16175, 
        ["MND"]=7
    }, 
    [180]={
        ["Evasion"]=-14, 
        ["category"]="Armor", 
        ["en"]="Oneiros Barbut", 
        ["VIT"]=9, 
        ["discription"]="DEF:30 VIT+9 Evasion-14 Physical damage taken -5% Reduces movement speed", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD"
        }, 
        ["DEF"]=30, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=11817, 
        ["PDT"]=-5
    }, 
    [181]={
        ["discription"]="DMG:35 Delay:286 AGI+6 +12 Evasion+6", 
        ["category"]="Weapon", 
        ["en"]="Aliyat Chakram", 
        ["Evasion"]=6, 
        ["delay"]=286, 
        ["skill"]="Throwing", 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["AGI"]=6, 
        ["id"]=19770, 
        ["slots"]={
            [2]="Range"
        }, 
        ["damage"]=35
    }, 
    [182]={
        ["id"]=11816, 
        ["en"]="Oneiros Helm", 
        ["DEF"]=28, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:28 DEX+13 \"Double Attack\"-3% \"Triple Attack\"-3% Increases critical hit damage", 
        ["DEX"]=13, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [14]="DRG", 
            [22]="RUN"
        }
    }, 
    [183]={
        ["discription"]="DEF:7 STR+7 Haste+12% \"Subtle Blow\"+5 Physical damage taken -5%", 
        ["category"]="Armor", 
        ["en"]="Black Belt", 
        ["DEF"]=7, 
        ["STR"]=7, 
        ["jobs"]={
            [2]="MNK"
        }, 
        ["Haste"]=12, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=13186, 
        ["PDT"]=-5
    }, 
    [184]={
        ["discription"]="DEF:33 AGI+10 MND+5 \"Subtle Blow\"+10", 
        ["MND"]=5, 
        ["category"]="Armor", 
        ["en"]="Ambusher's Hose", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=33, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=11935, 
        ["AGI"]=10
    }, 
    [185]={
        ["discription"]="DMG:109 Delay:196 Accuracy+15 Evasion+22 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Additional effect: Haste", 
        ["Evasion"]=22, 
        ["skill"]="Dagger", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Blurred Knife", 
        ["delay"]=196, 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["id"]=20601, 
        ["Dagger skill"]=242, 
        ["damage"]=109
    }, 
    [186]={
        ["Magic Accuracy"]=20, 
        ["category"]="Weapon", 
        ["MND"]=12, 
        ["INT"]=12, 
        ["Staff skill"]=242, 
        ["Magic Atk. Bonus"]=28, 
        ["item_level"]=119, 
        ["delay"]=412, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [7]="PLD", 
            [10]="BRD", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["skill"]="Staff", 
        ["discription"]="DMG:217 Delay:412 INT+12 MND+12 Magic Accuracy+20 \"Magic Atk. Bonus\"+28 Magic Damage+217 Staff skill +242 Parrying skill +242 Magic Accuracy skill +228 Additional effect: Haste", 
        ["slots"]={
            [0]="Main"
        }, 
        ["en"]="Blurred Staff", 
        ["id"]=21157, 
        ["Parrying skill"]=242, 
        ["damage"]=217
    }, 
    [187]={
        ["discription"]="DMG:92 Delay:192 HP+30 Throwing skill +215", 
        ["category"]="Weapon", 
        ["skill"]="Throwing", 
        ["item_level"]=117, 
        ["en"]="Suppa Shuriken", 
        ["delay"]=192, 
        ["Throwing skill"]=215, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["HP"]=30, 
        ["id"]=21356, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["damage"]=92
    }, 
    [188]={
        ["discription"]="Accuracy+6 \"Tonberry's Grudge\"", 
        ["Accuracy"]=6, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=10931, 
        ["en"]="Rancor Collar", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [189]={
        ["discription"]="DMG:66 Delay:280 MND+15 Enhances \"Starlight\" effect Additional effect: Regen", 
        ["category"]="Weapon", 
        ["en"]="Dukkha", 
        ["skill"]="Club", 
        ["delay"]=280, 
        ["MND"]=15, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=18887, 
        ["damage"]=66
    }, 
    [190]={
        ["discription"]="DMG:28 Delay:192 Magic Accuracy+8", 
        ["category"]="Weapon", 
        ["en"]="Aureole", 
        ["skill"]="Throwing", 
        ["delay"]=192, 
        ["Magic Accuracy"]=8, 
        ["slots"]={
            [2]="Range"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18245, 
        ["damage"]=28
    }, 
    [191]={
        ["discription"]="DEF:52 MP+30 STR+10 DEX+10 VIT+10  AGI+10 INT+10 MND+10 CHR+10  +50", 
        ["CHR"]=10, 
        ["MND"]=10, 
        ["category"]="Armor", 
        ["DEX"]=10, 
        ["en"]="Kirin's Osode", 
        ["AGI"]=10, 
        ["INT"]=10, 
        ["STR"]=10, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["MP"]=30, 
        ["DEF"]=52, 
        ["id"]=12562, 
        ["VIT"]=10
    }, 
    [192]={
        ["discription"]="DMG:48 Delay:264 HP-55 STR+3 Attack+10 Critical hit rate +3%", 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["en"]="Organics", 
        ["Critical hit rate"]=3, 
        ["HP"]=-55, 
        ["delay"]=264, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["id"]=17753, 
        ["STR"]=3, 
        ["Attack"]=10, 
        ["skill"]="Sword", 
        ["damage"]=48
    }, 
    [193]={
        ["discription"]="DMG:40 Delay:320  Enchantment: \"Reraise III\"", 
        ["en"]="Raphael's Rod", 
        ["skill"]="Club", 
        ["delay"]=320, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18398, 
        ["damage"]=40
    }, 
    [194]={
        ["discription"]="DMG:60 Delay:402 HP+20 MP+20 INT+10 MND+10 +15 +15 +15 +15 +15 +15 +15 +15", 
        ["category"]="Weapon", 
        ["HP"]=20, 
        ["en"]="Kirin's Pole", 
        ["skill"]="Staff", 
        ["delay"]=402, 
        ["MND"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [7]="PLD", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["MP"]=20, 
        ["INT"]=10, 
        ["id"]=17567, 
        ["slots"]={
            [0]="Main"
        }, 
        ["damage"]=60
    }, 
    [195]={
        ["discription"]="DMG:42 Delay:402 MP+20 \"Magic Atk. Bonus\"+25 MP recovered while healing +10", 
        ["category"]="Weapon", 
        ["en"]="Dorje", 
        ["Magic Atk. Bonus"]=25, 
        ["delay"]=402, 
        ["skill"]="Staff", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["MP"]=20, 
        ["id"]=18594, 
        ["damage"]=42
    }, 
    [196]={
        ["MDT"]=-8, 
        ["en"]="Minerva's Ring", 
        ["id"]=15550, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Physical damage taken +8% Magic damage taken -8%", 
        ["PDT"]=8, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [197]={
        ["discription"]="Capacity point bonus: +50% Maximum duration: 720 minutes Maximum bonus: 30000", 
        ["id"]=28546, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Capacity Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [198]={
        ["discription"]="Enchantment: Teleport (Crag of Dem) Destination is close to the dimensional portal in Konschtat Highlands.", 
        ["id"]=26177, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Dim. Ring (Dem)", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [199]={
        ["discription"]="DEF:1 Increases synthesis skill gain rate", 
        ["DEF"]=1, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Shaper's Shawl", 
        ["id"]=11009, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [200]={
        ["discription"]="Capacity point bonus: +200% Maximum duration: 720 minutes Maximum bonus: 30000", 
        ["id"]=28469, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Endorsement Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [201]={
        ["discription"]="DEF:6 Attack+6 Haste+6% \"Subtle Blow\"+6 Spell interruption rate down 6%", 
        ["category"]="Armor", 
        ["en"]="Ninurta's Sash", 
        ["Haste"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=6, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=15458, 
        ["Attack"]=6
    }, 
    [202]={
        ["discription"]="Evasion+7 Enmity-7", 
        ["en"]="Novia Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=14809, 
        ["Evasion"]=7, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [203]={
        ["discription"]="DEF:52 Accuracy+20 Attack+20 Critical hit rate +5% Enhances \"Zanshin\" effect Set: Enhances \"Store TP\" effect", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Store TP"]=5
                }, 
                [3]={
                    ["Store TP"]=10
                }, 
                [4]={
                    ["Store TP"]=15
                }, 
                [5]={}
            }, 
            ["set id"]=86
        }, 
        ["category"]="Armor", 
        ["en"]="Hachiryu Haramaki", 
        ["id"]=11281, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=52, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Accuracy"]=20, 
        ["Critical hit rate"]=5, 
        ["Attack"]=20
    }, 
    [204]={
        ["discription"]="Enchantment: Teleport (Crag of Mea) Destination is close to the dimensional portal Tahrongi Canyon.", 
        ["id"]=26178, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Dim. Ring (Mea)", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [205]={
        ["discription"]="DEF:42 STR+10 Attack+5 Enhances \"Zanshin\" effect Set: Enhances \"Store TP\" effect", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Store TP"]=5
                }, 
                [3]={
                    ["Store TP"]=10
                }, 
                [4]={
                    ["Store TP"]=15
                }, 
                [5]={}
            }, 
            ["set id"]=86
        }, 
        ["category"]="Armor", 
        ["en"]="Hachiryu Haidate", 
        ["STR"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=42, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=16337, 
        ["Attack"]=5
    }, 
    [206]={
        ["discription"]="STR+7 DEX+7 VIT+7 AGI+7 INT+7 MND+7 CHR+7 Enchantment: \"Teleport\" (Ru'Lude Gardens)", 
        ["category"]="Armor", 
        ["DEX"]=7, 
        ["en"]="Maat's Cap", 
        ["STR"]=7, 
        ["MND"]=7, 
        ["CHR"]=7, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15194, 
        ["INT"]=7, 
        ["AGI"]=7, 
        ["slots"]={
            [4]="Head"
        }, 
        ["VIT"]=7
    }, 
    [207]={
        ["discription"]="Accuracy+20 Ranged Accuracy+20 \"Store TP\"+5", 
        ["Ranged Accuracy"]=20, 
        ["category"]="Armor", 
        ["en"]="Ninja Nodowa +1", 
        ["Store TP"]=5, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=20, 
        ["id"]=25490
    }, 
    [208]={
        ["discription"]="HP+30 Damage taken -3% Avatar: Accuracy+15 Ranged Accuracy+15 Magic Accuracy+15", 
        ["en"]="Summoner's Collar", 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["HP"]=30, 
        ["category"]="Armor", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["id"]=25501, 
        ["DT"]=-3
    }, 
    [209]={
        ["discription"]="DMG:262 Delay:507 Accuracy+20 Polearm skill +242 Parrying skill +242 Magic Accuracy skill +188 Additional effect: Haste", 
        ["category"]="Weapon", 
        ["Parrying skill"]=242, 
        ["en"]="Blurred Lance", 
        ["Polearm skill"]=242, 
        ["delay"]=507, 
        ["skill"]="Polearm", 
        ["jobs"]={
            [1]="WAR", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["Accuracy"]=20, 
        ["item_level"]=119, 
        ["id"]=20940, 
        ["slots"]={
            [0]="Main"
        }, 
        ["damage"]=262
    }, 
    [210]={
        ["discription"]="HP+70 Enmity+5  Enhances resistance against \"Death\"", 
        ["en"]="Eihwaz Ring", 
        ["HP"]=70, 
        ["id"]=10798, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [211]={
        ["Attack"]=5, 
        ["Ranged Accuracy"]=10, 
        ["Throwing skill"]=242, 
        ["en"]="Togakushi Shuriken", 
        ["category"]="Weapon", 
        ["AGI"]=3, 
        ["item_level"]=119, 
        ["delay"]=192, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["skill"]="Throwing", 
        ["discription"]="DMG:104 Delay:192 VIT+3 AGI+3 Accuracy+5 Attack+5 Ranged Accuracy+10 Throwing skill +242", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["VIT"]=3, 
        ["id"]=21357, 
        ["Accuracy"]=5, 
        ["damage"]=104
    }, 
    [212]={
        ["discription"]="DMG:1 Delay:366 Enchantment: \"Signet\"", 
        ["en"]="Rep. Signet Staff", 
        ["skill"]="Staff", 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=17584, 
        ["damage"]=1
    }, 
    [213]={
        ["discription"]="Capacity point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["id"]=27557, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Trizek Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [214]={
        ["discription"]="HP+55 \"Magic Def. Bonus\"+4 Enmity+4", 
        ["en"]="Vexer Ring +1", 
        ["HP"]=55, 
        ["id"]=28584, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [215]={
        ["Evasion"]=-8, 
        ["Ranged Accuracy"]=8, 
        ["category"]="Armor", 
        ["en"]="Bellona's Ring", 
        ["Ranged Attack"]=8, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=-8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15549, 
        ["discription"]="Ranged Accuracy+8 Ranged Attack+8 Evasion-8 DEF-8"
    }, 
    [216]={
        ["discription"]="Capacity point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["id"]=26165, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Facility Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [217]={
        ["Evasion"]=13, 
        ["category"]="Armor", 
        ["en"]="Kasiri Belt", 
        ["DEF"]=13, 
        ["HP"]=30, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=4, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28456, 
        ["discription"]="DEF:13 HP+30 Evasion+13 Enmity+3 Haste+4%"
    }, 
    [218]={
        ["discription"]="Enchantment: \"Teleport\" (Tavnazian Safehold)", 
        ["id"]=14672, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Tavnazian Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [219]={
        ["discription"]="DEF:11 AGI+10 Attack-5 Evasion+10 \"Resist Gravity\"+15", 
        ["category"]="Armor", 
        ["en"]="Svelt. Gouriz +1", 
        ["AGI"]=10, 
        ["Evasion"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=11, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28436, 
        ["Attack"]=-5
    }, 
    [220]={
        ["Evasion"]=-8, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Mars's Ring", 
        ["discription"]="Accuracy+8 Attack+8 Evasion-8 DEF-8", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15548, 
        ["DEF"]=-8, 
        ["Accuracy"]=8, 
        ["Attack"]=8
    }, 
    [221]={
        ["discription"]="Accuracy+15 Magic Accuracy+15 \"Triple Attack\" damage +3", 
        ["category"]="Armor", 
        ["en"]="Assassin's Gorget", 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["id"]=25447, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=15, 
        ["Magic Accuracy"]=15
    }, 
    [222]={
        ["discription"]="DEF:1 Increases chances of obtaining crystals In Bastok: Movement speed +12%", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Republic Aketon", 
        ["id"]=14429, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [223]={
        ["discription"]="Accuracy+15 Attack+15 Critical hit rate +2% Wyvern: Lv.+1", 
        ["category"]="Armor", 
        ["en"]="Dragoon's Collar", 
        ["id"]=25495, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["Critical hit rate"]=2, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=15, 
        ["Attack"]=15
    }, 
    [224]={
        ["discription"]="DMG:140 Delay:240 Accuracy+20 Magic Accuracy+20 Sword skill +223 Parrying skill +223 Magic Accuracy skill +223", 
        ["item_level"]=119, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["Sword skill"]=223, 
        ["en"]="Ajja Sword", 
        ["delay"]=240, 
        ["Parrying skill"]=223, 
        ["skill"]="Sword", 
        ["Accuracy"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["id"]=21618, 
        ["Magic Accuracy"]=20, 
        ["damage"]=140
    }, 
    [225]={
        ["discription"]="Experience point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["id"]=27556, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Echad Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [226]={
        ["discription"]="DMG:274 Delay:420 STR+15 Accuracy+47 Katana skill +228 Parrying skill +228 Magic Accuracy skill +188 Weapon Skill Accuracy+25 Adds \"Tachi: Gekko\" effect", 
        ["skill"]="Great Katana", 
        ["STR"]=15, 
        ["category"]="Weapon", 
        ["en"]="Beryllium Tachi", 
        ["item_level"]=119, 
        ["delay"]=420, 
        ["Parrying skill"]=228, 
        ["slots"]={
            [0]="Main"
        }, 
        ["Accuracy"]=25, 
        ["jobs"]={
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["id"]=21963, 
        ["Katana skill"]=228, 
        ["damage"]=274
    }, 
    [227]={
        ["discription"]="Accuracy+15 Ranged Accuracy+15 \"Store TP\"+3", 
        ["Ranged Accuracy"]=15, 
        ["category"]="Armor", 
        ["en"]="Ninja Nodowa", 
        ["Store TP"]=3, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=15, 
        ["id"]=25489
    }, 
    [228]={
        ["discription"]="Physical damage taken +5% Pet: \"Regen\"+1 Physical damage taken -5%", 
        ["id"]=26079, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Hypaspist Earring", 
        ["PDT"]=5, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [229]={
        ["discription"]="DEF:8 Attack+8 Enhances \"Dual Wield\" effect \"Store TP\"+5", 
        ["category"]="Armor", 
        ["en"]="Patentia Sash", 
        ["Store TP"]=5, 
        ["Dual Wield"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=10838, 
        ["Attack"]=8
    }, 
    [230]={
        ["INT"]=3, 
        ["en"]="Strophadic Earring", 
        ["Magic Atk. Bonus"]=4, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="INT+3 \"Magic Atk. Bonus\"+4 Elemental magic skill +4", 
        ["id"]=11035, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [231]={
        ["MDT"]=-8, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Reiki Cloak", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=27615, 
        ["DEF"]=19, 
        ["discription"]="DEF:19 HP+130 Enmity+6 Enemy critical hit rate -3% Magic damage taken -8%", 
        ["HP"]=130
    }, 
    [232]={
        ["en"]="Seraphicaller", 
        ["id"]=21381, 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["discription"]="\"Blood Pact\" recast time II -5 Avatar: Lv. 119", 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [233]={
        ["discription"]="HP+75 -75", 
        ["en"]="Bomb Queen Ring", 
        ["HP"]=75, 
        ["id"]=13567, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [234]={
        ["discription"]="DEF:12 MP+25 Magic Accuracy+5 \"Magic Atk. Bonus\"+10 \"Conserve MP\"+2 ", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Izdubar Mantle", 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=27616, 
        ["DEF"]=12, 
        ["MP"]=25, 
        ["Magic Accuracy"]=5
    }, 
    [235]={
        ["discription"]="DEF:18 \"Last Resort\" effect duration +15 \"Absorb\" effect duration +10%", 
        ["DEF"]=18, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Ankou's Mantle", 
        ["id"]=26253, 
        ["category"]="Armor", 
        ["jobs"]={
            [8]="DRK"
        }
    }, 
    [236]={
        ["discription"]="DEF:9 Magic Damage+5 Converts 110 HP to MP Unity Ranking: Enmity-3～7", 
        ["DEF"]=9, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Mephitas's Ring +1", 
        ["id"]=27559, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [237]={
        ["discription"]="DEF:5 Summoning magic skill +7 \"Blood Boon\"+5 Avatar perpetuation cost -2", 
        ["DEF"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Lucidity Sash", 
        ["id"]=28416, 
        ["category"]="Armor", 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [238]={
        ["discription"]="DEF:20 HP+100 MP+100 Accuracy+5 Damage taken -3%", 
        ["category"]="Armor", 
        ["en"]="Xucau Mantle", 
        ["Accuracy"]=5, 
        ["HP"]=100, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=20, 
        ["slots"]={
            [15]="Back"
        }, 
        ["MP"]=100, 
        ["id"]=27614, 
        ["DT"]=-3
    }, 
    [239]={
        ["discription"]="DEF:10 Attack+20 \"Store TP\"+7 \"Resist Stun\"+10", 
        ["category"]="Armor", 
        ["en"]="Anu Torque", 
        ["Store TP"]=7, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [14]="DRG", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=10, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=26029, 
        ["Attack"]=20
    }, 
    [240]={
        ["discription"]="Magic Accuracy+2 Enhances \"Resist Poison\" effect Enhances \"Resist Silence\" effect Enhances \"Resist Virus\" effect", 
        ["id"]=15827, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Insect Ring", 
        ["Magic Accuracy"]=2, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [241]={
        ["discription"]="INT+4 MND+4 \"Magic Atk. Bonus\"+8 Magic burst damage +10 \"Resist Charm\"+5", 
        ["MND"]=4, 
        ["category"]="Armor", 
        ["en"]="Mizu. Kubikazari", 
        ["INT"]=4, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=28379, 
        ["Magic Atk. Bonus"]=8
    }, 
    [242]={
        ["id"]=15518, 
        ["en"]="M. No.17's Locket", 
        ["DEF"]=2, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:2 MP+10 +30 Enhances \"Resist Charm\" effect", 
        ["MP"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [243]={
        ["MDT"]=-3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Etiolation Earring", 
        ["HP"]=50, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["MP"]=50, 
        ["id"]=28478, 
        ["discription"]="HP+50 MP+50 \"Fast Cast\"+1% Magic damage taken -3% \"Resist Silence\"+15 ", 
        ["Fast Cast"]=1
    }, 
    [244]={
        ["discription"]="Evasion+9 \"Subtle Blow\"+9", 
        ["en"]="Torero Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=11626, 
        ["Evasion"]=9, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [245]={
        ["discription"]="DEF:3 \"Blood Boon\"+3 Diabolos perpetuation cost -1", 
        ["DEF"]=3, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Diabolos's Rope", 
        ["id"]=11752, 
        ["category"]="Armor", 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [246]={
        ["discription"]="Blood Boon+3 Avatar: Accuracy+5 Magic Accuracy+5 Enmity+5", 
        ["id"]=26000, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Consumm. Torque", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [247]={
        ["discription"]="STR+6 DEX+6 AGI+6 \"Store TP\"+3 \"Subtle Blow\"+5", 
        ["category"]="Armor", 
        ["en"]="Apate Ring", 
        ["Store TP"]=3, 
        ["DEX"]=6, 
        ["STR"]=6, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26173, 
        ["AGI"]=6
    }, 
    [248]={
        ["discription"]="DEF:16 AGI+6 Accuracy+10 Evasion+15 \"Triple Attack\"+2%", 
        ["category"]="Armor", 
        ["id"]=28622, 
        ["en"]="Canny Cape", 
        ["DEX"]=2, 
        ["AGI"]=9, 
        ["Evasion"]=15, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=10, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["augments"]={
            [1]="DEX+2", 
            [2]="AGI+3", 
            [3]="\"Dual Wield\"+5", 
            [4]="none", 
            [5]="none"
        }, 
        ["DEF"]=16, 
        ["Dual Wield"]=5
    }, 
    [249]={
        ["discription"]="INT+5 Scythe skill +5 Staff skill +5", 
        ["INT"]=5, 
        ["category"]="Armor", 
        ["en"]="Aife's Annulet", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Scythe skill"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=10759, 
        ["Staff skill"]=5
    }, 
    [250]={
        ["discription"]="VIT+5 Hand-to-Hand skill +5 Polearm skill +5", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Portus Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Polearm skill"]=5, 
        ["id"]=10760, 
        ["Hand-to-Hand skill"]=5, 
        ["VIT"]=5
    }, 
    [251]={
        ["discription"]="INT+6 MND+6 CHR+6 Converts 60 HP to MP Unity Ranking: Magic Accuracy+1～5", 
        ["MND"]=6, 
        ["category"]="Armor", 
        ["en"]="Metamor. Ring +1", 
        ["INT"]=6, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27563, 
        ["CHR"]=6
    }, 
    [252]={
        ["discription"]="DEF:6 Accuracy+15 Attack+15 \"Double Attack\"+1%", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Anguinus Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=11731, 
        ["DEF"]=6, 
        ["Accuracy"]=15, 
        ["Attack"]=15
    }, 
    [253]={
        ["discription"]="Damage taken -3%", 
        ["id"]=11730, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Nierenschutz", 
        ["DT"]=-3, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [14]="DRG"
        }
    }, 
    [254]={
        ["discription"]="DEF:17 Occasionally annuls severe physical damage taken Dark weather: Accuracy+13 Attack+13", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Archon Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=10975, 
        ["DEF"]=17, 
        ["Accuracy"]=13, 
        ["Attack"]=13
    }, 
    [255]={
        ["discription"]="DEF:16 STR+5 Attack+35", 
        ["category"]="Armor", 
        ["en"]="Niht Mantle", 
        ["STR"]=5, 
        ["id"]=28624, 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="Attack+10", 
            [2]="Dark magic skill +6", 
            [3]="\"Drain\" and \"Aspir\" potency +22", 
            [4]="none", 
            [5]="none"
        }, 
        ["Attack"]=45
    }, 
    [256]={
        ["Evasion"]=6, 
        ["en"]="Gelai Earring", 
        ["Dagger skill"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Evasion+6 Dagger skill +5 Pet: \"Subtle Blow\"+9", 
        ["id"]=28518, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [257]={
        ["VIT"]=20, 
        ["id"]=13658, 
        ["DEF"]=15, 
        ["slots"]={
            [15]="Back"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:15 Occasionally annuls damage from physical attacks On Darksdays: VIT+20", 
        ["en"]="Shadow Mantle", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [258]={
        ["discription"]="STR+7 DEX+5 VIT+7 AGI+5 INT+7 MND+5 CHR+7", 
        ["category"]="Armor", 
        ["DEX"]=5, 
        ["en"]="Latria Sash", 
        ["STR"]=7, 
        ["MND"]=5, 
        ["CHR"]=7, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26324, 
        ["INT"]=7, 
        ["AGI"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["VIT"]=7
    }, 
    [259]={
        ["discription"]="DEF:14 Pet: Evasion+10 \"Subtle Blow\"+5 \"Regen\"+1 Damage taken -3%", 
        ["DEF"]=14, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Isa Belt", 
        ["id"]=28451, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [260]={
        ["discription"]="+10 Increases \"Step\" accuracy", 
        ["id"]=16055, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Choreia Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [261]={
        ["en"]="Nusku's Sash", 
        ["id"]=11732, 
        ["Dual Wield"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="Evasion+5 Enhances \"Dual Wield\" effect \"Subtle Blow\"+5", 
        ["Evasion"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH"
        }
    }, 
    [262]={
        ["discription"]="DEF:10 Magic Damage+15 \"Conserve MP\"+3", 
        ["DEF"]=10, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Sekhmet Corset", 
        ["id"]=28461, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [21]="GEO"
        }
    }, 
    [263]={
        ["discription"]="HP+20 MP+20 Accuracy+3 Damage taken -1%", 
        ["category"]="Weapon", 
        ["en"]="Umbra Strap", 
        ["MP"]=20, 
        ["HP"]=20, 
        ["skill"]="(N/A)", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=3, 
        ["id"]=18826, 
        ["DT"]=-1
    }, 
    [264]={
        ["en"]="Enlivened Ring", 
        ["id"]=28549, 
        ["Accuracy"]=7, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEX+2 Accuracy+7", 
        ["DEX"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [265]={
        ["Parrying skill"]=7, 
        ["category"]="Weapon", 
        ["en"]="Balarama Grip", 
        ["skill"]="(N/A)", 
        ["HP"]=50, 
        ["Great Sword skill"]=10, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21411, 
        ["discription"]="HP+50 Great Sword skill +10 Parrying skill +7 Enmity+3"
    }, 
    [266]={
        ["discription"]="Accuracy+10 Pet: Accuracy+10 Ranged Accuracy+10 Attack+5 Ranged Attack+10 \"Regen\"+1", 
        ["Accuracy"]=10, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=27514, 
        ["en"]="Empath Necklace", 
        ["category"]="Armor", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }
    }, 
    [267]={
        ["Magic Accuracy"]=5, 
        ["en"]="Archon Ring", 
        ["Magic Atk. Bonus"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Occasionally annuls severe magic damage taken Dark Elemental Magic Accuracy+5 Dark Elemental \"Magic Atk. Bonus\"+5", 
        ["id"]=11674, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [268]={
        ["Attack"]=10, 
        ["en"]="Vehemence Ring", 
        ["id"]=28550, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="STR+2 Attack+10", 
        ["STR"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [269]={
        ["discription"]="Enemy critical hit rate -5% \"Death\" resistance +10 Physical damage taken -3%", 
        ["id"]=27555, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Warden's Ring", 
        ["PDT"]=-3, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [270]={
        ["discription"]="MND+2 Magic Evasion+8", 
        ["en"]="Flashward Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28503, 
        ["MND"]=2, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [271]={
        ["INT"]=2, 
        ["en"]="Acumen Ring", 
        ["Magic Atk. Bonus"]=4, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="INT+2 \"Magic Atk. Bonus\"+4", 
        ["id"]=28554, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [272]={
        ["Evasion"]=15, 
        ["category"]="Weapon", 
        ["en"]="Kupayopl", 
        ["skill"]="(N/A)", 
        ["HP"]=50, 
        ["Parrying skill"]=5, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21422, 
        ["discription"]="HP+50 Evasion+15 Parrying skill +5"
    }, 
    [273]={
        ["discription"]="Accuracy+6 \"Store TP\"+6", 
        ["category"]="Weapon", 
        ["en"]="Bloodrain Strap", 
        ["Store TP"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21427, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["Accuracy"]=6, 
        ["skill"]="(N/A)"
    }, 
    [274]={
        ["discription"]="DEF:13 Accuracy+15 Haste+7% Pet: Accuracy+10 Ranged Accuracy+10 Haste+5%", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hurch'lan Sash", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28462, 
        ["DEF"]=13, 
        ["Accuracy"]=15, 
        ["Haste"]=7
    }, 
    [275]={
        ["discription"]="DEF:20 HP+100 +25 Darksday: STR+10 DEX+10 VIT+10 AGI+10 INT+10 MND+10 CHR+10", 
        ["en"]="Trepidity Mantle", 
        ["MND"]=10, 
        ["category"]="Armor", 
        ["DEX"]=10, 
        ["AGI"]=10, 
        ["HP"]=100, 
        ["INT"]=10, 
        ["STR"]=10, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["CHR"]=10, 
        ["DEF"]=20, 
        ["id"]=28600, 
        ["VIT"]=10
    }, 
    [276]={
        ["discription"]="VIT+2 Converts 55 MP to HP", 
        ["id"]=28500, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Upsurge Earring", 
        ["VIT"]=2, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [277]={
        ["en"]="Fistmele Ring", 
        ["id"]=28552, 
        ["Ranged Attack"]=9, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="AGI+2 Ranged Attack+9", 
        ["AGI"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [278]={
        ["Magic Accuracy"]=7, 
        ["en"]="Hermetic Earring", 
        ["Magic Atk. Bonus"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Magic Accuracy+7 \"Magic Atk. Bonus\"+3 ", 
        ["id"]=28477, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [279]={
        ["Magic Accuracy"]=6, 
        ["en"]="Perception Ring", 
        ["MND"]=2, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="MND+2 Magic Accuracy+6", 
        ["id"]=28553, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [280]={
        ["discription"]="DEF:16 HP+50 Accuracy+15 Attack+15 Ranged Accuracy+15 Magic Accuracy+15 Evasion+15 \"Double Attack\"+2%", 
        ["Ranged Accuracy"]=15, 
        ["Evasion"]=15, 
        ["category"]="Armor", 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Yokaze Mantle", 
        ["HP"]=50, 
        ["augments"]={
            [1]="STR+3", 
            [2]="Weapon skill damage +4%", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["STR"]=3, 
        ["Attack"]=15, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=15, 
        ["DEF"]=16, 
        ["id"]=28629, 
        ["Magic Accuracy"]=15
    }, 
    [281]={
        ["discription"]="Dark magic skill +10 Spell interruption rate down 5% \"Drain\" and \"Aspir\" potency +10", 
        ["id"]=26160, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Evanescence Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [282]={
        ["discription"]="DEF:16 VIT+8 Accuracy+20 Attack+20  Wyvern: HP+100 Attack+20", 
        ["category"]="Armor", 
        ["VIT"]=8, 
        ["en"]="Updraft Mantle", 
        ["augments"]={
            [1]="STR+3", 
            [2]="Pet: Breath+9", 
            [3]="Pet: Damage taken -2%", 
            [4]="Weapon skill damage +4%", 
            [5]="none"
        }, 
        ["STR"]=3, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["id"]=28630, 
        ["Attack"]=20
    }, 
    [283]={
        ["DT"]=-4, 
        ["id"]=26245, 
        ["DEF"]=17, 
        ["slots"]={
            [15]="Back"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:17 \"Resist Charm\"+15 \"Conserve MP\"+5 \"Cure\" potency +7% Damage taken -4%", 
        ["en"]="Solemnity Cape", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [284]={
        ["discription"]="STR+5 DEX+5", 
        ["en"]="Potent Grip", 
        ["DEX"]=5, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["STR"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22198, 
        ["slots"]={
            [1]="Sub"
        }
    }, 
    [285]={
        ["en"]="Infused Earring", 
        ["id"]=28475, 
        ["Evasion"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="AGI+4 Evasion+10 \"Regen\"+1", 
        ["AGI"]=4, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [286]={
        ["discription"]="DEF:10 \"Reward\"+10 \"Spirit Link\"+50 \"Repair\" potency +10%", 
        ["DEF"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Pratik Earring", 
        ["id"]=28498, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [287]={
        ["discription"]="INT+10 MND+10 Magic Accuracy+10 Magic Evasion+10", 
        ["MND"]=10, 
        ["category"]="Weapon", 
        ["en"]="Enki Strap", 
        ["skill"]="(N/A)", 
        ["INT"]=10, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=22213, 
        ["Magic Accuracy"]=10
    }, 
    [288]={
        ["discription"]="MP+40 \"Resist Amnesia\"+10 Avatar: \"Magic Atk. Bonus\"+6", 
        ["MP"]=40, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26170, 
        ["en"]="Speaker's Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [289]={
        ["discription"]="DEF:9 STR+8 DEX+8 VIT-5 AGI-5 INT+8 MND-5", 
        ["category"]="Armor", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Wanion Belt", 
        ["DEX"]=8, 
        ["AGI"]=-5, 
        ["MND"]=-5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=10834, 
        ["INT"]=8, 
        ["DEF"]=9, 
        ["STR"]=8, 
        ["VIT"]=-5
    }, 
    [290]={
        ["discription"]="HP+20 Accuracy+7 Attack+7 Evasion+7 \"Subtle Blow\"+3", 
        ["category"]="Armor", 
        ["en"]="Assuage Earring", 
        ["Evasion"]=7, 
        ["HP"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27536, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Accuracy"]=7, 
        ["Attack"]=7
    }, 
    [291]={
        ["en"]="Cacoethic Ring +1", 
        ["id"]=10771, 
        ["Accuracy"]=11, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Accuracy+11 Ranged Accuracy+16 Unity Ranking: Enmity-1～5", 
        ["Ranged Accuracy"]=16, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [292]={
        ["discription"]="Accuracy+10 Magic Accuracy+8 \"Double Attack\"+1%", 
        ["category"]="Weapon", 
        ["en"]="Flanged Grip", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22195, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["Accuracy"]=10, 
        ["Magic Accuracy"]=8
    }, 
    [293]={
        ["discription"]="STR+3 INT+5 Attack+10", 
        ["category"]="Weapon", 
        ["en"]="Floestone", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["INT"]=5, 
        ["STR"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21366, 
        ["Attack"]=10
    }, 
    [294]={
        ["discription"]="INT+4 Magic Accuracy+8 \"Magic Atk. Bonus\"+4 \"Conserve MP\"+4", 
        ["category"]="Weapon", 
        ["en"]="Pemphredo Tathlum", 
        ["Magic Atk. Bonus"]=4, 
        ["skill"]="(N/A)", 
        ["INT"]=4, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22271, 
        ["Magic Accuracy"]=8
    }, 
    [295]={
        ["discription"]="Accuracy+5 Attack+10 \"Store TP\"+3", 
        ["category"]="Weapon", 
        ["en"]="Ginsen", 
        ["Store TP"]=3, 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=21371, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["Accuracy"]=5, 
        ["Attack"]=10
    }, 
    [296]={
        ["discription"]="MND+2 \"Magic Def. Bonus\"+2", 
        ["en"]="Spellbr. Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28504, 
        ["MND"]=2, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [297]={
        ["DT"]=-3, 
        ["en"]="Succor Ring", 
        ["MP"]=30, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="MP+30 Damage taken -3%", 
        ["id"]=15859, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [298]={
        ["VIT"]=5, 
        ["en"]="Iron Gobbet", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["discription"]="VIT+5 Enmity+2 Enemy critical hit rate -2%", 
        ["id"]=19782, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [299]={
        ["discription"]="Attack+13 \"Magic Atk. Bonus\"+5", 
        ["en"]="Grenade Core", 
        ["Magic Atk. Bonus"]=5, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [13]="NIN", 
            [22]="RUN"
        }, 
        ["id"]=22251, 
        ["Attack"]=13
    }, 
    [300]={
        ["discription"]="HP+10 DEX+3 Accuracy+13 ", 
        ["category"]="Weapon", 
        ["en"]="Falcon Eye", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["HP"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=22253, 
        ["DEX"]=3, 
        ["Accuracy"]=13, 
        ["skill"]="(N/A)"
    }, 
    [301]={
        ["en"]="Globidonta Ring", 
        ["id"]=28539, 
        ["MP"]=20, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="MP+20 MND+6 Divine magic skill +5 Enfeebling magic skill +5 Summoning magic skill +5", 
        ["MND"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [302]={
        ["discription"]="MP+20 MND+3 Magic Accuracy+6", 
        ["MND"]=3, 
        ["category"]="Weapon", 
        ["en"]="Hydrocera", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22263, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["MP"]=20, 
        ["Magic Accuracy"]=6
    }, 
    [303]={
        ["Magic Accuracy"]=8, 
        ["en"]="Gwati Earring", 
        ["MP"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="MP+10 Magic Accuracy+8 \"Conserve MP\"+1", 
        ["id"]=28507, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [304]={
        ["id"]=10767, 
        ["en"]="Pernicious Ring", 
        ["Store TP"]=4, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="HP+30 Enmity+5 \"Double Attack\"+1% \"Store TP\"+4", 
        ["HP"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [305]={
        ["discription"]="Occasionally annuls magic damage taken Enhances resistance against \"Death\" On Darksdays:  \"Magic Def. Bonus\"", 
        ["id"]=14646, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Shadow Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [306]={
        ["discription"]="STR+3 DEX+3 VIT+3 AGI+3 Enmity+4 \"Double Attack\"+1% \"Store TP\"+5", 
        ["category"]="Armor", 
        ["en"]="Petrov Ring", 
        ["Store TP"]=5, 
        ["AGI"]=3, 
        ["DEX"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=10772, 
        ["STR"]=3, 
        ["VIT"]=3
    }, 
    [307]={
        ["en"]="Clotharius Torque", 
        ["id"]=26017, 
        ["Accuracy"]=8, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="Accuracy+8 Ranged Accuracy+8 Enmity-4 \"Triple Attack\"+1% \"Subtle Blow\"+4", 
        ["Ranged Accuracy"]=8, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [308]={
        ["discription"]="STR+3 Accuracy+13 \"Resist Amnesia\"+10", 
        ["category"]="Weapon", 
        ["en"]="Mantoptera Eye", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=22264, 
        ["STR"]=3, 
        ["Accuracy"]=13, 
        ["skill"]="(N/A)"
    }, 
    [309]={
        ["INT"]=6, 
        ["id"]=27516, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Satlada Necklace", 
        ["discription"]="INT+6 Magic Damage+10", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [310]={
        ["Evasion"]=22, 
        ["MND"]=25, 
        ["discription"]="DEF:102 HP+29 STR+10 DEX+29 VIT+33 INT+8 MND+25 CHR+19 Evasion+22 Magic Evasion+26 Haste+4% Enmity+7 \"Magic Def. Bonus\"+1 \"Cure\" potency +11% Physical damage taken -4% Unity Ranking: HP+20～60", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["Haste"]=4, 
        ["item_level"]=119, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["VIT"]=33, 
        ["HP"]=89, 
        ["DEX"]=29, 
        ["PDT"]=-4, 
        ["STR"]=10, 
        ["DEF"]=102, 
        ["id"]=27994, 
        ["Unity Ranking Bonus Applied"]="HP + 60", 
        ["CHR"]=19, 
        ["INT"]=8, 
        ["category"]="Armor", 
        ["en"]="Macabre Gaunt. +1"
    }, 
    [311]={
        ["MDT"]=-3, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["DEX"]=35, 
        ["AGI"]=35, 
        ["MND"]=48, 
        ["DEF"]=226, 
        ["discription"]="Cannot equip headgear DEF:226 HP+91 MP+91 STR+35 DEX+35 VIT+35 AGI+35 INT+48 MND+48 CHR+48 Evasion+77 Magic Evasion+156 \"Magic Def. Bonus\"+12 Haste+9% \"Regen\"+3 \"Refresh\"+3 \"Drain\" and \"Aspir\" potency +31 Magic damage taken -3% Unity Ranking: \"Fast Cast\"+3～6%", 
        ["Fast Cast"]=6, 
        ["en"]="Lugra Cloak +1", 
        ["HP"]=91, 
        ["id"]=26897, 
        ["category"]="Armor", 
        ["Haste"]=9, 
        ["MP"]=91, 
        ["Evasion"]=77, 
        ["VIT"]=35, 
        ["STR"]=35, 
        ["INT"]=48, 
        ["Unity Ranking Bonus Applied"]="Fast Cast + 6", 
        ["CHR"]=48, 
        ["item_level"]=119
    }, 
    [312]={
        ["discription"]="DMG:313 Delay:492 Accuracy+35 Attack+35 Polearm skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Triple Attack\"+3% \"Subtle Blow\"+7 Damage taken -2%", 
        ["slots"]={
            [0]="Main"
        }, 
        ["Parrying skill"]=242, 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Lembing", 
        ["delay"]=492, 
        ["Accuracy"]=35, 
        ["skill"]="Polearm", 
        ["damage"]=313, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["Polearm skill"]=242, 
        ["Attack"]=35, 
        ["id"]=21855, 
        ["DT"]=-2
    }, 
    [313]={
        ["Attack"]=20, 
        ["STR"]=20, 
        ["Parrying skill"]=242, 
        ["skill"]="Polearm", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Rhomphaia", 
        ["delay"]=492, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["augments"]={
            [1]="DMG:+30", 
            [2]="STR+20", 
            [3]="Accuracy+15"
        }, 
        ["discription"]="DMG:268 Delay:492 Attack+20 Polearm skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Dragon Killer\"+10 Jump: \"Double Attack\"+7% \"TP Bonus\"+50", 
        ["slots"]={
            [0]="Main"
        }, 
        ["Accuracy"]=15, 
        ["id"]=20937, 
        ["Polearm skill"]=242, 
        ["damage"]=298
    }, 
    [314]={
        ["en"]="Divinator", 
        ["id"]=21452, 
        ["skill"]="(N/A)", 
        ["slots"]={
            [2]="Range"
        }, 
        ["category"]="Weapon", 
        ["discription"]="An animator crafted with ancient techniques that modern man cannot possibly hope to replicate. Automaton: Lv.. 119", 
        ["item_level"]=119, 
        ["jobs"]={
            [18]="PUP"
        }
    }, 
    [315]={
        ["discription"]="DMG:296 Delay:494 Attack+25 Great Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Store TP\"+8 Weapon Skill Accuracy+25 Chance for weapon skills not to consume TP +1%", 
        ["slots"]={
            [0]="Main"
        }, 
        ["Parrying skill"]=242, 
        ["category"]="Weapon", 
        ["Store TP"]=8, 
        ["item_level"]=119, 
        ["delay"]=494, 
        ["Great Katana skill"]=242, 
        ["skill"]="Great Katana", 
        ["Attack"]=25, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["Accuracy"]=25, 
        ["en"]="Deacon Blade", 
        ["id"]=21028, 
        ["damage"]=296
    }, 
    [316]={
        ["Evasion"]=41, 
        ["Haste"]=3, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEX"]=21, 
        ["AGI"]=21, 
        ["MND"]=36, 
        ["item_level"]=119, 
        ["STR"]=21, 
        ["Fast Cast"]=5, 
        ["en"]="Vanir Cotehardie", 
        ["HP"]=54, 
        ["id"]=27887, 
        ["VIT"]=21, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=120, 
        ["MP"]=59, 
        ["discription"]="DEF:120 HP+54 MP+59 STR+21 DEX+21 VIT+21 AGI+21 INT+36 MND+36 CHR+29 Magic Accuracy+18 \"Magic Atk. Bonus\"+18 Evasion+41 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+3% \"Fast Cast\"+5%", 
        ["INT"]=36, 
        ["category"]="Armor", 
        ["CHR"]=29, 
        ["Magic Atk. Bonus"]=18, 
        ["Magic Accuracy"]=18
    }, 
    [317]={
        ["Attack"]=25, 
        ["Parrying skill"]=242, 
        ["skill"]="Scythe", 
        ["INT"]=20, 
        ["category"]="Weapon", 
        ["Magic Atk. Bonus"]=25, 
        ["item_level"]=119, 
        ["delay"]=528, 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["Scythe skill"]=242, 
        ["discription"]="DMG:317 Delay:528 STR+20 INT+20 Attack+25 \"Magic Atk. Bonus\"+25 Magic Damage+170 Scythe skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Endark\"+20", 
        ["slots"]={
            [0]="Main"
        }, 
        ["en"]="Deacon Scythe", 
        ["id"]=20894, 
        ["STR"]=20, 
        ["damage"]=317
    }, 
    [318]={
        ["Evasion"]=27, 
        ["MND"]=24, 
        ["Haste"]=5, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["VIT"]=12, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["AGI"]=17, 
        ["en"]="Miasmic Pants", 
        ["discription"]="DEF:107 HP+43 MP+29 STR+29 VIT+12 AGI+17 INT+38 MND+24 CHR+19 Accuracy+22 Magic Accuracy+22 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% \"Conserve MP\"+4 Physical damage taken -3% Enchantment: \"Poison\"", 
        ["HP"]=43, 
        ["item_level"]=119, 
        ["Accuracy"]=22, 
        ["STR"]=29, 
        ["DEF"]=107, 
        ["MP"]=29, 
        ["id"]=27220, 
        ["INT"]=38, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["PDT"]=-3, 
        ["Magic Accuracy"]=22
    }, 
    [319]={
        ["MDT"]=-5, 
        ["skill"]="Dagger", 
        ["Evasion"]=22, 
        ["category"]="Weapon", 
        ["Parrying skill"]=242, 
        ["en"]="Vanir Knife", 
        ["delay"]=205, 
        ["item_level"]=119, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["discription"]="DMG:111 Delay:205 Accuracy+13 Evasion+22 Magic Damage+70 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Magic damage taken -5%", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["Accuracy"]=13, 
        ["Dagger skill"]=242, 
        ["id"]=20632, 
        ["damage"]=111
    }, 
    [320]={
        ["Evasion"]=22, 
        ["MND"]=32, 
        ["item_level"]=119, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["Haste"]=5, 
        ["AGI"]=16, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=27026, 
        ["en"]="Rao Kote", 
        ["DEX"]=34, 
        ["augments"]={
            [1]="Pet: HP+100", 
            [2]="Pet: Accuracy+15", 
            [3]="Pet: Damage taken -3%"
        }, 
        ["STR"]=14, 
        ["DEF"]=92, 
        ["discription"]="DEF:92 STR+14 DEX+34 VIT+29 AGI+16 INT+8 MND+32 CHR+15 Attack+32 Evasion+22 Magic Evasion+26 \"Magic Def. Bonus\"+1 Haste+5% \"Counter\"+4 \"Regen\"+1", 
        ["INT"]=8, 
        ["category"]="Armor", 
        ["CHR"]=15, 
        ["VIT"]=29, 
        ["Attack"]=32
    }, 
    [321]={
        ["discription"]="DMG:217 Delay:402 MP+88 Staff skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Blood Boon\"+5 Avatar: Magic Accuracy+35 \"Magic Atk. Bonus\"+110 \"Blood Pact\" damage +3", 
        ["category"]="Weapon", 
        ["Parrying skill"]=242, 
        ["item_level"]=119, 
        ["Staff skill"]=242, 
        ["delay"]=402, 
        ["skill"]="Staff", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["MP"]=88, 
        ["en"]="Marquetry Staff", 
        ["id"]=21155, 
        ["slots"]={
            [0]="Main"
        }, 
        ["damage"]=217
    }, 
    [322]={
        ["en"]="Divinator II", 
        ["id"]=22261, 
        ["skill"]="(N/A)", 
        ["slots"]={
            [2]="Range"
        }, 
        ["category"]="Weapon", 
        ["discription"]="A long-range animator crafted with ancient techniques that modern man cannot possibly hope to replicate. Automaton: Lv. 119", 
        ["item_level"]=119, 
        ["jobs"]={
            [18]="PUP"
        }
    }, 
    [323]={
        ["Evasion"]=52, 
        ["MND"]=24, 
        ["Haste"]=4, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=25, 
        ["slots"]={
            [5]="Body"
        }, 
        ["AGI"]=25, 
        ["discription"]="DEF:129 HP+59 STR+37 DEX+25 VIT+21 AGI+25 INT+24 MND+24 CHR+24 Attack+25 Evasion+52 Magic Evasion+53 \"Magic Def. Bonus\"+4 Guarding skill +20 Haste+4% \"Counter\"+5", 
        ["item_level"]=119, 
        ["HP"]=59, 
        ["en"]="Sweller's Harness", 
        ["VIT"]=21, 
        ["STR"]=37, 
        ["DEF"]=129, 
        ["id"]=26958, 
        ["Guarding skill"]=20, 
        ["CHR"]=24, 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["Attack"]=25
    }, 
    [324]={
        ["discription"]="DEF:60 HP+57 MP+64 \"Magic Atk. Bonus\"+20 Magic Damage+75 Shield skill +107 Spell interruption rate down 10%", 
        ["category"]="Armor", 
        ["Shield skill"]=107, 
        ["en"]="Culminus", 
        ["Magic Atk. Bonus"]=20, 
        ["HP"]=57, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEF"]=60, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["MP"]=64, 
        ["id"]=26400, 
        ["item_level"]=119
    }, 
    [325]={
        ["discription"]="DMG:190 Delay:366 MP+100 Staff skill +242 Parrying skill +242 Magic Accuracy skill +188 Avatar: Magic Accuracy+20 \"Magic Atk. Bonus\"+120 Enmity+10", 
        ["category"]="Weapon", 
        ["Parrying skill"]=242, 
        ["item_level"]=119, 
        ["Staff skill"]=242, 
        ["delay"]=366, 
        ["skill"]="Staff", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["MP"]=100, 
        ["en"]="Frazil Staff", 
        ["id"]=21167, 
        ["slots"]={
            [0]="Main"
        }, 
        ["damage"]=190
    }, 
    [326]={
        ["discription"]="DMG:288 Delay:528 Accuracy+15 Attack+15 Scythe skill +242 Parrying skill +242 Magic Accuracy skill +188 Enmity-10 Additional effect: HP drain", 
        ["Parrying skill"]=242, 
        ["skill"]="Scythe", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Cronus", 
        ["delay"]=528, 
        ["Attack"]=15, 
        ["slots"]={
            [0]="Main"
        }, 
        ["Accuracy"]=15, 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["id"]=20904, 
        ["Scythe skill"]=242, 
        ["damage"]=288
    }, 
    [327]={
        ["discription"]="DEF:63 HP+120 Shield skill +112 Chance of successful block +20 Damage taken -5% Physical damage taken: \"Reprisal\"", 
        ["category"]="Armor", 
        ["en"]="Adapa Shield", 
        ["item_level"]=119, 
        ["HP"]=120, 
        ["Shield skill"]=112, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [9]="BST"
        }, 
        ["id"]=26420, 
        ["DEF"]=63, 
        ["DT"]=-5
    }, 
    [328]={
        ["MDT"]=-7, 
        ["skill"]="Katana", 
        ["discription"]="DMG:128 Delay:222 STR+14 AGI+14 Accuracy+16 Evasion+38 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 Magic damage taken -7% Unity Ranking: \"Double Attack\"+1～3%", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Katana skill"]=242, 
        ["item_level"]=119, 
        ["AGI"]=14, 
        ["delay"]=222, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=16, 
        ["STR"]=14, 
        ["Evasion"]=38, 
        ["id"]=20981, 
        ["category"]="Weapon", 
        ["Parrying skill"]=242, 
        ["damage"]=128, 
        ["en"]="Raicho +1"
    }, 
    [329]={
        ["Attack"]=10, 
        ["STR"]=20, 
        ["Parrying skill"]=242, 
        ["skill"]="Polearm", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Reienkyo", 
        ["delay"]=480, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["Critical hit rate"]=3, 
        ["discription"]="DMG:282 Delay:480 STR+20 Accuracy+20 Attack+10 Polearm skill +242 Parrying skill +242 Magic Accuracy skill +188 Critical hit rate +3%", 
        ["slots"]={
            [0]="Main"
        }, 
        ["Accuracy"]=20, 
        ["id"]=21854, 
        ["Polearm skill"]=242, 
        ["damage"]=282
    }, 
    [330]={
        ["discription"]="DMG:298 Delay:551 HP+100 MP+100 Accuracy+18 Polearm skill +242 Parrying skill +242 Magic Accuracy skill +188 Absorbs ice elemental damage 3% Unity Ranking: Critical hit rate +1～5%", 
        ["Polearm skill"]=242, 
        ["en"]="Gae Derg", 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["skill"]="Polearm", 
        ["Critical hit rate"]=5, 
        ["item_level"]=119, 
        ["HP"]=100, 
        ["id"]=20942, 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main"
        }, 
        ["MP"]=100, 
        ["Accuracy"]=18, 
        ["Unity Ranking Bonus Applied"]="Critical hit rate + 5", 
        ["damage"]=298, 
        ["category"]="Weapon", 
        ["delay"]=551
    }, 
    [331]={
        ["discription"]="DMG:157 Delay:290 Attack+26 Sword skill +228 Parrying skill +228 Magic Accuracy skill +188 \"Double Attack\"+2% \"Triple Attack\"+2% Unity Ranking: STR+1～7 Additional effect: HP Drain", 
        ["item_level"]=119, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["Sword skill"]=228, 
        ["en"]="Sangarius", 
        ["delay"]=290, 
        ["Parrying skill"]=228, 
        ["skill"]="Sword", 
        ["Attack"]=26, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK"
        }, 
        ["Unity Ranking Bonus Applied"]="STR + 7", 
        ["STR"]=7, 
        ["id"]=20611, 
        ["damage"]=157
    }, 
    [332]={
        ["Evasion"]=24, 
        ["MND"]=30, 
        ["discription"]="DEF:90 HP+25 STR+11 DEX+35 VIT+32 AGI+5 INT+12 MND+30 CHR+17 Evasion+24 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+5% Pet: Accuracy+20 Ranged Accuracy+20 Magic Accuracy+20 Haste+6%", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["DEF"]=90, 
        ["en"]="Regimen Mittens", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["AGI"]=5, 
        ["HP"]=25, 
        ["DEX"]=35, 
        ["VIT"]=32, 
        ["STR"]=11, 
        ["Haste"]=5, 
        ["id"]=28025, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["item_level"]=119
    }, 
    [333]={
        ["discription"]="DMG:+114 Delay:+90 DEX+12 INT+12 +25 Accuracy+20 Hand-to-Hand skill +242 Guarding skill +242 Magic Accuracy skill +188 \"Skillchain Bonus\"+5 Additional effect: Paralysis", 
        ["Guarding skill"]=242, 
        ["en"]="Calved Claws", 
        ["category"]="Weapon", 
        ["DEX"]=12, 
        ["item_level"]=119, 
        ["delay"]=90, 
        ["INT"]=12, 
        ["skill"]="Hand-to-Hand", 
        ["Hand-to-Hand skill"]=242, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [13]="NIN", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["Accuracy"]=20, 
        ["slots"]={
            [0]="Main"
        }, 
        ["id"]=20529, 
        ["damage"]=114
    }, 
    [334]={
        ["Evasion"]=49, 
        ["MND"]=10, 
        ["discription"]="DEF:85 HP+78 STR+16 DEX+12 VIT+17 AGI+29 MND+10 CHR+26 Accuracy+18 Attack+18 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+2 Haste+3% \"Double Attack\"+4% \"Reward\"+35", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=12, 
        ["id"]=27492, 
        ["item_level"]=119, 
        ["DEF"]=85, 
        ["en"]="Loyalist Sabatons", 
        ["HP"]=78, 
        ["PDT"]=-1, 
        ["Accuracy"]=18, 
        ["CHR"]=26, 
        ["STR"]=22, 
        ["Haste"]=3, 
        ["augments"]={
            [1]="STR+6", 
            [2]="Attack+12", 
            [3]="Phys. dmg. taken -1%", 
            [4]="none", 
            [5]="none"
        }, 
        ["category"]="Armor", 
        ["AGI"]=29, 
        ["VIT"]=17, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Attack"]=30
    }, 
    [335]={
        ["Ranged Attack"]=33, 
        ["MND"]=17, 
        ["Haste"]=6, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [17]="COR"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["AGI"]=34, 
        ["en"]="Darraigner's Brais", 
        ["Evasion"]=38, 
        ["HP"]=47, 
        ["discription"]="DEF:113 HP+47 STR+29 VIT+16 AGI+34 INT+30 MND+17 CHR+11 Ranged Attack+33 Evasion+38 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% Enmity-6 Critical hit damage +6%", 
        ["Critical hit damage"]=6, 
        ["STR"]=29, 
        ["DEF"]=113, 
        ["id"]=25852, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["VIT"]=16, 
        ["item_level"]=119
    }, 
    [336]={
        ["Evasion"]=22, 
        ["Parrying skill"]=242, 
        ["discription"]="DMG:103 Delay:195 Accuracy+10 Attack+10 Evasion+22 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Critical hit rate +4% Critical hit damage +5% Additional effect: \"Flee\"", 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEX"]=15, 
        ["augments"]={
            [1]="DEX+15", 
            [2]="\"Dual Wield\"+5", 
            [3]="\"Triple Atk.\"+2"
        }, 
        ["en"]="Shijo", 
        ["Dual Wield"]=5, 
        ["item_level"]=119, 
        ["delay"]=195, 
        ["Dagger skill"]=242, 
        ["Accuracy"]=10, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=20598, 
        ["damage"]=103, 
        ["Critical hit damage"]=5, 
        ["Critical hit rate"]=4, 
        ["skill"]="Dagger", 
        ["Attack"]=10
    }, 
    [337]={
        ["Ranged Attack"]=10, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["augments"]={
            [1]="Accuracy+15", 
            [2]="Rng.Acc.+15", 
            [3]="\"Store TP\"+5"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=5, 
        ["Ranged Accuracy"]=25, 
        ["item_level"]=119, 
        ["Katana skill"]=228, 
        ["Store TP"]=5, 
        ["delay"]=190, 
        ["en"]="Mijin", 
        ["Accuracy"]=42, 
        ["category"]="Weapon", 
        ["STR"]=5, 
        ["id"]=20983, 
        ["damage"]=107, 
        ["Parrying skill"]=228, 
        ["Evasion"]=34, 
        ["skill"]="Katana", 
        ["discription"]="DMG:107 Delay:190 STR+5 DEX+5 Accuracy+27 Ranged Accuracy+10 Ranged Attack+10 Evasion+34 Katana skill +228 Parrying skill +228 Magic Accuracy skill +215"
    }, 
    [338]={
        ["Evasion"]=24, 
        ["MND"]=23, 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEF"]=103, 
        ["en"]="Iktomi Dastanas", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["discription"]="DEF:103 HP+27 STR+8 DEX+32 VIT+32 AGI+7 INT+6 MND+23 CHR+16 Evasion+24 Magic Evasion+32 \"Magic Def. Bonus\"+1 Haste+6% \"Double Attack\"+5% \"Subtle Blow\"+8 All Jumps: Accuracy+40", 
        ["HP"]=27, 
        ["DEX"]=32, 
        ["Accuracy"]=40, 
        ["STR"]=8, 
        ["Haste"]=6, 
        ["id"]=25761, 
        ["INT"]=6, 
        ["category"]="Armor", 
        ["CHR"]=16, 
        ["VIT"]=32, 
        ["AGI"]=7
    }, 
    [339]={
        ["discription"]="DMG:110 Delay:236 STR+15 +25 Accuracy+20 Sword skill +242 Parrying skill +242 Magic Accuracy skill +188 Fire elemental \"Magic Atk. Bonus\"+15 Additional effect: Fire damage", 
        ["skill"]="Sword", 
        ["STR"]=15, 
        ["category"]="Weapon", 
        ["Sword skill"]=242, 
        ["en"]="Perfervid Sword", 
        ["delay"]=236, 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Magic Atk. Bonus"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [16]="BLU"
        }, 
        ["Accuracy"]=20, 
        ["item_level"]=119, 
        ["id"]=20716, 
        ["damage"]=110
    }, 
    [340]={
        ["discription"]="DMG:183 Delay:264 MP+45 VIT+25 INT+25 MND+25 Accuracy+35 Magic Accuracy+35 \"Magic Def. Bonus\"+8 Sword skill +242 Parrying skill +242 Magic Accuracy skill +228 \"Fast Cast\"+8% Resistance to all status ailments +10 \"Refresh\"+1", 
        ["MND"]=25, 
        ["en"]="Malignance Sword", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["VIT"]=25, 
        ["item_level"]=119, 
        ["skill"]="Sword", 
        ["Fast Cast"]=8, 
        ["delay"]=264, 
        ["id"]=21635, 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["MP"]=45, 
        ["Accuracy"]=35, 
        ["INT"]=25, 
        ["Sword skill"]=242, 
        ["category"]="Weapon", 
        ["damage"]=183, 
        ["Magic Accuracy"]=35
    }, 
    [341]={
        ["Evasion"]=27, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["Haste"]=5, 
        ["Fast Cast"]=5, 
        ["MND"]=24, 
        ["item_level"]=119, 
        ["id"]=27321, 
        ["AGI"]=17, 
        ["en"]="Lengo Pants", 
        ["HP"]=43, 
        ["augments"]={
            [1]="INT+7", 
            [2]="Mag. Acc.+7", 
            [3]="\"Mag.Atk.Bns.\"+3", 
            [4]="\"Refresh\"+1", 
            [5]="none"
        }, 
        ["VIT"]=12, 
        ["STR"]=25, 
        ["DEF"]=105, 
        ["MP"]=29, 
        ["discription"]="DEF:105 HP+43 MP+29 STR+25 VIT+12 AGI+17 INT+34 MND+24 CHR+19 Evasion+27 Magic Evasion+107 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+6 Haste+5% \"Fast Cast\"+5% \"Conserve MP\"+5 Spell interruption rate down 10%", 
        ["INT"]=41, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["Magic Atk. Bonus"]=23, 
        ["Magic Accuracy"]=7
    }, 
    [342]={
        ["Evasion"]=69, 
        ["MND"]=16, 
        ["discription"]="DEF:74 STR+17 DEX+25 VIT+12 AGI+34 MND+16 CHR+28 Accuracy+31 Evasion+69 Magic Evasion+64 \"Magic Def. Bonus\"+3 Haste+4% \"Subtle Blow\"+7 \"Regen\"+1", 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["id"]=27378, 
        ["en"]="Rao Sune-Ate", 
        ["DEF"]=74, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["item_level"]=119, 
        ["DEX"]=25, 
        ["Accuracy"]=31, 
        ["STR"]=17, 
        ["Haste"]=4, 
        ["augments"]={
            [1]="Pet: HP+100", 
            [2]="Pet: Accuracy+15", 
            [3]="Pet: Damage taken -3%"
        }, 
        ["CHR"]=28, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["AGI"]=34
    }, 
    [343]={
        ["Magic Accuracy"]=40, 
        ["item_level"]=119, 
        ["MND"]=30, 
        ["Parrying skill"]=228, 
        ["Club skill"]=228, 
        ["Magic Atk. Bonus"]=40, 
        ["en"]="Daybreak", 
        ["delay"]=216, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["skill"]="Club", 
        ["discription"]="DMG:150 Delay:216 MP+60 MND+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+40 Magic Damage+241 Magic Evasion+30 Club skill +228 Parrying skill +228 Magic Accuracy skill +242 \"Cure\" potency +30% \"Refresh\"+1 Light elemental damage +50 Main hand: \"Dispelga\"", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["id"]=22040, 
        ["MP"]=60, 
        ["damage"]=150
    }, 
    [344]={
        ["Evasion"]=27, 
        ["skill"]="Dagger", 
        ["discription"]="DMG:100 Delay:175 HP+45 Accuracy+27 Evasion+27 Dagger skill +228 Parrying skill +228 Magic Accuracy skill +188 \"Triple Attack\"+4% \"Subtle Blow\"+9 Unity Ranking: AGI+10～15", 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["delay"]=175, 
        ["AGI"]=15, 
        ["item_level"]=119, 
        ["HP"]=45, 
        ["Dagger skill"]=228, 
        ["Accuracy"]=27, 
        ["Unity Ranking Bonus Applied"]="AGI + 15", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=20604, 
        ["category"]="Weapon", 
        ["Parrying skill"]=228, 
        ["damage"]=100, 
        ["en"]="Ternion Dagger +1"
    }, 
    [345]={
        ["Evasion"]=22, 
        ["skill"]="Katana", 
        ["en"]="Tancho +1", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Ranged Accuracy"]=21, 
        ["AGI"]=10, 
        ["Katana skill"]=242, 
        ["discription"]="DMG:126 Delay:227 DEX+10 AGI+10 Accuracy+21 Ranged Accuracy+21 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 Spell interruption rate down 35% Unity Ranking: \"Subtle Blow\"+1～6", 
        ["delay"]=227, 
        ["DEX"]=10, 
        ["Accuracy"]=21, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Subtle Blow"]=6, 
        ["id"]=20988, 
        ["Unity Ranking Bonus Applied"]="Subtle Blow + 6", 
        ["damage"]=126, 
        ["category"]="Weapon", 
        ["Parrying skill"]=242, 
        ["item_level"]=119
    }, 
    [346]={
        ["discription"]="DMG:173 Delay:288 HP+50 Axe skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Subtle Blow\"+7 Pet: Magic Accuracy+10 \"Magic Atk. Bonus\"+20", 
        ["category"]="Weapon", 
        ["Parrying skill"]=242, 
        ["item_level"]=119, 
        ["HP"]=50, 
        ["delay"]=288, 
        ["skill"]="Axe", 
        ["jobs"]={
            [9]="BST"
        }, 
        ["Axe skill"]=242, 
        ["en"]="Deacon Tabar", 
        ["id"]=20798, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=173
    }, 
    [347]={
        ["Evasion"]=53, 
        ["MND"]=17, 
        ["Haste"]=6, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=27322, 
        ["STR"]=29, 
        ["item_level"]=119, 
        ["Critical hit rate"]=2, 
        ["en"]="Ta'lab Trousers", 
        ["HP"]=47, 
        ["AGI"]=20, 
        ["Accuracy"]=3, 
        ["INT"]=30, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=115, 
        ["augments"]={
            [1]="Accuracy+3", 
            [2]="Mag. Evasion+15", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["CHR"]=11, 
        ["VIT"]=16, 
        ["category"]="Armor", 
        ["discription"]="DEF:115 HP+47 STR+29 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Attack+15 Evasion+38 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% \"Triple Attack\"+3% \"Counter\"+3 Critical hit rate +2%", 
        ["Attack"]=15
    }, 
    [348]={
        ["Evasion"]=52, 
        ["MND"]=10, 
        ["id"]=27491, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG"
        }, 
        ["DEX"]=17, 
        ["Haste"]=3, 
        ["en"]="Amm Greaves", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["item_level"]=119, 
        ["HP"]=125, 
        ["discription"]="DEF:81 HP+75 STR+15 DEX+17 VIT+21 AGI+32 MND+10 CHR+26 Evasion+52 Magic Evasion+75 \"Magic Def. Bonus\"+2 Haste+3% \"Double Attack\"+3% Damage taken -3%", 
        ["Accuracy"]=15, 
        ["STR"]=15, 
        ["DEF"]=81, 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Accuracy+15", 
            [4]="Damage taken-2%", 
            [5]="none"
        }, 
        ["CHR"]=26, 
        ["VIT"]=31, 
        ["category"]="Armor", 
        ["AGI"]=32, 
        ["DT"]=-5
    }, 
    [349]={
        ["Evasion"]=52, 
        ["MND"]=10, 
        ["discription"]="DEF:83 HP+15 STR+15 DEX+17 VIT+22 AGI+32 MND+10 CHR+26 Accuracy+23 Evasion+52 Magic Evasion+75 \"Magic Def. Bonus\"+2 Haste+3% All Jumps: Accuracy+58 \"Double Attack\"+5%", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEF"]=83, 
        ["en"]="Maenadic Gambieras", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["AGI"]=32, 
        ["HP"]=15, 
        ["DEX"]=17, 
        ["Accuracy"]=58, 
        ["STR"]=15, 
        ["Haste"]=3, 
        ["id"]=27502, 
        ["CHR"]=26, 
        ["VIT"]=22, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [350]={
        ["Ranged Attack"]=25, 
        ["Haste"]=6, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=32, 
        ["Evasion"]=52, 
        ["MND"]=19, 
        ["item_level"]=119, 
        ["STR"]=26, 
        ["AGI"]=32, 
        ["en"]="Lapidary Tunic", 
        ["HP"]=63, 
        ["id"]=26970, 
        ["VIT"]=23, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=135, 
        ["MP"]=61, 
        ["discription"]="DEF:135 HP+63 MP+61 STR+26 DEX+32 VIT+23 AGI+32 INT+23 MND+19 CHR+19 Attack+25 Ranged Attack+25 Evasion+52 Magic Evasion+80 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+6 Haste+6% \"Subtle Blow\"+13", 
        ["INT"]=23, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["Magic Atk. Bonus"]=20, 
        ["Attack"]=25
    }, 
    [351]={
        ["Attack"]=40, 
        ["skill"]="Scythe", 
        ["Parrying skill"]=242, 
        ["STR"]=20, 
        ["category"]="Weapon", 
        ["Store TP"]=3, 
        ["item_level"]=119, 
        ["delay"]=528, 
        ["jobs"]={
            [8]="DRK"
        }, 
        ["Scythe skill"]=242, 
        ["discription"]="DMG:290 Delay:528 Attack+20 Scythe skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Double Attack\"+4% \"Store TP\"+3 Weapon skill damage +5%", 
        ["slots"]={
            [0]="Main"
        }, 
        ["id"]=20892, 
        ["augments"]={
            [1]="DMG:+30", 
            [2]="STR+20", 
            [3]="Attack+20"
        }, 
        ["en"]="Deathbane", 
        ["damage"]=320
    }, 
    [352]={
        ["damage"]=122, 
        ["AGI"]=10, 
        ["discription"]="DMG:122 Delay:227 AGI+10 Accuracy+15 Evasion+37 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 Damage taken -3%", 
        ["Evasion"]=37, 
        ["category"]="Weapon", 
        ["Katana skill"]=242, 
        ["en"]="Jushimatsu", 
        ["delay"]=227, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["skill"]="Katana", 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["id"]=20990, 
        ["Accuracy"]=15, 
        ["DT"]=-3
    }, 
    [353]={
        ["Evasion"]=41, 
        ["STR"]=32, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=10, 
        ["Haste"]=6, 
        ["MND"]=16, 
        ["AGI"]=40, 
        ["Ranged Accuracy"]=24, 
        ["Store TP"]=7, 
        ["item_level"]=119, 
        ["HP"]=41, 
        ["id"]=27302, 
        ["en"]="Adhemar Kecks", 
        ["INT"]=28, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=113, 
        ["Accuracy"]=39, 
        ["CHR"]=8, 
        ["VIT"]=15, 
        ["category"]="Armor", 
        ["discription"]="DEF:113 HP+41 STR+32 VIT+15 AGI+30 INT+28 MND+16 CHR+8 Accuracy+24 Ranged Accuracy+24 Evasion+41 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% \"Recycle\"+15 \"Snapshot\"+9 \"Store TP\"+7", 
        ["augments"]={
            [1]="DEX+10", 
            [2]="AGI+10", 
            [3]="Accuracy+15"
        }
    }, 
    [354]={
        ["Evasion"]=38, 
        ["MND"]=17, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [14]="DRG", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=6, 
        ["AGI"]=20, 
        ["en"]="Limbo Trousers", 
        ["discription"]="DEF:111 HP+47 STR+29 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Attack+26 \"Magic Atk. Bonus\"+17 Evasion+38 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% \"Double Attack\"+2% \"Fast Cast\"+3%", 
        ["Fast Cast"]=3, 
        ["HP"]=47, 
        ["item_level"]=119, 
        ["VIT"]=16, 
        ["STR"]=29, 
        ["DEF"]=111, 
        ["id"]=27222, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["Magic Atk. Bonus"]=17, 
        ["Attack"]=26
    }, 
    [355]={
        ["discription"]="DMG:122 Delay:227 DEX+12 AGI+12 Accuracy+15 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188", 
        ["Katana skill"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=242, 
        ["category"]="Weapon", 
        ["AGI"]=12, 
        ["en"]="Raimitsukane", 
        ["delay"]=227, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["skill"]="Katana", 
        ["Evasion"]=22, 
        ["DEX"]=12, 
        ["item_level"]=119, 
        ["id"]=20997, 
        ["Accuracy"]=15, 
        ["damage"]=122
    }, 
    [356]={
        ["Ranged Attack"]=24, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=33, 
        ["Haste"]=4, 
        ["MND"]=11, 
        ["Critical hit rate"]=3, 
        ["Evasion"]=74, 
        ["item_level"]=119, 
        ["AGI"]=52, 
        ["HP"]=11, 
        ["augments"]={
            [1]="DEX+10", 
            [2]="AGI+10", 
            [3]="Accuracy+15"
        }, 
        ["en"]="Adhemar Gamashes", 
        ["CHR"]=25, 
        ["STR"]=15, 
        ["DEF"]=74, 
        ["Accuracy"]=15, 
        ["category"]="Armor", 
        ["VIT"]=8, 
        ["Magic Atk. Bonus"]=25, 
        ["discription"]="DEF:74 HP+11 STR+15 DEX+23 VIT+8 AGI+42 MND+11 CHR+25 Attack+24 Ranged Attack+24 Evasion+74 Magic Evasion+75 \"Magic Atk. Bonus\"+25 \"Magic Def. Bonus\"+5 Haste+4% \"True Shot\"+1 Critical hit rate +3%", 
        ["id"]=27473, 
        ["Attack"]=24
    }, 
    [357]={
        ["discription"]="DMG:125 Delay:222 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 Enmity+10 \"Counter\"+5 \"Fast Cast\"+5% Physical damage taken -3%", 
        ["en"]="Shuhansadamune", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Katana skill"]=242, 
        ["Fast Cast"]=5, 
        ["item_level"]=119, 
        ["delay"]=222, 
        ["Parrying skill"]=242, 
        ["skill"]="Katana", 
        ["damage"]=125, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["category"]="Weapon", 
        ["Evasion"]=22, 
        ["id"]=20982, 
        ["PDT"]=-3
    }, 
    [358]={
        ["Evasion"]=13, 
        ["AGI"]=13, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=13, 
        ["Dagger skill"]=242, 
        ["MND"]=13, 
        ["STR"]=13, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["en"]="Odium", 
        ["delay"]=208, 
        ["id"]=20605, 
        ["VIT"]=13, 
        ["CHR"]=13, 
        ["INT"]=13, 
        ["skill"]="Dagger", 
        ["Accuracy"]=13, 
        ["category"]="Weapon", 
        ["discription"]="DMG:113 Delay:208 STR+13 DEX+13 VIT+13 AGI+13 INT+13 MND+13 CHR+13 Accuracy+13 Attack+13 Evasion+13 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Magic Evasion+13 Resistance against \"Death\"+13 Additional effect: \"Death\"", 
        ["damage"]=113, 
        ["Parrying skill"]=242, 
        ["Attack"]=13
    }, 
    [359]={
        ["Evasion"]=67, 
        ["MND"]=30, 
        ["Haste"]=6, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["AGI"]=21, 
        ["id"]=27202, 
        ["Store TP"]=7, 
        ["en"]="Rao Haidate", 
        ["discription"]="DEF:114 STR+45 VIT+15 AGI+21 INT+30 MND+30 CHR+8 Attack+33 Evasion+67 Magic Evasion+64 \"Magic Def. Bonus\"+3 Haste+6% \"Store TP\"+7 \"Regen\"+2", 
        ["augments"]={
            [1]="Pet: HP+100", 
            [2]="Pet: Accuracy+15", 
            [3]="Pet: Damage taken -3%"
        }, 
        ["STR"]=45, 
        ["DEF"]=114, 
        ["item_level"]=119, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=8, 
        ["VIT"]=15, 
        ["Attack"]=33
    }, 
    [360]={
        ["Ranged Attack"]=25, 
        ["STR"]=13, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["DEX"]=28, 
        ["Haste"]=4, 
        ["MND"]=13, 
        ["Critical hit rate"]=4, 
        ["discription"]="DEF:79 HP+13 STR+13 DEX+28 VIT+13 AGI+38 INT+1 MND+13 CHR+31 Attack+25 Ranged Attack+25 Evasion+72 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+4% Critical hit rate +4% Critical hit damage +5%", 
        ["AGI"]=38, 
        ["en"]="Thereoid Greaves", 
        ["HP"]=13, 
        ["id"]=27503, 
        ["item_level"]=119, 
        ["INT"]=1, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=79, 
        ["Evasion"]=72, 
        ["CHR"]=31, 
        ["VIT"]=13, 
        ["category"]="Armor", 
        ["Critical hit damage"]=5, 
        ["Attack"]=25
    }, 
    [361]={
        ["discription"]="DMG:142 Delay:278 VIT+15 INT+6 MND+6 Accuracy+27 Club skill +228 Parrying skill +228 Magic Accuracy skill +188 Enmity+6 Physical damage taken -10% Additional effect: Earth damage", 
        ["VIT"]=15, 
        ["MND"]=6, 
        ["damage"]=142, 
        ["Club skill"]=228, 
        ["skill"]="Club", 
        ["item_level"]=119, 
        ["delay"]=278, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=27, 
        ["INT"]=6, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=21102, 
        ["category"]="Weapon", 
        ["Parrying skill"]=228, 
        ["PDT"]=-10, 
        ["en"]="Mafic Cudgel"
    }, 
    [362]={
        ["Evasion"]=38, 
        ["Haste"]=3, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=19, 
        ["discription"]="DEF:128 HP+50 MP+67 STR+19 DEX+19 VIT+19 AGI+19 INT+35 MND+28 CHR+28 Magic Damage+10 Evasion+38 Magic Evasion+91 \"Magic Atk. Bonus\"+25 \"Magic Def. Bonus\"+7 Haste+3% \"Conserve MP\"+5 \"Refresh\"+2", 
        ["MND"]=28, 
        ["id"]=25705, 
        ["slots"]={
            [5]="Body"
        }, 
        ["AGI"]=19, 
        ["en"]="Witching Robe", 
        ["HP"]=50, 
        ["augments"]={
            [1]="MP+25", 
            [2]="Mag. Acc.+1", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["VIT"]=19, 
        ["STR"]=19, 
        ["DEF"]=128, 
        ["MP"]=92, 
        ["item_level"]=119, 
        ["INT"]=35, 
        ["category"]="Armor", 
        ["CHR"]=28, 
        ["Magic Atk. Bonus"]=25, 
        ["Magic Accuracy"]=1
    }, 
    [363]={
        ["Magic Accuracy"]=13, 
        ["category"]="Weapon", 
        ["MND"]=20, 
        ["INT"]=6, 
        ["Club skill"]=242, 
        ["Magic Atk. Bonus"]=16, 
        ["item_level"]=119, 
        ["delay"]=288, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["skill"]="Club", 
        ["discription"]="DMG:156 Delay:288 INT+6 MND+20 Magic Accuracy+13 \"Magic Atk. Bonus\"+16 Magic Damage+124 Club skill +242 Parrying skill +242 Magic Accuracy skill +215", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["en"]="Cagliostro's Rod", 
        ["id"]=21116, 
        ["Parrying skill"]=242, 
        ["damage"]=156
    }, 
    [364]={
        ["discription"]="DMG:147 Delay:300 HP+30 STR+5 Ranged Accuracy+27 Archery skill +228 Unity Ranking: Ranged Accuracy+10～20 Daytime: \"Regen\"+2", 
        ["Ranged Accuracy"]=27, 
        ["delay"]=300, 
        ["category"]="Weapon", 
        ["STR"]=5, 
        ["en"]="Mengado", 
        ["HP"]=30, 
        ["Archery skill"]=228, 
        ["skill"]="Archery", 
        ["slots"]={
            [2]="Range"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["id"]=21222, 
        ["item_level"]=119, 
        ["damage"]=147
    }, 
    [365]={
        ["Evasion"]=69, 
        ["Haste"]=4, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEX"]=39, 
        ["MND"]=28, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=47
        }, 
        ["item_level"]=119, 
        ["slots"]={
            [5]="Body"
        }, 
        ["AGI"]=33, 
        ["en"]="Pillager's Vest +2", 
        ["HP"]=88, 
        ["id"]=23112, 
        ["Critical hit damage"]=5, 
        ["STR"]=29, 
        ["DEF"]=141, 
        ["MP"]=44, 
        ["Accuracy"]=50, 
        ["INT"]=28, 
        ["category"]="Armor", 
        ["CHR"]=28, 
        ["VIT"]=29, 
        ["discription"]="DEF:141 HP+88 MP+44 STR+29 DEX+39 VIT+29 AGI+33 INT+28 MND+28 CHR+28 Accuracy+50 Evasion+69 Magic Evasion+84 \"Magic Def. Bonus\"+6 Haste+4% \"Triple Attack\"+4% \"Hide\" duration +100 Critical hit damage +5% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy"
    }, 
    [366]={
        ["Evasion"]=41, 
        ["MND"]=40, 
        ["item_level"]=119, 
        ["jobs"]={
            [7]="PLD", 
            [22]="RUN"
        }, 
        ["DEX"]=30, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Regal Gauntlets", 
        ["DEF"]=126, 
        ["discription"]="DEF:126 HP+205 MP+29 STR+30 DEX+30 VIT+40 AGI+20 INT+30 MND+40 CHR+30 Accuracy+45 Evasion+41 Magic Evasion+48 \"Magic Def. Bonus\"+2 Haste+4% \"Regen\"+10 \"Refresh\"+1 Spell interruption rate down 10% Enhancing magic duration +20%", 
        ["HP"]=205, 
        ["id"]=25824, 
        ["VIT"]=40, 
        ["Haste"]=4, 
        ["MP"]=29, 
        ["Accuracy"]=45, 
        ["STR"]=30, 
        ["CHR"]=30, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["AGI"]=20
    }, 
    [367]={
        ["damage"]=286, 
        ["item_level"]=119, 
        ["delay"]=412, 
        ["Parrying skill"]=255, 
        ["category"]="Weapon", 
        ["Staff skill"]=255, 
        ["en"]="Malignance Pole", 
        ["HP"]=150, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [7]="PLD", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["skill"]="Staff", 
        ["discription"]="DMG:286 Delay:412 HP+150 VIT+40 Accuracy+40 Staff skill +255 Parrying skill +255 Magic Accuracy skill +215 Weapon skill damage +15% Damage taken -20%", 
        ["slots"]={
            [0]="Main"
        }, 
        ["VIT"]=40, 
        ["id"]=22087, 
        ["Accuracy"]=40, 
        ["DT"]=-20
    }, 
    [368]={
        ["Attack"]=26, 
        ["category"]="Weapon", 
        ["Parrying skill"]=228, 
        ["INT"]=13, 
        ["Great Sword skill"]=228, 
        ["item_level"]=119, 
        ["en"]="Foreshock Sword", 
        ["delay"]=504, 
        ["jobs"]={
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["skill"]="Great Sword", 
        ["discription"]="DMG:273 Delay:504 VIT+8 INT+13 Accuracy+15 Attack+26 Great Sword skill +228 Parrying skill +228 Magic Accuracy skill +188 \"Spinning Slash\" damage +35%", 
        ["slots"]={
            [0]="Main"
        }, 
        ["VIT"]=8, 
        ["id"]=20757, 
        ["Accuracy"]=15, 
        ["damage"]=273
    }, 
    [369]={
        ["Evasion"]=49, 
        ["STR"]=30, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=35, 
        ["Haste"]=4, 
        ["MND"]=25, 
        ["id"]=26950, 
        ["item_level"]=119, 
        ["AGI"]=30, 
        ["en"]="Rawhide Vest", 
        ["HP"]=109, 
        ["augments"]={
            [1]="HP+50", 
            [2]="\"Subtle Blow\"+7", 
            [3]="\"Triple Atk.\"+2"
        }, 
        ["discription"]="DEF:130 HP+59 MP+44 STR+30 DEX+35 VIT+26 AGI+30 INT+25 MND+25 CHR+25 Accuracy+15 Attack+15 \"Magic Atk. Bonus\"+25 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+4% \"Triple Attack\"+2%", 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=130, 
        ["MP"]=44, 
        ["Accuracy"]=15, 
        ["INT"]=25, 
        ["category"]="Armor", 
        ["CHR"]=25, 
        ["VIT"]=26, 
        ["Magic Atk. Bonus"]=25, 
        ["Attack"]=15
    }, 
    [370]={
        ["discription"]="DMG:270 Delay:480 STR+15 DEX+15 VIT+15 Accuracy+15 Attack+15 Magic Evasion+25 Magic Accuracy skill +188 Great Sword skill +242 Parrying skill +242 Enmity+7", 
        ["en"]="Humility", 
        ["VIT"]=15, 
        ["jobs"]={
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["slots"]={
            [0]="Main"
        }, 
        ["item_level"]=119, 
        ["Great Sword skill"]=242, 
        ["augments"]={
            [1]="STR+8", 
            [2]="Accuracy+10", 
            [3]="Attack+9", 
            [4]="DMG:+13", 
            [5]="none"
        }, 
        ["delay"]=480, 
        ["DEX"]=15, 
        ["id"]=21697, 
        ["category"]="Weapon", 
        ["skill"]="Great Sword", 
        ["STR"]=23, 
        ["damage"]=283, 
        ["Accuracy"]=25, 
        ["Parrying skill"]=242, 
        ["Attack"]=24
    }, 
    [371]={
        ["discription"]="DMG:94 Delay:201 Magic Accuracy+25 \"Magic Atk. Bonus\"+34 Magic Damage+118 Magic Accuracy skill +201 Dagger skill +242 Parrying skill +242 \"Undead Killer\"+10", 
        ["augments"]={
            [1]="INT+10", 
            [2]="Mag. Acc.+10", 
            [3]="\"Mag.Atk.Bns.\"+8", 
            [4]="\"Fast Cast\"+5", 
            [5]="none"
        }, 
        ["en"]="Malevolence", 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["skill"]="Dagger", 
        ["Fast Cast"]=5, 
        ["item_level"]=119, 
        ["delay"]=201, 
        ["Dagger skill"]=242, 
        ["Parrying skill"]=242, 
        ["INT"]=10, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=20595, 
        ["category"]="Weapon", 
        ["damage"]=94, 
        ["Magic Atk. Bonus"]=42, 
        ["Magic Accuracy"]=35
    }, 
    [372]={
        ["MDT"]=-2, 
        ["MND"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["id"]=20734, 
        ["item_level"]=119, 
        ["skill"]="Sword", 
        ["en"]="Anahera Sword", 
        ["delay"]=264, 
        ["Parrying skill"]=228, 
        ["Sword skill"]=228, 
        ["MP"]=20, 
        ["discription"]="DMG:143 Delay:264 MP+20 MND+15 Attack+26 Sword skill +228 Shield skill +15 Parrying skill +228 Magic Accuracy skill +188 Magic damage taken -2%", 
        ["damage"]=143, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["Shield skill"]=15, 
        ["Attack"]=26
    }, 
    [373]={
        ["discription"]="DMG:156 Delay:288 Axe skill +242 Parrying skill +242 Magic Accuracy skill +188 Enmity-6 Pet: Evasion+40 Enmity+6", 
        ["category"]="Weapon", 
        ["skill"]="Axe", 
        ["item_level"]=119, 
        ["en"]="Anahera Tabar", 
        ["delay"]=288, 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [9]="BST"
        }, 
        ["Axe skill"]=242, 
        ["id"]=20822, 
        ["damage"]=156
    }, 
    [374]={
        ["damage"]=300, 
        ["en"]="Ferocity", 
        ["VIT"]=30, 
        ["Parrying skill"]=242, 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["Great Axe skill"]=242, 
        ["delay"]=504, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["skill"]="Great Axe", 
        ["discription"]="DMG:285 Delay:504 STR+20 VIT+20 Attack+25 Great Axe skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Double Attack\"+3% \"Regen\"+3", 
        ["slots"]={
            [0]="Main"
        }, 
        ["id"]=20844, 
        ["augments"]={
            [1]="STR+10", 
            [2]="VIT+10", 
            [3]="\"Dbl.Atk.\"+3", 
            [4]="DMG:+15", 
            [5]="none"
        }, 
        ["STR"]=30, 
        ["Attack"]=25
    }, 
    [375]={
        ["discription"]="DMG:115 Delay:231 Sword skill +242 Parrying skill +242 Enhancing magic skill +10 Magic Accuracy skill +188 Sword enhancement spell damage +10 \"Stoneskin\" casting time -10% Unity Ranking: INT+5～15", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=242, 
        ["category"]="Weapon", 
        ["Sword skill"]=242, 
        ["en"]="Pukulatmuj", 
        ["delay"]=231, 
        ["INT"]=15, 
        ["skill"]="Sword", 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["id"]=20613, 
        ["Unity Ranking Bonus Applied"]="INT + 15", 
        ["damage"]=115
    }, 
    [376]={
        ["Evasion"]=41, 
        ["MND"]=29, 
        ["item_level"]=119, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEX"]=21, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Count's Garb", 
        ["DEF"]=130, 
        ["discription"]="DEF:130 HP+54 MP+59 STR+21 DEX+21 VIT+21 AGI+21 INT+38 MND+29 CHR+29 Evasion+41 Magic Evasion+80 \"Magic Atk. Bonus\"+30 \"Magic Def. Bonus\"+6 Haste+7% Magic critical hit rate +15 Magic critical hit damage +10%", 
        ["HP"]=54, 
        ["id"]=26945, 
        ["Magic Atk. Bonus"]=30, 
        ["Haste"]=7, 
        ["MP"]=59, 
        ["VIT"]=21, 
        ["STR"]=21, 
        ["CHR"]=29, 
        ["INT"]=38, 
        ["category"]="Armor", 
        ["AGI"]=21
    }, 
    [377]={
        ["Evasion"]=66, 
        ["MND"]=19, 
        ["id"]=26674, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=19, 
        ["Haste"]=8, 
        ["AGI"]=17, 
        ["STR"]=35, 
        ["en"]="Rao Kabuto", 
        ["item_level"]=119, 
        ["discription"]="DEF:102 STR+35 DEX+19 VIT+24 AGI+17 INT+15 MND+19 CHR+15 Accuracy+32 Evasion+66 Magic Evasion+43 \"Magic Def. Bonus\"+4 Haste+8% Critical hit rate +4% \"Regen\"+2", 
        ["Accuracy"]=32, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=102, 
        ["augments"]={
            [1]="Pet: HP+100", 
            [2]="Pet: Accuracy+15", 
            [3]="Pet: Damage taken -3%"
        }, 
        ["INT"]=15, 
        ["category"]="Armor", 
        ["CHR"]=15, 
        ["VIT"]=24, 
        ["Critical hit rate"]=4
    }, 
    [378]={
        ["MDT"]=-3, 
        ["MND"]=21, 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [13]="NIN", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=22, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Skormoth Mask", 
        ["discription"]="DEF:100 HP+36 STR+20 DEX+22 VIT+22 AGI+22 INT+21 MND+21 CHR+21 Accuracy+26 Evasion+38 Magic Evasion+43 \"Magic Def. Bonus\"+4 Haste+8% \"Triple Attack\"+4% Magic damage taken -3%", 
        ["DEF"]=100, 
        ["HP"]=36, 
        ["id"]=27783, 
        ["VIT"]=22, 
        ["Haste"]=8, 
        ["Evasion"]=38, 
        ["Accuracy"]=26, 
        ["STR"]=20, 
        ["CHR"]=21, 
        ["INT"]=21, 
        ["category"]="Armor", 
        ["AGI"]=22
    }, 
    [379]={
        ["discription"]="DMG:120 Delay:227 STR+12 DEX+12 VIT+12 AGI+12 INT+12 MND+12 CHR+12 Accuracy+20 Ranged Accuracy+20 \"Magic Atk. Bonus\"+14 Magic Damage+108 Katana skill +242 Parrying skill +242 Magic Accuracy skill +201 Magic burst damage II +13 \"Subtle Blow\"+8", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["STR"]=16, 
        ["DEX"]=18, 
        ["item_level"]=119, 
        ["id"]=20978, 
        ["MND"]=12, 
        ["Katana skill"]=242, 
        ["Ranged Accuracy"]=20, 
        ["AGI"]=12, 
        ["en"]="Ochu", 
        ["delay"]=227, 
        ["Accuracy"]=20, 
        ["Parrying skill"]=242, 
        ["INT"]=12, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Ninjutsu skill"]=6, 
        ["VIT"]=12, 
        ["CHR"]=12, 
        ["Magic Atk. Bonus"]=14, 
        ["category"]="Weapon", 
        ["augments"]={
            [1]="STR+4", 
            [2]="DEX+6", 
            [3]="Ninjutsu skill +6", 
            [4]="DMG:+9", 
            [5]="none"
        }, 
        ["damage"]=129, 
        ["skill"]="Katana"
    }, 
    [380]={
        ["Evasion"]=22, 
        ["id"]=20979, 
        ["skill"]="Katana", 
        ["Dual Wield"]=5, 
        ["Katana skill"]=242, 
        ["item_level"]=119, 
        ["en"]="Aizushintogo", 
        ["delay"]=227, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="DMG:+15", 
            [2]="STR+15", 
            [3]="Accuracy+10"
        }, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["discription"]="DMG:123 Delay:227 Accuracy+15 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Dual Wield\"+5 \"Utsusemi\" spellcasting time -7%  Attack based on number of Utsusemi shadow images +5", 
        ["damage"]=138, 
        ["Accuracy"]=25, 
        ["Parrying skill"]=242, 
        ["STR"]=15
    }, 
    [381]={
        ["Evasion"]=149, 
        ["STR"]=93, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEX"]=76, 
        ["Haste"]=16, 
        ["MND"]=60, 
        ["item_level"]=119, 
        ["discription"]="Cannot equip leggear DEF:428 HP+164 MP+88 STR+93 DEX+76 VIT+102 AGI+70 INT+51 MND+60 CHR+65 Accuracy+124 Attack+147 Evasion+149 Magic Evasion+252 \"Magic Def. Bonus\"+12 Haste+16% \"Double Attack\"+10% \"Resist Stun\"+90 Damage taken -10% Enchantment: Meteor", 
        ["AGI"]=70, 
        ["en"]="Onca Suit", 
        ["HP"]=164, 
        ["id"]=26963, 
        ["Attack"]=147, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=428, 
        ["MP"]=88, 
        ["Accuracy"]=124, 
        ["INT"]=51, 
        ["category"]="Armor", 
        ["CHR"]=65, 
        ["VIT"]=102, 
        ["DT"]=-10
    }, 
    [382]={
        ["Evasion"]=82, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=35, 
        ["Haste"]=4, 
        ["MND"]=34, 
        ["Dual Wield"]=10, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=84
        }, 
        ["id"]=23454, 
        ["item_level"]=119, 
        ["HP"]=98, 
        ["Critical hit rate"]=8, 
        ["en"]="Hachiya Chain. +3", 
        ["INT"]=34, 
        ["STR"]=39, 
        ["DEF"]=152, 
        ["Accuracy"]=50, 
        ["CHR"]=34, 
        ["VIT"]=36, 
        ["category"]="Armor", 
        ["discription"]="DEF:152 HP+98 STR+39 DEX+35 VIT+36 AGI+35 INT+34 MND+34 CHR+34 Accuracy+50 Evasion+82 Magic Evasion+73 \"Magic Def. Bonus\"+5 Haste+4% \"Dual Wield\"+10 \"Subtle Blow\"+9 Critical hit rate +8% Physical damage: \"Shock Spikes\" effect Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["AGI"]=35
    }, 
    [383]={
        ["Evasion"]=55, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }, 
            ["set id"]=477
        }, 
        ["DEX"]=11, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Critical hit rate"]=7, 
        ["MND"]=15, 
        ["discription"]="DEF:123 HP+52 MP+25 STR+33 DEX+11 VIT+16 AGI+45 INT+29 MND+15 CHR+12 Accuracy+45 Ranged Accuracy+45 Magic Accuracy+45 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+6% Critical hit rate +7% Damage taken -5% Set: Increases Dexterity, Agility, and Charisma", 
        ["Ranged Accuracy"]=45, 
        ["item_level"]=119, 
        ["en"]="Mummu Kecks +2", 
        ["HP"]=52, 
        ["Accuracy"]=45, 
        ["id"]=25887, 
        ["STR"]=33, 
        ["INT"]=29, 
        ["DEF"]=123, 
        ["MP"]=25, 
        ["Haste"]=6, 
        ["CHR"]=12, 
        ["Magic Accuracy"]=45, 
        ["category"]="Armor", 
        ["AGI"]=45, 
        ["VIT"]=16, 
        ["DT"]=-5
    }, 
    [384]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["Magic Atk. Bonus"]=10, 
        ["id"]=26258, 
        ["INT"]=20, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="INT+20", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="Magic Damage +10", 
            [4]="\"Mag.Atk.Bns.\"+10", 
            [5]="none"
        }, 
        ["DEF"]=16, 
        ["Magic Accuracy"]=20
    }, 
    [385]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["DT"]=-5, 
        ["en"]="Andartia's Mantle", 
        ["id"]=26258, 
        ["DEX"]=20, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=30, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="Accuracy+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["Attack"]=20
    }, 
    [386]={
        ["Ranged Attack"]=22, 
        ["MND"]=5, 
        ["id"]=27471, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=29, 
        ["DEF"]=87, 
        ["item_level"]=119, 
        ["discription"]="DEF:87 HP+18 STR+26 DEX+19 VIT+11 AGI+38 MND+5 CHR+19 Attack+22 Ranged Attack+22 Evasion+55 Magic Evasion+80 \"Magic Def. Bonus\"+2 Haste+3% \"Zanshin\"+4 Zanshin: Occasionally attacks twice +10%", 
        ["en"]="Ryuo Sune-Ate", 
        ["HP"]=18, 
        ["Evasion"]=55, 
        ["Accuracy"]=15, 
        ["CHR"]=19, 
        ["STR"]=36, 
        ["Haste"]=3, 
        ["augments"]={
            [1]="STR+10", 
            [2]="DEX+10", 
            [3]="Accuracy+15"
        }, 
        ["category"]="Armor", 
        ["AGI"]=38, 
        ["VIT"]=11, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Attack"]=22
    }, 
    [387]={
        ["Evasion"]=41, 
        ["Haste"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=39, 
        ["PDT"]=-2, 
        ["MND"]=26, 
        ["STR"]=24, 
        ["Ranged Accuracy"]=12, 
        ["augments"]={
            [1]="Accuracy+14", 
            [2]="\"Triple Atk.\"+4", 
            [3]="STR+8", 
            [4]="Attack+15", 
            [5]="none"
        }, 
        ["en"]="Herculean Gloves", 
        ["HP"]=20, 
        ["id"]=27140, 
        ["item_level"]=119, 
        ["INT"]=14, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=97, 
        ["Accuracy"]=26, 
        ["CHR"]=19, 
        ["VIT"]=30, 
        ["category"]="Armor", 
        ["discription"]="DEF:97 HP+20 STR+16 DEX+39 VIT+30 AGI+8 INT+14 MND+26 CHR+19 Accuracy+12 Ranged Accuracy+12 Evasion+41 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+2% \"Subtle Blow\"+5 Physical damage taken -2%", 
        ["AGI"]=8, 
        ["Attack"]=15
    }, 
    [388]={
        ["Evasion"]=70, 
        ["MND"]=23, 
        ["Critical hit rate"]=9, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=39, 
        ["Ranged Accuracy"]=47, 
        ["item_level"]=119, 
        ["Haste"]=4, 
        ["STR"]=33, 
        ["HP"]=122, 
        ["en"]="Ken. Samue +1", 
        ["Accuracy"]=52, 
        ["INT"]=24, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=150, 
        ["id"]=26528, 
        ["CHR"]=21, 
        ["VIT"]=21, 
        ["category"]="Armor", 
        ["discription"]="DEF:150 HP+122 STR+33 DEX+39 VIT+21 AGI+37 INT+24 MND+23 CHR+21 Accuracy+52 Ranged Accuracy+47 Evasion+70 Magic Evasion+117 \"Magic Def. Bonus\"+9 Haste+4% \"Triple Attack\"+6% \"Subtle Blow\"+12 Critical hit rate +9%", 
        ["AGI"]=37
    }, 
    [389]={
        ["discription"]="DMG:154 Delay:222 HP+150 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Magic Damage+217 Katana skill +269 Parrying skill +269 Magic Accuracy skill +255 Attack+15 for each Utsusemi shadow image", 
        ["augments"]={
            [1]="Path: B"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Ranged Accuracy"]=50, 
        ["item_level"]=119, 
        ["Katana skill"]=269, 
        ["HP"]=150, 
        ["delay"]=222, 
        ["en"]="Fudo Masamune", 
        ["id"]=21917, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["Attack"]=15, 
        ["damage"]=154, 
        ["Accuracy"]=50, 
        ["Parrying skill"]=269, 
        ["Magic Accuracy"]=50
    }, 
    [390]={
        ["discription"]="Accuracy+25 Ranged Accuracy+25 \"Store TP\"+7", 
        ["Ranged Accuracy"]=25, 
        ["category"]="Armor", 
        ["en"]="Ninja Nodowa +2", 
        ["Store TP"]=7, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=25, 
        ["id"]=25491
    }, 
    [391]={
        ["MDT"]=-3, 
        ["MND"]=18, 
        ["id"]=26793, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=24, 
        ["discription"]="DEF:98 HP+86 STR+17 DEX+24 VIT+19 AGI+19 INT+18 MND+18 CHR+18 Accuracy+18 Evasion+38 Magic Evasion+43 \"Magic Def. Bonus\"+4 Haste+8% Magic damage taken -3%", 
        ["AGI"]=19, 
        ["Haste"]=8, 
        ["slots"]={
            [4]="Head"
        }, 
        ["HP"]=136, 
        ["item_level"]=119, 
        ["Accuracy"]=18, 
        ["STR"]=17, 
        ["DEF"]=98, 
        ["Evasion"]=58, 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Evasion+20"
        }, 
        ["INT"]=18, 
        ["category"]="Armor", 
        ["CHR"]=18, 
        ["VIT"]=29, 
        ["en"]="Naga Somen"
    }, 
    [392]={
        ["discription"]="DMG:157 Delay:227 DEX+15 AGI+15 INT+15 Accuracy+40 Attack+30 Ranged Accuracy+40 Magic Accuracy+40 \"Magic Atk. Bonus\"+16 Magic Damage+217 Katana skill +250 Parrying skill +250 Magic Accuracy skill +250 Main hand: \"Blade: Ku\" \"Blade: Ku\" damage +60% Enhances \"Regain\" based on \"Dual Wield\" effect", 
        ["item_level"]=119, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=15, 
        ["Ranged Accuracy"]=40, 
        ["en"]="Gokotai", 
        ["Katana skill"]=250, 
        ["AGI"]=15, 
        ["delay"]=227, 
        ["Attack"]=30, 
        ["Accuracy"]=40, 
        ["INT"]=15, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=21922, 
        ["category"]="Weapon", 
        ["damage"]=157, 
        ["Magic Atk. Bonus"]=16, 
        ["Parrying skill"]=250, 
        ["Magic Accuracy"]=40
    }, 
    [393]={
        ["Evasion"]=73, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["STR"]=31, 
        ["DEX"]=31, 
        ["Haste"]=8, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Yonin\" and \"Innin\" effect", 
            [4]="none"
        }, 
        ["MND"]=32, 
        ["item_level"]=119, 
        ["discription"]="DEF:120 HP+56 STR+31 DEX+31 VIT+33 AGI+33 INT+32 MND+32 CHR+32 Accuracy+44 Attack+62 Magic Accuracy+37 Evasion+73 Magic Evasion+63 \"Magic Atk. Bonus\"+61 \"Magic Def. Bonus\"+6 Parrying skill +20 Haste+8% Ninjutsu damage +21", 
        ["id"]=23410, 
        ["AGI"]=33, 
        ["HP"]=56, 
        ["Accuracy"]=44, 
        ["Parrying skill"]=20, 
        ["INT"]=32, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=120, 
        ["en"]="Mochi. Hatsuburi +3", 
        ["CHR"]=32, 
        ["Magic Atk. Bonus"]=61, 
        ["category"]="Armor", 
        ["Attack"]=62, 
        ["VIT"]=33, 
        ["Magic Accuracy"]=37
    }, 
    [394]={
        ["discription"]="DEF:73 HP+15 STR+14 DEX+26 VIT+12 AGI+39 MND+12 CHR+30 Evasion+80 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+5% \"Critical Parry\"+20 \"Utsusemi\"+1 Set: Augments \"Dual Wield\"", 
        ["MND"]=12, 
        ["en"]="Hattori Kyahan +1", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=73, 
        ["AGI"]=39, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["item_level"]=119, 
        ["HP"]=15, 
        ["DEX"]=26, 
        ["id"]=27436, 
        ["STR"]=14, 
        ["Haste"]=5, 
        ["Evasion"]=80, 
        ["CHR"]=30, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=222
        }
    }, 
    [395]={
        ["discription"]="DEF:12 Enmity-2 Movement speed +12%", 
        ["DEF"]=12, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Danzo Sune-Ate", 
        ["id"]=12997, 
        ["category"]="Armor", 
        ["jobs"]={
            [12]="SAM", 
            [13]="NIN"
        }
    }, 
    [396]={
        ["Evasion"]=41, 
        ["STR"]=48, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=16, 
        ["Haste"]=6, 
        ["MND"]=16, 
        ["id"]=27295, 
        ["Ranged Accuracy"]=15, 
        ["Store TP"]=7, 
        ["item_level"]=119, 
        ["HP"]=41, 
        ["augments"]={
            [1]="STR+10", 
            [2]="DEX+10", 
            [3]="\"Dbl.Atk.\"+3", 
            [4]="\"Triple Atk.\"+3", 
            [5]="none"
        }, 
        ["en"]="Samnuha Tights", 
        ["INT"]=28, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=116, 
        ["Accuracy"]=15, 
        ["CHR"]=8, 
        ["VIT"]=15, 
        ["category"]="Armor", 
        ["discription"]="DEF:116 HP+41 STR+38 DEX+6 VIT+15 AGI+30 INT+28 MND+16 CHR+8 +30 Accuracy+15 Ranged Accuracy+15 Evasion+41 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% \"Store TP\"+7", 
        ["AGI"]=30
    }, 
    [397]={
        ["Evasion"]=24, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["Haste"]=4, 
        ["DEX"]=50, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Attack"]=20
                }, 
                [3]={
                    ["Attack"]=30
                }, 
                [4]={
                    ["Attack"]=40
                }, 
                [5]={
                    ["Attack"]=50
                }
            }, 
            ["set id"]=239
        }, 
        ["augments"]={
            [1]="DEX+12", 
            [2]="Accuracy+25", 
            [3]="\"Dbl.Atk.\"+4"
        }, 
        ["MND"]=30, 
        ["STR"]=12, 
        ["Ranged Accuracy"]=33, 
        ["AGI"]=13, 
        ["item_level"]=119, 
        ["HP"]=29, 
        ["Accuracy"]=58, 
        ["Critical hit damage"]=5, 
        ["INT"]=12, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=106, 
        ["en"]="Ryuo Tekko +1", 
        ["CHR"]=17, 
        ["id"]=27116, 
        ["category"]="Armor", 
        ["Critical hit rate"]=5, 
        ["VIT"]=30, 
        ["discription"]="DEF:106 HP+29 STR+12 DEX+38 VIT+30 AGI+13 INT+12 MND+30 CHR+17 Accuracy+33 Ranged Accuracy+33 Evasion+24 Magic Evasion+32 \"Magic Def. Bonus\"+1 Haste+4% Critical hit rate +5% Critical hit damage +5% Set: Increases Attack"
    }, 
    [398]={
        ["Evasion"]=44, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["STR"]=28, 
        ["DEX"]=24, 
        ["Haste"]=3, 
        ["augments"]={
            [1]="HP+65", 
            [2]="\"Store TP\"+8", 
            [3]="\"Dbl.Atk.\"+4"
        }, 
        ["MND"]=19, 
        ["AGI"]=29, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Attack"]=20
                }, 
                [3]={
                    ["Attack"]=30
                }, 
                [4]={
                    ["Attack"]=40
                }, 
                [5]={
                    ["Attack"]=50
                }
            }, 
            ["set id"]=239
        }, 
        ["Store TP"]=8, 
        ["en"]="Ryuo Domaru +1", 
        ["HP"]=233, 
        ["Accuracy"]=37, 
        ["discription"]="DEF:148 HP+168 STR+28 DEX+24 VIT+23 AGI+29 INT+19 MND+19 CHR+19 Accuracy+37 Attack+37 Evasion+44 Magic Evasion+59 \"Magic Def. Bonus\"+4 Haste+3% Critical hit rate +5% Physical damage taken -5% Set: Increases Attack", 
        ["INT"]=19, 
        ["CHR"]=19, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=148, 
        ["item_level"]=119, 
        ["category"]="Armor", 
        ["VIT"]=23, 
        ["Critical hit rate"]=5, 
        ["id"]=25685, 
        ["PDT"]=-5, 
        ["Attack"]=37
    }, 
    [399]={
        ["Evasion"]=49, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["STR"]=16, 
        ["DEX"]=53, 
        ["Haste"]=5, 
        ["Critical hit rate"]=6, 
        ["MND"]=26, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }, 
            ["set id"]=477
        }, 
        ["Ranged Accuracy"]=43, 
        ["AGI"]=22, 
        ["en"]="Mummu Wrists +2", 
        ["HP"]=45, 
        ["Accuracy"]=43, 
        ["id"]=25836, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=106, 
        ["MP"]=15, 
        ["discription"]="DEF:106 HP+45 MP+15 STR+16 DEX+53 VIT+30 AGI+22 INT+14 MND+26 CHR+21 Accuracy+43 Ranged Accuracy+43 Magic Accuracy+43 Evasion+49 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Double Attack\"+6% Critical hit rate +6% Set: Increases Dexterity, Agility, and Charisma", 
        ["INT"]=14, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["item_level"]=119, 
        ["VIT"]=30, 
        ["Magic Accuracy"]=43
    }, 
    [400]={
        ["Evasion"]=59, 
        ["MND"]=16, 
        ["Critical hit rate"]=7, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=5, 
        ["Ranged Accuracy"]=46, 
        ["item_level"]=119, 
        ["Haste"]=9, 
        ["STR"]=37, 
        ["HP"]=115, 
        ["en"]="Ken. Hakama +1", 
        ["Accuracy"]=51, 
        ["INT"]=32, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=132, 
        ["id"]=25892, 
        ["CHR"]=12, 
        ["VIT"]=25, 
        ["category"]="Armor", 
        ["discription"]="DEF:132 HP+115 STR+37 DEX+5 VIT+25 AGI+33 INT+32 MND+16 CHR+12 Accuracy+51 Ranged Accuracy+46 Evasion+59 Magic Evasion+139 \"Magic Def. Bonus\"+8 Haste+9% \"Triple Attack\"+5% \"Subtle Blow\"+10 Critical hit rate +7%", 
        ["AGI"]=33
    }, 
    [401]={
        ["Evasion"]=49, 
        ["MND"]=17, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=31, 
        ["en"]="Hattori Zukin +1", 
        ["AGI"]=22, 
        ["Dual Wield"]=7, 
        ["item_level"]=119, 
        ["HP"]=41, 
        ["Haste"]=10, 
        ["discription"]="DEF:101 HP+41 STR+19 DEX+31 VIT+18 AGI+22 INT+17 MND+17 CHR+17 Evasion+49 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+10% \"Dual Wield\"+7 Innin: \"Double Attack\"+9% Set: Augments \"Dual Wield\"", 
        ["STR"]=19, 
        ["DEF"]=101, 
        ["id"]=26765, 
        ["INT"]=17, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["VIT"]=18, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=222
        }
    }, 
    [402]={
        ["Evasion"]=68, 
        ["MND"]=31, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=33, 
        ["discription"]="DEF:122 HP+64 STR+33 DEX+33 VIT+32 AGI+32 INT+31 MND+31 CHR+31 Magic Accuracy+54 Evasion+68 Magic Evasion+63 \"Magic Def. Bonus\"+5 Ninjutsu skill +17 Haste+8% \"Subtle Blow\"+9 Weapon skill damage +10% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["AGI"]=32, 
        ["en"]="Hachiya Hatsu. +3", 
        ["item_level"]=119, 
        ["HP"]=64, 
        ["DEF"]=122, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=84
        }, 
        ["STR"]=33, 
        ["Haste"]=8, 
        ["Ninjutsu skill"]=17, 
        ["id"]=23387, 
        ["INT"]=31, 
        ["category"]="Armor", 
        ["CHR"]=31, 
        ["VIT"]=32, 
        ["Magic Accuracy"]=54
    }, 
    [403]={
        ["Ranged Attack"]=10, 
        ["DEX"]=24, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["discription"]="DEF:79 HP+9 STR+16 DEX+24 VIT+10 AGI+43 MND+11 CHR+26 Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+5 Evasion+80 Magic Evasion+75 Haste+4% \"Triple Attack\"+2 \"Subtle Blow\"+6 Physical damage taken -2%", 
        ["augments"]={
            [1]="Crit. hit damage +1%", 
            [2]="\"Fast Cast\"+4", 
            [3]="\"Treasure Hunter\"+2", 
            [4]="none", 
            [5]="none"
        }, 
        ["Accuracy"]=10, 
        ["Fast Cast"]=4, 
        ["Ranged Accuracy"]=10, 
        ["en"]="Herculean Boots", 
        ["MND"]=11, 
        ["AGI"]=43, 
        ["item_level"]=119, 
        ["HP"]=9, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=4, 
        ["Attack"]=10, 
        ["CHR"]=26, 
        ["STR"]=16, 
        ["DEF"]=79, 
        ["Critical hit damage"]=1, 
        ["PDT"]=-2, 
        ["Evasion"]=80, 
        ["VIT"]=10, 
        ["category"]="Armor", 
        ["id"]=27496, 
        ["Magic Atk. Bonus"]=10, 
        ["Magic Accuracy"]=10
    }, 
    [404]={
        ["Evasion"]=69, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEX"]=48, 
        ["Haste"]=4, 
        ["id"]=25798, 
        ["MND"]=20, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }, 
            ["set id"]=477
        }, 
        ["Ranged Accuracy"]=46, 
        ["Store TP"]=6, 
        ["en"]="Mummu Jacket +2", 
        ["HP"]=60, 
        ["Accuracy"]=46, 
        ["Critical hit rate"]=9, 
        ["STR"]=28, 
        ["INT"]=21, 
        ["DEF"]=141, 
        ["MP"]=35, 
        ["discription"]="DEF:141 HP+60 MP+35 STR+28 DEX+48 VIT+24 AGI+44 INT+21 MND+20 CHR+24 Accuracy+46 Ranged Accuracy+46 Magic Accuracy+46 Evasion+69 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+4% \"Store TP\"+6 Critical hit rate +9% Set: Increases Dexterity, Agility, and Charisma", 
        ["CHR"]=24, 
        ["AGI"]=44, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["VIT"]=24, 
        ["Magic Accuracy"]=46
    }, 
    [405]={
        ["Evasion"]=62, 
        ["MND"]=17, 
        ["Critical hit rate"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=47, 
        ["Ranged Accuracy"]=45, 
        ["item_level"]=119, 
        ["Haste"]=6, 
        ["STR"]=23, 
        ["HP"]=88, 
        ["en"]="Ken. Jinpachi +1", 
        ["Accuracy"]=50, 
        ["INT"]=19, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=120, 
        ["id"]=25552, 
        ["CHR"]=19, 
        ["VIT"]=32, 
        ["category"]="Armor", 
        ["discription"]="DEF:120 HP+88 STR+23 DEX+47 VIT+32 AGI+34 INT+19 MND+17 CHR+19 Accuracy+50 Ranged Accuracy+45 Evasion+62 Magic Evasion+101 \"Magic Def. Bonus\"+6 Haste+6% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit rate +5%", 
        ["AGI"]=34
    }, 
    [406]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["STR"]=30, 
        ["id"]=26258, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="STR+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="STR+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["Attack"]=20
    }, 
    [407]={
        ["Evasion"]=51, 
        ["MND"]=28, 
        ["Critical hit rate"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=62, 
        ["Ranged Accuracy"]=44, 
        ["item_level"]=119, 
        ["Haste"]=4, 
        ["STR"]=14, 
        ["HP"]=61, 
        ["en"]="Ken. Tekko +1", 
        ["Accuracy"]=49, 
        ["INT"]=14, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=108, 
        ["id"]=25979, 
        ["CHR"]=21, 
        ["VIT"]=37, 
        ["category"]="Armor", 
        ["discription"]="DEF:108 HP+61 STR+14 DEX+62 VIT+37 AGI+5 INT+14 MND+28 CHR+21 Accuracy+49 Ranged Accuracy+44 Evasion+51 Magic Evasion+90 \"Magic Def. Bonus\"+5 Haste+4% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit rate +5%", 
        ["AGI"]=5
    }, 
    [408]={
        ["Evasion"]=55, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=37, 
        ["Haste"]=4, 
        ["MND"]=21, 
        ["id"]=26923, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=222
        }, 
        ["item_level"]=119, 
        ["en"]="Hattori Ningi +1", 
        ["HP"]=63, 
        ["Critical hit rate"]=6, 
        ["AGI"]=28, 
        ["INT"]=21, 
        ["STR"]=30, 
        ["DEF"]=133, 
        ["Accuracy"]=24, 
        ["CHR"]=21, 
        ["VIT"]=24, 
        ["category"]="Armor", 
        ["discription"]="DEF:133 HP+63 STR+30 DEX+37 VIT+24 AGI+28 INT+21 MND+21 CHR+21 Accuracy+24 Attack+24 Evasion+55 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% \"Migawari\"+12 Critical hit rate +6% Set: Augments \"Dual Wield\"", 
        ["Attack"]=24
    }, 
    [409]={
        ["Evasion"]=91, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEX"]=40, 
        ["Haste"]=6, 
        ["id"]=23732, 
        ["MND"]=16, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=8, 
        ["en"]="Malignance Chapeau", 
        ["HP"]=45, 
        ["Accuracy"]=50, 
        ["AGI"]=33, 
        ["STR"]=11, 
        ["DEF"]=121, 
        ["MP"]=29, 
        ["discription"]="DEF:121 HP+45 MP+29 STR+11 DEX+40 VIT+19 AGI+33 INT+25 MND+16 CHR+17 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+91 Magic Evasion+123 \"Magic Def. Bonus\"+5 Haste+6% \"Store TP\"+8 Physical damage limit +3% Damage taken -6%", 
        ["INT"]=25, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["Magic Accuracy"]=50, 
        ["VIT"]=19, 
        ["DT"]=-6
    }, 
    [410]={
        ["Evasion"]=72, 
        ["MND"]=26, 
        ["Haste"]=4, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=30, 
        ["STR"]=29, 
        ["AGI"]=27, 
        ["en"]="Naga Samue", 
        ["Store TP"]=5, 
        ["HP"]=169, 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Evasion+20"
        }, 
        ["discription"]="DEF:124 HP+119 STR+29 DEX+30 VIT+23 AGI+27 INT+26 MND+26 CHR+26 Attack+15 Evasion+52 Magic Evasion+53 \"Magic Def. Bonus\"+4 Haste+4% \"Store TP\"+5", 
        ["INT"]=26, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=124, 
        ["id"]=26949, 
        ["CHR"]=26, 
        ["VIT"]=33, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["Attack"]=15
    }, 
    [411]={
        ["Evasion"]=55, 
        ["STR"]=26, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=33, 
        ["Haste"]=4, 
        ["MND"]=20, 
        ["Dual Wield"]=3, 
        ["discription"]="DEF:138 HP+63 STR+26 DEX+33 VIT+23 AGI+29 INT+20 MND+20 CHR+20 Accuracy+23 Magic Accuracy+23 Evasion+55 Magic Evasion+69 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+6 Haste+4% Magic burst damage II +8 \"Death\" resistance +15", 
        ["id"]=26973, 
        ["item_level"]=119, 
        ["HP"]=63, 
        ["augments"]={
            [1]="Mag. Acc.+12", 
            [2]="\"Mag.Atk.Bns.\"+12", 
            [3]="\"Dual Wield\"+3", 
            [4]="none", 
            [5]="none"
        }, 
        ["AGI"]=29, 
        ["INT"]=20, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=138, 
        ["Accuracy"]=23, 
        ["CHR"]=20, 
        ["Magic Atk. Bonus"]=32, 
        ["category"]="Armor", 
        ["en"]="Samnuha Coat", 
        ["VIT"]=23, 
        ["Magic Accuracy"]=35
    }, 
    [412]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["STR"]=20, 
        ["id"]=26258, 
        ["INT"]=10, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="STR+20", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="INT+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["DEF"]=16, 
        ["Magic Accuracy"]=20
    }, 
    [413]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["AGI"]=30, 
        ["id"]=26258, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="AGI+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="AGI+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["Attack"]=20
    }, 
    [414]={
        ["Ranged Attack"]=48, 
        ["Haste"]=5, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=44, 
        ["CHR"]=26, 
        ["MND"]=38, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Ranged Accuracy"]=48, 
        ["en"]="Hachiya Tekko +3", 
        ["item_level"]=119, 
        ["HP"]=47, 
        ["id"]=23521, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=84
        }, 
        ["INT"]=20, 
        ["STR"]=20, 
        ["DEF"]=110, 
        ["Accuracy"]=48, 
        ["Throwing skill"]=14, 
        ["VIT"]=38, 
        ["category"]="Armor", 
        ["Evasion"]=52, 
        ["discription"]="DEF:110 HP+47 STR+20 DEX+44 VIT+38 AGI+26 INT+20 MND+38 CHR+26 Accuracy+48 Ranged Accuracy+48 Ranged Attack+48 Evasion+52 Magic Evasion+46 \"Magic Def. Bonus\"+2 Throwing skill +14 Haste+5% \"Subtle Blow\"+9 \"Daken\"+10 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["AGI"]=26
    }, 
    [415]={
        ["Evasion"]=88, 
        ["STR"]=16, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=37, 
        ["Haste"]=4, 
        ["MND"]=11, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=42, 
        ["id"]=25954, 
        ["AGI"]=57, 
        ["HP"]=30, 
        ["Critical hit rate"]=5, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }, 
            ["set id"]=477
        }, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=85, 
        ["MP"]=10, 
        ["Accuracy"]=42, 
        ["CHR"]=29, 
        ["VIT"]=10, 
        ["category"]="Armor", 
        ["en"]="Mummu Gamash. +2", 
        ["discription"]="DEF:85 HP+30 MP+10 STR+16 DEX+37 VIT+10 AGI+57 MND+11 CHR+29 Accuracy+42 Ranged Accuracy+42 Magic Accuracy+42 Evasion+88 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+4% \"Subtle Blow\"+9 Critical hit rate +5% Set: Increases Dexterity, Agility, and Charisma", 
        ["Magic Accuracy"]=42
    }, 
    [416]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["id"]=26258, 
        ["Evasion"]=10, 
        ["AGI"]=20, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="AGI+20", 
            [2]="Eva.+20 /Mag. Eva.+20", 
            [3]="Mag. Evasion+10", 
            [4]="Enmity+10", 
            [5]="Damage taken-5%"
        }, 
        ["DEF"]=16, 
        ["DT"]=-5
    }, 
    [417]={
        ["Evasion"]=114, 
        ["MND"]=3, 
        ["DEF"]=85, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=31, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Counter"]=4
                }, 
                [3]={
                    ["Counter"]=8
                }, 
                [4]={
                    ["Counter"]=12
                }, 
                [5]={
                    ["Counter"]=16
                }
            }, 
            ["set id"]=281
        }, 
        ["AGI"]=34, 
        ["Dual Wield"]=8, 
        ["en"]="Hiza. Sune-Ate +2", 
        ["HP"]=30, 
        ["discription"]="DEF:85 HP+30 STR+28 DEX+31 VIT+23 AGI+34 MND+3 CHR+28 Accuracy+42 Attack+24 Evasion+114 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+3% \"Dual Wield\"+8 Set: Enhances \"Counter\" effect", 
        ["Accuracy"]=42, 
        ["CHR"]=28, 
        ["STR"]=28, 
        ["Haste"]=3, 
        ["id"]=25948, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["VIT"]=23, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Attack"]=24
    }, 
    [418]={
        ["Evasion"]=59, 
        ["MND"]=30, 
        ["DEF"]=91, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=45, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["AGI"]=14, 
        ["en"]="Hattori Tekko +1", 
        ["discription"]="DEF:91 HP+27 STR+12 DEX+45 VIT+29 AGI+14 INT+12 MND+30 CHR+17 Accuracy+23 Evasion+59 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Futae\"+24 Elemental ninjutsu damage +14% Set: Augments \"Dual Wield\"", 
        ["HP"]=27, 
        ["item_level"]=119, 
        ["Accuracy"]=23, 
        ["STR"]=12, 
        ["Haste"]=5, 
        ["id"]=27077, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["VIT"]=29, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=222
        }
    }, 
    [419]={
        ["discription"]="DMG:148 Delay:210 Attack+60 Magic Damage+186 Katana skill +269 Parrying skill +269 Magic Accuracy skill +242 \"Blade: Metsu\" Additional effect: Paralysis Aftermath: Attack+10% \"Subtle Blow\"+10 Afterglow", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=269, 
        ["Katana skill"]=269, 
        ["item_level"]=119, 
        ["en"]="Kikoku", 
        ["delay"]=210, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["skill"]="Katana", 
        ["Attack"]=10, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=21906, 
        ["category"]="Weapon", 
        ["damage"]=148
    }, 
    [420]={
        ["Evasion"]=27, 
        ["Ranged Accuracy"]=50, 
        ["augments"]={
            [1]="Accuracy+50", 
            [2]="Rng.Acc.+50", 
            [3]="Damage Taken -5%"
        }, 
        ["discription"]="DMG:98 Delay:190 Accuracy+27 Evasion+27 Katana skill +228 Parrying skill +228 Magic Accuracy skill +215 Ninjutsu skill +10 Enmity-10 Ninjutsu recast delay -3 \"Ninja Tool Expertise\"+5", 
        ["Katana skill"]=228, 
        ["skill"]="Katana", 
        ["en"]="Shigi", 
        ["delay"]=190, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=77, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Ninjutsu skill"]=10, 
        ["id"]=20994, 
        ["category"]="Weapon", 
        ["Parrying skill"]=228, 
        ["damage"]=98, 
        ["item_level"]=119
    }, 
    [421]={
        ["Evasion"]=47, 
        ["MND"]=17, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=113, 
        ["en"]="Hattori Hakama +1", 
        ["AGI"]=20, 
        ["Katana skill"]=23, 
        ["item_level"]=119, 
        ["HP"]=50, 
        ["discription"]="DEF:113 HP+50 STR+29 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Accuracy+20 Evasion+47 Magic Evasion+75 \"Magic Def. Bonus\"+5 Katana skill +23 Haste+8% \"Yonin\": \"Counter\"+14 Set: Augments \"Dual Wield\"", 
        ["Accuracy"]=20, 
        ["STR"]=29, 
        ["Haste"]=8, 
        ["id"]=27262, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["VIT"]=16, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=222
        }
    }, 
    [422]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["Magic Atk. Bonus"]=10, 
        ["id"]=26258, 
        ["INT"]=30, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="INT+20", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="INT+10", 
            [4]="\"Mag.Atk.Bns.\"+10", 
            [5]="none"
        }, 
        ["DEF"]=16, 
        ["Magic Accuracy"]=20
    }, 
    [423]={
        ["Evasion"]=41, 
        ["Haste"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=39, 
        ["item_level"]=119, 
        ["MND"]=26, 
        ["STR"]=16, 
        ["Ranged Accuracy"]=12, 
        ["augments"]={
            [1]="\"Mag.Atk.Bns.\"+24", 
            [2]="Magic burst dmg.+6%", 
            [3]="INT+8", 
            [4]="none", 
            [5]="none"
        }, 
        ["en"]="Herculean Gloves", 
        ["HP"]=20, 
        ["id"]=27140, 
        ["VIT"]=30, 
        ["INT"]=22, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=97, 
        ["Accuracy"]=12, 
        ["CHR"]=19, 
        ["Magic Atk. Bonus"]=24, 
        ["category"]="Armor", 
        ["discription"]="DEF:97 HP+20 STR+16 DEX+39 VIT+30 AGI+8 INT+14 MND+26 CHR+19 Accuracy+12 Ranged Accuracy+12 Evasion+41 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+2% \"Subtle Blow\"+5 Physical damage taken -2%", 
        ["PDT"]=-2, 
        ["AGI"]=8
    }, 
    [424]={
        ["Evasion"]=63, 
        ["item_level"]=119, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["STR"]=42, 
        ["Haste"]=6, 
        ["MND"]=27, 
        ["Dual Wield"]=10, 
        ["id"]=23611, 
        ["AGI"]=36, 
        ["en"]="Mochi. Hakama +3", 
        ["HP"]=82, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Mijin Gakure\" effect", 
            [4]="none"
        }, 
        ["discription"]="DEF:134 HP+82 STR+42 VIT+24 AGI+36 INT+42 MND+27 CHR+20 Accuracy+39 Attack+64 Magic Accuracy+39 Evasion+63 Magic Evasion+84 \"Magic Def. Bonus\"+5 Haste+6% \"Dual Wield\"+10 Weapon skill damage +10%", 
        ["INT"]=42, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=134, 
        ["Accuracy"]=39, 
        ["CHR"]=20, 
        ["VIT"]=24, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=39, 
        ["Attack"]=64
    }, 
    [425]={
        ["discription"]="DMG:100 Delay:222 Accuracy+20 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 Occasionally attacks twice Additional effect: Haste", 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["en"]="Kujaku +1", 
        ["item_level"]=119, 
        ["delay"]=222, 
        ["Evasion"]=22, 
        ["skill"]="Katana", 
        ["Accuracy"]=20, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=20985, 
        ["Katana skill"]=242, 
        ["damage"]=100
    }, 
    [426]={
        ["Ranged Attack"]=79, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=23477, 
        ["DEX"]=35, 
        ["Haste"]=4, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Sange\" effect", 
            [4]="none"
        }, 
        ["MND"]=34, 
        ["Dual Wield"]=9, 
        ["Ranged Accuracy"]=47, 
        ["item_level"]=119, 
        ["AGI"]=35, 
        ["HP"]=79, 
        ["Accuracy"]=51, 
        ["slots"]={
            [5]="Body"
        }, 
        ["INT"]=34, 
        ["CHR"]=34, 
        ["STR"]=34, 
        ["DEF"]=154, 
        ["discription"]="DEF:154 HP+79 STR+34 DEX+35 VIT+31 AGI+35 INT+34 MND+34 CHR+34 Accuracy+51 Attack+87 Ranged Accuracy+47 Ranged Attack+79 Magic Accuracy+40 Evasion+72 Magic Evasion+73 \"Magic Def. Bonus\"+6 Haste+4% \"Dual Wield\"+9 \"Utsusemi\" spellcasting time -14% \"Daken\"+10", 
        ["category"]="Armor", 
        ["Evasion"]=72, 
        ["Attack"]=87, 
        ["en"]="Mochi. Chainmail +3", 
        ["VIT"]=31, 
        ["Magic Accuracy"]=40
    }, 
    [427]={
        ["Evasion"]=80, 
        ["MND"]=14, 
        ["id"]=25959, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=44, 
        ["Ranged Accuracy"]=43, 
        ["item_level"]=119, 
        ["Haste"]=3, 
        ["STR"]=20, 
        ["HP"]=70, 
        ["en"]="Ken. Sune-Ate +1", 
        ["Accuracy"]=48, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=81, 
        ["Critical hit rate"]=5, 
        ["CHR"]=26, 
        ["VIT"]=21, 
        ["category"]="Armor", 
        ["discription"]="DEF:81 HP+70 STR+20 DEX+44 VIT+21 AGI+44 MND+14 CHR+26 Accuracy+48 Ranged Accuracy+43 Evasion+80 Magic Evasion+139 \"Magic Def. Bonus\"+6 Haste+3% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit rate +5%", 
        ["AGI"]=44
    }, 
    [428]={
        ["Evasion"]=42, 
        ["MND"]=30, 
        ["Haste"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=36, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Naga Tekko", 
        ["discription"]="DEF:83 HP+65 STR+16 DEX+36 VIT+34 AGI+8 INT+12 MND+30 CHR+18 Evasion+22 Magic Evasion+26 \"Magic Def. Bonus\"+1 Haste+5% Damage taken -2% Pet: Attack+20 Ranged Attack+20", 
        ["item_level"]=119, 
        ["HP"]=115, 
        ["id"]=27099, 
        ["AGI"]=8, 
        ["STR"]=16, 
        ["DEF"]=83, 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Evasion+20"
        }, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=18, 
        ["VIT"]=44, 
        ["DT"]=-2
    }, 
    [429]={
        ["Evasion"]=99, 
        ["MND"]=22, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=25, 
        ["discription"]="DEF:92 HP+29 STR+24 DEX+25 VIT+21 AGI+44 INT+20 MND+22 CHR+39 Magic Accuracy+52 Evasion+99 Magic Evasion+84 \"Magic Atk. Bonus\"+23 \"Magic Def. Bonus\"+4 Haste+4% Magic burst damage +10 Dusk to dawn: Movement speed +25% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["AGI"]=44, 
        ["en"]="Hachiya Kyahan +3", 
        ["item_level"]=119, 
        ["HP"]=29, 
        ["Haste"]=4, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=84
        }, 
        ["INT"]=20, 
        ["STR"]=24, 
        ["DEF"]=92, 
        ["id"]=23655, 
        ["CHR"]=39, 
        ["Magic Atk. Bonus"]=23, 
        ["category"]="Armor", 
        ["VIT"]=21, 
        ["Magic Accuracy"]=52
    }, 
    [430]={
        ["Evasion"]=102, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEX"]=49, 
        ["Haste"]=4, 
        ["id"]=23733, 
        ["MND"]=24, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=11, 
        ["en"]="Malignance Tabard", 
        ["HP"]=68, 
        ["Accuracy"]=50, 
        ["AGI"]=42, 
        ["STR"]=19, 
        ["DEF"]=143, 
        ["MP"]=44, 
        ["discription"]="DEF:143 HP+68 MP+44 STR+19 DEX+49 VIT+25 AGI+42 INT+19 MND+24 CHR+24 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+102 Magic Evasion+139 \"Magic Def. Bonus\"+8 Haste+4% \"Store TP\"+11 Physical damage limit +6% Damage taken -9%", 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["CHR"]=24, 
        ["Magic Accuracy"]=50, 
        ["VIT"]=25, 
        ["DT"]=-9
    }, 
    [431]={
        ["Evasion"]=68, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]=84
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["STR"]=37, 
        ["Haste"]=6, 
        ["MND"]=22, 
        ["Dual Wield"]=4, 
        ["Ranged Accuracy"]=25, 
        ["Store TP"]=3, 
        ["item_level"]=119, 
        ["HP"]=70, 
        ["id"]=23253, 
        ["en"]="Hachiya Hakama +2", 
        ["INT"]=37, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=124, 
        ["Accuracy"]=46, 
        ["CHR"]=15, 
        ["VIT"]=19, 
        ["category"]="Armor", 
        ["discription"]="DEF:124 HP+70 STR+37 VIT+19 AGI+26 INT+37 MND+22 CHR+15 Accuracy+46 Ranged Accuracy+25 Evasion+68 Magic Evasion+74 \"Magic Def. Bonus\"+3 Haste+6% \"Store TP\"+3 \"Dual Wield\"+4 \"Subtle Blow\"+8 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["AGI"]=26
    }, 
    [432]={
        ["Ranged Attack"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=27496, 
        ["DEX"]=24, 
        ["DEF"]=79, 
        ["augments"]={
            [1]="Accuracy+20", 
            [2]="\"Triple Atk.\"+4", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=11, 
        ["en"]="Herculean Boots", 
        ["Ranged Accuracy"]=10, 
        ["item_level"]=119, 
        ["AGI"]=43, 
        ["HP"]=9, 
        ["Accuracy"]=30, 
        ["discription"]="DEF:79 HP+9 STR+16 DEX+24 VIT+10 AGI+43 MND+11 CHR+26 Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+5 Evasion+80 Magic Evasion+75 Haste+4% \"Triple Attack\"+2 \"Subtle Blow\"+6 Physical damage taken -2%", 
        ["CHR"]=26, 
        ["category"]="Armor", 
        ["STR"]=16, 
        ["Haste"]=4, 
        ["Evasion"]=80, 
        ["Attack"]=10, 
        ["PDT"]=-2, 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["VIT"]=10, 
        ["Magic Accuracy"]=10
    }, 
    [433]={
        ["Ranged Attack"]=36, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=8, 
        ["DEX"]=33, 
        ["en"]="Adhemar Bonnet +1", 
        ["id"]=25614, 
        ["MND"]=14, 
        ["discription"]="DEF:102 HP+41 STR+19 DEX+21 VIT+15 AGI+19 INT+14 MND+14 CHR+14 Attack+36 Ranged Attack+36 Evasion+49 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+8% \"Triple Attack\"+4% \"Subtle Blow\"+8 Critical hit damage +6% Set: Increases rate of critical hits", 
        ["STR"]=19, 
        ["AGI"]=31, 
        ["item_level"]=119, 
        ["HP"]=41, 
        ["Accuracy"]=20, 
        ["Critical hit damage"]=6, 
        ["INT"]=14, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=102, 
        ["Evasion"]=49, 
        ["CHR"]=14, 
        ["augments"]={
            [1]="DEX+12", 
            [2]="AGI+12", 
            [3]="Accuracy+20"
        }, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }, 
            ["set id"]=11
        }, 
        ["VIT"]=15, 
        ["Attack"]=36
    }, 
    [434]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["DEX"]=30, 
        ["id"]=26258, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["Attack"]=20
    }, 
    [435]={
        ["Ranged Attack"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["STR"]=22, 
        ["DEX"]=28, 
        ["DEF"]=108, 
        ["augments"]={
            [1]="Accuracy+13", 
            [2]="\"Fast Cast\"+6", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=16, 
        ["Evasion"]=55, 
        ["en"]="Herculean Helm", 
        ["Fast Cast"]=13, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["Accuracy"]=13, 
        ["discription"]="DEF:108 HP+38 STR+22 DEX+28 VIT+18 AGI+25 INT+20 MND+16 CHR+17 Attack+15 Ranged Attack+15 \"Magic Atk. Bonus\"+10 Evasion+55 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+8% \"Fast Cast\"+7%", 
        ["INT"]=20, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Haste"]=8, 
        ["AGI"]=25, 
        ["CHR"]=17, 
        ["Magic Atk. Bonus"]=10, 
        ["category"]="Armor", 
        ["id"]=25642, 
        ["VIT"]=18, 
        ["Attack"]=15
    }, 
    [436]={
        ["Ranged Attack"]=10, 
        ["en"]="Kanaria", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=21904, 
        ["AGI"]=15, 
        ["Fast Cast"]=5, 
        ["Katana skill"]=242, 
        ["Ranged Accuracy"]=15, 
        ["Store TP"]=5, 
        ["item_level"]=119, 
        ["delay"]=227, 
        ["augments"]={
            [1]="Crit. hit damage +6%", 
            [2]="AGI+15", 
            [3]="Accuracy+9", 
            [4]="none", 
            [5]="none"
        }, 
        ["Evasion"]=22, 
        ["discription"]="DMG:127 Delay:227 Accuracy+15 Attack+10 Ranged Accuracy+15 Ranged Attack+10 Evasion+22 Katana skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Store TP\"+5 \"Fast Cast\"+5%", 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=24, 
        ["Critical hit damage"]=6, 
        ["skill"]="Katana", 
        ["damage"]=127, 
        ["Parrying skill"]=242, 
        ["Attack"]=10
    }, 
    [437]={
        ["Evasion"]=89, 
        ["STR"]=28, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=29, 
        ["Haste"]=4, 
        ["MND"]=22, 
        ["en"]="Mochi. Kyahan +3", 
        ["id"]=23678, 
        ["AGI"]=48, 
        ["item_level"]=119, 
        ["HP"]=33, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enh. Ninj. Mag. Acc/Cast Time Red.", 
            [4]="none"
        }, 
        ["discription"]="DEF:93 HP+33 STR+28 DEX+29 VIT+25 AGI+48 MND+22 CHR+39 Accuracy+43 Attack+76 Magic Accuracy+36 Evasion+89 Magic Evasion+84 \"Magic Def. Bonus\"+5 Ninjutsu skill +23 Haste+4% Enmity+8", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=93, 
        ["Ninjutsu skill"]=23, 
        ["Accuracy"]=43, 
        ["CHR"]=39, 
        ["VIT"]=25, 
        ["category"]="Armor", 
        ["Attack"]=76, 
        ["Magic Accuracy"]=36
    }, 
    [438]={
        ["AGI"]=5, 
        ["Ranged Accuracy"]=5, 
        ["Throwing skill"]=242, 
        ["Evasion"]=5, 
        ["category"]="Weapon", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["en"]="Date Shuriken", 
        ["delay"]=192, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["skill"]="Throwing", 
        ["discription"]="DMG:125 Delay:192 DEX+5 AGI+5 Accuracy+5 Ranged Accuracy+5 Evasion+5 Throwing skill +242 Enmity +3", 
        ["DEX"]=5, 
        ["item_level"]=119, 
        ["id"]=22292, 
        ["Accuracy"]=5, 
        ["damage"]=125
    }, 
    [439]={
        ["discription"]="DMG:123 Delay:190 AGI+20 Accuracy+27 Attack+27 Ranged Accuracy+50 Evasion+27 Katana skill +228 Parrying skill +228 Magic Accuracy skill +215 Critical hit rate +3%", 
        ["id"]=21905, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Ranged Accuracy"]=50, 
        ["AGI"]=20, 
        ["Katana skill"]=228, 
        ["en"]="Taka", 
        ["delay"]=190, 
        ["Evasion"]=27, 
        ["Critical hit rate"]=3, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["item_level"]=119, 
        ["damage"]=123, 
        ["Accuracy"]=27, 
        ["Parrying skill"]=228, 
        ["Attack"]=27
    }, 
    [440]={
        ["Evasion"]=63, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["STR"]=20, 
        ["DEX"]=39, 
        ["Haste"]=8, 
        ["Critical hit rate"]=5, 
        ["MND"]=14, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }, 
            ["set id"]=477
        }, 
        ["Ranged Accuracy"]=44, 
        ["AGI"]=34, 
        ["en"]="Mummu Bonnet +2", 
        ["HP"]=37, 
        ["Accuracy"]=44, 
        ["id"]=25570, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=115, 
        ["MP"]=20, 
        ["discription"]="DEF:115 HP+37 MP+20 STR+20 DEX+39 VIT+16 AGI+34 INT+15 MND+14 CHR+17 Accuracy+44 Ranged Accuracy+44 Magic Accuracy+44 Evasion+63 Magic Evasion+75 \"Magic Def. Bonus\"+3 Haste+8% Potency of \"Waltz\" effects received +9% Critical hit rate +5% Set: Increases Dexterity, Agility, and Charisma", 
        ["INT"]=15, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["item_level"]=119, 
        ["VIT"]=16, 
        ["Magic Accuracy"]=44
    }, 
    [441]={
        ["discription"]="DMG:159 Delay:227 Magic Damage+186 Katana skill +269 Parrying skill +269 Magic Accuracy skill +242 \"Store TP\"+10 \"TP Bonus\"+500 \"Blade: Shun\" Aftermath: Increases skillchain potency Increases magic burst potency Ultimate Skillchain", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=269, 
        ["category"]="Weapon", 
        ["Store TP"]=10, 
        ["en"]="Heishi Shorinken", 
        ["delay"]=227, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["skill"]="Katana", 
        ["Katana skill"]=269, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=20977, 
        ["item_level"]=119, 
        ["damage"]=159
    }, 
    [442]={
        ["Evasion"]=53, 
        ["MND"]=17, 
        ["Haste"]=6, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["STR"]=37, 
        ["AGI"]=21, 
        ["Dual Wield"]=4, 
        ["id"]=27284, 
        ["HP"]=147, 
        ["en"]="Naga Hakama", 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Evasion+20"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=110, 
        ["item_level"]=119, 
        ["INT"]=32, 
        ["category"]="Armor", 
        ["CHR"]=10, 
        ["VIT"]=29, 
        ["discription"]="DEF:110 HP+97 STR+37 VIT+19 AGI+21 INT+32 MND+17 CHR+10 Evasion+33 Magic Evasion+64 \"Magic Def. Bonus\"+3 Haste+6% \"Dual Wield\"+4 Pet: Accuracy+20 Ranged Accuracy+20"
    }, 
    [443]={
        ["Evasion"]=24, 
        ["MND"]=17, 
        ["en"]="Jokushu Haidate", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["Haste"]=20, 
        ["AGI"]=21, 
        ["STR"]=29, 
        ["id"]=27318, 
        ["HP"]=50, 
        ["DEX"]=35, 
        ["Critical hit rate"]=4, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=120, 
        ["discription"]="DEF:120 HP+50 STR+29 DEX+35 VIT+15 AGI+21 INT+30 MND+17 CHR+11 +50 Evasion+24 Magic Evasion+80 \"Magic Def. Bonus\"+3 Haste+20% Critical hit rate +4%", 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["VIT"]=15, 
        ["item_level"]=119
    }, 
    [444]={
        ["Evasion"]=36, 
        ["STR"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=56, 
        ["Haste"]=5, 
        ["MND"]=30, 
        ["id"]=27118, 
        ["Ranged Accuracy"]=32, 
        ["Store TP"]=7, 
        ["item_level"]=119, 
        ["HP"]=22, 
        ["augments"]={
            [1]="DEX+12", 
            [2]="AGI+12", 
            [3]="Accuracy+20"
        }, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }, 
            ["set id"]=11
        }, 
        ["INT"]=12, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=93, 
        ["Accuracy"]=52, 
        ["CHR"]=17, 
        ["VIT"]=29, 
        ["category"]="Armor", 
        ["en"]="Adhemar Wrist. +1", 
        ["discription"]="DEF:93 HP+22 STR+15 DEX+44 VIT+29 AGI+7 INT+12 MND+30 CHR+17 Accuracy+32 Ranged Accuracy+32 Evasion+36 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+4% \"Store TP\"+7 Set: Increases rate of critical hits", 
        ["AGI"]=19
    }, 
    [445]={
        ["Evasion"]=89, 
        ["MND"]=12, 
        ["id"]=27459, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=15, 
        ["STR"]=14, 
        ["AGI"]=34, 
        ["en"]="Naga Kyahan", 
        ["All skills"]=10, 
        ["HP"]=113, 
        ["discription"]="DEF:67 HP+63 STR+14 DEX+15 VIT+11 AGI+34 MND+12 CHR+29 Accuracy+18 Attack+18 Evasion+69 Magic Evasion+64 \"Magic Def. Bonus\"+3 Haste+4% \"Double Attack\"+3% Automaton: All skills +10", 
        ["Accuracy"]=18, 
        ["CHR"]=29, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=4, 
        ["augments"]={
            [1]="HP+50", 
            [2]="VIT+10", 
            [3]="Evasion+20"
        }, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["VIT"]=21, 
        ["DEF"]=67, 
        ["Attack"]=18
    }, 
    [446]={
        ["Evasion"]=55, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["STR"]=26, 
        ["DEX"]=45, 
        ["Haste"]=4, 
        ["augments"]={
            [1]="DEX+12", 
            [2]="AGI+12", 
            [3]="Accuracy+20"
        }, 
        ["MND"]=20, 
        ["Dual Wield"]=6, 
        ["Ranged Accuracy"]=35, 
        ["Ranged Attack"]=35, 
        ["AGI"]=41, 
        ["HP"]=63, 
        ["Accuracy"]=55, 
        ["discription"]="DEF:133 HP+63 STR+26 DEX+33 VIT+23 AGI+29 INT+20 MND+20 CHR+20 Accuracy+35 Attack+35 Ranged Accuracy+35 Ranged Attack+35 Evasion+55 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% \"Triple Attack\"+4% Enmity-8 \"Dual Wield\"+6 Set: Increases rate of critical hits", 
        ["INT"]=20, 
        ["CHR"]=20, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=133, 
        ["id"]=25687, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=4
                }, 
                [3]={
                    ["Critical Hit Rate"]=6
                }, 
                [4]={
                    ["Critical Hit Rate"]=8
                }, 
                [5]={
                    ["Critical Hit Rate"]=10
                }
            }, 
            ["set id"]=11
        }, 
        ["item_level"]=119, 
        ["en"]="Adhemar Jacket +1", 
        ["VIT"]=23, 
        ["Attack"]=35
    }, 
    [447]={
        ["discription"]="DMG:99 Delay:188 Accuracy+6 Attack+6 Ranged Accuracy+11 Throwing skill +228 Critical hit rate +2%", 
        ["Ranged Accuracy"]=11, 
        ["Throwing skill"]=228, 
        ["category"]="Weapon", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["item_level"]=118, 
        ["delay"]=188, 
        ["en"]="Happo Shuriken +1", 
        ["skill"]="Throwing", 
        ["Attack"]=6, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=6, 
        ["Critical hit rate"]=2, 
        ["id"]=21354, 
        ["damage"]=99
    }, 
    [448]={
        ["Evasion"]=36, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["STR"]=21, 
        ["DEX"]=17, 
        ["Haste"]=7, 
        ["augments"]={
            [1]="HP+65", 
            [2]="\"Store TP\"+5", 
            [3]="\"Subtle Blow\"+8"
        }, 
        ["MND"]=11, 
        ["Dual Wield"]=9, 
        ["Ranged Accuracy"]=35, 
        ["Store TP"]=12, 
        ["item_level"]=119, 
        ["HP"]=106, 
        ["Accuracy"]=35, 
        ["en"]="Ryuo Somen +1", 
        ["INT"]=11, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=116, 
        ["AGI"]=20, 
        ["CHR"]=11, 
        ["discription"]="DEF:116 HP+41 STR+21 DEX+17 VIT+14 AGI+20 INT+11 MND+11 CHR+11 Accuracy+35 Ranged Accuracy+35 Evasion+36 Magic Evasion+48 \"Magic Def. Bonus\"+2 Haste+7% Enmity-6 \"Store TP\"+7 \"Dual Wield\"+9 Set: Increases Attack", 
        ["category"]="Armor", 
        ["id"]=25612, 
        ["VIT"]=14, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Attack"]=20
                }, 
                [3]={
                    ["Attack"]=30
                }, 
                [4]={
                    ["Attack"]=40
                }, 
                [5]={
                    ["Attack"]=50
                }
            }, 
            ["set id"]=239
        }
    }, 
    [449]={
        ["Evasion"]=80, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEX"]=56, 
        ["Haste"]=4, 
        ["id"]=23734, 
        ["MND"]=42, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=12, 
        ["en"]="Malignance Gloves", 
        ["HP"]=57, 
        ["Accuracy"]=50, 
        ["AGI"]=24, 
        ["STR"]=25, 
        ["DEF"]=108, 
        ["MP"]=36, 
        ["discription"]="DEF:108 HP+57 MP+36 STR+25 DEX+56 VIT+32 AGI+24 INT+11 MND+42 CHR+21 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+80 Magic Evasion+112 \"Magic Def. Bonus\"+4 Haste+4% \"Store TP\"+12 Physical damage limit +4% Damage taken -5%", 
        ["INT"]=11, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["Magic Accuracy"]=50, 
        ["VIT"]=32, 
        ["DT"]=-5
    }, 
    [450]={
        ["Evasion"]=119, 
        ["STR"]=6, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["DEX"]=40, 
        ["Haste"]=3, 
        ["MND"]=15, 
        ["item_level"]=119, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=9, 
        ["AGI"]=49, 
        ["HP"]=34, 
        ["id"]=23736, 
        ["en"]="Malignance Boots", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=88, 
        ["MP"]=22, 
        ["Accuracy"]=50, 
        ["CHR"]=40, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["discription"]="DEF:88 HP+34 MP+22 STR+6 DEX+40 VIT+12 AGI+49 MND+15 CHR+40 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+119 Magic Evasion+150 \"Magic Def. Bonus\"+5 Haste+3% \"Store TP\"+9 Physical damage limit +2% Damage taken -4%", 
        ["Magic Accuracy"]=50, 
        ["DT"]=-4
    }, 
    [451]={
        ["discription"]="DMG:90 Delay:180 Accuracy+34 Evasion+27 Katana skill +228 Parrying skill +228 Magic Accuracy skill +215 \"Double Attack\"+4% \"Store TP\"+5 \"Subtle Blow\"+8", 
        ["Katana skill"]=228, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["Store TP"]=5, 
        ["en"]="Achiuchikapu", 
        ["delay"]=180, 
        ["Parrying skill"]=228, 
        ["skill"]="Katana", 
        ["Evasion"]=27, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=34, 
        ["item_level"]=119, 
        ["id"]=20986, 
        ["damage"]=90
    }, 
    [452]={
        ["discription"]="DMG:154 Delay:222 HP+150 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Magic Damage+217 Katana skill +269 Parrying skill +269 Magic Accuracy skill +255 Attack+15 for each Utsusemi shadow image", 
        ["augments"]={
            [1]="Path: C"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Ranged Accuracy"]=50, 
        ["item_level"]=119, 
        ["Katana skill"]=269, 
        ["HP"]=150, 
        ["delay"]=222, 
        ["en"]="Fudo Masamune", 
        ["id"]=21917, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["Attack"]=15, 
        ["damage"]=154, 
        ["Accuracy"]=50, 
        ["Parrying skill"]=269, 
        ["Magic Accuracy"]=50
    }, 
    [453]={
        ["discription"]="DMG:154 Delay:222 HP+150 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Magic Damage+217 Katana skill +269 Parrying skill +269 Magic Accuracy skill +255 Attack+15 for each Utsusemi shadow image", 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Ranged Accuracy"]=50, 
        ["item_level"]=119, 
        ["Katana skill"]=269, 
        ["HP"]=150, 
        ["delay"]=222, 
        ["en"]="Fudo Masamune", 
        ["id"]=21917, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["Attack"]=15, 
        ["damage"]=154, 
        ["Accuracy"]=50, 
        ["Parrying skill"]=269, 
        ["Magic Accuracy"]=50
    }, 
    [454]={
        ["Evasion"]=85, 
        ["en"]="Malignance Tights", 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["STR"]=28, 
        ["Haste"]=9, 
        ["MND"]=19, 
        ["AGI"]=42, 
        ["Ranged Accuracy"]=50, 
        ["Store TP"]=10, 
        ["item_level"]=119, 
        ["HP"]=45, 
        ["id"]=23735, 
        ["discription"]="DEF:125 HP+45 MP+29 STR+28 VIT+17 AGI+42 INT+26 MND+19 CHR+12 Accuracy+50 Ranged Accuracy+50 Magic Accuracy+50 Evasion+85 Magic Evasion+150 \"Magic Def. Bonus\"+7 Haste+9% \"Store TP\"+10 Physical damage limit +5% Damage taken -7%", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=125, 
        ["MP"]=29, 
        ["Accuracy"]=50, 
        ["INT"]=26, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["Magic Accuracy"]=50, 
        ["VIT"]=17, 
        ["DT"]=-7
    }, 
    [455]={
        ["Evasion"]=42, 
        ["STR"]=30, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=44, 
        ["DEF"]=109, 
        ["MND"]=38, 
        ["en"]="Mochizuki Tekko +3", 
        ["id"]=23544, 
        ["AGI"]=16, 
        ["item_level"]=119, 
        ["HP"]=45, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enh. \"Ninja Tool Expertise\" effect", 
            [4]="none"
        }, 
        ["discription"]="DEF:109 HP+45 STR+30 DEX+44 VIT+37 AGI+16 INT+20 MND+38 CHR+26 Accuracy+38 Attack+79 Magic Accuracy+38 Evasion+42 Magic Evasion+46 \"Magic Def. Bonus\"+3 Haste+5% \"Subtle Blow\"+9 \"Ninja tool expertise\"+38", 
        ["INT"]=20, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=5, 
        ["Accuracy"]=38, 
        ["CHR"]=26, 
        ["VIT"]=37, 
        ["category"]="Armor", 
        ["Attack"]=79, 
        ["Magic Accuracy"]=38
    }, 
    [456]={
        ["MDT"]=-4, 
        ["Haste"]=5, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR"
        }, 
        ["DEX"]=35, 
        ["discription"]="DEF:89 HP+25 STR+16 DEX+35 VIT+29 AGI+12 INT+12 MND+30 CHR+17 +25 Accuracy+21 Ranged Accuracy+21 Evasion+24 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+5% \"Dual Wield\"+5", 
        ["MND"]=30, 
        ["Dual Wield"]=5, 
        ["Ranged Accuracy"]=36, 
        ["STR"]=16, 
        ["AGI"]=12, 
        ["HP"]=25, 
        ["augments"]={
            [1]="Rng.Acc.+15", 
            [2]="Accuracy+15", 
            [3]="\"Triple Atk.\"+3", 
            [4]="Magic dmg. taken -4%", 
            [5]="none"
        }, 
        ["en"]="Floral Gauntlets", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=89, 
        ["Evasion"]=24, 
        ["Accuracy"]=36, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["item_level"]=119, 
        ["VIT"]=29, 
        ["id"]=27137
    }, 
    [457]={
        ["Ranged Attack"]=23, 
        ["STR"]=39, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=10, 
        ["Haste"]=5, 
        ["MND"]=17, 
        ["AGI"]=21, 
        ["en"]="Ryuo Hakama", 
        ["Store TP"]=7, 
        ["item_level"]=119, 
        ["HP"]=50, 
        ["augments"]={
            [1]="STR+10", 
            [2]="DEX+10", 
            [3]="Accuracy+15"
        }, 
        ["id"]=27300, 
        ["INT"]=30, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=127, 
        ["Accuracy"]=15, 
        ["CHR"]=11, 
        ["VIT"]=15, 
        ["category"]="Armor", 
        ["discription"]="DEF:127 HP+50 STR+29 VIT+15 AGI+21 INT+30 MND+17 CHR+11 Attack+23 Ranged Attack+23 Evasion+24 Magic Evasion+80 \"Magic Def. Bonus\"+3 Haste+5% \"Double Attack\"+3% \"Store TP\"+7 \"Skillchain Bonus\"+10", 
        ["Evasion"]=24, 
        ["Attack"]=23
    }, 
    [458]={
        ["discription"]="DMG:101 Delay:192 HP+25 Attack+13 Throwing skill +242 \"Store TP\"+2", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["Throwing skill"]=242, 
        ["category"]="Weapon", 
        ["Store TP"]=2, 
        ["item_level"]=119, 
        ["HP"]=25, 
        ["delay"]=192, 
        ["skill"]="Throwing", 
        ["Attack"]=13, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=21391, 
        ["en"]="Seki Shuriken", 
        ["damage"]=101
    }, 
    [459]={
        ["Ranged Attack"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=25842, 
        ["STR"]=33, 
        ["Haste"]=6, 
        ["augments"]={
            [1]="\"Mag.Atk.Bns.\"+24", 
            [2]="Magic burst dmg.+8%", 
            [3]="Mag. Acc.+15", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=15, 
        ["AGI"]=32, 
        ["discription"]="DEF:114 HP+38 STR+33 VIT+16 AGI+32 INT+29 MND+15 CHR+10 Attack+15 Ranged Attack+15 Evasion+62 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% Enmity-4 \"Store TP\"+4 Physical damage taken -2%", 
        ["Store TP"]=4, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["Evasion"]=62, 
        ["VIT"]=16, 
        ["INT"]=29, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=114, 
        ["en"]="Herculean Trousers", 
        ["CHR"]=10, 
        ["Magic Atk. Bonus"]=24, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=15, 
        ["PDT"]=-2, 
        ["Attack"]=15
    }, 
    [460]={
        ["discription"]="DMG:148 Delay:210 AGI+50 Magic Damage+186 Katana skill +269 Parrying skill +269 Magic Accuracy skill +242 \"Blade: Hi\" Aftermath: Occasionally attacks for triple damage Afterglow", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["Katana skill"]=269, 
        ["AGI"]=50, 
        ["en"]="Kannagi", 
        ["delay"]=210, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["skill"]="Katana", 
        ["Parrying skill"]=269, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=21908, 
        ["item_level"]=119, 
        ["damage"]=148
    }, 
    [461]={
        ["discription"]="STR+2～5 DEX+2～5 \"Store TP\"+5 \"Subtle Blow\"+5", 
        ["en"]="Rajas Ring", 
        ["Store TP"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["DEX"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15543, 
        ["STR"]=2
    }, 
    [462]={
        ["discription"]="DEF:28 Fellow: HP+10 MP+10 INT+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["INT"]=2, 
        ["category"]="Armor", 
        ["en"]="Hydra Cap", 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15263, 
        ["DEF"]=28, 
        ["MP"]=10, 
        ["HP"]=10
    }, 
    [463]={
        ["discription"]="INT+1 MND+1 CHR+1 Converts 25 HP to MP", 
        ["MND"]=1, 
        ["category"]="Armor", 
        ["en"]="Vilma's Ring", 
        ["INT"]=1, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15547, 
        ["CHR"]=1
    }, 
    [464]={
        ["discription"]="DEF:35 Fellow: HP+10 MP+10 STR+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hydra Hose", 
        ["HP"]=10, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15598, 
        ["DEF"]=35, 
        ["MP"]=10, 
        ["STR"]=2
    }, 
    [465]={
        ["discription"]="DEF:20 Fellow: HP+10 MP+10 DEX+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hydra Bracers", 
        ["HP"]=10, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=14927, 
        ["DEF"]=20, 
        ["MP"]=10, 
        ["DEX"]=2
    }, 
    [466]={
        ["discription"]="Reives: Damage taken -8% Auto-Reraise", 
        ["id"]=28367, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Adoulin's Refuge +1", 
        ["DT"]=-8, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [467]={
        ["discription"]="Accuracy+4 Attack+4 Assault: STR+4 DEX+4 Adds \"Regen\" effect", 
        ["category"]="Armor", 
        ["en"]="Ulthalam's Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["DEX"]=4, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15808, 
        ["STR"]=4, 
        ["Accuracy"]=4, 
        ["Attack"]=4
    }, 
    [468]={
        ["discription"]="DEF:2 HP+50 MP-10", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Bloodbead Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=13302, 
        ["DEF"]=2, 
        ["MP"]=-10, 
        ["HP"]=50
    }, 
    [469]={
        ["discription"]="DEF:42 Fellow: HP+20 MP+20 VIT+2 ", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hydra Jupon", 
        ["HP"]=20, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=14518, 
        ["DEF"]=42, 
        ["MP"]=20, 
        ["VIT"]=2
    }, 
    [470]={
        ["discription"]="Experience point bonus: +100% Maximum duration: 720 min. Maximum bonus: 12000", 
        ["id"]=28562, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Duodec. Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [471]={
        ["discription"]="Slightly enhances chocobo digging skill", 
        ["id"]=11767, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Chocobo Rope", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [472]={
        ["discription"]="DEF:31 INT+2 MND+2 CHR+2", 
        ["CHR"]=2, 
        ["category"]="Armor", 
        ["en"]="Tatsu. Sitagoromo", 
        ["MND"]=2, 
        ["INT"]=2, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["augments"]={
            [1]="Pet: Accuracy+7 Pet: Rng. Acc.+7", 
            [2]="Movement speed +8%+2", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["DEF"]=31, 
        ["id"]=16371
    }, 
    [473]={
        ["discription"]="MP+25 Depending on day: Enhances elemental magic", 
        ["MP"]=25, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15858, 
        ["en"]="Zodiac Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [474]={
        ["discription"]="Attack+8 Enhances effect of \"Drain\" and \"Aspir\"", 
        ["id"]=15857, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Excelsis Ring", 
        ["Attack"]=8, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [475]={
        ["discription"]="HP+25 Reduces enemy critical hit rate", 
        ["en"]="Griffon Ring", 
        ["HP"]=25, 
        ["id"]=15856, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [476]={
        ["discription"]="DMG:47 Delay:190", 
        ["category"]="Weapon", 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="DEX+11", 
            [4]="Accuracy+16"
        }, 
        ["en"]="Thokcha", 
        ["skill"]="Dagger", 
        ["delay"]=190, 
        ["DEX"]=11, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF", 
            [10]="BRD", 
            [19]="DNC"
        }, 
        ["Accuracy"]=16, 
        ["id"]=19873, 
        ["damage"]=47
    }, 
    [477]={
        ["discription"]="DMG:51 Delay:201 \"Rudra's Storm\"", 
        ["category"]="Weapon", 
        ["en"]="Khandroma", 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="none", 
            [4]="none"
        }, 
        ["delay"]=201, 
        ["skill"]="Dagger", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF", 
            [10]="BRD", 
            [19]="DNC"
        }, 
        ["id"]=19871, 
        ["damage"]=51
    }, 
    [478]={
        ["discription"]="DMG:140 Delay:492 \"Camlann's Torment\"", 
        ["category"]="Weapon", 
        ["en"]="Daboya", 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="none", 
            [4]="none"
        }, 
        ["delay"]=492, 
        ["skill"]="Polearm", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["id"]=19895, 
        ["damage"]=140
    }, 
    [479]={
        ["discription"]="DMG:58 Delay:227 \"Blade: Hi\"", 
        ["category"]="Weapon", 
        ["en"]="Kasasagi", 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="none", 
            [4]="none"
        }, 
        ["delay"]=227, 
        ["skill"]="Katana", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=19899, 
        ["damage"]=58
    }, 
    [480]={
        ["id"]=16372, 
        ["en"]="Stearc Subligar", 
        ["DEF"]=30, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:30", 
        ["augments"]={
            [1]="\"Refresh\"+1", 
            [2]="MP recovered while healing +1", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [481]={
        ["discription"]="Enchantment: Call chocobo", 
        ["id"]=15533, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Chocobo Whistle", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [482]={
        ["discription"]="DMG:104 Delay:402 \"Myrkr\"", 
        ["category"]="Weapon", 
        ["en"]="Paikea", 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="none", 
            [4]="none"
        }, 
        ["delay"]=402, 
        ["skill"]="Staff", 
        ["slots"]={
            [0]="Main"
        }, 
        ["jobs"]={
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH"
        }, 
        ["id"]=19911, 
        ["damage"]=104
    }, 
    [483]={
        ["discription"]="A magical pearl that allows you to send a signal to your adventuring fellow. Unlike a linkpearl, it is worn on the ear.", 
        ["id"]=14810, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Signal Pearl", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [484]={
        ["discription"]="Experience point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["id"]=26164, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Caliber Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [485]={
        ["discription"]="A magical pearl that allows you to send a code to your adventuring fellow. Unlike a linkpearl, it is worn on the ear.", 
        ["id"]=14811, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Tactics Pearl", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [486]={
        ["discription"]="DMG:42 Delay:186", 
        ["category"]="Weapon", 
        ["en"]="Centovente", 
        ["augments"]={
            [1]="DMG:+2", 
            [2]="none", 
            [3]="Weapon Skill:DMG:+10%", 
            [4]="none"
        }, 
        ["delay"]=186, 
        ["skill"]="Dagger", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF", 
            [10]="BRD", 
            [19]="DNC"
        }, 
        ["id"]=19874, 
        ["damage"]=54
    }, 
    [487]={
        ["discription"]="DEF:18 Fellow: HP+10 MP+10 AGI+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Hydra Boots", 
        ["HP"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15683, 
        ["DEF"]=18, 
        ["MP"]=10, 
        ["AGI"]=2
    }, 
    [488]={
        ["discription"]="Experience point bonus: +50% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["id"]=15763, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Emperor Band", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [489]={
        ["discription"]="DMG:50 Delay:201", 
        ["category"]="Weapon", 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="AGI+11", 
            [4]="Evasion+22"
        }, 
        ["en"]="Arisui", 
        ["AGI"]=11, 
        ["delay"]=201, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Evasion"]=22, 
        ["id"]=19901, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=50
    }, 
    [490]={
        ["discription"]="DMG:50 Delay:201", 
        ["category"]="Weapon", 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="AGI+11", 
            [4]="Evasion+22"
        }, 
        ["en"]="Arisui", 
        ["AGI"]=11, 
        ["delay"]=201, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Evasion"]=22, 
        ["id"]=19901, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=50
    }, 
    [491]={
        ["discription"]="DMG:27 Delay:232", 
        ["category"]="Weapon", 
        ["en"]="Majimun", 
        ["augments"]={
            [1]="none", 
            [2]="Delay:+10", 
            [3]="Occ. atk. 2-4 times+12", 
            [4]="none"
        }, 
        ["delay"]=242, 
        ["skill"]="Katana", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=19900, 
        ["damage"]=27
    }, 
    [492]={
        ["discription"]="Magic Atk. Bonus+5", 
        ["Magic Atk. Bonus"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Moldavite Earring", 
        ["id"]=14724, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [493]={
        ["discription"]="DMG:49 Delay:216", 
        ["category"]="Weapon", 
        ["en"]="Hitaki", 
        ["Store TP"]=15, 
        ["delay"]=216, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="DMG:+2", 
            [2]="none", 
            [3]="\"Store TP\"+15", 
            [4]="none"
        }, 
        ["id"]=19902, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=51
    }, 
    [494]={
        ["discription"]="DMG:47 Delay:190", 
        ["category"]="Weapon", 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="AGI+11", 
            [4]="Evasion+22"
        }, 
        ["en"]="Thokcha", 
        ["AGI"]=11, 
        ["delay"]=190, 
        ["skill"]="Dagger", 
        ["jobs"]={
            [6]="THF", 
            [10]="BRD", 
            [19]="DNC"
        }, 
        ["Evasion"]=22, 
        ["id"]=19873, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=47
    }, 
    [495]={
        ["discription"]="DEX+3", 
        ["en"]="Pixie Earring", 
        ["DEX"]=3, 
        ["id"]=13415, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [496]={
        ["discription"]="DEF:21 HP+10 MP+10 \"Subtle Blow\"+3 ", 
        ["Accuracy"]=15, 
        ["augments"]={
            [1]="STR+4", 
            [2]="Weapon Skill Acc.+15", 
            [3]="DEX+4", 
            [4]="Crit. hit damage +2%", 
            [5]="none"
        }, 
        ["category"]="Armor", 
        ["DEX"]=4, 
        ["en"]="Anwig Salade", 
        ["HP"]=10, 
        ["Critical hit damage"]=2, 
        ["slots"]={
            [4]="Head"
        }, 
        ["MP"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=11488, 
        ["DEF"]=21, 
        ["STR"]=4
    }, 
    [497]={
        ["discription"]="DEF:42 HP+10 MP+10 STR+5 DEX+5 AGI+5", 
        ["AGI"]=5, 
        ["DEX"]=5, 
        ["Dual Wield"]=3, 
        ["Store TP"]=4, 
        ["en"]="Mirke Wardecors", 
        ["HP"]=10, 
        ["id"]=11314, 
        ["slots"]={
            [5]="Body"
        }, 
        ["STR"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["MP"]=10, 
        ["DEF"]=42, 
        ["augments"]={
            [1]="\"Dual Wield\"+3", 
            [2]="\"Store TP\"+4 \"Subtle Blow\"+4", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["category"]="Armor"
    }, 
    [498]={
        ["discription"]="DMG:49 Delay:189 DEX+15 Critical hit rate +5% Occasionally ignores physical defense", 
        ["category"]="Weapon", 
        ["en"]="Coruscanti", 
        ["Critical hit rate"]=5, 
        ["delay"]=189, 
        ["DEX"]=15, 
        ["jobs"]={
            [6]="THF", 
            [10]="BRD", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["skill"]="Dagger", 
        ["id"]=19144, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=49
    }, 
    [499]={
        ["discription"]="DEF:1 Dispense: Watermelon Snow Cone", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Citrullus Shirt", 
        ["id"]=26516, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [500]={
        ["discription"]="DMG:3 Delay:216  Extends chocobo riding time", 
        ["en"]="Chocobo Wand", 
        ["skill"]="Club", 
        ["delay"]=216, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=17074, 
        ["damage"]=3
    }, 
    [501]={
        ["Evasion"]=9, 
        ["category"]="Armor", 
        ["en"]="Vengeful Ring", 
        ["HP"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27592, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=20, 
        ["discription"]="HP+20 MP+20 Evasion+9 Magic Evasion+9 Enmity+3"
    }, 
    [502]={
        ["Ranged Attack"]=15, 
        ["Ranged Accuracy"]=15, 
        ["discription"]="DEF:9 HP+20 MP+20 Accuracy+15 Ranged Accuracy+15 Attack+15 Ranged Attack+15 Magic Accuracy+7 \"Magic Atk. Bonus\"+7", 
        ["category"]="Armor", 
        ["Magic Atk. Bonus"]=7, 
        ["en"]="Eschan Stone", 
        ["HP"]=20, 
        ["MP"]=20, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["Attack"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=15, 
        ["DEF"]=9, 
        ["id"]=28415, 
        ["Magic Accuracy"]=7
    }, 
    [503]={
        ["discription"]="Regain+5 Weapon Skill Accuracy+5 Weapon Skill Damage+3%", 
        ["Accuracy"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=27587, 
        ["en"]="Karieyh Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [504]={
        ["discription"]="Double Attack+3% \"Triple Attack\"+3%", 
        ["id"]=11651, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Epona's Ring", 
        ["Attack"]=3, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [505]={
        ["en"]="Sapience Orb", 
        ["id"]=22252, 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["discription"]="Enmity+2 \"Fast Cast\"+2%", 
        ["Fast Cast"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [506]={
        ["Ranged Attack"]=10, 
        ["Ranged Accuracy"]=10, 
        ["discription"]="DEF:14 HP+35 MP+35 Attack+10 Accuracy+10 Ranged Attack+10 Ranged Accuracy+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Regen\"+2", 
        ["category"]="Armor", 
        ["Magic Atk. Bonus"]=10, 
        ["en"]="Sanctity Necklace", 
        ["HP"]=35, 
        ["MP"]=35, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Attack"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=10, 
        ["DEF"]=14, 
        ["id"]=26023, 
        ["Magic Accuracy"]=10
    }, 
    [507]={
        ["id"]=28403, 
        ["en"]="Inq. Bead Necklace", 
        ["DEF"]=13, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:13 HP+55 \"Magic Def. Bonus\"+8", 
        ["HP"]=55, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [508]={
        ["Ranged Attack"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=27496, 
        ["DEX"]=24, 
        ["DEF"]=79, 
        ["augments"]={
            [1]="Weapon skill damage +5%", 
            [2]="AGI+9", 
            [3]="Accuracy+13", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=11, 
        ["en"]="Herculean Boots", 
        ["Ranged Accuracy"]=10, 
        ["item_level"]=119, 
        ["AGI"]=52, 
        ["HP"]=9, 
        ["Accuracy"]=23, 
        ["discription"]="DEF:79 HP+9 STR+16 DEX+24 VIT+10 AGI+43 MND+11 CHR+26 Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+5 Evasion+80 Magic Evasion+75 Haste+4% \"Triple Attack\"+2 \"Subtle Blow\"+6 Physical damage taken -2%", 
        ["CHR"]=26, 
        ["category"]="Armor", 
        ["STR"]=16, 
        ["Haste"]=4, 
        ["Evasion"]=80, 
        ["Attack"]=10, 
        ["PDT"]=-2, 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["VIT"]=10, 
        ["Magic Accuracy"]=10
    }, 
    [509]={
        ["discription"]="TP not depleted when weapon skill used +1% Latent effect: Weapon Skill Accuracy+10 Weapon skill damage +10%", 
        ["id"]=27510, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Fotia Gorget", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [510]={
        ["MDT"]=-4, 
        ["id"]=27554, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Purity Ring", 
        ["discription"]="Magic Evasion+10 Potency of \"Cursna\" effects received +7 Magic damage taken -4% \"Holy Water\"+7%", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [511]={
        ["discription"]="Magic Atk. Bonus+7", 
        ["Magic Atk. Bonus"]=7, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Novio Earring", 
        ["id"]=14808, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [512]={
        ["discription"]="DEF:7 \"Conserve TP\"+7 TP not depleted when weapon skill used +1% Latent effect: Weapon Skill Accuracy+10 Weapon skill damage +10%", 
        ["DEF"]=7, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Fotia Belt", 
        ["id"]=28420, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [513]={
        ["discription"]="MP+35 Magic Damage+11 Unity Ranking: INT+2～6", 
        ["INT"]=6, 
        ["category"]="Weapon", 
        ["en"]="Ghastly Tathlum +1", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["Unity Ranking Bonus Applied"]="INT + 6", 
        ["id"]=21344, 
        ["skill"]="(N/A)", 
        ["MP"]=35, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [514]={
        ["discription"]="HP+90 -20", 
        ["en"]="Meridian Ring", 
        ["HP"]=90, 
        ["id"]=11637, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [515]={
        ["Ranged Attack"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=25842, 
        ["Fast Cast"]=6, 
        ["STR"]=33, 
        ["augments"]={
            [1]="Mag. Acc.+14 \"Mag.Atk.Bns.\"+14", 
            [2]="\"Fast Cast\"+6", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=15, 
        ["AGI"]=32, 
        ["discription"]="DEF:114 HP+38 STR+33 VIT+16 AGI+32 INT+29 MND+15 CHR+10 Attack+15 Ranged Attack+15 Evasion+62 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% Enmity-4 \"Store TP\"+4 Physical damage taken -2%", 
        ["Store TP"]=4, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["Haste"]=6, 
        ["en"]="Herculean Trousers", 
        ["INT"]=29, 
        ["CHR"]=10, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=114, 
        ["Evasion"]=62, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=14, 
        ["Magic Atk. Bonus"]=14, 
        ["VIT"]=16, 
        ["PDT"]=-2, 
        ["Attack"]=15
    }, 
    [516]={
        ["DT"]=-3, 
        ["en"]="Staunch Tathlum +1", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["discription"]="Resistance to all status ailments +11 Spellcasting interruption rate -11% Damage taken -3%", 
        ["id"]=22279, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [517]={
        ["discription"]="Damage taken -10%", 
        ["id"]=13566, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Defending Ring", 
        ["DT"]=-10, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [518]={
        ["discription"]="Critical hit rate +2% Critical hit damage +6%", 
        ["en"]="Yetshila +1", 
        ["Critical hit damage"]=6, 
        ["id"]=21379, 
        ["category"]="Weapon", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [13]="NIN", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["Critical hit rate"]=2, 
        ["skill"]="(N/A)"
    }, 
    [519]={
        ["MDT"]=-2, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=12, 
        ["en"]="Gyve Trousers", 
        ["MND"]=25, 
        ["Haste"]=5, 
        ["discription"]="DEF:109 HP+22 MP+32 STR+19 DEX+12 VIT+19 AGI+5 INT+35 MND+25 CHR+23 \"Magic Atk. Bonus\"+40 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% \"Fast Cast\"+4% \"Cure\" potency +10% Magic damage taken -2%", 
        ["AGI"]=5, 
        ["Fast Cast"]=4, 
        ["HP"]=22, 
        ["id"]=27324, 
        ["Magic Atk. Bonus"]=40, 
        ["DEF"]=109, 
        ["MP"]=32, 
        ["Evasion"]=27, 
        ["VIT"]=19, 
        ["STR"]=19, 
        ["CHR"]=23, 
        ["INT"]=35, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [520]={
        ["Evasion"]=41, 
        ["Haste"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=39, 
        ["PDT"]=-2, 
        ["MND"]=26, 
        ["STR"]=16, 
        ["Ranged Accuracy"]=12, 
        ["augments"]={
            [1]="Accuracy+10", 
            [2]="Weapon skill damage +5%", 
            [3]="Attack+10", 
            [4]="none", 
            [5]="none"
        }, 
        ["en"]="Herculean Gloves", 
        ["HP"]=20, 
        ["id"]=27140, 
        ["item_level"]=119, 
        ["INT"]=14, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=97, 
        ["Accuracy"]=22, 
        ["CHR"]=19, 
        ["VIT"]=30, 
        ["category"]="Armor", 
        ["discription"]="DEF:97 HP+20 STR+16 DEX+39 VIT+30 AGI+8 INT+14 MND+26 CHR+19 Accuracy+12 Ranged Accuracy+12 Evasion+41 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+2% \"Subtle Blow\"+5 Physical damage taken -2%", 
        ["AGI"]=8, 
        ["Attack"]=10
    }, 
    [521]={
        ["id"]=28440, 
        ["en"]="Windbuffet Belt +1", 
        ["DEF"]=9, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:9 Accuracy+2 \"Triple Attack\"+2% \"Quadruple Attack\"+2%", 
        ["Accuracy"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [522]={
        ["discription"]="Increases all elemental attacks by 1-15 based on distance to target", 
        ["id"]=26359, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Orpheus's Sash", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [523]={
        ["id"]=26015, 
        ["en"]="Combatant's Torque", 
        ["Store TP"]=4, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="Combat skills +15 \"Store TP\"+4", 
        ["Combat skills"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [524]={
        ["discription"]="Store TP-10 Weapon skill damage +5%", 
        ["id"]=26214, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Epaminondas's Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [525]={
        ["Parrying skill"]=5, 
        ["category"]="Armor", 
        ["en"]="Portus Annulet", 
        ["discription"]="Accuracy+7 Guarding skill +5 Evasion skill +5 Shield skill +5 Parrying skill +5", 
        ["Guarding skill"]=5, 
        ["Shield skill"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Accuracy"]=7, 
        ["id"]=10761, 
        ["Evasion skill"]=5
    }, 
    [526]={
        ["discription"]="DEF:13 Accuracy+20 Attack-5 \"Store TP\"+3", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Olseni Belt", 
        ["Store TP"]=3, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28442, 
        ["DEF"]=13, 
        ["Accuracy"]=20, 
        ["Attack"]=-5
    }, 
    [527]={
        ["Evasion"]=41, 
        ["MND"]=19, 
        ["Haste"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEX"]=19, 
        ["slots"]={
            [5]="Body"
        }, 
        ["item_level"]=119, 
        ["discription"]="DEF:142 HP+63 MP+35 STR+29 DEX+19 VIT+29 AGI+19 INT+19 MND+19 CHR+19 Attack+20 Evasion+41 Magic Evasion+48 \"Magic Def. Bonus\"+4 Haste+3% \"Double Attack\"+3% Critical hit rate +3% \"Skillchain Bonus\"+5", 
        ["en"]="Uac Jerkin", 
        ["HP"]=63, 
        ["id"]=25703, 
        ["AGI"]=19, 
        ["STR"]=29, 
        ["DEF"]=142, 
        ["MP"]=35, 
        ["Critical hit rate"]=3, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["VIT"]=29, 
        ["Attack"]=20
    }, 
    [528]={
        ["Evasion"]=41, 
        ["Haste"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=39, 
        ["PDT"]=-2, 
        ["MND"]=32, 
        ["STR"]=16, 
        ["Ranged Accuracy"]=12, 
        ["augments"]={
            [1]="Accuracy+16 Attack+16", 
            [2]="\"Waltz\" potency +11%", 
            [3]="MND+6", 
            [4]="none", 
            [5]="none"
        }, 
        ["en"]="Herculean Gloves", 
        ["HP"]=20, 
        ["id"]=27140, 
        ["item_level"]=119, 
        ["INT"]=14, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=97, 
        ["Accuracy"]=28, 
        ["CHR"]=19, 
        ["VIT"]=30, 
        ["category"]="Armor", 
        ["discription"]="DEF:97 HP+20 STR+16 DEX+39 VIT+30 AGI+8 INT+14 MND+26 CHR+19 Accuracy+12 Ranged Accuracy+12 Evasion+41 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Triple Attack\"+2% \"Subtle Blow\"+5 Physical damage taken -2%", 
        ["AGI"]=8, 
        ["Attack"]=16
    }, 
    [529]={
        ["discription"]="DEF:7 Hand-to-Hand skill +5 Evasion skill +5", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Nesanica Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28454, 
        ["DEF"]=7, 
        ["Hand-to-Hand skill"]=5, 
        ["Evasion skill"]=5
    }, 
    [530]={
        ["Evasion"]=38, 
        ["MND"]=17, 
        ["Haste"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["STR"]=29, 
        ["item_level"]=119, 
        ["en"]="Zoar Subligar +1", 
        ["Store TP"]=-5, 
        ["HP"]=47, 
        ["discription"]="DEF:111 HP+47 STR+29 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Evasion+38 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% Enmity+6 \"Triple Attack\"+3% \"Store TP\"-5 Unity Ranking: \"Double Attack\"+1～5%", 
        ["VIT"]=16, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=111, 
        ["id"]=27231, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["AGI"]=20
    }, 
    [531]={
        ["Evasion"]=49, 
        ["MND"]=26, 
        ["Haste"]=4, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=37, 
        ["slots"]={
            [5]="Body"
        }, 
        ["AGI"]=36, 
        ["Fast Cast"]=7, 
        ["item_level"]=119, 
        ["HP"]=59, 
        ["discription"]="DEF:131 HP+59 MP+44 STR+27 DEX+37 VIT+27 AGI+36 INT+26 MND+26 CHR+26 Accuracy+10 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+4% \"Double Attack\"+2% \"Fast Cast\"+7%", 
        ["Accuracy"]=10, 
        ["STR"]=27, 
        ["DEF"]=131, 
        ["MP"]=44, 
        ["id"]=27858, 
        ["INT"]=26, 
        ["category"]="Armor", 
        ["CHR"]=26, 
        ["VIT"]=27, 
        ["en"]="Dread Jupon"
    }, 
    [532]={
        ["discription"]="AGI+2 \"Utsusemi\" spellcasting time -10%", 
        ["en"]="Magoraga Beads", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["AGI"]=2, 
        ["id"]=11627, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [533]={
        ["Ranged Attack"]=15, 
        ["STR"]=33, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=6, 
        ["item_level"]=119, 
        ["MND"]=15, 
        ["AGI"]=32, 
        ["augments"]={
            [1]="\"Waltz\" potency +11%", 
            [2]="INT+4", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["Store TP"]=4, 
        ["en"]="Herculean Trousers", 
        ["HP"]=38, 
        ["id"]=25842, 
        ["Evasion"]=62, 
        ["INT"]=33, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=114, 
        ["PDT"]=-2, 
        ["CHR"]=10, 
        ["VIT"]=16, 
        ["category"]="Armor", 
        ["discription"]="DEF:114 HP+38 STR+33 VIT+16 AGI+32 INT+29 MND+15 CHR+10 Attack+15 Ranged Attack+15 Evasion+62 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% Enmity-4 \"Store TP\"+4 Physical damage taken -2%", 
        ["Attack"]=15
    }, 
    [534]={
        ["Evasion"]=60, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["STR"]=37, 
        ["DEX"]=34, 
        ["Haste"]=4, 
        ["augments"]={
            [1]="Weapon skill damage +5%", 
            [2]="STR+9", 
            [3]="Attack+13", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=20, 
        ["en"]="Herculean Vest", 
        ["Ranged Accuracy"]=15, 
        ["Store TP"]=3, 
        ["item_level"]=119, 
        ["HP"]=61, 
        ["Accuracy"]=15, 
        ["discription"]="DEF:133 HP+61 STR+28 DEX+34 VIT+24 AGI+30 INT+21 MND+20 CHR+21 Accuracy+15 Ranged Accuracy+15 Evasion+60 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% Enmity-4 \"Store TP\"+3 Critical hit rate +3%", 
        ["INT"]=21, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=133, 
        ["AGI"]=30, 
        ["CHR"]=21, 
        ["id"]=25718, 
        ["category"]="Armor", 
        ["Critical hit rate"]=3, 
        ["VIT"]=24, 
        ["Attack"]=13
    }, 
    [535]={
        ["discription"]="DEF:35 HP+275 Damage taken -6%", 
        ["category"]="Armor", 
        ["en"]="Moonlight Cape", 
        ["HP"]=275, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=35, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=26269, 
        ["DT"]=-6
    }, 
    [536]={
        ["Evasion"]=15, 
        ["category"]="Weapon", 
        ["en"]="Yamarang", 
        ["Store TP"]=3, 
        ["skill"]="(N/A)", 
        ["discription"]="Accuracy+15 Magic Accuracy+15 Evasion+15 Magic Evasion+15 \"Store TP\"+3 \"Waltz\" potency +5%", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Accuracy"]=15, 
        ["id"]=22280, 
        ["Magic Accuracy"]=15
    }, 
    [537]={
        ["discription"]="+20 +20 +20 +20 +20 +20 Occasionally absorbs magic damage taken Unity Ranking: Enmity+1～8", 
        ["id"]=27505, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Warder's Charm +1", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [538]={
        ["discription"]="Skillchain Bonus+5 Magic burst damage II +5", 
        ["id"]=11672, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Mujin Band", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [539]={
        ["discription"]="MND+2 \"Magic Def. Bonus\"+2  Bonus damage added to magic burst", 
        ["en"]="Static Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=15962, 
        ["MND"]=2, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [540]={
        ["discription"]="MP+30 Enhances \"Fast Cast\" effect", 
        ["MP"]=30, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=14812, 
        ["en"]="Loquac. Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [541]={
        ["discription"]="Dusk to dawn: STR+7 DEX+7 VIT+7 INT+7 Unity Ranking: \"Double Attack\"+1～3%", 
        ["category"]="Armor", 
        ["en"]="Lugra Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["STR"]=7, 
        ["INT"]=7, 
        ["DEX"]=7, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["id"]=28481, 
        ["VIT"]=7
    }, 
    [542]={
        ["discription"]="Weapon skill damage +2%", 
        ["id"]=27537, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Ishvara Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [543]={
        ["Magic Accuracy"]=5, 
        ["en"]="Kishar Ring", 
        ["id"]=26188, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Magic Accuracy+5 \"Fast Cast\"+4% Enfeebling magic effect duration +10% \"Absorb\" effect duration +10%", 
        ["Fast Cast"]=4, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [13]="NIN", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [544]={
        ["discription"]="Dusk to dawn: STR+8 DEX+8 VIT+8 INT+8 Unity Ranking: \"Double Attack\"+1～3%", 
        ["category"]="Armor", 
        ["en"]="Lugra Earring +1", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["STR"]=8, 
        ["INT"]=8, 
        ["DEX"]=8, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["id"]=28482, 
        ["VIT"]=8
    }, 
    [545]={
        ["discription"]="AGI+5 CHR+5 \"Dual Wield\"+6 Latent effect: Attack+10 Evasion+10", 
        ["category"]="Armor", 
        ["en"]="Shetal Stone", 
        ["Dual Wield"]=6, 
        ["CHR"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=28445, 
        ["AGI"]=5
    }, 
    [546]={
        ["discription"]="DEF:12 STR+7 INT+7 MND+7 +20 +20 +20 +20 +20 +20 +30 +30 Accuracy+10 Attack+10", 
        ["MND"]=7, 
        ["INT"]=7, 
        ["category"]="Armor", 
        ["en"]="Engraved Belt", 
        ["STR"]=7, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [13]="NIN", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=12, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["Accuracy"]=10, 
        ["id"]=28414, 
        ["Attack"]=10
    }, 
    [547]={
        ["discription"]="AGI+2 Enhances \"Dual Wield\" effect Sword skill +5", 
        ["en"]="Suppanomimi", 
        ["Sword skill"]=5, 
        ["category"]="Armor", 
        ["Dual Wield"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=14739, 
        ["AGI"]=2
    }, 
    [548]={
        ["Evasion"]=70, 
        ["MND"]=23, 
        ["VIT"]=25, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=24, 
        ["Haste"]=4, 
        ["AGI"]=23, 
        ["slots"]={
            [5]="Body"
        }, 
        ["item_level"]=119, 
        ["HP"]=61, 
        ["en"]="Emet Harness +1", 
        ["Accuracy"]=20, 
        ["Unity Ranking Bonus Applied"]="Accuracy + 20", 
        ["STR"]=25, 
        ["DEF"]=131, 
        ["id"]=26871, 
        ["INT"]=23, 
        ["category"]="Armor", 
        ["CHR"]=23, 
        ["PDT"]=-6, 
        ["discription"]="DEF:131 HP+61 STR+25 DEX+24 VIT+25 AGI+23 INT+23 MND+23 CHR+23 Evasion+70 Magic Evasion+64 \"Magic Def. Bonus\"+5 Haste+4% Enmity+10 Physical damage taken -6% Unity Ranking: Accuracy+10～20"
    }, 
    [549]={
        ["Evasion"]=44, 
        ["MND"]=30, 
        ["Haste"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=35, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["AGI"]=5, 
        ["discription"]="DEF:92 HP+25 STR+11 DEX+35 VIT+32 AGI+5 INT+12 MND+30 CHR+17 Accuracy+20 Evasion+44 Magic Evasion+57 \"Magic Def. Bonus\"+2 Haste+5% Enmity+9 Damage taken -2%", 
        ["en"]="Kurys Gloves", 
        ["HP"]=25, 
        ["item_level"]=119, 
        ["Accuracy"]=20, 
        ["STR"]=11, 
        ["DEF"]=92, 
        ["id"]=27134, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["VIT"]=32, 
        ["DT"]=-2
    }, 
    [550]={
        ["discription"]="DEF:8 HP+55 STR+3", 
        ["category"]="Armor", 
        ["en"]="Oneiros Belt", 
        ["HP"]=55, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=11773, 
        ["STR"]=3
    }, 
    [551]={
        ["discription"]="Accuracy+3 \"Waltz\" potency +3%", 
        ["Accuracy"]=3, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=10751, 
        ["en"]="Valseur's Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [552]={
        ["discription"]="DEF:7 Accuracy+6 Ranged Accuracy+6 Magic Accuracy+6 Critical hit rate +3% Set: Increases Dexterity, Agility, and Charisma", 
        ["Ranged Accuracy"]=6, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }, 
            ["set id"]=477
        }, 
        ["category"]="Armor", 
        ["en"]="Mummu Ring", 
        ["Critical hit rate"]=3, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEF"]=7, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=6, 
        ["id"]=26212, 
        ["Magic Accuracy"]=6
    }, 
    [553]={
        ["discription"]="DEF:11 VIT+9 CHR+9 \"Resist Charm\"+9 Enmity+10 Unity Ranking: Accuracy+1～5", 
        ["CHR"]=9, 
        ["category"]="Armor", 
        ["en"]="Unmoving Collar +1", 
        ["Unity Ranking Bonus Applied"]="Accuracy + 5", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=11, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=5, 
        ["id"]=27509, 
        ["VIT"]=9
    }, 
    [554]={
        ["discription"]="DEX+10 Accuracy+10 Critical hit rate +5%", 
        ["category"]="Armor", 
        ["en"]="Odr Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Critical hit rate"]=5, 
        ["DEX"]=10, 
        ["Accuracy"]=10, 
        ["id"]=26108
    }, 
    [555]={
        ["discription"]="Accuracy+10 Magic Accuracy+10 \"Subtle Blow\"+5 \"Store TP\"+3", 
        ["category"]="Armor", 
        ["en"]="Digni. Earring", 
        ["Store TP"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27547, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Accuracy"]=10, 
        ["Magic Accuracy"]=10
    }, 
    [556]={
        ["discription"]="Accuracy+13 Attack+13 \"Magic Atk. Bonus\"+7 Unity ranking: STR+1～5", 
        ["category"]="Weapon", 
        ["en"]="Seeth. Bomblet +1", 
        ["Magic Atk. Bonus"]=7, 
        ["STR"]=1, 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [13]="NIN", 
            [22]="RUN"
        }, 
        ["Accuracy"]=13, 
        ["id"]=22255, 
        ["Attack"]=13
    }, 
    [557]={
        ["en"]="Moonshade Earring", 
        ["id"]=11697, 
        ["Accuracy"]=4, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="none", 
        ["augments"]={
            [1]="Accuracy+4", 
            [2]="TP Bonus +250", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [558]={
        ["discription"]="Katana skill +5 Enmity+5 \"Double Attack\"+3%", 
        ["Katana skill"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28515, 
        ["en"]="Trux Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [559]={
        ["Ranged Attack"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=27496, 
        ["DEX"]=24, 
        ["DEF"]=79, 
        ["augments"]={
            [1]="Attack+7", 
            [2]="\"Waltz\" potency +11%", 
            [3]="AGI+6", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=11, 
        ["en"]="Herculean Boots", 
        ["Ranged Accuracy"]=10, 
        ["item_level"]=119, 
        ["AGI"]=49, 
        ["HP"]=9, 
        ["Accuracy"]=10, 
        ["discription"]="DEF:79 HP+9 STR+16 DEX+24 VIT+10 AGI+43 MND+11 CHR+26 Accuracy+10 Attack+10 Ranged Accuracy+10 Ranged Attack+10 Magic Accuracy+10 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+5 Evasion+80 Magic Evasion+75 Haste+4% \"Triple Attack\"+2 \"Subtle Blow\"+6 Physical damage taken -2%", 
        ["CHR"]=26, 
        ["category"]="Armor", 
        ["STR"]=16, 
        ["Haste"]=4, 
        ["Evasion"]=80, 
        ["Attack"]=17, 
        ["PDT"]=-2, 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["VIT"]=10, 
        ["Magic Accuracy"]=10
    }, 
    [560]={
        ["discription"]="Magic Evasion+6 \"Magic Def. Bonus\"+4 Club skill +5", 
        ["Club skill"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28516, 
        ["en"]="Sanare Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [561]={
        ["MDT"]=-2, 
        ["category"]="Armor", 
        ["en"]="Odnowa Earring +1", 
        ["Unity Ranking Bonus Applied"]="Accuracy + 10", 
        ["STR"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27549, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["discription"]="STR+3 VIT+3 Converts 100 MP to HP Magic damage taken -2% Unity Ranking: Accuracy+5～10", 
        ["Accuracy"]=10, 
        ["VIT"]=3
    }, 
    [562]={
        ["Evasion"]=15, 
        ["en"]="Eabani Earring", 
        ["category"]="Armor", 
        ["HP"]=45, 
        ["Dual Wield"]=4, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=27540, 
        ["discription"]="HP+45 Evasion+15 Magic Evasion+8 \"Dual Wield\"+4"
    }, 
    [563]={
        ["id"]=15895, 
        ["en"]="Trance Belt", 
        ["DEF"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:5 HP+14 Enmity+4", 
        ["HP"]=14, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [564]={
        ["discription"]="MND+5 Magic Accuracy+8 All magic skills +5", 
        ["category"]="Armor", 
        ["en"]="Stikini Ring", 
        ["All magic skills"]=5, 
        ["MND"]=5, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26183, 
        ["Magic Accuracy"]=8
    }, 
    [565]={
        ["Accuracy"]=6, 
        ["en"]="Cessance Earring", 
        ["Store TP"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Accuracy+6 \"Double Attack\"+3% \"Store TP\"+3", 
        ["id"]=27541, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [566]={
        ["Evasion skill"]=10, 
        ["id"]=26089, 
        ["DEF"]=20, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:20 Evasion skill +10", 
        ["en"]="Ran Earring", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [567]={
        ["Attack"]=16, 
        ["en"]="Gere Ring", 
        ["id"]=28471, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="STR+10 Attack+16 \"Triple Attack\"+5%", 
        ["STR"]=10, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [13]="NIN", 
            [18]="PUP", 
            [19]="DNC"
        }
    }, 
    [568]={
        ["Evasion"]=24, 
        ["STR"]=11, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=35, 
        ["Haste"]=5, 
        ["MND"]=30, 
        ["id"]=27135, 
        ["Fast Cast"]=8, 
        ["en"]="Leyline Gloves", 
        ["AGI"]=5, 
        ["HP"]=25, 
        ["augments"]={
            [1]="Accuracy+15", 
            [2]="Mag. Acc.+15", 
            [3]="\"Mag.Atk.Bns.\"+15", 
            [4]="\"Fast Cast\"+3", 
            [5]="none"
        }, 
        ["discription"]="DEF:91 HP+25 STR+11 DEX+35 VIT+32 AGI+5 INT+12 MND+30 CHR+17 Accuracy+18 Magic Accuracy+18 Evasion+24 Magic Evasion+62 \"Magic Atk. Bonus\"+15 \"Magic Def. Bonus\"+2 Haste+5% \"Fast Cast\"+5%", 
        ["INT"]=12, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=91, 
        ["Accuracy"]=33, 
        ["CHR"]=17, 
        ["Magic Atk. Bonus"]=30, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["VIT"]=32, 
        ["Magic Accuracy"]=33
    }, 
    [569]={
        ["discription"]="MND+8 Magic Accuracy+11 All magic skills +8 \"Refresh\"+1", 
        ["category"]="Armor", 
        ["en"]="Stikini Ring +1", 
        ["All magic skills"]=8, 
        ["MND"]=8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26184, 
        ["Magic Accuracy"]=11
    }, 
    [570]={
        ["discription"]="Magic Atk. Bonus+10 Enmity+2", 
        ["Magic Atk. Bonus"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Friomisi Earring", 
        ["id"]=28514, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [571]={
        ["Attack"]=7, 
        ["en"]="Begrudging Ring", 
        ["Accuracy"]=7, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Accuracy+7 Attack+7 Enmity+5 \"Tonberry's Grudge\"", 
        ["id"]=26172, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [572]={
        ["discription"]="Enhances \"Double Attack\" effect \"Store TP\"+1", 
        ["Store TP"]=1, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Brutal Earring", 
        ["id"]=14813, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [573]={
        ["discription"]="AGI+10 Ranged Attack+25 \"Magic Atk. Bonus\"+10 \"Recycle\"+10", 
        ["en"]="Dingir Ring", 
        ["Magic Atk. Bonus"]=10, 
        ["Ranged Attack"]=25, 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR"
        }, 
        ["id"]=26187, 
        ["AGI"]=10
    }, 
    [574]={
        ["discription"]="HP+30 MP+30 VIT+5 Accuracy+7 Enmity+5", 
        ["category"]="Armor", 
        ["en"]="Supershear Ring", 
        ["MP"]=30, 
        ["HP"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=28535, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=7, 
        ["VIT"]=5
    }, 
    [575]={
        ["discription"]="Magic critical hit rate +5% Bonus damage added to magic burst", 
        ["id"]=28582, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Locus Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [576]={
        ["Ranged Attack"]=15, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["STR"]=22, 
        ["DEX"]=28, 
        ["DEF"]=108, 
        ["augments"]={
            [1]="Weapon skill damage +5%", 
            [2]="AGI+4", 
            [3]="Accuracy+4", 
            [4]="none", 
            [5]="none"
        }, 
        ["MND"]=16, 
        ["Evasion"]=55, 
        ["en"]="Herculean Helm", 
        ["Fast Cast"]=7, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["Accuracy"]=4, 
        ["discription"]="DEF:108 HP+38 STR+22 DEX+28 VIT+18 AGI+25 INT+20 MND+16 CHR+17 Attack+15 Ranged Attack+15 \"Magic Atk. Bonus\"+10 Evasion+55 Magic Evasion+59 \"Magic Def. Bonus\"+3 Haste+8% \"Fast Cast\"+7%", 
        ["INT"]=20, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Haste"]=8, 
        ["AGI"]=29, 
        ["CHR"]=17, 
        ["Magic Atk. Bonus"]=10, 
        ["category"]="Armor", 
        ["id"]=25642, 
        ["VIT"]=18, 
        ["Attack"]=15
    }, 
    [577]={
        ["id"]=26003, 
        ["en"]="Baetyl Pendant", 
        ["Magic Atk. Bonus"]=13, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="Magic Atk. Bonus+13 \"Fast Cast\"+4%", 
        ["Fast Cast"]=4, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [578]={
        ["discription"]="HP+40 Enmity+4 \"Counter\"+3", 
        ["en"]="Cryptic Earring", 
        ["HP"]=40, 
        ["id"]=28483, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [579]={
        ["discription"]="Magic Atk. Bonus+6 Magic critical hit rate +3%", 
        ["Magic Atk. Bonus"]=6, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Hecate's Earring", 
        ["id"]=11698, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [580]={
        ["discription"]="DEF:10 HP+60 DEX+10 AGI+10 Attack+25 \"Store TP\"+5 ", 
        ["category"]="Armor", 
        ["DEX"]=10, 
        ["en"]="Ilabrat Ring", 
        ["Store TP"]=5, 
        ["HP"]=60, 
        ["AGI"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26186, 
        ["DEF"]=10, 
        ["Attack"]=25
    }, 
    [581]={
        ["discription"]="Pet: Accuracy+15 Magic Accuracy+15 \"Store TP\"+8 Damage taken -3%", 
        ["id"]=26083, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Enmerkar Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }
    }, 
    [582]={
        ["discription"]="DMG:204 Delay:366 MP+88 Staff skill +242 Parrying skill +242 Magic Accuracy skill +188 Avatar perpetuation cost -5 Avatar: Accuracy+25 Haste+3%", 
        ["slots"]={
            [0]="Main"
        }, 
        ["augments"]={
            [1]="Pet: Accuracy+70", 
            [2]="Pet: Attack+70", 
            [3]="Pet: \"Dbl. Atk.\"+15"
        }, 
        ["Staff skill"]=242, 
        ["en"]="Gridarvor", 
        ["item_level"]=119, 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["skill"]="Staff", 
        ["MP"]=88, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["id"]=21174, 
        ["Parrying skill"]=242, 
        ["damage"]=204
    }, 
    [583]={
        ["discription"]="Summoning magic skill +3", 
        ["id"]=14777, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Smn. Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [584]={
        ["discription"]="HP+50 Damage taken -5% Avatar: Accuracy+25 Ranged Accuracy+25 Magic Accuracy+25", 
        ["en"]="Smn. Collar +2", 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["HP"]=50, 
        ["category"]="Armor", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["id"]=25503, 
        ["DT"]=-5
    }, 
    [585]={
        ["Evasion"]=33, 
        ["STR"]=15, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=15, 
        ["Haste"]=6, 
        ["MND"]=28, 
        ["id"]=25643, 
        ["discription"]="DEF:95 HP+22 MP+56 STR+15 DEX+15 VIT+15 AGI+6 INT+29 MND+28 CHR+26 Evasion+33 Magic Evasion+86 Magic Accuracy+15 \"Magic Atk. Bonus\"+10 \"Magic Def. Bonus\"+6 Haste+6% \"Fast Cast\"+8%", 
        ["en"]="Merlinic Hood", 
        ["Fast Cast"]=8, 
        ["HP"]=22, 
        ["augments"]={
            [1]="Blood Pact Dmg.+10", 
            [2]="Pet: \"Mag.Atk.Bns.\"+13", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["item_level"]=119, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=95, 
        ["MP"]=56, 
        ["AGI"]=6, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["CHR"]=26, 
        ["VIT"]=15, 
        ["Magic Atk. Bonus"]=10, 
        ["Magic Accuracy"]=15
    }, 
    [586]={
        ["Evasion"]=33, 
        ["MND"]=23, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEF"]=102, 
        ["item_level"]=119, 
        ["en"]="Beck. Spats +1", 
        ["AGI"]=17, 
        ["HP"]=41, 
        ["discription"]="DEF:102 HP+41 MP+116 STR+24 VIT+12 AGI+17 INT+35 MND+23 CHR+20 Evasion+33 Magic Evasion+107 \"Magic Def. Bonus\"+6 Summoning magic skill +20 Haste+5% \"Blood Boon\"+12 Avatar: TP Bonus +600 Set: Augments \"Blood Boon\"", 
        ["VIT"]=12, 
        ["Haste"]=5, 
        ["MP"]=116, 
        ["id"]=27266, 
        ["STR"]=24, 
        ["CHR"]=20, 
        ["INT"]=35, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=365
        }
    }, 
    [587]={
        ["en"]="Sancus Sachet +1", 
        ["id"]=21395, 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["discription"]="\"Blood Pact\" recast time II -7 Avatar: Lv119 \"Blood Pact\" damage +15 Accuracy+20 Ranged Accuracy+20 Magic Accuracy+20", 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [588]={
        ["discription"]="Adds \"Regen\" effect Latent effect: Adds \"Refresh\" effect", 
        ["en"]="Oneiros Grip", 
        ["skill"]="(N/A)", 
        ["id"]=18811, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [589]={
        ["discription"]="Summoning magic skill +3", 
        ["en"]="Vox Grip", 
        ["skill"]="(N/A)", 
        ["id"]=19058, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [590]={
        ["discription"]="Spell interruption rate down 10% Occ. quickens spellcasting +2%", 
        ["en"]="Impatiens", 
        ["skill"]="(N/A)", 
        ["id"]=19761, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [591]={
        ["Evasion"]=56, 
        ["MND"]=29, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=24, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Convoker's Horn +3", 
        ["DEF"]=112, 
        ["discription"]="DEF:112 HP+56 MP+98 STR+22 DEX+24 VIT+24 AGI+24 INT+29 MND+29 CHR+29 Accuracy+47 Evasion+56 Magic Evasion+95 \"Magic Def. Bonus\"+6 Summoning magic skill +19 Haste+6% \"Refresh\"+3 Avatar: Accuracy+41 Magic Accuracy+41 Haste+10% Set (Avatar): Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["HP"]=56, 
        ["id"]=23389, 
        ["VIT"]=24, 
        ["Haste"]=6, 
        ["MP"]=98, 
        ["Accuracy"]=47, 
        ["STR"]=22, 
        ["CHR"]=29, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["AGI"]=24
    }, 
    [592]={
        ["Evasion"]=41, 
        ["MND"]=29, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=20, 
        ["id"]=26829, 
        ["AGI"]=21, 
        ["Haste"]=3, 
        ["en"]="Glyphic Doublet +1", 
        ["HP"]=50, 
        ["discription"]="DEF:123 HP+50 MP+115 STR+21 DEX+20 VIT+21 AGI+21 INT+29 MND+29 CHR+29 Evasion+41 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+3% \"Blood Pact\" ability delay II -2 Avatar perpetuation cost -5 Avatar: Critical hit rate +12%", 
        ["VIT"]=21, 
        ["DEF"]=123, 
        ["MP"]=115, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Reduces Sp. \"Blood Pact\" MP cost", 
            [4]="none"
        }, 
        ["STR"]=21, 
        ["CHR"]=29, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [593]={
        ["Evasion"]=41, 
        ["MND"]=29, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Shomonjijoe +1", 
        ["DEF"]=127, 
        ["discription"]="DEF:127 HP+50 MP+85 STR+21 DEX+20 VIT+21 AGI+21 INT+29 MND+29 CHR+29 Evasion+41 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+3%  \"Blood Pact\" ability delay -8 \"Refresh\"+3 Avatar: Enmity+14 Unity Ranking: Avatar: \"Magic Atk. Bonus\"+25～30", 
        ["HP"]=50, 
        ["DEX"]=20, 
        ["VIT"]=21, 
        ["Haste"]=3, 
        ["MP"]=85, 
        ["id"]=26888, 
        ["STR"]=21, 
        ["CHR"]=29, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["AGI"]=21
    }, 
    [594]={
        ["Evasion"]=22, 
        ["MND"]=33, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=28, 
        ["id"]=27005, 
        ["AGI"]=5, 
        ["Haste"]=3, 
        ["en"]="Glyphic Bracers +1", 
        ["HP"]=18, 
        ["discription"]="DEF:81 HP+18 MP+41 STR+6 DEX+28 VIT+24 AGI+5 INT+19 MND+33 CHR+19 Evasion+22 Magic Evasion+37 \"Magic Def. Bonus\"+3 Summoning magic skill +19 Haste+3% \"Blood Pact\" ability delay -6 Avatar: Accuracy+28 Haste+3%", 
        ["VIT"]=24, 
        ["DEF"]=81, 
        ["MP"]=41, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Inc. Sp. \"Blood Pact\" magic burst dmg.", 
            [4]="none"
        }, 
        ["STR"]=6, 
        ["CHR"]=19, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [595]={
        ["Evasion"]=61, 
        ["MND"]=39, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=30, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Con. Doublet +3", 
        ["DEF"]=142, 
        ["discription"]="DEF:142 HP+85 MP+211 STR+31 DEX+30 VIT+31 AGI+31 INT+39 MND+39 CHR+39 Accuracy+50 Evasion+61 Magic Evasion+100 \"Magic Def. Bonus\"+7 Haste+3% \"Blood Pact\" ability delay -15 Resistance to current avatar's element +50 Avatar: Acc.+45 Magic Acc.+45 \"Blood Pact\" damage +16 Set (Avatar): Inc. Acc., R. Acc., and M. Acc.", 
        ["HP"]=85, 
        ["id"]=23456, 
        ["VIT"]=31, 
        ["Haste"]=3, 
        ["MP"]=211, 
        ["Accuracy"]=50, 
        ["STR"]=31, 
        ["CHR"]=39, 
        ["INT"]=39, 
        ["category"]="Armor", 
        ["AGI"]=31
    }, 
    [596]={
        ["Evasion"]=27, 
        ["MND"]=26, 
        ["discription"]="DEF:105 HP+43 MP+29 STR+25 VIT+12 AGI+17 INT+36 MND+26 CHR+19 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% Enmity-6 Avatar perpetuation cost-3 Unity Ranking: \"Refresh\"+1～2", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [10]="BRD", 
            [15]="SMN", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["Refresh"]=2, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Assid. Pants +1", 
        ["DEF"]=105, 
        ["AGI"]=17, 
        ["HP"]=43, 
        ["id"]=28135, 
        ["category"]="Armor", 
        ["Haste"]=5, 
        ["MP"]=29, 
        ["VIT"]=12, 
        ["STR"]=25, 
        ["INT"]=36, 
        ["Unity Ranking Bonus Applied"]="Refresh + 2", 
        ["CHR"]=19, 
        ["item_level"]=119
    }, 
    [597]={
        ["discription"]="DEF:100 HP+37 MP+86 STR+16 DEX+38 VIT+34 AGI+15 INT+29 MND+43 CHR+29 Acc.+48 Eva.+42 Magic Evasion+57 \"Magic Def. Bonus\"+4 Haste+3% Occasionally converts damage taken of avatar's element to MP Avatar: Accuracy+43 Magic Accuracy+43 Enmity+15 \"Double Attack\"+10% Set (Avatar): Inc. Acc., Ranged Acc., and Magic Acc.", 
        ["MND"]=43, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=38, 
        ["AGI"]=15, 
        ["en"]="Convo. Bracers +3", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=100, 
        ["HP"]=37, 
        ["id"]=23523, 
        ["VIT"]=34, 
        ["Haste"]=3, 
        ["MP"]=86, 
        ["Accuracy"]=48, 
        ["STR"]=16, 
        ["CHR"]=29, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [598]={
        ["discription"]="DEF:16 MP+12 Evasion+8 Movement speed +12%", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["category"]="Armor", 
        ["en"]="Crier's Gaiters", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=27456, 
        ["DEF"]=16, 
        ["MP"]=12, 
        ["Evasion"]=8
    }, 
    [599]={
        ["discription"]="Summoning magic skill +9 Avatar: \"Regain\"+25 Weather: Avatar perpetuation cost -1", 
        ["id"]=11619, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Caller's Pendant", 
        ["category"]="Armor", 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [600]={
        ["discription"]="DEF:17 Accuracy+20 Haste+9% Pet: Accuracy+20 Ranged Accuracy+20 Haste+9%", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["category"]="Armor", 
        ["en"]="Klouskap Sash +1", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=26336, 
        ["DEF"]=17, 
        ["Accuracy"]=20, 
        ["Haste"]=9
    }, 
    [601]={
        ["id"]=28452, 
        ["en"]="Fucho-no-Obi", 
        ["DEF"]=10, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:10 MP+30 \"Drain\" and \"Aspir\" potency +8 Latent effect: \"Refresh\"+1", 
        ["MP"]=30, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [602]={
        ["id"]=26260, 
        ["en"]="Campestres's Cape", 
        ["DEF"]=15, 
        ["slots"]={
            [15]="Back"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:15 Avatar: Lv.+1 \"Blood Pact\" damage +5", 
        ["augments"]={
            [1]="Pet: Acc.+20 Pet: R.Acc.+20 Pet: Atk.+20 Pet: R.Atk.+20", 
            [2]="none", 
            [3]="Pet: Accuracy+10 Pet: Rng. Acc.+10", 
            [4]="Pet: Haste+10", 
            [5]="Pet: \"Regen\"+5"
        }, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [603]={
        ["Evasion"]=22, 
        ["MND"]=33, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=28, 
        ["DEF"]=82, 
        ["en"]="Asteria Mitts +1", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["discription"]="DEF:82 HP+18 MP+44 STR+6 DEX+28 VIT+24 AGI+5 INT+19 MND+33 CHR+20 Evasion+22 Magic Evasion+43 \"Magic Def. Bonus\"+3 Haste+3% Carbuncle: Halves perpetuation cost Lv.+1 Avatar: \"Magic Atk. Bonus\"+26 Unity Ranking: \"Refresh\"+1～2", 
        ["HP"]=18, 
        ["Refresh"]=2, 
        ["VIT"]=24, 
        ["STR"]=6, 
        ["Haste"]=3, 
        ["MP"]=44, 
        ["id"]=27107, 
        ["Unity Ranking Bonus Applied"]="Refresh + 2", 
        ["CHR"]=20, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["AGI"]=5
    }, 
    [604]={
        ["discription"]="DEF:3 Magic Evasion+10 \"Magic Def. Bonus\"+5 Avatar: Accuracy+15 Ranged Accuracy+15 Magic Accuracy+15 \"Blood Pact\" damage +10", 
        ["DEF"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Lugalbanda Earring", 
        ["id"]=26082, 
        ["category"]="Armor", 
        ["jobs"]={
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [605]={
        ["discription"]="DMG:217 Delay:402 MP+88 Staff skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Blood Pact\" ability delay II -2 Avatar: Magic Accuracy+15 \"Magic Atk. Bonus\"+120 \"Blood Pact\" damage +3", 
        ["slots"]={
            [0]="Main"
        }, 
        ["augments"]={
            [1]="Summoning magic skill +15", 
            [2]="Pet: Mag. Acc.+30", 
            [3]="Pet: Damage taken -4%"
        }, 
        ["Staff skill"]=242, 
        ["en"]="Espiritus", 
        ["item_level"]=119, 
        ["delay"]=402, 
        ["category"]="Weapon", 
        ["skill"]="Staff", 
        ["MP"]=88, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["id"]=21149, 
        ["Parrying skill"]=242, 
        ["damage"]=217
    }, 
    [606]={
        ["Evasion"]=60, 
        ["MND"]=17, 
        ["item_level"]=119, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=8, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Inspirited Boots", 
        ["DEF"]=70, 
        ["discription"]="DEF:70 HP+9 MP+20 STR+8 DEX+8 VIT+8 AGI+29 INT+25 MND+17 CHR+32 \"Magic Atk. Bonus\"+20 Magic Damage+10 Evasion+60 Magic Evasion+118 \"Magic Def. Bonus\"+6 Haste+3% Duration of Refresh effects received +15", 
        ["HP"]=9, 
        ["id"]=27464, 
        ["Magic Atk. Bonus"]=20, 
        ["Haste"]=3, 
        ["MP"]=20, 
        ["VIT"]=8, 
        ["STR"]=8, 
        ["CHR"]=32, 
        ["INT"]=25, 
        ["category"]="Armor", 
        ["AGI"]=29
    }, 
    [607]={
        ["discription"]="DEF:7 MP+20 Divine magic skill +8 Summoning magic skill +8 Singing skill +8 Geomancy skill +5", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["category"]="Armor", 
        ["en"]="Kobo Obi", 
        ["Singing skill"]=8, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=26320, 
        ["DEF"]=7, 
        ["MP"]=20, 
        ["Geomancy skill"]=5
    }, 
    [608]={
        ["Evasion"]=27, 
        ["MND"]=24, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["id"]=27323, 
        ["AGI"]=17, 
        ["Haste"]=5, 
        ["en"]="Enticer's Pants", 
        ["HP"]=38, 
        ["discription"]="DEF:102 HP+38 MP+56 STR+25 VIT+11 AGI+17 INT+34 MND+24 CHR+19 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% Avatar: \"Double Attack\"+3% Critical hit rate +5% TP Bonus +650 \"Blood Pact\" damage +12", 
        ["VIT"]=11, 
        ["DEF"]=102, 
        ["MP"]=101, 
        ["augments"]={
            [1]="MP+45", 
            [2]="Pet: Accuracy+14 Pet: Rng. Acc.+14", 
            [3]="Pet: Mag. Acc.+13", 
            [4]="Pet: Damage taken -3%", 
            [5]="none"
        }, 
        ["STR"]=25, 
        ["CHR"]=19, 
        ["INT"]=34, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [609]={
        ["discription"]="DEF:7 INT+3 MND+3 Increases duration of \"Refresh\" effect received", 
        ["INT"]=3, 
        ["MND"]=3, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEF"]=7, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=11575, 
        ["en"]="Grapevine Cape"
    }, 
    [610]={
        ["discription"]="MP+30 Enhancing magic skill +5 Summoning magic skill +5", 
        ["MP"]=30, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28506, 
        ["en"]="Andoaa Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [611]={
        ["MDT"]=-8, 
        ["Haste"]=2, 
        ["jobs"]={
            [3]="WHM", 
            [10]="BRD", 
            [15]="SMN"
        }, 
        ["DEX"]=19, 
        ["discription"]="DEF:129 HP+85 MP+90 STR+16 DEX+19 VIT+24 AGI+23 INT+48 MND+43 CHR+42 Magic Accuracy+46 Evasion+38 Magic Evasion+120 \"Magic Def. Bonus\"+11 Haste+2% \"Fast Cast\"+14% Magic damage taken -8% Set: Enhances \"Refresh\" effect", 
        ["MND"]=43, 
        ["item_level"]=119, 
        ["AGI"]=23, 
        ["Fast Cast"]=14, 
        ["en"]="Inyanga Jubbah +2", 
        ["HP"]=85, 
        ["id"]=25793, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Refresh"]=1
                }, 
                [3]={
                    ["Refresh"]=2
                }, 
                [4]={
                    ["Refresh"]=3
                }, 
                [5]={
                    ["Refresh"]=4
                }
            }, 
            ["set id"]=16
        }, 
        ["DEF"]=129, 
        ["MP"]=90, 
        ["Evasion"]=38, 
        ["slots"]={
            [5]="Body"
        }, 
        ["STR"]=16, 
        ["CHR"]=42, 
        ["INT"]=48, 
        ["VIT"]=24, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=46
    }, 
    [612]={
        ["Evasion"]=38, 
        ["MND"]=25, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Baayami Hat", 
        ["DEF"]=102, 
        ["discription"]="DEF:102 HP+34 MP+44 STR+15 DEX+16 VIT+29 AGI+19 INT+33 MND+25 CHR+20 Evasion+38 Magic Evasion+96 \"Magic Def. Bonus\"+5 Summoning magic skill +26 Haste+6% Avatar: \"Regain\"+3", 
        ["HP"]=34, 
        ["DEX"]=16, 
        ["VIT"]=29, 
        ["Haste"]=6, 
        ["MP"]=44, 
        ["id"]=25565, 
        ["STR"]=15, 
        ["CHR"]=20, 
        ["INT"]=33, 
        ["category"]="Armor", 
        ["AGI"]=19
    }, 
    [613]={
        ["discription"]="MP+45 \"Conserve MP\"+3 \"Blood Boon\"+3", 
        ["MP"]=45, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=11700, 
        ["en"]="Gifted Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [614]={
        ["Evasion"]=22, 
        ["MND"]=37, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=28, 
        ["id"]=27028, 
        ["AGI"]=5, 
        ["Haste"]=3, 
        ["en"]="Apogee Mitts", 
        ["HP"]=-80, 
        ["discription"]="DEF:83 HP-80 MP+41 STR+6 DEX+28 VIT+25 AGI+5 INT+23 MND+37 CHR+23 Evasion+22 Magic Evasion+48 \"Magic Def. Bonus\"+4 Haste+3% Avatar: HP+80 Accuracy+28 Magic Accuracy+28", 
        ["VIT"]=25, 
        ["DEF"]=83, 
        ["MP"]=101, 
        ["augments"]={
            [1]="MP+60", 
            [2]="Pet: \"Mag.Atk.Bns.\"+30", 
            [3]="Blood Pact Dmg.+7"
        }, 
        ["STR"]=6, 
        ["CHR"]=23, 
        ["INT"]=23, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [615]={
        ["Evasion"]=55, 
        ["MND"]=19, 
        ["Haste"]=3, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=11, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["AGI"]=33, 
        ["en"]="Regal Pumps", 
        ["item_level"]=119, 
        ["HP"]=13, 
        ["discription"]="DEF:65 HP+13 MP+34 STR+10 DEX+11 VIT+10 AGI+33 INT+17 MND+19 CHR+34 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Healing magic skill +10 Enhancing magic skill +10 Haste+3% \"Fast Cast\"+3% Unity Ranking: \"Fast Cast\"+1～3%", 
        ["VIT"]=10, 
        ["STR"]=10, 
        ["DEF"]=65, 
        ["MP"]=34, 
        ["id"]=28273, 
        ["Unity Ranking Bonus Applied"]="Fast Cast + 3", 
        ["CHR"]=34, 
        ["INT"]=17, 
        ["category"]="Armor", 
        ["Fast Cast"]=6
    }, 
    [616]={
        ["discription"]="Accuracy+10 Pet: Accuracy+10 Ranged Accuracy+10 \"Store TP\"+6 Avatar: \"Blood Pact\" damage +4", 
        ["Accuracy"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26180, 
        ["en"]="Varar Ring +1", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [617]={
        ["Evasion"]=55, 
        ["MND"]=23, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=11, 
        ["id"]=27380, 
        ["AGI"]=33, 
        ["Haste"]=3, 
        ["en"]="Apogee Pumps", 
        ["HP"]=-80, 
        ["discription"]="DEF:62 HP-80 MP+41 STR+10 DEX+11 VIT+10 AGI+33 INT+21 MND+23 CHR+38 Evasion+55 Magic Evasion+118 \"Magic Def. Bonus\"+6 Haste+3% Avatar perpetuation cost -8 Avatar: HP+80 \"Blood Pact\" damage +1", 
        ["VIT"]=10, 
        ["DEF"]=62, 
        ["MP"]=101, 
        ["augments"]={
            [1]="MP+60", 
            [2]="Pet: \"Mag.Atk.Bns.\"+30", 
            [3]="Blood Pact Dmg.+7"
        }, 
        ["STR"]=10, 
        ["CHR"]=38, 
        ["INT"]=21, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [618]={
        ["discription"]="MP+25 Summoning magic skill +10 Avatar perpetuation cost -1", 
        ["MP"]=25, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=14625, 
        ["en"]="Evoker's Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [619]={
        ["Attack"]=7, 
        ["en"]="Elan Strap +1", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["discription"]="Magic Attack+7 Avatar: \"Blood Pact\" damage +5", 
        ["id"]=22211, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [620]={
        ["discription"]="DEF:12 HP+88 Damage taken -3% Avatar: Attack+20 \"Magic Atk. Bonus\"+10 Set (avatar only): Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["category"]="Armor", 
        ["en"]="Regal Belt", 
        ["HP"]=88, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEF"]=12, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=26342, 
        ["DT"]=-3
    }, 
    [621]={
        ["Evasion"]=19, 
        ["MND"]=37, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=23, 
        ["id"]=27141, 
        ["AGI"]=2, 
        ["Haste"]=3, 
        ["en"]="Merlinic Dastanas", 
        ["HP"]=9, 
        ["discription"]="DEF:84 HP+9 MP+20 STR+3 DEX+23 VIT+20 AGI+2 INT+26 MND+37 CHR+21 Evasion+19 Magic Evasion+48 \"Magic Def. Bonus\"+3 Haste+3% Avatar: Attack+20 \"Magic Atk. Bonus\"+20 Enmity+5 \"Blood Pact\" damage +5", 
        ["VIT"]=20, 
        ["DEF"]=84, 
        ["MP"]=20, 
        ["augments"]={
            [1]="Pet: \"Mag.Atk.Bns.\"+15", 
            [2]="Blood Pact Dmg.+10", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["STR"]=3, 
        ["CHR"]=21, 
        ["INT"]=26, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [622]={
        ["discription"]="Accuracy+10 Pet: Accuracy+10 Ranged Accuracy+10 \"Store TP\"+6 Avatar: \"Blood Pact\" damage +4", 
        ["Accuracy"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26180, 
        ["en"]="Varar Ring +1", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [623]={
        ["Evasion"]=27, 
        ["MND"]=30, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["Haste"]=5, 
        ["AGI"]=17, 
        ["Fast Cast"]=7, 
        ["discription"]="DEF:101 HP+43 MP+29 STR+25 VIT+12 AGI+17 INT+40 MND+30 CHR+19 Magic Accuracy+20 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Enfeebling magic skill +18 Haste+5% Pet: Damage taken -4%", 
        ["en"]="Psycloth Lappas", 
        ["HP"]=43, 
        ["id"]=27287, 
        ["item_level"]=119, 
        ["STR"]=25, 
        ["DEF"]=101, 
        ["MP"]=109, 
        ["augments"]={
            [1]="MP+80", 
            [2]="Mag. Acc.+15", 
            [3]="\"Fast Cast\"+7"
        }, 
        ["INT"]=40, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["VIT"]=12, 
        ["Magic Accuracy"]=35
    }, 
    [624]={
        ["discription"]="DMG:208 Delay:366 INT+19 MND+19 \"Magic Atk. Bonus\"+38 Magic Damage+217 Staff skill +242 Parrying skill +242 Magic Accuracy skill +228 \"Fast Cast\"+4% Pet: \"Magic Atk. Bonus\"+110", 
        ["augments"]={
            [1]="Pet: Mag. Acc.+20", 
            [2]="Pet: \"Mag.Atk.Bns.\"+20", 
            [3]="Pet: \"Regen\"+2"
        }, 
        ["MND"]=19, 
        ["en"]="Nibiru Staff", 
        ["Staff skill"]=242, 
        ["skill"]="Staff", 
        ["Fast Cast"]=4, 
        ["delay"]=366, 
        ["jobs"]={
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH"
        }, 
        ["Parrying skill"]=242, 
        ["INT"]=19, 
        ["slots"]={
            [0]="Main"
        }, 
        ["id"]=21156, 
        ["category"]="Weapon", 
        ["damage"]=208, 
        ["Magic Atk. Bonus"]=38, 
        ["item_level"]=119
    }, 
    [625]={
        ["Evasion"]=27, 
        ["MND"]=28, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["id"]=27204, 
        ["AGI"]=17, 
        ["Haste"]=5, 
        ["en"]="Apogee Slacks", 
        ["HP"]=-100, 
        ["discription"]="DEF:103 HP-100 MP+56 STR+25 VIT+12 AGI+17 INT+38 MND+28 CHR+23 Evasion+27 Magic Evasion+118 \"Magic Def. Bonus\"+6 Haste+5% Avatar: HP+100 Enmity+5 \"Blood Pact\" damage +6", 
        ["VIT"]=12, 
        ["DEF"]=103, 
        ["MP"]=56, 
        ["augments"]={
            [1]="Pet: STR+15", 
            [2]="Blood Pact Dmg.+13", 
            [3]="Pet: \"Dbl. Atk.\"+3"
        }, 
        ["STR"]=25, 
        ["CHR"]=23, 
        ["INT"]=38, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [626]={
        ["discription"]="MP+30 Magic Accuracy+5 \"Fast Cast\"+2%", 
        ["category"]="Armor", 
        ["en"]="Rahab Ring", 
        ["Fast Cast"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26162, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=30, 
        ["Magic Accuracy"]=5
    }, 
    [627]={
        ["Evasion"]=19, 
        ["STR"]=16, 
        ["jobs"]={
            [9]="BST", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["DEX"]=50, 
        ["Haste"]=5, 
        ["MND"]=26, 
        ["id"]=25834, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["CHR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["CHR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["CHR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["CHR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }, 
            ["set id"]=154
        }, 
        ["AGI"]=11, 
        ["en"]="Tali'ah Gages +2", 
        ["HP"]=27, 
        ["Critical hit rate"]=8, 
        ["item_level"]=119, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=88, 
        ["MP"]=20, 
        ["Accuracy"]=43, 
        ["INT"]=14, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["discription"]="DEF:88 HP+27 MP+20 STR+16 DEX+50 VIT+44 AGI+11 INT+14 MND+26 CHR+19 Accuracy+43 Magic Accuracy+43 Evasion+19 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+5% Critical hit rate +8% Pet: Accuracy+43 Ranged Accuracy+43 Magic Accuracy+43 Set: Increases Dexterity, Vitality, and Charisma", 
        ["VIT"]=44, 
        ["Magic Accuracy"]=43
    }, 
    [628]={
        ["Evasion"]=36, 
        ["MND"]=32, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=14, 
        ["id"]=26676, 
        ["AGI"]=14, 
        ["Haste"]=6, 
        ["en"]="Apogee Crown", 
        ["HP"]=-100, 
        ["discription"]="DEF:94 HP-100 MP+59 STR+14 DEX+14 VIT+14 AGI+14 INT+32 MND+32 CHR+32 Evasion+36 Magic Evasion+86 \"Magic Def. Bonus\"+6 Haste+6% Avatar: HP+100 Accuracy+25 Enmity+9", 
        ["VIT"]=14, 
        ["DEF"]=94, 
        ["MP"]=119, 
        ["augments"]={
            [1]="MP+60", 
            [2]="Pet: \"Mag.Atk.Bns.\"+30", 
            [3]="Blood Pact Dmg.+7"
        }, 
        ["STR"]=14, 
        ["CHR"]=32, 
        ["INT"]=32, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [629]={
        ["Evasion"]=60, 
        ["MND"]=11, 
        ["DEF"]=70, 
        ["jobs"]={
            [9]="BST", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["DEX"]=35, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["AGI"]=46, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["CHR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["CHR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["CHR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["CHR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }, 
            ["set id"]=154
        }, 
        ["en"]="Tali'ah Crackows +2", 
        ["HP"]=15, 
        ["discription"]="DEF:70 HP+15 MP+20 STR+16 DEX+35 VIT+23 AGI+46 MND+11 CHR+26 Accuracy+42 Magic Accuracy+42 Evasion+60 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+4% Pet: Accuracy+42 Ranged Accuracy+42 Magic Accuracy+42 Haste+7% Set: Increases Dexterity, Vitality, and Charisma", 
        ["Accuracy"]=42, 
        ["STR"]=16, 
        ["Haste"]=4, 
        ["MP"]=20, 
        ["id"]=25952, 
        ["CHR"]=26, 
        ["VIT"]=23, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["Magic Accuracy"]=42
    }, 
    [630]={
        ["discription"]="Evasion+3 Enmity-5 Pet: Enmity+5 \"Double Attack\"+3%", 
        ["en"]="Domes. Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28505, 
        ["Evasion"]=3, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [631]={
        ["Evasion"]=44, 
        ["MND"]=29, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=19, 
        ["DEF"]=123, 
        ["AGI"]=20, 
        ["en"]="Beck. Doublet +1", 
        ["discription"]="DEF:123 HP+54 MP+151 STR+23 DEX+19 VIT+23 AGI+20 INT+29 MND+29 CHR+29 Evasion+44 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+3% Summoning magic skill +14 Avatar perpetuation cost -6 Avatar: \"Blood Pact\" damage +11 Set: Augments \"Blood Boon\"", 
        ["HP"]=54, 
        ["item_level"]=119, 
        ["VIT"]=23, 
        ["Haste"]=3, 
        ["MP"]=151, 
        ["id"]=26927, 
        ["STR"]=23, 
        ["CHR"]=29, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=365
        }
    }, 
    [632]={
        ["MDT"]=-3, 
        ["MND"]=33, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [10]="BRD", 
            [15]="SMN"
        }, 
        ["DEX"]=6, 
        ["discription"]="DEF:70 HP+25 MP+30 STR+6 DEX+6 VIT+14 AGI+33 INT+32 MND+33 CHR+46 Evasion+60 Magic Evasion+147 \"Magic Def. Bonus\"+8 Haste+2% Magic damage taken -3% Avatar: \"Blood Pact\" damage +9 Set: Enhances \"Refresh\" effect", 
        ["AGI"]=33, 
        ["DEF"]=70, 
        ["en"]="Inyan. Crackows +2", 
        ["HP"]=25, 
        ["item_level"]=119, 
        ["VIT"]=14, 
        ["Haste"]=2, 
        ["MP"]=30, 
        ["Evasion"]=60, 
        ["id"]=25949, 
        ["STR"]=6, 
        ["CHR"]=46, 
        ["INT"]=32, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Refresh"]=1
                }, 
                [3]={
                    ["Refresh"]=2
                }, 
                [4]={
                    ["Refresh"]=3
                }, 
                [5]={
                    ["Refresh"]=4
                }
            }, 
            ["set id"]=16
        }
    }, 
    [633]={
        ["Evasion"]=24, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [9]="BST", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["DEX"]=11, 
        ["Haste"]=6, 
        ["MND"]=15, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["CHR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["CHR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["CHR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["CHR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }, 
            ["set id"]=154
        }, 
        ["item_level"]=119, 
        ["AGI"]=34, 
        ["en"]="Tali'ah Sera. +2", 
        ["HP"]=57, 
        ["id"]=25885, 
        ["discription"]="DEF:110 HP+57 MP+53 STR+33 DEX+11 VIT+30 AGI+34 INT+29 MND+15 CHR+10 Accuracy+45 Magic Accuracy+45 Evasion+24 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+6% Pet: Accuracy+45 Ranged Accuracy+45 Magic Accuracy+45 Damage taken -5% Set: Increases Dexterity, Vitality, and Charisma", 
        ["STR"]=33, 
        ["DEF"]=110, 
        ["MP"]=53, 
        ["Accuracy"]=45, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["CHR"]=10, 
        ["VIT"]=30, 
        ["Magic Accuracy"]=45
    }, 
    [634]={
        ["Evasion"]=22, 
        ["MND"]=33, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=28, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Lamassu Mitts +1", 
        ["DEF"]=82, 
        ["discription"]="DEF:82 HP+18 MP+44 STR+6 DEX+28 VIT+24 AGI+5 INT+19 MND+33 CHR+20 Evasion+22 Magic Evasion+43 \"Magic Def. Bonus\"+3 Haste+3% Summoning magic skill +22 Cait Sith: Lv.+1 Avatar: Magic Accuracy+26 Unity Ranking: MP+10～50", 
        ["HP"]=18, 
        ["id"]=27109, 
        ["category"]="Armor", 
        ["Haste"]=3, 
        ["MP"]=94, 
        ["VIT"]=24, 
        ["STR"]=6, 
        ["INT"]=19, 
        ["Unity Ranking Bonus Applied"]="MP + 50", 
        ["CHR"]=20, 
        ["AGI"]=5
    }, 
    [635]={
        ["Evasion"]=22, 
        ["MND"]=33, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=28, 
        ["DEF"]=82, 
        ["AGI"]=5, 
        ["en"]="Beck. Bracers +1", 
        ["discription"]="DEF:82 HP+18 MP+94 STR+6 DEX+28 VIT+24 AGI+5 INT+19 MND+33 CHR+20 Evasion+22 Magic Evasion+43 \"Magic Def. Bonus\"+3 Haste+3% \"Mana Cede\"+120 Depending on day or weather: Halves avatar perpetuation cost Avatar: Accuracy+30  Set: Augments \"Blood Boon\"", 
        ["HP"]=18, 
        ["item_level"]=119, 
        ["VIT"]=24, 
        ["Haste"]=3, 
        ["MP"]=94, 
        ["id"]=27081, 
        ["STR"]=6, 
        ["CHR"]=20, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=365
        }
    }, 
    [636]={
        ["discription"]="MP+35 Avatar: \"Blood Pact\" damage +5", 
        ["MP"]=35, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=27528, 
        ["en"]="Gelos Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [637]={
        ["DEF"]=8, 
        ["en"]="Witful Belt", 
        ["Haste"]=3, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:8  Enhances \"Fast Cast\" effect Haste+3% Occ. quickens spellcasting +3%", 
        ["id"]=10826, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [638]={
        ["Evasion"]=45, 
        ["MND"]=34, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=24, 
        ["Haste"]=3, 
        ["AGI"]=25, 
        ["en"]="Baayami Robe", 
        ["item_level"]=119, 
        ["HP"]=68, 
        ["discription"]="DEF:132 HP+68 MP+103 STR+23 DEX+24 VIT+34 AGI+25 INT+42 MND+34 CHR+30 Evasion+45 Magic Evasion+112 \"Magic Def. Bonus\"+8 Summoning magic skill +32 Haste+3% \"Fast Cast\"+11% Summoning magic interruption rate down 100%", 
        ["VIT"]=34, 
        ["DEF"]=132, 
        ["MP"]=103, 
        ["id"]=26541, 
        ["STR"]=23, 
        ["CHR"]=30, 
        ["INT"]=42, 
        ["category"]="Armor", 
        ["Fast Cast"]=11
    }, 
    [639]={
        ["discription"]="MP+50 Avatar perpetuation cost -2 \"Blood Pact\" ability delay -2", 
        ["MP"]=50, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=27534, 
        ["en"]="Evans Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [640]={
        ["Evasion"]=37, 
        ["MND"]=29, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Convo. Spats +2", 
        ["DEF"]=114, 
        ["discription"]="DEF:114 HP+57 MP+99 STR+30 VIT+16 AGI+22 INT+39 MND+29 CHR+24 Accuracy+39 Evasion+37 Magic Evasion+117 \"Magic Def. Bonus\"+6 Haste+5% Enmity-7 Avatar: Accuracy+40 Magic Accuracy+40 Enmity+8 \"Store TP\"+5 Set (Avatar): Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["HP"]=57, 
        ["id"]=23255, 
        ["VIT"]=16, 
        ["Haste"]=5, 
        ["MP"]=99, 
        ["Accuracy"]=39, 
        ["STR"]=30, 
        ["CHR"]=24, 
        ["INT"]=39, 
        ["category"]="Armor", 
        ["AGI"]=22
    }, 
    [641]={
        ["Evasion"]=36, 
        ["MND"]=19, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=14, 
        ["id"]=26653, 
        ["AGI"]=14, 
        ["Haste"]=6, 
        ["en"]="Glyphic Horn +1", 
        ["HP"]=31, 
        ["discription"]="DEF:93 HP+31 MP+95 STR+12 DEX+14 VIT+14 AGI+14 INT+19 MND+19 CHR+19 Evasion+36 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% \"Blood Pact\" ability delay -8 Avatar perpetuation cost -4 Avatar: \"Magic Atk. Bonus\"+23", 
        ["VIT"]=14, 
        ["DEF"]=93, 
        ["MP"]=95, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Astral Flow\" effect", 
            [4]="none"
        }, 
        ["STR"]=12, 
        ["CHR"]=19, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [642]={
        ["Evasion"]=65, 
        ["MND"]=24, 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=16, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Convo. Pigaches +2", 
        ["DEF"]=72, 
        ["discription"]="DEF:72 HP+13 MP+61 STR+15 DEX+16 VIT+15 AGI+37 INT+22 MND+24 CHR+39 Accuracy+36 Evasion+65 Magic Evasion+117 \"Magic Def. Bonus\"+5 Haste+3% Avatar perpetuation cost -5 Avatar: Accuracy+30 Magic Accuracy+30 Evasion+30 \"Blood Pact\" damage +8 Set (Avatar): Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["HP"]=13, 
        ["id"]=23322, 
        ["VIT"]=15, 
        ["Haste"]=3, 
        ["MP"]=61, 
        ["Accuracy"]=36, 
        ["STR"]=15, 
        ["CHR"]=39, 
        ["INT"]=22, 
        ["category"]="Armor", 
        ["AGI"]=37
    }, 
    [643]={
        ["discription"]="CHR+4 Pet: Haste+3% Enmity+5 Damage taken -1%", 
        ["en"]="Rimeice Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=28495, 
        ["CHR"]=4, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [644]={
        ["Evasion"]=27, 
        ["MND"]=24, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["id"]=27181, 
        ["AGI"]=17, 
        ["Haste"]=5, 
        ["en"]="Glyphic Spats +1", 
        ["HP"]=38, 
        ["discription"]="DEF:103 HP+38 MP+85 STR+25 VIT+11 AGI+17 INT+34 MND+24 CHR+19 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% Shortens magic recast time for spirits \"Blood Pact\" ability delay -6 Avatar: Magic Accuracy+13", 
        ["VIT"]=11, 
        ["DEF"]=103, 
        ["MP"]=85, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Increases Sp. \"Blood Pact\" accuracy", 
            [4]="none"
        }, 
        ["STR"]=25, 
        ["CHR"]=19, 
        ["INT"]=34, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [645]={
        ["Evasion"]=55, 
        ["MND"]=19, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=11, 
        ["id"]=27357, 
        ["AGI"]=32, 
        ["Haste"]=3, 
        ["en"]="Glyph. Pigaches +1", 
        ["HP"]=9, 
        ["discription"]="DEF:60 HP+9 MP+75 STR+10 DEX+11 VIT+10 AGI+32 INT+17 MND+19 CHR+34 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+3% \"Blood Pact\" ability delay II -1 Avatar: Attack+28 Magic critical hit rate +9%", 
        ["VIT"]=10, 
        ["DEF"]=60, 
        ["MP"]=75, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Inc. Sp. \"Blood Pact\" magic crit. dmg.", 
            [4]="none"
        }, 
        ["STR"]=10, 
        ["CHR"]=34, 
        ["INT"]=17, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [646]={
        ["discription"]="DEF:13 MP+100 Summoning magic skill +8 Enhances \"Elemental Siphon\" effect", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["category"]="Armor", 
        ["en"]="Conveyance Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=28631, 
        ["DEF"]=13, 
        ["MP"]=100, 
        ["augments"]={
            [1]="Summoning magic skill +5", 
            [2]="Pet: Enmity+8", 
            [3]="Blood Pact Dmg.+2", 
            [4]="Blood Pact ab. del. II -1", 
            [5]="none"
        }
    }, 
    [647]={
        ["Evasion"]=33, 
        ["STR"]=10, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=10, 
        ["Haste"]=6, 
        ["MND"]=20, 
        ["id"]=25615, 
        ["discription"]="DEF:95 HP+27 MP+61 STR+10 DEX+10 VIT+10 AGI+1 INT+24 MND+20 CHR+19 Magic Accuracy+26 Evasion+33 Magic Evasion+86 \"Magic Def. Bonus\"+6 Haste+6% \"Fast Cast\"+10% \"Refresh\" potency +1 \"Aquaveil\"+1", 
        ["AGI"]=1, 
        ["Fast Cast"]=10, 
        ["HP"]=27, 
        ["augments"]={
            [1]="MP+60", 
            [2]="Mag. Acc.+15", 
            [3]="\"Mag.Atk.Bns.\"+15"
        }, 
        ["item_level"]=119, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=95, 
        ["MP"]=121, 
        ["en"]="Amalric Coif", 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["VIT"]=10, 
        ["Magic Atk. Bonus"]=15, 
        ["Magic Accuracy"]=41
    }, 
    [648]={
        ["Evasion"]=66, 
        ["MND"]=30, 
        ["discription"]="DEF:82 HP+30 MP+49 STR+12 DEX+14 VIT+29 AGI+37 MND+30 CHR+35 Evasion+66 Magic Evasion+139 \"Magic Def. Bonus\"+6 Summoning magic skill +29 Haste+3% \"Refresh\"+3 Avatar: \"Regen\"+5", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Baaya. Sabots +1", 
        ["DEF"]=82, 
        ["AGI"]=37, 
        ["HP"]=30, 
        ["DEX"]=14, 
        ["VIT"]=29, 
        ["Haste"]=3, 
        ["MP"]=49, 
        ["id"]=25973, 
        ["STR"]=12, 
        ["category"]="Armor", 
        ["CHR"]=35, 
        ["item_level"]=119
    }, 
    [649]={
        ["discription"]="Pet: Accuracy+15 Ranged Accuracy+15 Magic Accuracy+15 \"Double Attack\"+3% Damage taken +10% Avatar: \"Blood Pact\" damage +1", 
        ["id"]=26078, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Kyrene's Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [650]={
        ["discription"]="DMG:251 Delay:402 Accuracy+30 Magic Damage+279 Staff skill +269 Parrying skill +269 Magic Accuracy skill +269 Avatar perpetuation cost -8 Avatar: Lv.+2 \"Blood Pact\" damage +40 \"Garland of Bliss\" Aftermath (including avatar): Increases Accuracy and Attack Occasionally attacks twice or thrice Afterglow", 
        ["category"]="Weapon", 
        ["Parrying skill"]=269, 
        ["item_level"]=119, 
        ["Staff skill"]=269, 
        ["delay"]=402, 
        ["skill"]="Staff", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["Accuracy"]=30, 
        ["en"]="Nirvana", 
        ["id"]=22063, 
        ["slots"]={
            [0]="Main"
        }, 
        ["damage"]=251
    }, 
    [651]={
        ["Evasion"]=27, 
        ["MND"]=38, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=30, 
        ["discription"]="DEF:90 HP+6 MP+35 STR+7 DEX+30 VIT+37 INT+30 MND+38 CHR+20 Evasion+27 Magic Evasion+83 \"Magic Def. Bonus\"+4 Summoning magic skill +28 Haste+3% \"Blood Pact\" ability delay -6 Avatar: \"Regen\"+5", 
        ["en"]="Baayami Cuffs", 
        ["STR"]=7, 
        ["DEF"]=90, 
        ["HP"]=6, 
        ["id"]=25992, 
        ["category"]="Armor", 
        ["Haste"]=3, 
        ["MP"]=35, 
        ["VIT"]=37, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["CHR"]=20, 
        ["INT"]=30, 
        ["item_level"]=119
    }, 
    [652]={
        ["discription"]="DEF:8 HP+25 Damage taken -4% Pet: Magic Accuracy+20 \"Magic Atk. Bonus\"+10", 
        ["category"]="Armor", 
        ["en"]="Adad Amulet", 
        ["HP"]=25, 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=26028, 
        ["DT"]=-4
    }, 
    [653]={
        ["Evasion"]=60, 
        ["Haste"]=3, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=6, 
        ["en"]="Merlinic Crackows", 
        ["MND"]=23, 
        ["id"]=27497, 
        ["STR"]=6, 
        ["AGI"]=26, 
        ["Fast Cast"]=5, 
        ["HP"]=4, 
        ["augments"]={
            [1]="Pet: \"Mag.Atk.Bns.\"+12", 
            [2]="Blood Pact Dmg.+10", 
            [3]="Pet: STR+5", 
            [4]="none", 
            [5]="none"
        }, 
        ["VIT"]=6, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=67, 
        ["MP"]=20, 
        ["discription"]="DEF:67 HP+4 MP+20 STR+6 DEX+6 VIT+6 AGI+26 INT+24 MND+23 CHR+35 Evasion+60 Magic Evasion+118 \"Magic Atk. Bonus\"+15 \"Magic Def. Bonus\"+6 Haste+3% \"Fast Cast\"+5% \"Conserve MP\"+4 \"Drain\" and \"Aspir\" potency +7", 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["CHR"]=35, 
        ["Magic Atk. Bonus"]=15, 
        ["item_level"]=119
    }, 
    [654]={
        ["Evasion"]=37, 
        ["MND"]=29, 
        ["discription"]="DEF:114 HP+61 MP+53 STR+26 VIT+24 AGI+23 INT+47 MND+29 CHR+20 Evasion+37 Magic Evasion+129 \"Magic Def. Bonus\"+7 Summoning magic skill +30 Haste+5% \"Blood Pact\" ability delay -7 Avatar: \"Regen\"+6", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Baayami Slops", 
        ["DEF"]=114, 
        ["AGI"]=23, 
        ["HP"]=61, 
        ["id"]=25905, 
        ["category"]="Armor", 
        ["Haste"]=5, 
        ["MP"]=53, 
        ["VIT"]=24, 
        ["STR"]=26, 
        ["CHR"]=20, 
        ["INT"]=47, 
        ["item_level"]=119
    }, 
    [655]={
        ["Evasion"]=55, 
        ["MND"]=19, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=11, 
        ["DEF"]=61, 
        ["AGI"]=30, 
        ["en"]="Beck. Pigaches +1", 
        ["discription"]="DEF:61 HP+9 MP+97 STR+11 DEX+11 VIT+11 AGI+30 INT+19 MND+19 CHR+35 Evasion+55 Magic Evasion+118 \"Magic Def. Bonus\"+6 Haste+3% \"Elemental Siphon\"+60 Avatar perpetuation cost -7 Avatar: Magic Accuracy+27 Set: Augments \"Blood Boon\"", 
        ["HP"]=9, 
        ["item_level"]=119, 
        ["VIT"]=11, 
        ["Haste"]=3, 
        ["MP"]=97, 
        ["id"]=27440, 
        ["STR"]=11, 
        ["CHR"]=35, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=365
        }
    }, 
    [656]={
        ["discription"]="DEF:15 Avatar: Lv.+1 \"Blood Pact\" damage +5", 
        ["category"]="Armor", 
        ["en"]="Campestres's Cape", 
        ["Fast Cast"]=10, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEF"]=15, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=26260, 
        ["augments"]={
            [1]="Pet: M.Acc.+20 Pet: M.Dmg.+20", 
            [2]="none", 
            [3]="Pet: Magic Damage+10", 
            [4]="\"Fast Cast\"+10", 
            [5]="none"
        }
    }, 
    [657]={
        ["discription"]="DEF:15 Pet: Accuracy+15 Ranged Accuracy+15 Magic Accuracy+15 \"Double Attack\"+4%", 
        ["DEF"]=15, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Incarnation Sash", 
        ["id"]=28418, 
        ["category"]="Armor", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }
    }, 
    [658]={
        ["Evasion"]=36, 
        ["MND"]=20, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["DEX"]=15, 
        ["DEF"]=93, 
        ["AGI"]=15, 
        ["en"]="Beckoner's Horn +1", 
        ["discription"]="DEF:93 HP+31 MP+134 STR+14 DEX+15 VIT+15 AGI+15 INT+20 MND+20 CHR+20 Evasion+36 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+6% Summoning magic skill +13 \"Avatar's Favor\"+3 \"Refresh\"+2 Set: Augments \"Blood Boon\"", 
        ["HP"]=31, 
        ["item_level"]=119, 
        ["VIT"]=15, 
        ["Haste"]=6, 
        ["MP"]=134, 
        ["id"]=26769, 
        ["STR"]=14, 
        ["CHR"]=20, 
        ["INT"]=20, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=365
        }
    }, 
    [659]={
        ["discription"]="Potency of \"Cure\" effect received +10% Potency of \"Cursna\" effects received +10 Duration of Refresh effects received +20", 
        ["id"]=26323, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Gishdubar Sash", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [660]={
        ["discription"]="Magic skills +10 MP not depleted when magic used +1%", 
        ["en"]="Incanter's Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Magic skills"]=10, 
        ["id"]=26016, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [661]={
        ["discription"]="MND+7 Magic Accuracy+15 Enfeebling magic effect +10", 
        ["category"]="Weapon", 
        ["en"]="Regal Gem", 
        ["skill"]="(N/A)", 
        ["MND"]=7, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["id"]=21396, 
        ["Magic Accuracy"]=15
    }, 
    [662]={
        ["discription"]="DMG:127 Delay:240 STR+15 Attack+23 \"Magic Atk. Bonus\"+34 Magic Damage+108 Magic Accuracy skill +201 Sword skill +242 Parrying skill +242 \"Fast Cast\"+7% Additional effect: HP, MP, or TP Drain", 
        ["id"]=20706, 
        ["Magic Atk. Bonus"]=34, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["STR"]=21, 
        ["item_level"]=119, 
        ["en"]="Vampirism", 
        ["Fast Cast"]=7, 
        ["delay"]=240, 
        ["skill"]="Sword", 
        ["Parrying skill"]=242, 
        ["INT"]=5, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["augments"]={
            [1]="STR+6", 
            [2]="INT+5", 
            [3]="\"Occult Acumen\"+6", 
            [4]="DMG:+10", 
            [5]="none"
        }, 
        ["category"]="Weapon", 
        ["damage"]=137, 
        ["Sword skill"]=242, 
        ["Attack"]=23
    }, 
    [663]={
        ["Evasion"]=41, 
        ["MND"]=21, 
        ["Haste"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG"
        }, 
        ["DEX"]=21, 
        ["slots"]={
            [5]="Body"
        }, 
        ["item_level"]=119, 
        ["discription"]="DEF:144 HP+61 MP+44 STR+26 DEX+21 VIT+26 AGI+21 INT+21 MND+21 CHR+21 Attack+40 Evasion+41 Magic Evasion+53 \"Magic Def. Bonus\"+4 Haste+3% Enmity+6 \"Double Attack\"+3% Critical hit rate +3%", 
        ["en"]="Vatic Byrnie", 
        ["HP"]=61, 
        ["id"]=25729, 
        ["AGI"]=21, 
        ["STR"]=26, 
        ["DEF"]=144, 
        ["MP"]=44, 
        ["Critical hit rate"]=3, 
        ["INT"]=21, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["VIT"]=26, 
        ["Attack"]=40
    }, 
    [664]={
        ["Magic Accuracy"]=5, 
        ["Ranged Accuracy"]=20, 
        ["Throwing skill"]=242, 
        ["Ranged Attack"]=20, 
        ["category"]="Weapon", 
        ["delay"]=240, 
        ["item_level"]=119, 
        ["HP"]=15, 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["skill"]="Throwing", 
        ["discription"]="DMG:66 Delay:240 HP+15 MP+15 Ranged Accuracy+20 Ranged Attack+20 Magic Accuracy+5 Throwing skill +242", 
        ["slots"]={
            [2]="Range"
        }, 
        ["en"]="Albin Bane", 
        ["id"]=21390, 
        ["MP"]=15, 
        ["damage"]=66
    }, 
    [665]={
        ["discription"]="DEF:9 STR+5 DEX+5 Accuracy+10 Attack+20 \"Double Attack\"+2%", 
        ["category"]="Armor", 
        ["en"]="Grunfeld Rope", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["DEX"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=9, 
        ["STR"]=5, 
        ["Accuracy"]=10, 
        ["id"]=28408, 
        ["Attack"]=20
    }, 
    [666]={
        ["MDT"]=-5, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=8, 
        ["item_level"]=119, 
        ["MND"]=12, 
        ["discription"]="DEF:111 HP+41 MP+29 STR+24 DEX+8 VIT+19 AGI+14 INT+16 MND+12 CHR+14 Accuracy+23 Ranged Accuracy+23 \"Magic Atk. Bonus\"+15 Magic Damage+15 Evasion+36 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+7% Magic damage taken -5%", 
        ["Ranged Accuracy"]=23, 
        ["Haste"]=7, 
        ["en"]="Terminal Helm", 
        ["HP"]=41, 
        ["id"]=25634, 
        ["VIT"]=19, 
        ["DEF"]=111, 
        ["MP"]=29, 
        ["Evasion"]=36, 
        ["Accuracy"]=23, 
        ["STR"]=24, 
        ["CHR"]=14, 
        ["INT"]=16, 
        ["Magic Atk. Bonus"]=15, 
        ["category"]="Armor", 
        ["AGI"]=14
    }, 
    [667]={
        ["discription"]="Accuracy+20 Magic Accuracy+20 \"Triple Attack\" damage +4", 
        ["category"]="Armor", 
        ["en"]="Asn. Gorget +1", 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["id"]=25448, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=20, 
        ["Magic Accuracy"]=20
    }, 
    [668]={
        ["Evasion"]=44, 
        ["STR"]=32, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=16, 
        ["Haste"]=3, 
        ["MND"]=20, 
        ["en"]="Terminal Plate", 
        ["Ranged Attack"]=25, 
        ["AGI"]=19, 
        ["item_level"]=119, 
        ["HP"]=63, 
        ["id"]=25707, 
        ["discription"]="DEF:143 HP+63 MP+59 STR+32 DEX+16 VIT+29 AGI+19 INT+20 MND+20 CHR+20 Attack+25 Ranged Attack+25 \"Magic Atk. Bonus\"+20 Magic Damage+15 Evasion+44 Magic Evasion+53 \"Magic Def. Bonus\"+4 Haste+3% Physical damage taken -5%", 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=143, 
        ["MP"]=59, 
        ["VIT"]=29, 
        ["INT"]=20, 
        ["category"]="Armor", 
        ["CHR"]=20, 
        ["PDT"]=-5, 
        ["Magic Atk. Bonus"]=20, 
        ["Attack"]=25
    }, 
    [669]={
        ["Evasion"]=36, 
        ["Haste"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=17, 
        ["VIT"]=32, 
        ["MND"]=16, 
        ["discription"]="DEF:153 HP+166 MP+59 STR+29 DEX+17 VIT+32 AGI+17 INT+16 MND+16 CHR+16 Accuracy+25 Attack+25 Evasion+36 Magic Evasion+69 \"Magic Def. Bonus\"+4 Haste+3% Physical damage taken -10% Sphere: \"Double Attack\"+4%", 
        ["STR"]=29, 
        ["AGI"]=17, 
        ["en"]="Kubira Meikogai", 
        ["HP"]=166, 
        ["id"]=26959, 
        ["item_level"]=119, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=153, 
        ["MP"]=59, 
        ["Accuracy"]=25, 
        ["INT"]=16, 
        ["category"]="Armor", 
        ["CHR"]=16, 
        ["PDT"]=-10, 
        ["Attack"]=25
    }, 
    [670]={
        ["Evasion"]=16, 
        ["STR"]=23, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["Haste"]=3, 
        ["MND"]=32, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }, 
            ["set id"]=161
        }, 
        ["discription"]="DEF:111 HP+30 MP+30 STR+23 DEX+34 VIT+45 INT+6 MND+32 CHR+27 Accuracy+43 Attack+47 Evasion+16 Magic Evasion+37 Haste+3% \"Double Attack\"+6% Damage taken -5% Set: Enhances \"Subtle Blow\" effect", 
        ["en"]="Sulev. Gauntlets +2", 
        ["item_level"]=119, 
        ["HP"]=30, 
        ["id"]=25828, 
        ["Attack"]=47, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=111, 
        ["MP"]=30, 
        ["Accuracy"]=43, 
        ["INT"]=6, 
        ["category"]="Armor", 
        ["CHR"]=27, 
        ["VIT"]=45, 
        ["DT"]=-5
    }, 
    [671]={
        ["discription"]="DEF:18 Attack-4 Evasion+4 Movement speed +18%", 
        ["category"]="Armor", 
        ["en"]="Fajin Boots", 
        ["Evasion"]=4, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG"
        }, 
        ["DEF"]=18, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=11460, 
        ["Attack"]=-4
    }, 
    [672]={
        ["discription"]="DEF:6 Accuracy+20 Attack+20 \"Double Attack\"+3% Pet: Accuracy+20 Attack+20 \"Double Attack\"+5%", 
        ["jobs"]={
            [9]="BST", 
            [14]="DRG", 
            [15]="SMN", 
            [18]="PUP"
        }, 
        ["category"]="Armor", 
        ["en"]="Shulmanu Collar", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=26026, 
        ["DEF"]=6, 
        ["Accuracy"]=20, 
        ["Attack"]=20
    }, 
    [673]={
        ["discription"]="DEF:13 \"Cure\" potency +6% Magic Damage+6 Sword enhancement spell damage +5", 
        ["category"]="Armor", 
        ["en"]="Ghostfyre Cape", 
        ["id"]=28621, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["DEF"]=13, 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="Enfb.mag. skill +8", 
            [2]="Enha.mag. skill +8", 
            [3]="Mag. Acc.+8", 
            [4]="none", 
            [5]="none"
        }, 
        ["Magic Accuracy"]=8
    }, 
    [674]={
        ["Evasion"]=16, 
        ["MND"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=2, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }, 
            ["set id"]=161
        }, 
        ["AGI"]=14, 
        ["en"]="Sulev. Cuisses +2", 
        ["discription"]="DEF:135 HP+50 MP+50 STR+47 VIT+33 AGI+14 INT+24 MND+20 CHR+18 Accuracy+45 Attack+49 Evasion+16 Magic Evasion+75 \"Magic Def. Bonus\"+2 Haste+2% \"Triple Attack\"+4% Damage taken -7% Set: Enhances \"Subtle Blow\" effect", 
        ["item_level"]=119, 
        ["HP"]=50, 
        ["id"]=25879, 
        ["Attack"]=49, 
        ["STR"]=47, 
        ["DEF"]=135, 
        ["MP"]=50, 
        ["Accuracy"]=45, 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["CHR"]=18, 
        ["VIT"]=33, 
        ["DT"]=-7
    }, 
    [675]={
        ["discription"]="DMG:65 Delay:286 AGI+6 +20 Throwing skill +242 Critical hit rate +2% Unity Ranking: DEX+1～5", 
        ["en"]="Wingcutter +1", 
        ["Throwing skill"]=242, 
        ["category"]="Weapon", 
        ["slots"]={
            [2]="Range"
        }, 
        ["item_level"]=119, 
        ["delay"]=286, 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN"
        }, 
        ["skill"]="Throwing", 
        ["AGI"]=6, 
        ["Unity Ranking Bonus Applied"]="DEX + 5", 
        ["Critical hit rate"]=2, 
        ["DEX"]=5, 
        ["id"]=21350, 
        ["damage"]=65
    }, 
    [676]={
        ["Evasion"]=44, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEX"]=19, 
        ["Haste"]=1, 
        ["MND"]=18, 
        ["item_level"]=119, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }, 
            ["set id"]=161
        }, 
        ["AGI"]=26, 
        ["en"]="Sulev. Leggings +2", 
        ["HP"]=20, 
        ["id"]=25946, 
        ["discription"]="DEF:93 HP+20 MP+20 STR+29 DEX+19 VIT+29 AGI+26 MND+18 CHR+32 Accuracy+42 Attack+46 Evasion+44 Magic Evasion+75 \"Magic Def. Bonus\"+1 Haste+1% Weapon skill damage +7% Damage taken -4% Set: Enhances \"Subtle Blow\" effect", 
        ["STR"]=29, 
        ["DEF"]=93, 
        ["MP"]=20, 
        ["Accuracy"]=42, 
        ["CHR"]=32, 
        ["VIT"]=29, 
        ["category"]="Armor", 
        ["Attack"]=46, 
        ["DT"]=-4
    }, 
    [677]={
        ["Evasion"]=72, 
        ["MND"]=12, 
        ["en"]="Pill. Poulaines +1", 
        ["jobs"]={
            [6]="THF"
        }, 
        ["Ranged Accuracy"]=13, 
        ["AGI"]=37, 
        ["DEF"]=71, 
        ["STR"]=12, 
        ["HP"]=13, 
        ["DEX"]=24, 
        ["id"]=28249, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=4, 
        ["item_level"]=119, 
        ["CHR"]=30, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["Accuracy"]=13, 
        ["discription"]="DEF:71 HP+13 STR+12 DEX+24 VIT+12 AGI+37 MND+12 CHR+30 Accuracy+13 Ranged Accuracy+13 Evasion+72 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+4% \"Steal\"+3 \"Flee\" duration +16 Movement speed +12%"
    }, 
    [678]={
        ["discription"]="DMG:128 Delay:240 Accuracy+10 Attack+10 \"Magic Atk. Bonus\"+14 Magic Damage+108 Sword skill +242 Parrying skill +242 Blue Magic skill +15 Magic Accuracy skill +201 \"Chain Affinity\"+25 Blue magic spellcasting time -7%", 
        ["augments"]={
            [1]="Blue Magic skill +15", 
            [2]="Mag. Acc.+15", 
            [3]="\"Mag.Atk.Bns.\"+15"
        }, 
        ["Magic Atk. Bonus"]=29, 
        ["Blue Magic skill"]=30, 
        ["skill"]="Sword", 
        ["item_level"]=119, 
        ["en"]="Iris", 
        ["jobs"]={
            [16]="BLU"
        }, 
        ["delay"]=240, 
        ["Magic Accuracy"]=15, 
        ["Accuracy"]=10, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=20701, 
        ["Sword skill"]=242, 
        ["Parrying skill"]=242, 
        ["damage"]=128, 
        ["Attack"]=10
    }, 
    [679]={
        ["discription"]="DEF:16 \"Sneak Attack\"+10 \"Triple Attack\" damage +20", 
        ["category"]="Armor", 
        ["DT"]=-5, 
        ["en"]="Toutatis's Cape", 
        ["id"]=26251, 
        ["DEX"]=30, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="Damage taken-5%"
        }, 
        ["Attack"]=20
    }, 
    [680]={
        ["Evasion"]=49, 
        ["STR"]=36, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=32, 
        ["Haste"]=4, 
        ["MND"]=12, 
        ["AGI"]=16, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["DEX"]=8, 
                    ["STR"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["DEX"]=16, 
                    ["STR"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["DEX"]=24, 
                    ["STR"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["DEX"]=32, 
                    ["STR"]=32, 
                    ["VIT"]=32
                }
            }, 
            ["set id"]=218
        }, 
        ["Store TP"]=6, 
        ["en"]="Flam. Zucchetto +2", 
        ["HP"]=80, 
        ["id"]=25569, 
        ["item_level"]=119, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=123, 
        ["MP"]=20, 
        ["Accuracy"]=44, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["discription"]="DEF:123 HP+80 MP+20 STR+36 DEX+32 VIT+24 AGI+16 INT+12 MND+12 CHR+12 Accuracy+44 Magic Accuracy+44 Evasion+49 Magic Evasion+53 \"Magic Def. Bonus\"+3 Haste+4% \"Triple Attack\"+5% \"Store TP\"+6 Set: Increases Strength, Dexterity, and Vitality", 
        ["VIT"]=24, 
        ["Magic Accuracy"]=44
    }, 
    [681]={
        ["discription"]="HP+70 Accuracy+30 Attack+30 Weapon skill DEX +10%", 
        ["category"]="Weapon", 
        ["en"]="Utu Grip", 
        ["skill"]="(N/A)", 
        ["HP"]=70, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [22]="RUN"
        }, 
        ["id"]=22212, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["Accuracy"]=30, 
        ["Attack"]=30
    }, 
    [682]={
        ["Evasion"]=55, 
        ["MND"]=21, 
        ["id"]=26962, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=42, 
        ["Haste"]=4, 
        ["AGI"]=28, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Enforcer's Harness", 
        ["HP"]=63, 
        ["discription"]="DEF:135 HP+63 STR+25 DEX+42 VIT+24 AGI+28 INT+21 MND+21 CHR+21 Evasion+55 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+4% Critical hit rate +4% Critical hit damage +5% Sphere: Critical hit rate +4%", 
        ["Critical hit damage"]=5, 
        ["STR"]=25, 
        ["DEF"]=135, 
        ["Critical hit rate"]=4, 
        ["INT"]=21, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["VIT"]=24, 
        ["item_level"]=119
    }, 
    [683]={
        ["discription"]="DEF:10 Accuracy+6 Attack+6 Damage taken -3% Set: Enhances \"Subtle Blow\" effect", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }, 
            ["set id"]=161
        }, 
        ["category"]="Armor", 
        ["en"]="Sulevia's Ring", 
        ["Attack"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEF"]=10, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=6, 
        ["id"]=26204, 
        ["DT"]=-3
    }, 
    [684]={
        ["discription"]="DMG:123 Delay:240 Accuracy+15 \"Magic Atk. Bonus\"+14 Magic Damage+130 Magic Accuracy skill +201 Sword skill +242 Parrying skill +242 \"Fast Cast\"+10% Physical damage taken -3%", 
        ["Magic Atk. Bonus"]=34, 
        ["damage"]=123, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["augments"]={
            [1]="Mag. Acc.+15", 
            [2]="\"Mag.Atk.Bns.\"+20", 
            [3]="\"Refresh\"+1"
        }, 
        ["en"]="Emissary", 
        ["skill"]="Sword", 
        ["Fast Cast"]=10, 
        ["delay"]=240, 
        ["item_level"]=119, 
        ["Accuracy"]=15, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=20702, 
        ["Sword skill"]=242, 
        ["Parrying skill"]=242, 
        ["PDT"]=-3, 
        ["Magic Accuracy"]=15
    }, 
    [685]={
        ["discription"]="DMG:71 Delay:252 HP+40 MP+40 +16 +16 Ranged Accuracy+21 Ranged Attack+21 Throwing skill +242 Unity Ranking: \"Double Attack\"+1～3%", 
        ["Ranged Accuracy"]=21, 
        ["Throwing skill"]=242, 
        ["category"]="Weapon", 
        ["slots"]={
            [2]="Range"
        }, 
        ["en"]="Antitail +1", 
        ["HP"]=40, 
        ["Ranged Attack"]=21, 
        ["skill"]="Throwing", 
        ["delay"]=252, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [11]="RNG"
        }, 
        ["MP"]=40, 
        ["item_level"]=119, 
        ["id"]=22267, 
        ["damage"]=71
    }, 
    [686]={
        ["Haste"]=8, 
        ["Ranged Accuracy"]=17, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Haste"]=8
                }, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=278
        }, 
        ["DEF"]=57, 
        ["Katana skill"]=7, 
        ["Sword skill"]=7, 
        ["en"]="Mextli Harness", 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Marksmanship skill"]=7, 
        ["discription"]="DEF:57 Accuracy+17 Ranged Accuracy+17 Sword skill +7 Katana skill +7 Marksmanship skill +7 Enhances \"Dual Wield\" effect Sphere: Critical hit rate +3% Set: Haste+8%", 
        ["slots"]={
            [5]="Body"
        }, 
        ["Critical hit rate"]=3, 
        ["id"]=11855, 
        ["Accuracy"]=17, 
        ["Dual Wield"]=3
    }, 
    [687]={
        ["discription"]="DEF:18 All Jumps: \"Double Attack\"+20% Wyvern: \"Breath\" attacks +15", 
        ["category"]="Armor", 
        ["en"]="Brigantia's Mantle", 
        ["STR"]=30, 
        ["id"]=26259, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=18, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="STR+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="STR+10", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["Attack"]=20
    }, 
    [688]={
        ["discription"]="DEF:2 Enchantment: Teleport (the place of parting)", 
        ["DEF"]=2, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Cumulus Masque +1", 
        ["id"]=10385, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [689]={
        ["discription"]="Critical hit rate +3% Magic critical hit rate +3% Increases magic critical hit damage", 
        ["en"]="Nefarious Collar", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Critical hit rate"]=3, 
        ["id"]=10958, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [690]={
        ["discription"]="Accuracy+3 \"Double Attack\"+3%", 
        ["Accuracy"]=3, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=10944, 
        ["en"]="Portus Collar", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [691]={
        ["discription"]="INT+8 MND+8 Magic Accuracy+10 \"Magic Atk. Bonus\"+8 \"Fast Cast\"+4%", 
        ["category"]="Armor", 
        ["en"]="Malignance Earring", 
        ["Magic Atk. Bonus"]=8, 
        ["Fast Cast"]=4, 
        ["MND"]=8, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [8]="DRK", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["INT"]=8, 
        ["id"]=26088, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Magic Accuracy"]=10
    }, 
    [692]={
        ["slots"]={
            [15]="Back"
        }, 
        ["STR"]=5, 
        ["MND"]=5, 
        ["INT"]=5, 
        ["category"]="Armor", 
        ["Magic Atk. Bonus"]=15, 
        ["en"]="Cornflower Cape", 
        ["Blue Magic skill"]=10, 
        ["jobs"]={
            [16]="BLU"
        }, 
        ["DEF"]=16, 
        ["discription"]="DEF:16 STR+5 INT+5 MND+5 Magic Accuracy+15 \"Magic Atk. Bonus\"+15 Blue magic skill +5", 
        ["DEX"]=5, 
        ["augments"]={
            [1]="MP+20", 
            [2]="DEX+5", 
            [3]="Blue Magic skill +10", 
            [4]="none", 
            [5]="none"
        }, 
        ["id"]=28632, 
        ["MP"]=20, 
        ["Magic Accuracy"]=15
    }, 
    [693]={
        ["MDT"]=-3, 
        ["Haste"]=7, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=26, 
        ["discription"]="DEF:116 HP+47 STR+24 DEX+20 VIT+23 AGI+17 INT+14 MND+14 CHR+14 Resist all elements +25 Accuracy+20 Magic Accuracy+20 Evasion+36 Magic Evasion+48 \"Magic Def. Bonus\"+2 Haste+7% \"Double Attack\"+2% \"Killer\" effects +2", 
        ["MND"]=14, 
        ["AGI"]=17, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=27764, 
        ["en"]="Founder's Corona", 
        ["HP"]=47, 
        ["augments"]={
            [1]="DEX+6", 
            [2]="Accuracy+10", 
            [3]="Magic dmg. taken -3%", 
            [4]="none", 
            [5]="none"
        }, 
        ["item_level"]=119, 
        ["STR"]=24, 
        ["DEF"]=116, 
        ["Evasion"]=36, 
        ["Accuracy"]=30, 
        ["INT"]=14, 
        ["category"]="Armor", 
        ["CHR"]=14, 
        ["VIT"]=23, 
        ["Magic Accuracy"]=20
    }, 
    [694]={
        ["discription"]="DEF:67 STR+14 Attack+14 Great Sword skill +7 Polearm skill +7 Shield skill +7 Haste+2% Sphere: \"Store TP\"+6 Set: \"Double Attack\"+5%", 
        ["DEF"]=67, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Double Attack"]=5
                }, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=398
        }, 
        ["category"]="Armor", 
        ["Store TP"]=6, 
        ["en"]="Fazheluo R. Mail", 
        ["slots"]={
            [5]="Body"
        }, 
        ["Shield skill"]=7, 
        ["STR"]=14, 
        ["Great Sword skill"]=7, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["Polearm skill"]=7, 
        ["Haste"]=2, 
        ["id"]=11857, 
        ["Attack"]=14
    }, 
    [695]={
        ["Evasion"]=74, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["Haste"]=2, 
        ["MND"]=6, 
        ["AGI"]=26, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["DEX"]=8, 
                    ["STR"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["DEX"]=16, 
                    ["STR"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["DEX"]=24, 
                    ["STR"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["DEX"]=32, 
                    ["STR"]=32, 
                    ["VIT"]=32
                }
            }, 
            ["set id"]=218
        }, 
        ["Store TP"]=6, 
        ["en"]="Flam. Gambieras +2", 
        ["HP"]=40, 
        ["id"]=25953, 
        ["discription"]="DEF:93 HP+40 MP+10 STR+31 DEX+34 VIT+20 AGI+26 MND+6 CHR+20 Accuracy+42 Magic Accuracy+42 Evasion+74 Magic Evasion+86 \"Magic Def. Bonus\"+5 Haste+2% \"Double Attack\"+6% \"Store TP\"+6 Set: Increases Strength, Dexterity, and Vitality", 
        ["STR"]=31, 
        ["DEF"]=93, 
        ["MP"]=10, 
        ["Accuracy"]=42, 
        ["CHR"]=20, 
        ["VIT"]=20, 
        ["category"]="Armor", 
        ["item_level"]=119, 
        ["Magic Accuracy"]=42
    }, 
    [696]={
        ["discription"]="DEF:18 All Jumps: \"Double Attack\"+20% Wyvern: \"Breath\" attacks +15", 
        ["category"]="Armor", 
        ["en"]="Brigantia's Mantle", 
        ["DEX"]=30, 
        ["id"]=26259, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=18, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="DEX+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="none"
        }, 
        ["Attack"]=20
    }, 
    [697]={
        ["INT"]=9, 
        ["en"]="Shiva Ring +1", 
        ["Magic Atk. Bonus"]=3, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="INT+9 +16 \"Magic Atk. Bonus\"+3", 
        ["id"]=27575, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [698]={
        ["discription"]="Accuracy+20 Attack+20 Critical hit rate +3% Wyvern: Lv.+1", 
        ["category"]="Armor", 
        ["en"]="Dgn. Collar +1", 
        ["id"]=25496, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["Critical hit rate"]=3, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=20, 
        ["Attack"]=20
    }, 
    [699]={
        ["discription"]="\"Double Attack\"+3%", 
        ["en"]="Duplus Grip", 
        ["skill"]="(N/A)", 
        ["id"]=18820, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [700]={
        ["Ranged Attack"]=15, 
        ["STR"]=33, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=6, 
        ["PDT"]=-2, 
        ["MND"]=15, 
        ["AGI"]=32, 
        ["augments"]={
            [1]="Accuracy+17", 
            [2]="Weapon skill damage +5%", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["Store TP"]=4, 
        ["en"]="Herculean Trousers", 
        ["HP"]=38, 
        ["id"]=25842, 
        ["item_level"]=119, 
        ["INT"]=29, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=114, 
        ["Accuracy"]=17, 
        ["CHR"]=10, 
        ["VIT"]=16, 
        ["category"]="Armor", 
        ["Evasion"]=62, 
        ["discription"]="DEF:114 HP+38 STR+33 VIT+16 AGI+32 INT+29 MND+15 CHR+10 Attack+15 Ranged Attack+15 Evasion+62 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% Enmity-4 \"Store TP\"+4 Physical damage taken -2%", 
        ["Attack"]=15
    }, 
    [701]={
        ["discription"]="DMG:130 Delay:240 Accuracy+15 Magic Accuracy+15 Magic Damage+96 Sword skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Chain Affinity\"+10 \"Skillchain Bonus\"+10", 
        ["item_level"]=119, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["Sword skill"]=242, 
        ["en"]="Acclimator", 
        ["delay"]=240, 
        ["Parrying skill"]=242, 
        ["skill"]="Sword", 
        ["Accuracy"]=15, 
        ["jobs"]={
            [5]="RDM", 
            [7]="PLD", 
            [16]="BLU"
        }, 
        ["id"]=20715, 
        ["Magic Accuracy"]=15, 
        ["damage"]=130
    }, 
    [702]={
        ["discription"]="Damage taken -5%", 
        ["id"]=11625, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Twilight Torque", 
        ["DT"]=-5, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [703]={
        ["discription"]="HP+60 MP+60 Accuracy+7 Magic Accuracy+7 ", 
        ["category"]="Armor", 
        ["en"]="Etana Ring", 
        ["MP"]=60, 
        ["HP"]=60, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26163, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=7, 
        ["Magic Accuracy"]=7
    }, 
    [704]={
        ["discription"]="DEF:8 Accuracy+6 Magic Accuracy+6 \"Store TP\"+5 Set: Increases Strength, Dexterity, and Vitality", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["DEX"]=8, 
                    ["STR"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["DEX"]=16, 
                    ["STR"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["DEX"]=24, 
                    ["STR"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["DEX"]=32, 
                    ["STR"]=32, 
                    ["VIT"]=32
                }
            }, 
            ["set id"]=218
        }, 
        ["category"]="Armor", 
        ["en"]="Flamma Ring", 
        ["Store TP"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=6, 
        ["id"]=26211, 
        ["Magic Accuracy"]=6
    }, 
    [705]={
        ["discription"]="DMG:145 Delay:240 STR+15 AGI+15 \"Magic Atk. Bonus\"+14 Magic Damage+108 Sword skill +242 Parrying skill +242 Magic Accuracy skill +201 \"Double Attack\"+2% \"Dual Wield\"+3 Critical hit rate +2%", 
        ["STR"]=15, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Magic Atk. Bonus"]=14, 
        ["Dual Wield"]=3, 
        ["id"]=20703, 
        ["en"]="Deacon Saber", 
        ["delay"]=240, 
        ["jobs"]={
            [5]="RDM", 
            [16]="BLU"
        }, 
        ["Critical hit rate"]=2, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["AGI"]=15, 
        ["Sword skill"]=242, 
        ["Parrying skill"]=242, 
        ["damage"]=145, 
        ["item_level"]=119
    }, 
    [706]={
        ["Evasion"]=47, 
        ["MND"]=30, 
        ["Haste"]=4, 
        ["jobs"]={
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=40, 
        ["Ranged Accuracy"]=45, 
        ["item_level"]=119, 
        ["STR"]=30, 
        ["en"]="Regal Gloves", 
        ["HP"]=342, 
        ["discription"]="DEF:106 HP+342 STR+30 DEX+40 VIT+30 AGI+20 INT+30 MND+30 CHR+40 Accuracy+45 Ranged Accuracy+45 Evasion+47 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+4% Converts damage taken to TP +20 Damage taken +20%", 
        ["Accuracy"]=45, 
        ["INT"]=30, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=106, 
        ["id"]=25826, 
        ["CHR"]=40, 
        ["VIT"]=30, 
        ["category"]="Armor", 
        ["AGI"]=20, 
        ["DT"]=20
    }, 
    [707]={
        ["discription"]="Critical hit rate +1% \"Triple Attack\"+2% \"Triple Attack\" damage +5", 
        ["en"]="Hetairoi Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Critical hit rate"]=1, 
        ["id"]=26175, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [708]={
        ["Magic Accuracy"]=21, 
        ["discription"]="DMG:82 Delay:142 +20 Evasion+22 Magic Accuracy+21 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 \"Triple Attack\"+3% Additional effect: Wind damage Unity Ranking: AGI+10～15", 
        ["Evasion"]=22, 
        ["skill"]="Dagger", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["en"]="Jugo Kukri +1", 
        ["delay"]=142, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["Dagger skill"]=242, 
        ["Parrying skill"]=242, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Unity Ranking Bonus Applied"]="AGI + 15", 
        ["id"]=20609, 
        ["AGI"]=15, 
        ["damage"]=82
    }, 
    [709]={
        ["Attack"]=23, 
        ["en"]="Knobkierrie", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["category"]="Weapon", 
        ["discription"]="Attack+23 Weapon skill damage +6%", 
        ["id"]=22281, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [22]="RUN"
        }
    }, 
    [710]={
        ["INT"]=9, 
        ["en"]="Shiva Ring +1", 
        ["Magic Atk. Bonus"]=3, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="INT+9 +16 \"Magic Atk. Bonus\"+3", 
        ["id"]=27575, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [711]={
        ["Evasion"]=39, 
        ["MND"]=28, 
        ["id"]=26987, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEX"]=33, 
        ["Haste"]=5, 
        ["AGI"]=3, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Plun. Armlets +1", 
        ["HP"]=25, 
        ["discription"]="DEF:90 HP+25 STR+9 DEX+33 VIT+30 AGI+3 INT+10 MND+28 CHR+24 Accuracy+15 Evasion+39 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+5% Enmity+6 \"Treasure Hunter\"+3", 
        ["Accuracy"]=15, 
        ["STR"]=9, 
        ["DEF"]=90, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Perfect Dodge\" effect", 
            [4]="none"
        }, 
        ["INT"]=10, 
        ["category"]="Armor", 
        ["CHR"]=24, 
        ["VIT"]=30, 
        ["item_level"]=119
    }, 
    [712]={
        ["discription"]="Accuracy-10 Attack+10 \"Double Attack\"+2%", 
        ["category"]="Weapon", 
        ["en"]="Focal Orb", 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=21345, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["Accuracy"]=-10, 
        ["Attack"]=10
    }, 
    [713]={
        ["Evasion"]=12, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Counter"]=4
                }, 
                [3]={
                    ["Counter"]=8
                }, 
                [4]={
                    ["Counter"]=12
                }, 
                [5]={
                    ["Counter"]=16
                }
            }, 
            ["set id"]=281
        }, 
        ["category"]="Armor", 
        ["en"]="Hizamaru Ring", 
        ["Store TP"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=6, 
        ["id"]=26206, 
        ["discription"]="DEF:8 Accuracy+6 Evasion+12 \"Store TP\"+5 Set: Enhances \"Counter\" effect"
    }, 
    [714]={
        ["discription"]="DEF:11 Divine magic skill +10 Healing magic skill +10 Magic Evasion+20 \"Magic Def. Bonus\"+3", 
        ["DEF"]=11, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["en"]="Asklepian Belt", 
        ["id"]=26327, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [14]="DRG"
        }
    }, 
    [715]={
        ["Evasion"]=22, 
        ["Critical hit rate"]=5, 
        ["skill"]="Dagger", 
        ["discription"]="DMG:102 Delay:200 AGI+10 Evasion+22 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Enmity-10 \"Treasure Hunter\"+1 Weapon skill damage +5", 
        ["en"]="Sandung", 
        ["item_level"]=119, 
        ["AGI"]=10, 
        ["delay"]=200, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["augments"]={
            [1]="Accuracy+50", 
            [2]="Crit. hit rate+5%", 
            [3]="\"Triple Atk.\"+3"
        }, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Dagger skill"]=242, 
        ["damage"]=102, 
        ["Accuracy"]=50, 
        ["Parrying skill"]=242, 
        ["id"]=20618
    }, 
    [716]={
        ["discription"]="DMG:333 Delay:480 DEX+20 INT+20 MND+20 Accuracy+40 Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+21 Magic Damage+226 Polearm skill +250 Parrying skill +250 Magic Accuracy skill +250 \"Impulse Drive\" \"Impulse Drive\" damage +40% Weapon Skill: Increases critical hit rate based on amount of TP consumed", 
        ["MND"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=20, 
        ["Attack"]=30, 
        ["en"]="Shining One", 
        ["skill"]="Polearm", 
        ["item_level"]=119, 
        ["delay"]=480, 
        ["id"]=21883, 
        ["Parrying skill"]=250, 
        ["slots"]={
            [0]="Main"
        }, 
        ["Polearm skill"]=250, 
        ["Accuracy"]=40, 
        ["INT"]=20, 
        ["Magic Atk. Bonus"]=21, 
        ["category"]="Weapon", 
        ["damage"]=333, 
        ["Magic Accuracy"]=40
    }, 
    [717]={
        ["discription"]="Latent effect: Fishing skill +1", 
        ["id"]=11499, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Trainee's Specs.", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [718]={
        ["discription"]="STR+10 DEX+10 VIT+10 \"Quad Attack\"+3% \"Subtle Blow II\"+5", 
        ["en"]="Niqmaddu Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["STR"]=10, 
        ["category"]="Armor", 
        ["DEX"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [18]="PUP", 
            [22]="RUN"
        }, 
        ["id"]=26185, 
        ["VIT"]=10
    }, 
    [719]={
        ["INT"]=10, 
        ["en"]="Freke Ring", 
        ["Magic Atk. Bonus"]=8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="INT+10 \"Magic Atk. Bonus\"+8 Spell interruption rate down 10%", 
        ["id"]=28472, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [720]={
        ["discription"]="DEF:73 HP+15 STR+12 DEX+24 VIT+12 AGI+44 MND+12 CHR+30 Evasion+107 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+4% \"Treasure Hunter\"+3 \"Despoil\" effect +6 Set: Augments \"Triple Attack\"", 
        ["MND"]=12, 
        ["en"]="Skulk. Poulaines +1", 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=73, 
        ["AGI"]=44, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["item_level"]=119, 
        ["HP"]=15, 
        ["DEX"]=24, 
        ["id"]=27422, 
        ["STR"]=12, 
        ["Haste"]=4, 
        ["Evasion"]=107, 
        ["CHR"]=30, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={}, 
                [4]={}, 
                [5]={}
            }, 
            ["set id"]=65
        }
    }, 
    [721]={
        ["Evasion"]=44, 
        ["STR"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=26, 
        ["DEF"]=146, 
        ["MND"]=21, 
        ["en"]="Found. Breastplate", 
        ["id"]=27910, 
        ["item_level"]=119, 
        ["AGI"]=21, 
        ["HP"]=70, 
        ["augments"]={
            [1]="Accuracy+14", 
            [2]="Mag. Acc.+13", 
            [3]="Attack+14", 
            [4]="\"Mag.Atk.Bns.\"+14", 
            [5]="none"
        }, 
        ["discription"]="DEF:146 HP+70 STR+30 DEX+26 VIT+30 AGI+21 INT+21 MND+21 CHR+21 Accuracy+20 Attack+20 Magic Accuracy+20 Evasion+44 Magic Evasion+59 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+4 Haste+3% \"Double Attack\"+3% Augments \"Killer\" effects Annuls damage taken +2%", 
        ["INT"]=21, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=3, 
        ["Accuracy"]=34, 
        ["CHR"]=21, 
        ["Magic Atk. Bonus"]=34, 
        ["category"]="Armor", 
        ["Attack"]=34, 
        ["VIT"]=30, 
        ["Magic Accuracy"]=33
    }, 
    [722]={
        ["discription"]="DEF:2 \"Treasure Hunter\"+1 Enchantment: Reraise", 
        ["DEF"]=2, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Wh. Rarab Cap +1", 
        ["id"]=25679, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [723]={
        ["Evasion"]=10, 
        ["category"]="Weapon", 
        ["en"]="Amar Cluster", 
        ["STR"]=2, 
        ["skill"]="(N/A)", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22262, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["Accuracy"]=10, 
        ["discription"]="STR+2 Accuracy+10 Evasion+10 \"Counter\"+2"
    }, 
    [724]={
        ["discription"]="DEF:1", 
        ["CHR"]=1, 
        ["category"]="Armor", 
        ["en"]="Mecisto. Mantle", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=6, 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="Cap. Point+50%", 
            [2]="CHR+1", 
            [3]="DEF+5", 
            [4]="none", 
            [5]="none"
        }, 
        ["id"]=27596
    }, 
    [725]={
        ["Evasion"]=44, 
        ["STR"]=38, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [14]="DRG"
        }, 
        ["DEX"]=29, 
        ["Haste"]=3, 
        ["MND"]=24, 
        ["id"]=25682, 
        ["item_level"]=119, 
        ["AGI"]=29, 
        ["en"]="Emicho Haubert", 
        ["HP"]=113, 
        ["augments"]={
            [1]="HP+50", 
            [2]="STR+10", 
            [3]="Attack+15"
        }, 
        ["discription"]="DEF:147 HP+63 MP+29 STR+28 DEX+29 VIT+24 AGI+29 INT+25 MND+24 CHR+24 Accuracy+27 Attack+27 Evasion+44 Magic Evasion+53 \"Magic Def. Bonus\"+4 Haste+3% \"Double Attack\"+4% Pet: \"Magic Atk. Bonus\"+25 Damage taken -3%", 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=147, 
        ["MP"]=29, 
        ["Accuracy"]=27, 
        ["INT"]=25, 
        ["category"]="Armor", 
        ["CHR"]=24, 
        ["VIT"]=24, 
        ["Attack"]=42
    }, 
    [726]={
        ["discription"]="DEX+8 Accuracy+10 \"Double Attack\"+2% \"Martial Arts\"+13", 
        ["category"]="Armor", 
        ["en"]="Mache Earring +1", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Martial Arts"]=13, 
        ["DEX"]=8, 
        ["Accuracy"]=10, 
        ["id"]=26081
    }, 
    [727]={
        ["Evasion"]=36, 
        ["STR"]=29, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [14]="DRG"
        }, 
        ["DEX"]=17, 
        ["Haste"]=3, 
        ["MND"]=16, 
        ["id"]=26972, 
        ["discription"]="DEF:153 HP+66 MP+59 STR+29 DEX+17 VIT+32 AGI+17 INT+16 MND+16 CHR+16 Attack+20 Evasion+36 Magic Evasion+69 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+4 Haste+3% \"Cure\" potency +15% \"Cure\" spellcasting time -10% Damage taken -8%", 
        ["en"]="Jumalik Mail", 
        ["item_level"]=119, 
        ["HP"]=116, 
        ["augments"]={
            [1]="HP+50", 
            [2]="Attack+15", 
            [3]="Enmity+9", 
            [4]="\"Refresh\"+2", 
            [5]="none"
        }, 
        ["Attack"]=35, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=153, 
        ["MP"]=59, 
        ["AGI"]=17, 
        ["INT"]=16, 
        ["category"]="Armor", 
        ["CHR"]=16, 
        ["VIT"]=32, 
        ["Magic Atk. Bonus"]=20, 
        ["DT"]=-8
    }, 
    [728]={
        ["discription"]="DEX+8 Accuracy+10 \"Double Attack\"+2% \"Martial Arts\"+13", 
        ["category"]="Armor", 
        ["en"]="Mache Earring +1", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Martial Arts"]=13, 
        ["DEX"]=8, 
        ["Accuracy"]=10, 
        ["id"]=26081
    }, 
    [729]={
        ["Accuracy"]=10, 
        ["en"]="Chirich Ring +1", 
        ["Store TP"]=6, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Accuracy+10 \"Store TP\"+6 \"Subtle Blow\"+10 \"Regen\"+2", 
        ["id"]=26182, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [730]={
        ["Evasion"]=24, 
        ["STR"]=17, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["DEF"]=102, 
        ["MND"]=25, 
        ["id"]=28049, 
        ["AGI"]=10, 
        ["item_level"]=119, 
        ["en"]="Founder's Gauntlets", 
        ["HP"]=31, 
        ["augments"]={
            [1]="STR+6", 
            [2]="Attack+10", 
            [3]="Phys. dmg. taken -3%", 
            [4]="none", 
            [5]="none"
        }, 
        ["discription"]="DEF:102 HP+31 STR+11 DEX+34 VIT+34 AGI+10 INT+8 MND+25 CHR+19 Attack+20 Evasion+24 Magic Evasion+32 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+1 Haste+4% \"Double Attack\"+2% \"Counter\"+3 \"Killer\" effects +2", 
        ["INT"]=8, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=4, 
        ["PDT"]=-3, 
        ["CHR"]=19, 
        ["Magic Atk. Bonus"]=20, 
        ["category"]="Armor", 
        ["VIT"]=34, 
        ["Attack"]=30
    }, 
    [731]={
        ["Evasion"]=24, 
        ["MND"]=17, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["Haste"]=5, 
        ["AGI"]=17, 
        ["item_level"]=119, 
        ["en"]="Founder's Hose", 
        ["BDT"]=-1, 
        ["HP"]=54, 
        ["augments"]={
            [1]="MND+2", 
            [2]="Mag. Acc.+4", 
            [3]="Breath dmg. taken -1%", 
            [4]="none", 
            [5]="none"
        }, 
        ["discription"]="DEF:127 HP+54 STR+40 VIT+28 AGI+17 INT+25 MND+15 CHR+12 Attack+20 Magic Accuracy+20 Evasion+24 Magic Evasion+80 \"Magic Def. Bonus\"+3 Haste+5% \"Double Attack\"+2% Spell interruption rate down 30% \"Killer\" effects +2", 
        ["INT"]=25, 
        ["STR"]=40, 
        ["DEF"]=127, 
        ["id"]=28191, 
        ["CHR"]=12, 
        ["VIT"]=28, 
        ["category"]="Armor", 
        ["Attack"]=20, 
        ["Magic Accuracy"]=24
    }, 
    [732]={
        ["Evasion"]=65, 
        ["MND"]=7, 
        ["id"]=28330, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=21, 
        ["DEF"]=84, 
        ["AGI"]=28, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Founder's Greaves", 
        ["HP"]=20, 
        ["discription"]="DEF:84 HP+20 STR+19 DEX+21 VIT+19 AGI+28 MND+7 CHR+21 Accuracy+20 Evasion+55 Magic Evasion+80 \"Magic Atk. Bonus\"+20 \"Magic Def. Bonus\"+2 Haste+3% \"Double Attack\"+2% Terror resistance +50 \"Killer\" effects +2", 
        ["Accuracy"]=30, 
        ["STR"]=19, 
        ["Haste"]=3, 
        ["augments"]={
            [1]="VIT+7", 
            [2]="Accuracy+10", 
            [3]="\"Mag.Atk.Bns.\"+9", 
            [4]="Mag. Evasion+10", 
            [5]="none"
        }, 
        ["CHR"]=21, 
        ["Magic Atk. Bonus"]=29, 
        ["category"]="Armor", 
        ["VIT"]=26, 
        ["item_level"]=119
    }, 
    [733]={
        ["Evasion"]=85, 
        ["STR"]=23, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEX"]=23, 
        ["Haste"]=5, 
        ["MND"]=23, 
        ["discription"]="DEF:85 HP+57 MP+59 STR+23 DEX+23 VIT+23 AGI+23 INT+23 MND+23 CHR+23 Accuracy+37 Ranged Accuracy+37 Magic Accuracy+37 Evasion+85 Magic Evasion+102 \"Magic Def. Bonus\"+7 Haste+5% \"Treasure Hunter\"+1 Resistance to all status ailments +10", 
        ["Ranged Accuracy"]=37, 
        ["AGI"]=23, 
        ["en"]="Volte Boots", 
        ["HP"]=57, 
        ["id"]=23729, 
        ["item_level"]=119, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=85, 
        ["MP"]=59, 
        ["Accuracy"]=37, 
        ["INT"]=23, 
        ["category"]="Armor", 
        ["CHR"]=23, 
        ["VIT"]=23, 
        ["Magic Accuracy"]=37
    }, 
    [734]={
        ["Accuracy"]=10, 
        ["en"]="Chirich Ring +1", 
        ["Store TP"]=6, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Accuracy+10 \"Store TP\"+6 \"Subtle Blow\"+10 \"Regen\"+2", 
        ["id"]=26182, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [735]={
        ["Evasion"]=27, 
        ["id"]=27207, 
        ["jobs"]={
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [11]="RNG", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=122, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=20
                }, 
                [3]={
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=40
                }, 
                [5]={
                    ["Accuracy"]=50
                }
            }, 
            ["set id"]=51
        }, 
        ["Dual Wield"]=6, 
        ["discription"]="DEF:122 HP+50 STR+30 VIT+17 AGI+17 INT+29 MND+16 CHR+16 Accuracy+35 Attack+35 Evasion+27 Magic Evasion+80 \"Magic Def. Bonus\"+4 Healing magic skill +18 Enhancing magic skill +18 Spell interruption rate down 20% Movement speed +18% Haste+6% Set: Increases Accuracy", 
        ["AGI"]=17, 
        ["en"]="Carmine Cuisses +1", 
        ["HP"]=50, 
        ["augments"]={
            [1]="Accuracy+20", 
            [2]="Attack+12", 
            [3]="\"Dual Wield\"+6"
        }, 
        ["item_level"]=119, 
        ["INT"]=29, 
        ["STR"]=30, 
        ["Haste"]=6, 
        ["Accuracy"]=55, 
        ["CHR"]=16, 
        ["VIT"]=17, 
        ["category"]="Armor", 
        ["MND"]=16, 
        ["Attack"]=47
    }, 
    [736]={
        ["discription"]="DEF:30 AGI+10 Evasion+5 Enhances \"Zanshin\" effect Set: Enhances \"Store TP\" effect", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Store TP"]=5
                }, 
                [3]={
                    ["Store TP"]=10
                }, 
                [4]={
                    ["Store TP"]=15
                }, 
                [5]={}
            }, 
            ["set id"]=86
        }, 
        ["category"]="Armor", 
        ["en"]="Hachiryu Sune-Ate", 
        ["Evasion"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=30, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=11364, 
        ["AGI"]=10
    }, 
    [737]={
        ["discription"]="DEF:26 DEX+10 Accuracy+5 Enhances \"Zanshin\" effect Set: Enhances \"Store TP\" effect", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Store TP"]=5
                }, 
                [3]={
                    ["Store TP"]=10
                }, 
                [4]={
                    ["Store TP"]=15
                }, 
                [5]={}
            }, 
            ["set id"]=86
        }, 
        ["category"]="Armor", 
        ["en"]="Hachiryu Kote", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=15015, 
        ["DEF"]=26, 
        ["Accuracy"]=5, 
        ["DEX"]=10
    }, 
    [738]={
        ["discription"]="STR+5 DEX+5 \"Double Attack\"+5% \"Store TP\"+5 \"Subtle Blow II\"+5", 
        ["en"]="Sherida Earring", 
        ["Store TP"]=5, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["DEX"]=5, 
        ["jobs"]={
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [11]="RNG", 
            [14]="DRG", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26084, 
        ["STR"]=5
    }, 
    [739]={
        ["discription"]="DEF:13 DEX+5 AGI+5 CHR+5 \"Treasure Hunter\"+1", 
        ["CHR"]=5, 
        ["category"]="Armor", 
        ["en"]="Chaac Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=13, 
        ["DEX"]=5, 
        ["id"]=28450, 
        ["AGI"]=5
    }, 
    [740]={
        ["discription"]="DMG:125 Delay:180 DEX+15 INT+15 MND+15 Accuracy+40 Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+16 Magic Damage+217 Dagger skill +250 Parrying skill +250 Magic Accuracy skill +250 Main hand: \"Evisceration\" \"Evisceration\" damage +50% Increases critical hit rate based with lower TP.", 
        ["MND"]=15, 
        ["jobs"]={
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["DEX"]=15, 
        ["Attack"]=30, 
        ["en"]="Tauret", 
        ["skill"]="Dagger", 
        ["item_level"]=119, 
        ["delay"]=180, 
        ["Dagger skill"]=250, 
        ["Accuracy"]=40, 
        ["INT"]=15, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=21565, 
        ["category"]="Weapon", 
        ["damage"]=125, 
        ["Magic Atk. Bonus"]=16, 
        ["Parrying skill"]=250, 
        ["Magic Accuracy"]=40
    }, 
    [741]={
        ["discription"]="DEF:25 HP+16 STR+4 +10 Enhances effect of wyvern's breath", 
        ["category"]="Armor", 
        ["en"]="Wyrm Armet", 
        ["HP"]=16, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=25, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15085, 
        ["STR"]=4
    }, 
    [742]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["augments"]={
            [1]="AGI+20", 
            [2]="Eva.+20 /Mag. Eva.+20", 
            [3]="none", 
            [4]="\"Dual Wield\"+10", 
            [5]="Evasion+15"
        }, 
        ["AGI"]=20, 
        ["Evasion"]=15, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=26258, 
        ["DEF"]=16, 
        ["Dual Wield"]=10
    }, 
    [743]={
        ["discription"]="DEF:49 HP+24 Parrying skill +15 Enhances \"Resist Blind\" effect  Adds support job abilities to wyvern", 
        ["category"]="Armor", 
        ["en"]="Wyrm Mail", 
        ["HP"]=24, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=49, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=15100, 
        ["Parrying skill"]=15
    }, 
    [744]={
        ["discription"]="DEF:19 HP+16 AGI+3 Accuracy+5 Wyvern: Magic damage taken -5%", 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["category"]="Armor", 
        ["en"]="Wyrm Fng.Gnt.", 
        ["HP"]=16, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=15115, 
        ["DEF"]=19, 
        ["Accuracy"]=5, 
        ["AGI"]=3
    }, 
    [745]={
        ["discription"]="DEF:32 HP+13 DEX+5  Enhances \"High Jump\" effect Wyvern: Physical damage taken -5%", 
        ["category"]="Armor", 
        ["en"]="Wyrm Brais", 
        ["HP"]=13, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=32, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15130, 
        ["DEX"]=5
    }, 
    [746]={
        ["discription"]="Chocobo riding time +4", 
        ["id"]=10924, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["en"]="Chocobo Torque", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [747]={
        ["Evasion"]=4, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Furia Harness", 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEX"]=2, 
        ["id"]=12157, 
        ["DEF"]=45, 
        ["Accuracy"]=4, 
        ["discription"]="DEF:45 DEX+2 Accuracy+4 Evasion+4"
    }, 
    [748]={
        ["discription"]="Enchantment: Warp", 
        ["id"]=28540, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Warp Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [749]={
        ["discription"]="DEF:16 HP+10 VIT+4 +10 Wyvern: HP recovered while healing +6", 
        ["category"]="Armor", 
        ["en"]="Wyrm Greaves", 
        ["HP"]=10, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15145, 
        ["VIT"]=4
    }, 
    [750]={
        ["discription"]="Enchantment: Teleport (Crag of Holla) Destination is close to the dimensional portal in La Theine Plateau.", 
        ["id"]=26176, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Dim. Ring (Holla)", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [751]={
        ["Evasion"]=44, 
        ["Haste"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=35, 
        ["PDT"]=-2, 
        ["MND"]=20, 
        ["augments"]={
            [1]="Weapon skill damage +5%", 
            [2]="DEX+10", 
            [3]="Accuracy+15", 
            [4]="Attack+10", 
            [5]="none"
        }, 
        ["STR"]=29, 
        ["Store TP"]=3, 
        ["en"]="Valorous Mail", 
        ["HP"]=61, 
        ["id"]=25717, 
        ["item_level"]=119, 
        ["INT"]=20, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=146, 
        ["Accuracy"]=35, 
        ["CHR"]=20, 
        ["VIT"]=29, 
        ["category"]="Armor", 
        ["discription"]="DEF:146 HP+61 STR+29 DEX+25 VIT+29 AGI+20 INT+20 MND+20 CHR+20 Accuracy+20 Evasion+44 Magic Evasion+59 \"Magic Def. Bonus\"+4 Haste+3% \"Store TP\"+3 \"Double Attack\"+2% Physical damage taken -2%", 
        ["AGI"]=20, 
        ["Attack"]=10
    }, 
    [752]={
        ["discription"]="DMG:134 Delay:231 STR+12 MND+12 Accuracy+27 Ranged Accuracy+27 Magic Accuracy+15 \"Magic Atk. Bonus\"+14 Magic Damage+108 Sword skill +242 Parrying skill +242 Magic Accuracy skill +201 Critical hit rate +4%", 
        ["MND"]=12, 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["Ranged Accuracy"]=27, 
        ["en"]="Fettering Blade", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["id"]=20698, 
        ["delay"]=231, 
        ["Magic Atk. Bonus"]=14, 
        ["Critical hit rate"]=4, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["STR"]=12, 
        ["Sword skill"]=242, 
        ["Parrying skill"]=242, 
        ["damage"]=134, 
        ["Accuracy"]=27, 
        ["Magic Accuracy"]=15
    }, 
    [753]={
        ["Evasion"]=36, 
        ["STR"]=28, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["Haste"]=7, 
        ["MND"]=14, 
        ["id"]=25641, 
        ["en"]="Valorous Mask", 
        ["AGI"]=18, 
        ["item_level"]=119, 
        ["HP"]=38, 
        ["augments"]={
            [1]="Weapon skill damage +4%", 
            [2]="DEX+10", 
            [3]="Accuracy+15", 
            [4]="Attack+12", 
            [5]="none"
        }, 
        ["discription"]="DEF:116 HP+38 STR+28 DEX+24 VIT+23 AGI+18 INT+14 MND+14 CHR+14 Accuracy+13 Evasion+36 Magic Evasion+48 \"Magic Def. Bonus\"+2 Haste+7% \"Regain\"+3 Critical hit rate +2%", 
        ["INT"]=14, 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEF"]=116, 
        ["Accuracy"]=28, 
        ["CHR"]=14, 
        ["VIT"]=23, 
        ["category"]="Armor", 
        ["Critical hit rate"]=2, 
        ["Attack"]=12
    }, 
    [754]={
        ["discription"]="DMG:243 Delay:600 Archery skill +242 Minuet: Ranged Attack+35 \"Conserve TP\"+5 \"Skillchain Bonus\"+5", 
        ["category"]="Weapon", 
        ["Archery skill"]=242, 
        ["en"]="Venery Bow", 
        ["Ranged Attack"]=35, 
        ["delay"]=600, 
        ["skill"]="Archery", 
        ["jobs"]={
            [11]="RNG"
        }, 
        ["item_level"]=119, 
        ["id"]=22118, 
        ["slots"]={
            [2]="Range"
        }, 
        ["damage"]=243
    }, 
    [755]={
        ["Evasion"]=24, 
        ["MND"]=24, 
        ["id"]=27139, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=33, 
        ["Haste"]=4, 
        ["item_level"]=119, 
        ["STR"]=13, 
        ["en"]="Valorous Mitts", 
        ["HP"]=22, 
        ["discription"]="DEF:102 HP+22 STR+13 DEX+33 VIT+33 AGI+8 INT+7 MND+24 CHR+17 Accuracy+10 Attack+10 Evasion+24 Magic Evasion+32 \"Magic Def. Bonus\"+1 Haste+4% \"Zanshin\"+10 \"Skillchain Bonus\"+5", 
        ["Accuracy"]=12, 
        ["INT"]=7, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=102, 
        ["augments"]={
            [1]="Weapon skill damage +5%", 
            [2]="VIT+3", 
            [3]="Accuracy+2", 
            [4]="none", 
            [5]="none"
        }, 
        ["CHR"]=17, 
        ["VIT"]=36, 
        ["category"]="Armor", 
        ["AGI"]=8, 
        ["Attack"]=10
    }, 
    [756]={
        ["Evasion"]=24, 
        ["MND"]=14, 
        ["id"]=25841, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["PDT"]=-2, 
        ["Haste"]=5, 
        ["AGI"]=16, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["item_level"]=119, 
        ["HP"]=95, 
        ["discription"]="DEF:127 HP+95 STR+39 VIT+26 AGI+16 INT+24 MND+14 CHR+11 Attack+15 Evasion+24 Magic Evasion+80 \"Magic Def. Bonus\"+3 Haste+5% \"Double Attack\"+3% Physical damage taken -2%", 
        ["Accuracy"]=21, 
        ["INT"]=24, 
        ["STR"]=39, 
        ["DEF"]=127, 
        ["augments"]={
            [1]="Accuracy+21", 
            [2]="Weapon skill damage +4%", 
            [3]="VIT+2", 
            [4]="none", 
            [5]="none"
        }, 
        ["CHR"]=11, 
        ["VIT"]=28, 
        ["category"]="Armor", 
        ["en"]="Valor. Hose", 
        ["Attack"]=15
    }, 
    [757]={
        ["discription"]="MP+20 INT+10 MND+10 CHR+10 \"Magic Atk. Bonus\"+7 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["category"]="Armor", 
        ["CHR"]=10, 
        ["en"]="Regal Earring", 
        ["Magic Atk. Bonus"]=7, 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Magic Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Accuracy"]=15
                }, 
                [3]={
                    ["Magic Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Accuracy"]=30
                }, 
                [4]={
                    ["Magic Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Accuracy"]=45
                }, 
                [5]={
                    ["Magic Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Accuracy"]=60
                }
            }, 
            ["set id"]={
                [1]=7, 
                [2]=8, 
                [3]=48, 
                [4]=49, 
                [5]=53, 
                [6]=89, 
                [7]=112
            }
        }, 
        ["INT"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["MP"]=20, 
        ["id"]=26085, 
        ["MND"]=10
    }, 
    [758]={
        ["Evasion"]=49, 
        ["STR"]=24, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=33, 
        ["Haste"]=4, 
        ["MND"]=27, 
        ["discription"]="DEF:133 HP+59 MP+44 STR+24 DEX+33 VIT+24 AGI+32 INT+27 MND+27 CHR+23 Accuracy+20 Rng. Acc.+20 Magic Accuracy+20 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+4% \"Refresh\"+2 Sphere: \"Refresh\"+1", 
        ["Ranged Accuracy"]=20, 
        ["AGI"]=32, 
        ["en"]="Mekosu. Harness", 
        ["HP"]=59, 
        ["id"]=27856, 
        ["item_level"]=119, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=133, 
        ["MP"]=44, 
        ["Accuracy"]=20, 
        ["INT"]=27, 
        ["category"]="Armor", 
        ["CHR"]=23, 
        ["VIT"]=24, 
        ["Magic Accuracy"]=20
    }, 
    [759]={
        ["PDT"]=-5, 
        ["en"]="Patricius Ring", 
        ["Accuracy"]=7, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["category"]="Armor", 
        ["discription"]="Accuracy+7 Physical damage taken -5%", 
        ["id"]=28578, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [760]={
        ["discription"]="DEF:16 \"Utsusemi\"+1 \"Mikage\"+5", 
        ["category"]="Armor", 
        ["en"]="Andartia's Mantle", 
        ["Fast Cast"]=10, 
        ["id"]=26258, 
        ["INT"]=20, 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["augments"]={
            [1]="INT+20", 
            [2]="Mag. Acc+20 /Mag. Dmg.+20", 
            [3]="Mag. Acc.+10", 
            [4]="\"Fast Cast\"+10", 
            [5]="none"
        }, 
        ["DEF"]=16, 
        ["Magic Accuracy"]=30
    }, 
    [761]={
        ["discription"]="DEF:16 \"Sneak Attack\"+10 \"Triple Attack\" damage +20", 
        ["category"]="Armor", 
        ["en"]="Toutatis's Cape", 
        ["DEX"]=20, 
        ["id"]=26251, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [15]="Back"
        }, 
        ["Accuracy"]=20, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="none", 
            [4]="Weapon skill damage +10%", 
            [5]="none"
        }, 
        ["Attack"]=20
    }, 
    [762]={
        ["discription"]="DEF:30 STR+7 DEX+7 VIT+7  AGI+7 INT+7 MND+7 CHR+7 Elemental weapon skill damage increases depending on day Set: Increases rate of critical hits", 
        ["en"]="Athos's Gloves", 
        ["Set Bonus"]={
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Critical Hit Rate"]=3
                }, 
                [3]={
                    ["Critical Hit Rate"]=4
                }, 
                [4]={
                    ["Critical Hit Rate"]=5
                }, 
                [5]={
                    ["Critical Hit Rate"]=6
                }
            }, 
            ["set id"]=375
        }, 
        ["category"]="Armor", 
        ["STR"]=7, 
        ["AGI"]=7, 
        ["DEX"]=7, 
        ["INT"]=7, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["MND"]=7, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["CHR"]=7, 
        ["DEF"]=30, 
        ["id"]=10501, 
        ["VIT"]=7
    }, 
    [763]={
        ["discription"]="DEF:13 MP+100 Summoning magic skill +8 Enhances \"Elemental Siphon\" effect", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["category"]="Armor", 
        ["en"]="Conveyance Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=28631, 
        ["DEF"]=13, 
        ["MP"]=100, 
        ["augments"]={
            [1]="Summoning magic skill +3", 
            [2]="Pet: Enmity+5", 
            [3]="Blood Pact Dmg.+2", 
            [4]="none", 
            [5]="none"
        }
    }, 
    [764]={
        ["Ranged Attack"]=20, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Set Bonus"]={
            ["set id"]={
                [1]=91, 
                [2]=9, 
                [3]=47, 
                [4]=87, 
                [5]=6, 
                [6]=46, 
                [7]=133, 
                [8]=45, 
                [9]=84, 
                [10]=129, 
                [11]=92, 
                [12]=10, 
                [13]=50, 
                [14]=88
            }, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Magic Accuracy"]=15
                }, 
                [3]={
                    ["Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Magic Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Magic Accuracy"]=45
                }, 
                [5]={
                    ["Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Magic Accuracy"]=60
                }
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Regal Ring", 
        ["AGI"]=10, 
        ["HP"]=50, 
        ["DEX"]=10, 
        ["STR"]=10, 
        ["Attack"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=26191, 
        ["discription"]="HP+50 STR+10 DEX+10 VIT+10 AGI+10 Attack+20 Ranged Attack+20 Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["VIT"]=10
    }, 
    [765]={
        ["en"]="Hnoss Earring", 
        ["id"]=26100, 
        ["DEF"]=20, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:20 Ninjutsu skill +10", 
        ["Ninjutsu skill"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [766]={
        ["Evasion"]=55, 
        ["MND"]=19, 
        ["AGI"]=33, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=11, 
        ["discription"]="DEF:66 HP+13 MP+39 STR+10 DEX+11 VIT+10 AGI+33 INT+17 MND+19 CHR+34 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Healing magic skill +11 Enhancing magic skill +11 Haste+3% \"Fast Cast\"+4% Unity Ranking: \"Fast Cast\"+1～3%", 
        ["item_level"]=119, 
        ["Haste"]=3, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["HP"]=13, 
        ["Fast Cast"]=7, 
        ["VIT"]=10, 
        ["STR"]=10, 
        ["DEF"]=66, 
        ["MP"]=39, 
        ["id"]=28274, 
        ["Unity Ranking Bonus Applied"]="Fast Cast + 3", 
        ["CHR"]=34, 
        ["INT"]=17, 
        ["category"]="Armor", 
        ["en"]="Regal Pumps +1"
    }
}